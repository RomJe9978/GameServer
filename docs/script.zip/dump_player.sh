#/bin/bash

set -e

# HOST=localhost
# DB_USER=root
# DB_PASSWORD=password
HOST=$1
PORT=$2
DB_USER=$3
DB_PASSWORD=$4
OUTPUT=user_dump$(date +%Y%m%dT%H%M%S).sql
DB_NAME=projectx

PLAYER_IDS="107002212"
TABLES=(battle_pet_list equip fetter formation hero hero_journal hero_shard house item kizuna master misc mission privilege_card snapshot soul special_treasure spring system_buff treasure treasure_kizuna wish worker weapon weapon_journal marry marry_equip marry_house marry_idle marry_task)

if [ ! $HOST ]; then
    HOST=localhost
fi

if [ ! $PORT ]; then
    PORT=3306
fi

dump_table() {
    table_name=$1
    filter_field=$2
    echo "begin dump table: $table_name"
    mysqldump -h$HOST -P$PORT -u$DB_USER -p$DB_PASSWORD --single-transaction --hex-blob --no-create-info --set-gtid-purged=OFF  $DB_NAME $table_name --where="$filter_field in ($PLAYER_IDS)" >> $OUTPUT
    echo "finish dump table: $table_name"
}

dump() {
    # dump player
    dump_table "player" "id"
    for table in ${TABLES[@]};
    do
        dump_table $table "player_id"
    done
}

echo start dump
echo ouput file is $OUTPUT
dump
echo "Over"