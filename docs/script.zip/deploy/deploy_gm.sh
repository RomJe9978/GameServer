#!/usr/bin/env bash

HOST=$1
ENV=$2
LOG=$3
START=$4

DEPLOY_PATH=/home/data/project

if [[ "$5" != "" ]]; then
  DEPLOY_PATH=$5
  echo $DEPLOY_PATH
fi

if [ -z "${HOST}" ]; then
  echo 'usage: deploy_gm.sh [host] [env] [log]'
  exit 1
fi

if [ -z "${ENV}" ]; then
  echo 'usage: deploy_gm.sh [host] [env] [log]'
  echo "env is not set, will use default env(local) to build"
fi

SERVER_NAME=gm

build_path='../..'
build_output_path='gm/gmserver/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true
if [[ "$?" -ne 0 ]] ; then
  echo 'maven build failed'; exit $rc
fi

cd ${build_output_path}
rsync -zav -R lib gmserver.jar *.properties *.xml ${HOST}:${DEPLOY_PATH}/${ENV}/${SERVER_NAME}/
rsync -zav -R classes ${HOST}:${DEPLOY_PATH}/${ENV}/${SERVER_NAME}/target

cd ../../../tools/deploy
rsync -zav -R server.sh ${HOST}:${DEPLOY_PATH}/${ENV}/${SERVER_NAME}/

if [[ "$START" != "no" ]]; then
  ssh ${HOST} "pushd ${DEPLOY_PATH}/${ENV}/${SERVER_NAME}; ./server.sh start_${SERVER_NAME} ${LOG}"
fi
