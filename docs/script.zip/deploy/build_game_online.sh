#!/usr/bin/env bash

ENV=$1
NAME=$2
VERSION=$3

build_path='../..'
gameserver_build_output_path='gameserver/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true
if [[ "$?" -ne 0 ]] ; then
  echo 'maven build failed'; exit $rc
fi

cd ${gameserver_build_output_path}
mv gameserver-1.0-SNAPSHOT.jar gameserver.jar

cp ../../ops/sql/jp/projectx.sql .

mkdir -p game
echo $VERSION > game/version.txt
cp -rf lib table scripts scripts-output gameserver.jar logback.xml hibernate.cfg.xml hibernate-global.cfg.xml hibernate-world.cfg.xml config-base.yaml redis-base.yaml redis.yaml msgid.json internal_msgid.json projectx.sql ./game
tar -zcvf game.${NAME}.tar.gz ./game

