#!/usr/bin/env bash

HOST=$1
ENV=$2
START=$3
LOG=$4
DEPLOY_PATH=/home/data/project

if [[ "$5" != "" ]]; then
  DEPLOY_PATH=$5
  echo $DEPLOY_PATH
fi

if [ -z "${HOST}" ]; then
  echo 'usage: deploy_game.sh [host] [env] [start] [log]'
  exit 1
fi

if [ -z "${ENV}" ]; then
  echo 'usage: deploy_game.sh [host] [env] [log]'
  echo "env is not set, will use default env(local) to build"
fi

build_path='../..'
gameserver_build_output_path='gameserver/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true
if [[ "$?" -ne 0 ]] ; then
  echo 'maven build failed'; exit 1
fi

cd ${gameserver_build_output_path}
mv gameserver-1.0-SNAPSHOT.jar gameserver.jar
rsync -zav -R lib table scripts scripts-output gameserver.jar *.xml *.yaml *.json ${HOST}:${DEPLOY_PATH}/${ENV}/game/

cd ../../tools/deploy
#rsync -zav -R server.sh ${HOST}:${DEPLOY_PATH}/${ENV}/game/

cd ../../ops/sql/jp
rsync -zav -R projectx.sql ${HOST}:${DEPLOY_PATH}/${ENV}/game/

if [[ "$START" != "no" ]]; then
  ssh ${HOST} "pushd ${DEPLOY_PATH}/${ENV}/game; ./server.sh start  ${LOG}"
fi
