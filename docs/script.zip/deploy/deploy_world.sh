#!/usr/bin/env bash

HOST=$1
ENV=$2
START=$3
LOG=$4
DEPLOY_PATH=/home/data/project

if [[ "$5" != "" ]]; then
  DEPLOY_PATH=$5
  echo $DEPLOY_PATH
fi

if [ -z "${HOST}" ]; then
  echo 'usage: deploy_world.sh [host] [env] [start] [log]'
  exit 1
fi

if [ -z "${ENV}" ]; then
  echo 'usage: deploy_world.sh [host] [env] [log]'
  echo "env is not set, will use default env(local) to build"
fi

build_path='../..'
worldserver_build_output_path='worldserver/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true
if [[ "$?" -ne 0 ]] ; then
  echo 'maven build failed'; exit $rc
fi

cd ${worldserver_build_output_path}
mv worldserver-1.0-SNAPSHOT.jar worldserver.jar
rsync -zav -R lib table scripts scripts-output worldserver.jar *.xml *.yaml *.json ${HOST}:${DEPLOY_PATH}/${ENV}/world/

cd ../../tools/deploy
rsync -zav -R server.sh ${HOST}:${DEPLOY_PATH}/${ENV}/world/

if [[ "$START" != "" ]]; then
  ssh ${HOST} "pushd ${DEPLOY_PATH}/${ENV}/world; ./server.sh start_world  ${LOG}"
fi
