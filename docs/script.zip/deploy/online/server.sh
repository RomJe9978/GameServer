#!/usr/bin/env bash

CMD=$1
LOG=$2

function startGameServer() {
  stopServer
  sleep 10
  startAndRecordGamePid
  showLog
}

function startAndRecordGamePid() {
  echo "starting gameserver..."
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar gameserver.jar >/data/sh_log/console.log 2>&1 &
  echo $! >pid
}

function startWorldServer() {
  stopServer
  sleep 10
  startAndRecordWorldPid
  showLog
}

function startAndRecordWorldPid() {
  echo "starting worldserver..."
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar worldserver.jar >/data/sh_log/console.log 2>&1 &
  echo $! >pid
}

function startAccountServer() {
  stopServer
  startAndRecordAccountPid
  showLog
}

function startCommentServer() {
  stopServer
  startAndRecordCommentPid
  showLog
}

function startGmServer() {
  stopServer
  startAndRecordGmPid
  showLog
}

function startProxy() {
  stopServer
  startAndRecordProxyPid
  showLog
}

function startPlatform() {
  stopServer
  startAndRecordPlatformPid
  showLog
}

function startRobot() {
  stopServer
  startAndRecordRobotPid
  showLog
}

function startAndRecordAccountPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar accountserver.jar >/data/sh_log/account_console.log 2>&1 &
  echo $! >pid
}

function startAndRecordCommentPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar commentserver.jar >./console.log 2>&1 &
  echo $! >pid
}

function startAndRecordGmPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar gmserver.jar >./console.log 2>&1 &
  echo $! >pid
}

function startAndRecordProxyPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar proxy.jar >/data/sh_log/proxy_console.log 2>&1 &
  echo $! >pid
}

function startAndRecordPlatformPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar platform.jar >./console.log 2>&1 &
  echo $! >pid
}

function showLog() {
  if [[ "$LOG" != "no" ]]; then
    tail -fn 100 console.log
  fi
}


function stopServer() {
  kill $(cat pid) >/dev/null 2>/dev/null
  echo "waiting old server shutdown..."

  sleep 5
}

function startAndRecordRobotPid() {
  nohup java -XX:+HeapDumpOnOutOfMemoryError -jar smartrobot.jar >./console.log 2>&1 &
  echo $! >pid
}

if [ $CMD == "start" ]; then
  startGameServer
elif [ $CMD == "start_world" ]; then
  startWorldServer
elif [ $CMD == "start_account" ]; then
  startAccountServer
elif [ $CMD == "start_comment" ]; then
  startCommentServer
elif [ $CMD == "start_gm" ]; then
  startGmServer
elif [ $CMD == "start_proxy" ]; then
  startProxy
elif [ $CMD == "start_robot" ]; then
  startRobot
elif [ $CMD == "start_platform" ]; then
  startPlatform
elif [ $CMD == "stop" ]; then
  stopServer
  echo "stop server success."
else
  echo "server.sh [CMD]"
fi
