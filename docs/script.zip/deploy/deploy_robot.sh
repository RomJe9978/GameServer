#!/usr/bin/env bash

HOST=$1
ENV=$2
LOG=$3

if [ -z "${HOST}" ]; then
  echo 'usage: deploy_robot.sh [host] [env] [log]'
  exit 1
fi

if [ -z "${ENV}" ]; then
  echo 'usage: deploy_robot.sh [host] [env] [log]'
  echo "env is not set, will use default env(local) to build"
fi

build_path='../..'
build_output_path='smartrobot/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true

cd ${build_output_path}
rsync -zav -R lib smartrobot.jar *.txt *.yaml ${HOST}:/home/data/project/robot/

cd ../../tools/deploy
rsync -zav -R server.sh ${HOST}:/home/data/project/robot/

ssh ${HOST} "pushd /home/data/project/robot; ./server.sh start_robot ${LOG}"
