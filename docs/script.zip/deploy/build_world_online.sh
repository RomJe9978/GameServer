#!/usr/bin/env bash

ENV=$1
NAME=$2
VERSION=$3

build_path='../..'
worldserver_build_output_path='worldserver/target'

pushd ${build_path}

mvn package -P${ENV} -Dmaven.test.skip=true
if [[ "$?" -ne 0 ]] ; then
  echo 'maven build failed'; exit $rc
fi

cd ${worldserver_build_output_path}
mv worldserver-1.0-SNAPSHOT.jar worldserver.jar
cp ../../tools/deploy/server_online.sh ./server.sh

rm -rf world
mkdir -p world
echo $VERSION > world/version.txt
cp -rf lib table scripts scripts-output worldserver.jar logback.xml hibernate.cfg.xml hibernate-global.cfg.xml config-base.yaml redis-base.yaml redis.yaml msgid.json internal_msgid.json ./world
tar -zcvf world.${NAME}.tar.gz ./world

