# ---------------------------- account initialize sql --------------------------------
CREATE database account;
USE account;

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `account_id` varchar(128) NOT NULL,
  `device_id` varchar(128) NOT NULL,
  `facebook_id` varchar(128) DEFAULT NULL,
  `role_info` mediumtext,
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  PRIMARY KEY (`account_id`),
  KEY `device_id` (`device_id`),
  KEY `facebook_id` (`facebook_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
# ---------------------------- account initialize sql --------------------------------
