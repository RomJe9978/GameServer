#!/bin/sh

DB_NAME=projectx_pre_dev
if [[ "$1" != "" ]]; then
  DB_NAME=$1
  echo "using db name" $DB_NAME
fi

sql_file=mysql/setup_game.sql
migration_sql_file=mysql/setup_game_migration.sql
mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -d $DB_NAME > $sql_file
mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -t $DB_NAME migrations > $migration_sql_file

echo 'CREATE database projectx_universal;\nUSE projectx_universal;\n' | cat - $sql_file> temp
cat $migration_sql_file >> temp && mv temp $sql_file
rm -rf $migration_sql_file

docker build -t 172.18.28.13:5000/mysql-image:universal ./mysql
docker push 172.18.28.13:5000/mysql-image:universal

docker build -t 172.18.28.13:5000/sql-migrate:universal ../migration
docker push 172.18.28.13:5000/sql-migrate:universal