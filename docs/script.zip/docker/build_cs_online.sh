#!/bin/bash

CMD=$1
ENV=docker-cs

function mavenBuild() {
    build_path='../..'
    pushd ${build_path}
    mvn package -P${ENV} -Dmaven.test.skip=true
    popd
}

function buildGameServer() {
  mavenBuild

  docker build -t 172.18.28.13:5000/gameserver:cs_online ../../gameserver
  docker push 172.18.28.13:5000/gameserver:cs_online
}

function startGameServer() {
  docker kill game
  docker rm game
  docker run --name=game  --link db:db --link world:world -d 172.18.28.13:5000/gameserver:cs_online
  echo "start game server success."
}

function buildWorldServer() {
  mavenBuild

  docker build -t 172.18.28.13:5000/worldserver:cs_online ../../worldserver
  docker push 172.18.28.13:5000/worldserver:cs_online
}

function startWorldServer() {
  docker kill world
  docker rm world

  docker run --name=world  --link db:db -d 172.18.28.13:5000/worldserver:cs_online
  echo "start world server success."
}

function buildAccountServer() {
  mavenBuild

  docker build -t 172.18.28.13:5000/accountserver:cs_online ../../accountserver
  docker push 172.18.28.13:5000/accountserver:cs_online
}

function startAccountServer() {
  docker kill account
  docker rm account

  docker run --name=account  --link db:db -d 172.18.28.13:5000/accountserver:cs_online
  echo "start account server success."
}

function stopGameServer() {
  docker kill game
  echo "stop game server success."
}

function stopWorldServer() {
  docker kill world
  echo "stop world server success."
}

function stopAccountServer() {
  docker kill account
  echo "stop account server success."
}


if [ $CMD == "game" ]; then
  buildGameServer
  echo "build server success."
elif [ $CMD == "world" ]; then
  buildWorldServer
  echo "build world server success."
elif [ $CMD == "account" ]; then
  buildAccountServer
  echo "build account server success."
elif [ $CMD == "start_game" ]; then
  startGameServer
elif [ $CMD == "stop_game" ]; then
  stopGameServer
elif [ $CMD == "start_world" ]; then
  startWorldServer
elif [ $CMD == "stop_world" ]; then
  stopWorldServer
elif [ $CMD == "start_account" ]; then
  startAccountServer
elif [ $CMD == "stop_account" ]; then
  stopAccountServer
else
  echo "server.sh [CMD]"
fi