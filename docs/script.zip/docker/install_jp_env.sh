#!/bin/sh

sql_file=mysql/setup_game.sql
migration_sql_file=mysql/setup_game_migration.sql
mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -d projectx_debug > $sql_file
mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -t projectx_debug migrations > $migration_sql_file

echo 'CREATE database projectx_jp;\nUSE projectx_jp;\n' | cat - $sql_file> temp
cat $migration_sql_file >> temp && mv temp $sql_file
rm -rf $migration_sql_file

docker build -t 172.18.28.13:5000/mysql-image:jp ./mysql
docker push 172.18.28.13:5000/mysql-image:jp

docker build -t 172.18.28.13:5000/sql-migrate:jp ../migration
docker push 172.18.28.13:5000/sql-migrate:jp