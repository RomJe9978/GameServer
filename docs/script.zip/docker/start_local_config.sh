#!/bin/sh

LOCAL_TABLE_PATH=$1

if [ -z "${LOCAL_TABLE_PATH}" ]; then
  echo 'usage: start_local.sh [local_table_path]'
  exit 1
fi

docker kill db
docker rm db
docker image rm 172.18.28.13:5000/mysql-image:dev

docker run  --name db -e MYSQL_ROOT_PASSWORD=password -d -it 172.18.28.13:5000/mysql-image:dev
echo "start mysql server success."

docker kill world
docker rm world
docker image rm 172.18.28.13:5000/worldserver:dev
docker run --name=world  --link db:db -d 172.18.28.13:5000/worldserver:dev
echo "start world server success."

docker kill game
docker rm game
docker image rm 172.18.28.13:5000/gameserver:dev
docker run --name=game  -v $LOCAL_TABLE_PATH:/table -p 9090:9090  -p 8888:8888 --link db:db --link world:world -d 172.18.28.13:5000/gameserver:dev
echo "start game server success."
