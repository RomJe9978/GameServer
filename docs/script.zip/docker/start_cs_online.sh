#!/bin/sh

docker container rm -f db
docker rmi -f 172.18.28.13:5000/mysql-image:cs_online
docker run --name db -p 3308:3306 -e MYSQL_ROOT_PASSWORD=password -d -it 172.18.28.13:5000/mysql-image:cs_online
echo "start mysql server success."

docker kill world
docker rm world
docker rmi -f 172.18.28.13:5000/worldserver:cs_online
docker run --name=world -p 2021:2021 -p 29898:29898 --link db:db -d 172.18.28.13:5000/worldserver:cs_online
echo "start world server success."

docker kill game
docker rm game
docker rmi -f 172.18.28.13:5000/gameserver:cs_online
docker run --name=game -p 9090:9090  -p 8888:8888 --link db:db --link world:world -d 172.18.28.13:5000/gameserver:cs_online
echo "start game server success."
