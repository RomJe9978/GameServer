#!/bin/sh

docker rmi -f 172.18.28.13:5000/sql-migrate:dev
docker run --name migration -it --rm --link db:db  172.18.28.13:5000/sql-migrate:dev  up -env="docker"

docker container rm -f db
docker rmi -f 172.18.28.13:5000/mysql-image:dev
docker run --name db -p 3308:3306 -e MYSQL_ROOT_PASSWORD=password -d -it 172.18.28.13:5000/mysql-image:dev
echo "start mysql server success."

docker kill redishost
docker rm redishost
docker rmi -f 172.18.28.13:5000/redis-image:dev
docker run -d --name redishost -p 16379:6379 172.18.28.13:5000/redis-image:dev --requirepass "pwd4redis"
echo "start redis server success."

docker kill world
docker rm world
docker rmi -f 172.18.28.13:5000/worldserver:dev
docker run --name=world  --link db:db -d 172.18.28.13:5000/worldserver:dev
echo "start world server success."

docker kill game
docker rm game
docker rmi -f 172.18.28.13:5000/gameserver:dev
docker run --name=game -p 9090:9090  -p 8888:8888 --link db:db --link redishost:redishost --link world:world -d 172.18.28.13:5000/gameserver:dev
echo "start game server success."
