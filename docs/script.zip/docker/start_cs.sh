#!/bin/sh

docker container rm -f db
docker rmi -f 172.18.28.13:5000/mysql-image:cs
docker run --name db -p 3308:3306 -e MYSQL_ROOT_PASSWORD=password -d -it 172.18.28.13:5000/mysql-image:cs
echo "start mysql server success."

docker kill redishost
docker rm redishost
docker rmi -f 172.18.28.13:5000/redis-image:dev
docker run -d --name redishost -p 16379:6379 172.18.28.13:5000/redis-image:dev --requirepass "pwd4redis"
echo "start redis server success."

docker kill world
docker rm world
docker rmi -f 172.18.28.13:5000/worldserver:cs
docker run --name=world -p 2021:2021 -p 29898:29898 --link db:db --link redishost:redishost -d 172.18.28.13:5000/worldserver:cs
echo "start world server success."

docker kill game
docker rm game
docker rmi -f 172.18.28.13:5000/gameserver:cs
docker run --name=game -p 9090:9090  -p 8888:8888 --link db:db --link world:world --link redishost:redishost -d 172.18.28.13:5000/gameserver:cs
echo "start game server success."
