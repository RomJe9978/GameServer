#!/bin/sh

sql_file=mysql/setup_game.sql
migration_sql_file=mysql/setup_game_migration.sql
mysqldump --column-statistics=0 --host=172.18.29.2 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -d projectx_dev_tw > $sql_file
mysqldump --column-statistics=0 --host=172.18.29.2 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -t projectx_dev_tw migrations > $migration_sql_file

echo 'CREATE database projectx_tw;\nUSE projectx_tw;\n' | cat - $sql_file> temp
cat $migration_sql_file >> temp && mv temp $sql_file
rm -rf $migration_sql_file

docker build -t 172.18.28.13:5000/mysql-image:tw ./mysql
docker push 172.18.28.13:5000/mysql-image:tw

docker build -t 172.18.28.13:5000/sql-migrate:tw ../migration
docker push 172.18.28.13:5000/sql-migrate:tw