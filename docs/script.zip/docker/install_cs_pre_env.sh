#!/bin/sh
#### 跨服相关环境设置 ####
sql_file=mysql/setup_game.sql
migration_sql_file=mysql/setup_game_migration.sql

world_sql_file=mysql/setup_world.sql

mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -d projectx_cs_dev > $sql_file
mysqldump --column-statistics=0 --host=172.18.28.13 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -t projectx_cs_dev migrations > $migration_sql_file

echo 'CREATE database projectx_cs;\nUSE projectx_cs;\n' | cat - $sql_file> temp
cat - $migration_sql_file>> temp && mv temp $sql_file
rm -rf $migration_sql_file

mysqldump --column-statistics=0 --host=172.18.29.2 -u root -pJLQSCzw001! --single-transaction --default-character-set=utf8  -d projectx_world_debug > $world_sql_file

echo 'CREATE database projectx_world;\nUSE projectx_world;\n' | cat - $world_sql_file> worldtemp
mv worldtemp $world_sql_file


docker build -t 172.18.28.13:5000/mysql-image:cs_pre ./mysql
docker push 172.18.28.13:5000/mysql-image:cs_pre
