#!/bin/sh

docker rmi -f 172.18.28.13:5000/sql-migrate:universal
docker run --name migration -it --rm --link db:db  172.18.28.13:5000/sql-migrate:universal  up -env="docker"

docker container rm -f db
docker rmi -f 172.18.28.13:5000/mysql-image:universal
docker run --name db -p 3308:3306 -e MYSQL_ROOT_PASSWORD=password -d -it 172.18.28.13:5000/mysql-image:universal
echo "start mysql server success."

docker kill game
docker rm game
docker rmi -f 172.18.28.13:5000/gameserver:universal
docker run --name=game -p 9090:9090  -p 8888:8888 --link db:db -d 172.18.28.13:5000/gameserver:universal
echo "start game server success."
