#!/bin/sh

sql_file=mysql/setup_game.sql
mysqldump --column-statistics=0  --host=172.18.28.13 -u root -pJLQSCzw001! projectx_debug_br > $sql_file

echo 'CREATE database projectx_br;\nUSE projectx_br;\n' | cat - $sql_file > temp && mv temp $sql_file

docker build -t 172.18.28.13:5000/mysql-image:br ./mysql
docker push 172.18.28.13:5000/mysql-image:br

docker build -t 172.18.28.13:5000/sql-migrate:br ../migration
docker push 172.18.28.13:5000/sql-migrate:br