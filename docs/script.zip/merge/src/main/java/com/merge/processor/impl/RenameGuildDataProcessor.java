package com.merge.processor.impl;

import com.gameserver.player.entity.GuildEntity;
import com.jengine.logger.Log;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;
import com.merge.util.MergeUtil;

import java.util.*;

/**
 * RenameGuildDataProcessor
 * rename player names whose name repeated with others.
 *
 * @author mengyan
 */
public class RenameGuildDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "RenameGuildDataProcessor";
    }

    public RenameGuildDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始查询目标库昵称重复公会信息");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        Set<Long> repeatedNamePlayers = this.queryRepeatedNamesData(targetInfo);
        Log.getDatabaseLogger().info("查询目标库昵称信息结束");

        Log.getDatabaseLogger().info("开始执行去重名操作");
        for (Long guildId : repeatedNamePlayers) {
            GuildEntity guildEntity = MergeUtil.loadGuildEntity(guildId);
            guildEntity.setName(String.valueOf(guildId));
            guildEntity.addFreeRenameTimes();

            guildEntity.notifyUpdate(false);
        }
        Log.getDatabaseLogger().info("去重名操作结束");

        return true;
    }

    private Set<Long> queryRepeatedNamesData(DbInfo dbInfo) {
        Set<Long> repeatedNameGuilds = new HashSet<>();
        Map<String, Long> nameGuild = new HashMap<>();
        List<Object[]> playerBasicInfos = dbInfo.getDbEntityManager().sqlQuery("select id, name from guild");
        if (playerBasicInfos != null) {
            for (Object[] result : playerBasicInfos) {
                String name = String.valueOf(result[1]);
                Long guildId = Long.parseLong(String.valueOf(result[0]));
                if (!nameGuild.containsKey(name)) {
                    nameGuild.put(name, guildId);
                } else {
                    repeatedNameGuilds.add(guildId);
                    repeatedNameGuilds.add(nameGuild.get(name));
                }
            }
        }

        return repeatedNameGuilds;
    }
}
