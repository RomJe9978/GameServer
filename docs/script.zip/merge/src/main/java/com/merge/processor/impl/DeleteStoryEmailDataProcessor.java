package com.merge.processor.impl;

import com.jengine.logger.Log;
import com.jengine.util.TimeUtil;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

/**
 * Delete datas from story_email table;
 *
 * @author mengyan
 */
public class DeleteStoryEmailDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "DeleteStoryEmailDataProcessor";
    }

    public DeleteStoryEmailDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始执行源库数据剧情邮件相关数据清理操作");
        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        this.deleteStoryEmailData(sourceInfo);
        Log.getDatabaseLogger().info("源库数据剧情邮件相关数据清理操作结束");

        Log.getDatabaseLogger().info("开始执行目标库剧情邮件相关数据清理操作");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        this.deleteStoryEmailData(targetInfo);
        Log.getDatabaseLogger().info("目标库剧情邮件相关数据清理操作结束");

        return true;
    }

    private void deleteStoryEmailData(DbInfo dbInfo) throws Exception {
        long startTime = TimeUtil.getTimeInMillis();
        String talbeName = "story_email";
        Log.getDatabaseLogger().info("【{}】服数据表:{}执行数据删除操作", dbInfo.getServerId(), talbeName);
        String sql = "delete from " + talbeName;
        int deleteCount = dbInfo.getDbEntityManager().sqlUpdate(sql);
        Log.getDatabaseLogger().info("-------------------删除{}服【{}】表: {}条数据，耗时 {}ms-------------------",
                dbInfo.getServerId(), talbeName, deleteCount, TimeUtil.getTimeInMillis() - startTime);
    }
}
