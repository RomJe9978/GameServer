package com.merge.processor.impl;

import com.jengine.logger.Log;
import com.jengine.util.TimeUtil;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

/**
 * Delete datas from mail table;
 *
 * @author mengyan
 */
public class DeleteExpiredMailDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "DeleteExpiredMailDataProcessor";
    }

    public DeleteExpiredMailDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始执行源库数据邮件相关数据清理操作");
        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        this.deleteMailData(sourceInfo);
        Log.getDatabaseLogger().info("源库数据邮件相关数据清理操作结束");

        Log.getDatabaseLogger().info("开始执行源库数据全服邮件相关数据清理操作");
        this.deleteGlobalMailData(sourceInfo);
        Log.getDatabaseLogger().info("源库数据全服邮件相关数据清理操作结束");

        Log.getDatabaseLogger().info("开始执行目标库邮件相关数据清理操作");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        this.deleteMailData(targetInfo);
        Log.getDatabaseLogger().info("目标库邮件相关数据清理操作结束");

        return true;
    }

    private void deleteMailData(DbInfo dbInfo) throws Exception {
        long startTime = TimeUtil.getTimeInMillis();
        String tableMail = "mail";
        Log.getDatabaseLogger().info("【{}】服数据表:{}执行数据删除操作", dbInfo.getServerId(), tableMail);
        String sql = "delete from " + tableMail + " where expire_at<=" + TimeUtil.getTimeInSeconds();
        int deleteCount = dbInfo.getDbEntityManager().sqlUpdate(sql);
        Log.getDatabaseLogger().info("-------------------删除{}服【{}】表: {}条数据，耗时 {}ms-------------------",
                dbInfo.getServerId(), tableMail, deleteCount, TimeUtil.getTimeInMillis() - startTime);
    }

    private void deleteGlobalMailData(DbInfo dbInfo) throws Exception {
        long startTime = TimeUtil.getTimeInMillis();
        String tableMail = "global_mail";
        Log.getDatabaseLogger().info("【{}】服数据表:{}执行数据删除操作", dbInfo.getServerId(), tableMail);
        String sql = "delete from " + tableMail;
        int deleteCount = dbInfo.getDbEntityManager().sqlUpdate(sql);
        Log.getDatabaseLogger().info("-------------------删除{}服【{}】表: {}条数据，耗时 {}ms-------------------",
                dbInfo.getServerId(), tableMail, deleteCount, TimeUtil.getTimeInMillis() - startTime);
    }
}
