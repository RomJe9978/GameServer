package com.merge.processor.impl;

import com.gameserver.player.entity.NpcLoveEntity;
import com.jengine.logger.Log;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * UpdateNpcLoveProcessor
 *
 * @author mengyan
 */
public class UpdateNpcLoveProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "UpdateNpcLoveProcessor";
    }

    public UpdateNpcLoveProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始查询目标库npc好感度信息");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        Map<Integer, NpcLoveEntity> targetNpcLoveInfos = this.loadNpcLoveEntities(targetInfo);
        Log.getDatabaseLogger().info("查询目标库npc好感度信息结束");

        Log.getDatabaseLogger().info("开始查询源库npc好感度信息");
        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        Map<Integer, NpcLoveEntity> sourceBattleLevelInfos = this.loadNpcLoveEntities(sourceInfo);
        Log.getDatabaseLogger().info("查询源库关卡信息结束");

        Log.getDatabaseLogger().info("开始更新npc好感度信息");
        for (Map.Entry<Integer, NpcLoveEntity> kv : sourceBattleLevelInfos.entrySet()) {
            if (targetNpcLoveInfos.get(kv.getKey()) != null) {
                NpcLoveEntity targetNpcLoveEntity = targetNpcLoveInfos.get(kv.getKey());
                NpcLoveEntity sourceNpcLoveEntity = kv.getValue();
                targetNpcLoveEntity.setLoveCount(targetNpcLoveEntity.getLoveCount() + sourceNpcLoveEntity.getLoveCount());
                targetInfo.getDbEntityManager().update(targetNpcLoveEntity);
            }
        }

        Log.getDatabaseLogger().info("更新npc好感度信息完成");

        return true;
    }

    private Map<Integer, NpcLoveEntity> loadNpcLoveEntities(DbInfo dbInfo) {
        Map<Integer, NpcLoveEntity> entityMap = new HashMap<>();
        List<NpcLoveEntity> entities = dbInfo.getDbEntityManager().query(
                "from NpcLoveEntity where invalid = 0"
        );

        if (entities != null && entities.size() > 0) {
            for (NpcLoveEntity entity : entities) {
                entityMap.put(entity.getNpcId(), entity);
            }
        }

        return entityMap;
    }
}
