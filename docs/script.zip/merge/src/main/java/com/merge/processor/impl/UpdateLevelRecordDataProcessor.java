package com.merge.processor.impl;

import com.gameserver.player.entity.BattleLevelRecordEntity;
import com.jengine.logger.Log;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

import java.util.*;

/**
 * UpdateLevelRecordDataProcessor
 *
 * @author mengyan
 */
public class UpdateLevelRecordDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "UpdateLevelRecordDataProcessor";
    }

    public UpdateLevelRecordDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始查询目标库关卡信息");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        Map<Integer, Map<Integer, BattleLevelRecordEntity>> targetBattleLevelInfos = this.loadBattleLevelRecordEntities(targetInfo);
        Log.getDatabaseLogger().info("查询目标库关卡信息结束");

        Log.getDatabaseLogger().info("开始查询源库关卡信息");
        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        Map<Integer, Map<Integer, BattleLevelRecordEntity>> sourceBattleLevelInfos = this.loadBattleLevelRecordEntities(sourceInfo);
        Log.getDatabaseLogger().info("查询源库关卡信息结束");

        Log.getDatabaseLogger().info("开始更新关卡进度信息");
        for (Map.Entry<Integer, Map<Integer, BattleLevelRecordEntity>> kv : targetBattleLevelInfos.entrySet()) {
            Set<Integer> processedLevels = new HashSet<>();

            int type = kv.getKey();
            Map<Integer, BattleLevelRecordEntity> targetLevelRecords = kv.getValue();
            Map<Integer, BattleLevelRecordEntity> sourceLevelRecords = sourceBattleLevelInfos.get(type);

            for (Integer level : targetLevelRecords.keySet()) {
                if (!processedLevels.contains(level)) {
                    processedLevels.add(level);
                    BattleLevelRecordEntity targetLevelRecord = null;
                    if (targetLevelRecords != null) {
                        targetLevelRecord = targetLevelRecords.get(level);
                    }
                    BattleLevelRecordEntity sourceLevelRecord = null;
                    if (sourceLevelRecords != null) {
                        sourceLevelRecord = sourceLevelRecords.get(level);
                    }

                    if (targetLevelRecord != null && sourceLevelRecord != null) {
                        BattleLevelRecordEntity.RankData targetRankData = targetLevelRecord.getFirstPassData();
                        BattleLevelRecordEntity.RankData sourceRankData = sourceLevelRecord.getFirstPassData();
                        if (sourceRankData.getTimestamp() < targetRankData.getTimestamp()) {
                            targetLevelRecord.updateFirstPassData(sourceRankData);
                        }
                    }
                }
            }

            for (Integer level : sourceLevelRecords.keySet()) {
                if (!processedLevels.contains(level)) {
                    processedLevels.add(level);
                    BattleLevelRecordEntity sourceLevelRecordEntity = sourceLevelRecords.get(level);
                    if (sourceLevelRecordEntity != null) {
                        this.mergeClient.getTargetDbInfo().getDbEntityManager().create(sourceLevelRecordEntity);
                    }
                }
            }

        }

        Log.getDatabaseLogger().info("更新关卡进度信息完成");

        return true;
    }

    private Map<Integer, Map<Integer, BattleLevelRecordEntity>> loadBattleLevelRecordEntities(DbInfo dbInfo) {
        Map<Integer, Map<Integer, BattleLevelRecordEntity>> battleLevelRecordEntities = new HashMap<>();
        List<BattleLevelRecordEntity> entityList = dbInfo.getDbEntityManager().query(
                "from BattleLevelRecordEntity where invalid = 0");
        if (entityList != null) {
            entityList.forEach(BattleLevelRecordEntity::parse);
        } else {
            entityList = new ArrayList<>();
        }

        for (BattleLevelRecordEntity battleRecord : entityList) {
            if (!battleLevelRecordEntities.containsKey(battleRecord.getType())) {
                battleLevelRecordEntities.put(battleRecord.getType(), new HashMap<>());
            }
            battleLevelRecordEntities.get(battleRecord.getType()).put(battleRecord.getLevel(), battleRecord);
        }
        return battleLevelRecordEntities;
    }
}
