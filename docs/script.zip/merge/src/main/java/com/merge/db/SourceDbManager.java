package com.merge.db;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.persist.DefaultDBEntityManager;
import com.jengine.util.ClassScanner;
import org.hibernate.cfg.Configuration;

import java.io.File;
import java.util.Set;

public class SourceDbManager extends DefaultDBEntityManager {
    @Override
    public String getId() {
        return "SourceDbManager";
    }

    @Override
    public boolean init() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            if (this.configuration == null) {
                String configPath = System.getProperty("user.dir") + File.separator + "hibernate-source.cfg.xml";
                this.configuration = new Configuration();
                this.configuration.configure(new File(configPath));
            }

            String url = Jengine.getConfiguration().getString("sourcedb.connection.url");
            this.configuration.setProperty("hibernate.connection.url", url);
            this.configuration.setProperty("hibernate.connection.username", Jengine.getConfiguration().getString("sourcedb.connection.username"));
            this.configuration.setProperty("hibernate.connection.password", Jengine.getConfiguration().getString("sourcedb.connection.password"));

            String[] entityPackages = Jengine.getConfiguration().getString("sourcedb.entityPackages").split(",");
            if (entityPackages != null) {
                for (String entityPackage : entityPackages) {
                    log.info("init entity package: " + entityPackage);
                    Set<Class> entities = ClassScanner.scanClassInPackage(entityPackage, false);
                    for (Class entity : entities) {
                        this.configuration.addAnnotatedClass(entity);
                    }
                }
            }

            this.sessionFactory = this.configuration.buildSessionFactory();

            log.info("Init database url: {}, entity packages: {} success.", url, entityPackages);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }
        return true;
    }

    @Override
    protected void startAsyncThread() {
        if (asyncThread == null) {
            asyncThread = new Thread(this);
            asyncThread.setName("SourceDbManager");
            asyncThread.start();
        }
    }
}
