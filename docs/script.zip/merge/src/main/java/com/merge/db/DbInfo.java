package com.merge.db;

import com.jengine.Jengine;
import com.jengine.persist.DBEntityManager;
import com.jengine.util.ClassScanner;

import javax.persistence.Table;
import java.util.*;

/**
 * A wrapper for database information.
 *
 * @author mengyan
 */
public class DbInfo {
    private String dbName;
    private DBEntityManager dbEntityManager;
    private String serverId;
    private Map<String, String> tableEntities;
    private Map<String, String> externalKey;
    private List<String> ignoreTables;

    public DbInfo(String name, DBEntityManager dbEntityManager) {
        this.dbName = name;
        this.dbEntityManager = dbEntityManager;
        this.tableEntities = new HashMap<>();
        this.externalKey = new HashMap<>();
        this.ignoreTables = new ArrayList<>();

        this.initTableEntities();
        String externalKeyStr = Jengine.getConfiguration().getString("merge.externalKey");
        String[] keyArray = externalKeyStr.split(",");
        for (String tableKey : keyArray) {
            String[] tableAndKey = tableKey.split("-");
            this.externalKey.put(tableAndKey[0], tableAndKey[1]);
        }

        String ignoreTableStr = Jengine.getConfiguration().getString("merge.ignoreTables");
        String[] toIgnoreTables = ignoreTableStr.split(",");
        for (String ignore : toIgnoreTables) {
            this.ignoreTables.add(ignore);
        }

    }

    public Map<String, DbTable> getAllTables() {
        String tableSql = "SELECT table_name FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '"
                + this.dbName + "'";
        List<String> tableNames = this.dbEntityManager.sqlQuery(tableSql);
        Map<String, DbTable> tableNameMap = new HashMap<>();
        for (String tableName : tableNames) {
            if (!tableName.equals("migrations")) {
                tableNameMap.put(tableName, new DbTable(this.dbName, tableName, this.dbEntityManager));
            }
        }
        return tableNameMap;
    }

    public String getTableEntity(String tableName) {
        return this.tableEntities.get(tableName);
    }

    private void initTableEntities() {
        String[] entityPackages = Jengine.getConfiguration().getString("database.entityPackages").split(",");
        if (entityPackages != null) {
            for (String entityPackage : entityPackages) {
                Set<Class> entities = ClassScanner.scanClassInPackage(entityPackage, false);
                for (Class entity : entities) {
                    if (entity.isAnnotationPresent(Table.class)) {
                        Table tclass = (Table) entity.getDeclaredAnnotation(Table.class);
                        this.tableEntities.put(tclass.name(), entity.getSimpleName());
                    }
                }
            }
        }
    }

    public String getServerId() {
        return serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public DBEntityManager getDbEntityManager() {
        return dbEntityManager;
    }

    public String getExternalKey(String tableName) {
        return this.externalKey.get(tableName);
    }

    public boolean isIgnore(String tableName) {
        return this.ignoreTables.contains(tableName);
    }
}
