package com.merge;


import com.jengine.logger.Log;
import com.merge.merge.MergeClient;

public class MergeMain {
    public static void main(String[] args) throws Exception {
        Log.initLogPath();

        MergeClient client = new MergeClient();
        client.init();
        client.startup();
        client.shutdown();

        System.exit(0);
    }
}
