package com.merge.processor.impl;

import com.gameserver.player.entity.PlayerEntity;
import com.jengine.logger.Log;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;
import com.merge.util.MergeUtil;

import java.util.*;

/**
 * RenameRepeatedNamesDataProcessor
 * rename player names whose name repeated with others.
 *
 * @author mengyan
 */
public class RenamePlayerDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "RenameRepeatedNamesDataProcessor";
    }

    public RenamePlayerDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始查询目标库昵称重复玩家信息");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        Set<Long> repeatedNamePlayers = this.queryRepeatedNamesData(targetInfo);
        Log.getDatabaseLogger().info("查询目标库昵称信息结束");

        Log.getDatabaseLogger().info("开始执行去重名操作");
        for (Long playerId : repeatedNamePlayers) {
            PlayerEntity playerEntity = MergeUtil.loadPlayerData(playerId).getPlayerEntity();
            playerEntity.setName(String.valueOf(playerId));
            playerEntity.setLeftRenameTimes(1);
            playerEntity.notifyUpdate(false);
        }
        Log.getDatabaseLogger().info("去重名操作结束");

        return true;
    }

    private Set<Long> queryRepeatedNamesData(DbInfo dbInfo) {
        Set<Long> repeatedNamePlayers = new HashSet<>();
        Map<String, Long> namePlayer = new HashMap<>();
        List<Object[]> playerBasicInfos = dbInfo.getDbEntityManager().sqlQuery("select id, client_id, name, server_id from player where name !=''");
        if (playerBasicInfos != null) {
            for (Object[] result : playerBasicInfos) {
                String name = String.valueOf(result[2]);
                Long playerId = Long.parseLong(String.valueOf(result[0]));
                if (!namePlayer.containsKey(name)) {
                    namePlayer.put(name, playerId);
                } else {
                    repeatedNamePlayers.add(playerId);
                    repeatedNamePlayers.add(namePlayer.get(name));
                }
            }
        }

        return repeatedNamePlayers;
    }
}
