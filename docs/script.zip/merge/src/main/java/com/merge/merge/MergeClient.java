package com.merge.merge;

import com.jengine.Jengine;
import com.jengine.logger.Log;
import com.jengine.persist.AbstractEntity;
import com.jengine.persist.DBEntityManager;
import com.jengine.util.StringUtil;
import com.jengine.util.TimeUtil;
import com.merge.base.BaseClient;
import com.merge.db.DbInfo;
import com.merge.db.DbTable;
import com.merge.db.SourceDbManager;
import com.merge.processor.DataProcessor;
import com.merge.processor.impl.*;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * MergeClient
 *
 * @author mengyan
 */
public class MergeClient extends BaseClient {
    private List<DataProcessor> dataProcessorList = new ArrayList<>();
    private List<DataProcessor> afterMergeProcessorList = new ArrayList<>();

    private DbInfo targetDbInfo;
    private DbInfo sourceDbInfo;
    private int pageSize = 1000;


    @Override
    public boolean init() throws Exception {
        super.init();

        this.pageSize = Jengine.getConfiguration().getInt("merge.pageSize");
        this.initDbInfo();

        this.initProcessors();
        return true;
    }

    public boolean beforeMerge() throws Exception {
        for (DataProcessor processor : this.dataProcessorList) {
            boolean ok = processor.execute();
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    private String getSqlTableName() {
        String sqlTableNames = " ";
        for (DbTable table : this.sourceDbInfo.getAllTables().values()) {
            if (this.sourceDbInfo.isIgnore(table.getTableName())) {
                continue;
            }

            sqlTableNames += " " + table.getTableName();
        }
        sqlTableNames += " ";
        return sqlTableNames;
    }

    // 优化合服机制，节省合服时间
    public boolean sqlToolMerge() throws IOException, InterruptedException {
        String sqlTableNames = getSqlTableName();
        String sqlToolBasePath = Jengine.getConfiguration().getString("sqltool.basePath");
        String sqlToolDumpPath = Jengine.getConfiguration().getString("sqltool.dumpPath");

        String targetUrl = Jengine.getConfiguration().getString("database.connection.url");
        String targetURIStr = targetUrl.substring(5);
        URI targetUri = URI.create(targetURIStr);
        String sqlTargetUserName = Jengine.getConfiguration().getString("database.connection.username");
        String sqlTargetPassword = Jengine.getConfiguration().getString("database.connection.password");
        String sqlTargetName = targetUri.getPath().replaceAll("/", "");
        String sqlTargetHost = targetUri.getHost();
        int sqlTargetPort = targetUri.getPort();

        String sourceUrl = Jengine.getConfiguration().getString("sourcedb.connection.url");
        String sourceURIStr = sourceUrl.substring(5);
        URI sourceUri = URI.create(sourceURIStr);
        String sqlSourceUserName = Jengine.getConfiguration().getString("sourcedb.connection.username");
        String sqlSourcePassword = Jengine.getConfiguration().getString("sourcedb.connection.password");
        String sqlSourceName = sourceUri.getPath().replaceAll("/", "");
        String sqlSourceHost = sourceUri.getHost();
        int sqlSourcePort = sourceUri.getPort();

        String dumpSql = sqlToolBasePath + "mysqldump --host="
                + sqlSourceHost + " -P " +
                +sqlSourcePort + " -u "
                + sqlSourceUserName + " -p"
                + sqlSourcePassword + " --single-transaction --force --default-character-set=utf8mb4  --set-gtid-purged=OFF  -t "
                + sqlSourceName + " "
                + sqlTableNames + "  > "
                + sqlToolDumpPath;
        Log.getDatabaseLogger().info("sql dump raw info:{}", dumpSql);

        String[] cmdarray = {"/bin/sh", "-c", dumpSql};
        Process p = Runtime.getRuntime().exec(cmdarray);
        int flag = p.waitFor();
        if (flag == 0) {
            Log.getDatabaseLogger().info("sql dump数据成功");

            String importSql = sqlToolBasePath
                    + "mysql --host="
                    + sqlTargetHost + "  --force  -u "
                    + sqlTargetUserName + " -P "
                    + sqlTargetPort + " -p"
                    + sqlTargetPassword + " "
                    + sqlTargetName
                    + " < " + sqlToolDumpPath;
            Log.getDatabaseLogger().info("sql import raw info:{}", importSql);

            String[] importCmdarray = {"/bin/sh", "-c", importSql};
            Process pr = Runtime.getRuntime().exec(importCmdarray);

            int importFlag = pr.waitFor();
            if (importFlag == 0) {
                Log.getDatabaseLogger().info("sql导入数据成功");
            } else {
                Log.getDatabaseLogger().error("sql import 失败，错误码:{}", importFlag);
                return false;
            }
        } else {
            Log.getDatabaseLogger().error("sql dump 失败，错误码:{}", flag);
            return false;
        }

        return true;
    }

    public boolean merge() {
        for (DbTable table : this.sourceDbInfo.getAllTables().values()) {
            int startTime = TimeUtil.getTimeInSeconds();

            if (this.sourceDbInfo.isIgnore(table.getTableName())) {
                continue;
            }

            if (StringUtil.isEmpty(this.sourceDbInfo.getTableEntity(table.getTableName()))) {
                Log.getDatabaseLogger().error("没有找到table:{} 对应的实体", table.getTableName());
                continue;
            }

            Log.getDatabaseLogger().info("从源数据库读取【" + table.getTableName() + "】");

            long count = this.getRecordCount(this.sourceDbInfo, table);
            long times = getTimes(count, pageSize);
            Log.getDatabaseLogger().info("数据表【{}】,总记录数:【{}】,需要分【{}】批处理", table.getTableName(), count, times);

            for (int i = 0; i < times; i++) {
                Log.getDatabaseLogger().info("开始处理第{}批数据合并", i + 1);
                String sql = "from " + this.sourceDbInfo.getTableEntity(table.getTableName()) + " order by create_ts DESC";
                if (this.sourceDbInfo.getExternalKey(table.getTableName()) != null) {
                    sql = "from " + this.sourceDbInfo.getTableEntity(table.getTableName()) + " order by create_ts DESC," + this.sourceDbInfo.getExternalKey(table.getTableName()) + " desc";

                }
                List<AbstractEntity> values = this.sourceDbInfo.getDbEntityManager().limitQuery(sql, i * pageSize, pageSize);
                for (AbstractEntity abstractEntity : values) {
                    this.targetDbInfo.getDbEntityManager().create(abstractEntity);
                }
            }

            Log.getDatabaseLogger().info("--------- 合并{}服" + "【{}】数据表表, 耗时{} s---------", this.sourceDbInfo.getServerId(), table.getTableName(), (TimeUtil.getTimeInSeconds() - startTime));
        }

        return true;
    }

    public boolean afterMerge() throws Exception {
        for (DataProcessor processor : this.afterMergeProcessorList) {
            boolean ok = processor.execute();
            if (!ok) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean startup() throws Exception {
        boolean beforeMerge = this.beforeMerge();
        if (beforeMerge) {
            boolean mergeSuccess = this.sqlToolMerge();
            if (mergeSuccess) {
                this.afterMerge();
            }
        }

        return true;
    }

    private long getRecordCount(DbInfo dbInfo, DbTable table) {
        String selectSql = "select count(*) FROM " + table.getTableName();
        List<Object[]> resultList = dbInfo.getDbEntityManager().sqlQuery(selectSql);
        return Long.valueOf(String.valueOf(resultList.get(0)));
    }

    private long getTimes(long count, int everyCount) {
        long times = count / everyCount;
        long surplus = count % everyCount;
        if (surplus != 0) {
            times = times + 1;
        }
        return times;
    }

    @Override
    public boolean shutdown() throws Exception {

        return true;
    }

    public DbInfo getTargetDbInfo() {
        return targetDbInfo;
    }

    public DbInfo getSourceDbInfo() {
        return sourceDbInfo;
    }

    private void initDbInfo() {
        String targetUrl = Jengine.getConfiguration().getString("database.connection.url");
        String targetURIStr = targetUrl.substring(5);
        URI targetUri = URI.create(targetURIStr);
        String sqlTargetName = targetUri.getPath().replaceAll("/", "");
        this.targetDbInfo = new DbInfo(sqlTargetName, Jengine.getAppContext().get(DBEntityManager.class));
        this.targetDbInfo.setServerId(Jengine.getConfiguration().getString("database.serverId"));

        String sourceUrl = Jengine.getConfiguration().getString("sourcedb.connection.url");
        String sourceURIStr = sourceUrl.substring(5);
        URI sourceUri = URI.create(sourceURIStr);
        String sqlSourceName = sourceUri.getPath().replaceAll("/", "");
        this.sourceDbInfo = new DbInfo(sqlSourceName, Jengine.getAppContext().get(SourceDbManager.class));
        this.sourceDbInfo.setServerId(Jengine.getConfiguration().getString("sourcedb.serverId"));
    }

    private void initProcessors() {
        this.dataProcessorList.add(new CheckTableDataProcessor(this));
        this.dataProcessorList.add(new DeleteInvalidDataProcessor(this));
        this.dataProcessorList.add(new DeleteArenaDataProcessor(this));
        this.dataProcessorList.add(new UpdateLevelRecordDataProcessor(this));

        this.afterMergeProcessorList.add(new RenamePlayerDataProcessor(this));
        this.afterMergeProcessorList.add(new RenameGuildDataProcessor(this));
    }
}
