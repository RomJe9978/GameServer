package com.merge.db;

public class DbField {
    private String tableName;
    private String colume;
    private Object value;

    public DbField(String tableName, String colume) {
        this.tableName = tableName;
        this.colume = colume;
    }

    public DbField(String tableName, String colume, Object value) {
        this(tableName, colume);
        this.value = value;
    }

    public String getColume() {
        return colume;
    }

    public void setColume(String colume) {
        this.colume = colume;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }
}
