package com.merge.util;

import com.gameserver.player.Player;
import com.gameserver.player.PlayerData;
import com.gameserver.player.entity.GuildEntity;
import com.jengine.Jengine;
import com.jengine.persist.DBEntityManager;

public class MergeUtil {
    public static PlayerData loadPlayerData(long playerId) {
        Player player = new Player(playerId);
        return player.getPlayerData();
    }

    public static GuildEntity loadGuildEntity(long guildId) {
        GuildEntity guildEntity = Jengine.getAppContext().get(DBEntityManager.class).fetch("from GuildEntity where invalid = 0 and id=?0", guildId);
        return guildEntity;
    }
}
