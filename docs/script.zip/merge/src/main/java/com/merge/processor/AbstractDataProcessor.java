package com.merge.processor;

import com.merge.merge.MergeClient;

public abstract class AbstractDataProcessor implements DataProcessor {
    protected MergeClient mergeClient;

    public abstract String getId();

    public AbstractDataProcessor(MergeClient mergeClient) {
        this.mergeClient = mergeClient;
    }
}
