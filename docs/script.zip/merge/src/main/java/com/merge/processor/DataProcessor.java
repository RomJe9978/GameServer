package com.merge.processor;

public interface DataProcessor {
    boolean execute() throws Exception;
}
