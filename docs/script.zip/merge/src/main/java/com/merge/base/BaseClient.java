package com.merge.base;

import com.jengine.DefaultAppContext;
import com.jengine.Jengine;
import com.jengine.configuration.PriorityConfiguration;
import com.jengine.persist.DBEntityManager;
import com.jengine.persist.DefaultDBEntityManager;
import com.jengine.shutdown.ShutdownManager;
import com.merge.db.SourceDbManager;
import org.apache.commons.configuration2.YAMLConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public abstract class BaseClient {
    public boolean init() throws Exception {
        this.initBase();
        this.initDb();

        return true;
    }

    public abstract boolean startup() throws Exception;

    public abstract boolean shutdown() throws Exception;

    private void initBase() throws FileNotFoundException, ConfigurationException {
        YAMLConfiguration configBase = new YAMLConfiguration();
        configBase.read(new FileInputStream("config-base.yaml"));

        YAMLConfiguration config = new YAMLConfiguration();
        config.read(new FileInputStream("config.yaml"));

        PriorityConfiguration priorityConfiguration = new PriorityConfiguration(config, configBase);
        Jengine.setConfiguration(priorityConfiguration);
        Jengine.setAppContext(new DefaultAppContext());

        Jengine.setShutdownManager(new ShutdownManager());
        Jengine.getShutdownManager().init();
    }

    private void initDb() throws Exception {
        Jengine.getAppContext().create(DefaultDBEntityManager.class, DBEntityManager.class);
        Jengine.getAppContext().create(SourceDbManager.class, SourceDbManager.class);
    }
}
