package com.merge.processor.impl;

import com.jengine.logger.Log;
import com.jengine.util.TimeUtil;
import com.merge.db.DbInfo;
import com.merge.db.DbTable;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

/**
 * Delete the data from all table where invalid =1;
 *
 * @author mengyan
 */
public class DeleteInvalidDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "DeleteInvalidDataProcessor";
    }

    public DeleteInvalidDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始执行源库数据清理操作");

        // delete gvg_player table
        String sql = "delete from gvg_player where player_id=0 ";
        String sqlChatId0 = "delete from chat where chat_id=0 ";
        String sqlChat3 = "delete from chat where chat_id=3 and type=3";
        String sqlChat4 = "delete from chat where chat_id=4 and type=4";

        String sqlResetFirstPurchase = "update mall set buy_list='' where mall_type =1;";
        String sqlResetLevelGiftPurchase = "update mall set stage_id=2 where mall_type =9;";

        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        for (DbTable table : sourceInfo.getAllTables().values()) {
            this.deleteInvalidData(sourceInfo, table);
        }
        sourceInfo.getDbEntityManager().sqlUpdate(sql);
        sourceInfo.getDbEntityManager().sqlUpdate(sqlChatId0);
        sourceInfo.getDbEntityManager().sqlUpdate(sqlChat3);
        sourceInfo.getDbEntityManager().sqlUpdate(sqlChat4);
        sourceInfo.getDbEntityManager().sqlUpdate(sqlResetFirstPurchase);
        sourceInfo.getDbEntityManager().sqlUpdate(sqlResetLevelGiftPurchase);
        Log.getDatabaseLogger().info("源库数据清理操作结束");

        Log.getDatabaseLogger().info("开始执行目标库数据清理操作");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        for (DbTable table : targetInfo.getAllTables().values()) {
            this.deleteInvalidData(targetInfo, table);
        }
        targetInfo.getDbEntityManager().sqlUpdate(sql);
        targetInfo.getDbEntityManager().sqlUpdate(sqlChatId0);
        targetInfo.getDbEntityManager().sqlUpdate(sqlChat3);
        targetInfo.getDbEntityManager().sqlUpdate(sqlChat4);
        targetInfo.getDbEntityManager().sqlUpdate(sqlResetFirstPurchase);
        targetInfo.getDbEntityManager().sqlUpdate(sqlResetLevelGiftPurchase);

        Log.getDatabaseLogger().info("目标库数据清理操作结束");

        return true;
    }

    private void deleteInvalidData(DbInfo dbInfo, DbTable table) throws Exception {
        long startTime = TimeUtil.getTimeInMillis();
        Log.getDatabaseLogger().info("【{}】数据表:【{}】执行数据删除删除操作", table.getDbName(), table.getTableName());
        String sql = "delete from " + table.getTableName() + " where invalid=1 ";
        int deleteCount = dbInfo.getDbEntityManager().sqlUpdate(sql);
        Log.getDatabaseLogger().info("-------------------删除{}服【{}】表: {}条数据，耗时 {}ms-------------------",
                dbInfo.getServerId(), table.getTableName(), deleteCount, TimeUtil.getTimeInMillis() - startTime);
    }
}
