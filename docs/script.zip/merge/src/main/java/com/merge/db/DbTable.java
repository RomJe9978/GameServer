package com.merge.db;

import com.jengine.persist.DBEntityManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DbTable {
    private String dbName;
    private String tableName;
    private List<DbField> fields = new ArrayList<>();
    private DBEntityManager dbEntityManager;

    public DbTable(String dbName, String tableName, DBEntityManager dbEntityManager) {
        this.dbName = dbName;
        this.tableName = tableName;
        this.dbEntityManager = dbEntityManager;

        this.getAllFields();
    }

    public void setDbEntityManager(DBEntityManager dbEntityManager) {
        this.dbEntityManager = dbEntityManager;
    }

    private Map<String, DbField> getAllFields() {
        String fieldSql = "select column_name  from Information_schema.columns  where table_Name = '"
                + this.tableName + "' and TABLE_SCHEMA='" + this.dbName + "';";
        List<String> fieldMaps = this.dbEntityManager.sqlQuery(fieldSql);
        Map<String, DbField> map = new HashMap<>();
        for (String columeName : fieldMaps) {
            DbField dbField = new DbField(this.tableName, columeName);
            this.addField(dbField);
            map.put(columeName, dbField);
        }
        return map;
    }

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<DbField> getFields() {
        return fields;
    }

    public void addField(DbField field) {
        this.fields.add(field);
    }
}
