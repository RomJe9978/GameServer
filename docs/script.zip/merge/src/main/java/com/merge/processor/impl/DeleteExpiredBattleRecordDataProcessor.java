package com.merge.processor.impl;

import com.jengine.logger.Log;
import com.jengine.util.TimeUtil;
import com.merge.db.DbInfo;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

/**
 * Delete datas from battle_record table;
 *
 * @author mengyan
 */
public class DeleteExpiredBattleRecordDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "DeleteArenaDataProcessor";
    }

    public DeleteExpiredBattleRecordDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始执行源库数据战斗相关数据清理操作");
        DbInfo sourceInfo = this.mergeClient.getSourceDbInfo();
        this.deleteBattleData(sourceInfo);
        Log.getDatabaseLogger().info("源库数据战斗相关数据清理操作结束");

        Log.getDatabaseLogger().info("开始执行目标库战斗相关数据清理操作");
        DbInfo targetInfo = this.mergeClient.getTargetDbInfo();
        this.deleteBattleData(targetInfo);
        Log.getDatabaseLogger().info("目标库战斗相关数据清理操作结束");

        return true;
    }

    private void deleteBattleData(DbInfo dbInfo) throws Exception {
        long startTime = TimeUtil.getTimeInMillis();
        String tableArenaBattleRecord = "battle_record";
        Log.getDatabaseLogger().info("【{}】服数据表:{}执行数据删除操作", dbInfo.getServerId(), tableArenaBattleRecord);
        String sql = "delete from " + tableArenaBattleRecord + " where create_ts>" + (TimeUtil.getTimeInSeconds() - 30 * 60 * 60);
        int deleteCount = dbInfo.getDbEntityManager().sqlUpdate(sql);
        Log.getDatabaseLogger().info("-------------------删除{}服【{}】表: {}条数据，耗时 {}ms-------------------",
                dbInfo.getServerId(), tableArenaBattleRecord, deleteCount, TimeUtil.getTimeInMillis() - startTime);
    }
}
