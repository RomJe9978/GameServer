package com.merge.processor.impl;

import com.jengine.logger.Log;
import com.merge.db.DbInfo;
import com.merge.db.DbTable;
import com.merge.merge.MergeClient;
import com.merge.processor.AbstractDataProcessor;

import java.util.Map;

/**
 * Delete the data from all table where invalid =1;
 *
 * @author mengyan
 */
public class CheckTableDataProcessor extends AbstractDataProcessor {
    @Override
    public String getId() {
        return "CheckTableDataProcessor";
    }

    public CheckTableDataProcessor(MergeClient mergeClient) {
        super(mergeClient);
    }

    @Override
    public boolean execute() throws Exception {
        Log.getDatabaseLogger().info("开始检查数据表结构");
        DbInfo sourceDbInfo = this.mergeClient.getSourceDbInfo();
        DbInfo targetDbInfo = this.mergeClient.getTargetDbInfo();

        Map<String, DbTable> sourceTables = sourceDbInfo.getAllTables();
        Map<String, DbTable> targetTables = targetDbInfo.getAllTables();
        for (Map.Entry<String, DbTable> kv : sourceTables.entrySet()) {
            if (!targetTables.containsKey(kv.getKey())) {
                Log.getDatabaseLogger().error("目标数据库不包含数据表: {}", kv.getKey());
                return false;
            }
        }

        for (Map.Entry<String, DbTable> kv : targetTables.entrySet()) {
            if (!sourceTables.containsKey(kv.getKey())) {
                Log.getDatabaseLogger().error("源数据库不包含数据表: {}", kv.getKey());
                return false;
            }
        }

        Log.getDatabaseLogger().info("数据表结构检查结束");
        return true;
    }
}
