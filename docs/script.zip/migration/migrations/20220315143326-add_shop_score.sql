
-- +migrate Up
ALTER TABLE `shop` ADD `score` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '商店累计消费积分' AFTER `stage_id`;

-- +migrate Down
ALTER TABLE `shop` DROP `score`;