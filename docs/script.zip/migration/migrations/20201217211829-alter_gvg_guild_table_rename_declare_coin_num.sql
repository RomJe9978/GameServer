
-- +migrate Up
ALTER TABLE gvg_guild CHANGE `declare_num` `declare_coin_num` int(11) NOT NULL DEFAULT '0' COMMENT '宣战币数量';

-- +migrate Down
