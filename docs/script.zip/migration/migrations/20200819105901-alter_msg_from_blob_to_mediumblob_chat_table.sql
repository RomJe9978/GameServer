
-- +migrate Up
ALTER TABLE `chat` MODIFY `msg` mediumblob;

-- +migrate Down
ALTER TABLE `chat` MODIFY `msg` blob;