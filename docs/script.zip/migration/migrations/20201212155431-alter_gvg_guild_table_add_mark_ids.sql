
-- +migrate Up
ALTER TABLE `gvg_city` ADD `mark_ids` mediumtext COMMENT '各公会对该城池标记' AFTER `defender_teams`;

-- +migrate Down
ALTER TABLE `gvg_city` DROP COLUMN `mark_ids`;