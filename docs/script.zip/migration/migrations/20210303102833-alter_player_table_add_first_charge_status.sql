
-- +migrate Up
ALTER TABLE `player` ADD `first_charge_status` int (11) not null DEFAULT 0  COMMENT '首充奖励领取状态，0代表未完成首充，1代表已经完成未领取，2代表已经完成并领取';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `first_charge_status`;