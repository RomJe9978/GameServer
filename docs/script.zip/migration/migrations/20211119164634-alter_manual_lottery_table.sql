
-- +migrate Up
ALTER TABLE `activity_manual_lottery` ADD `reset_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '重置次数' AFTER `lottery_id`;

-- +migrate Down
ALTER TABLE `activity_manual_lottery` DROP `reset_times`;
