
-- +migrate Up
ALTER TABLE `hero` ADD `used_skin_id` INT UNSIGNED NULL DEFAULT 0 COMMENT '英雄正在使用的皮肤id' AFTER `skill_list`; 
ALTER TABLE `hero` ADD `activated_skin_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '英雄激活的皮肤列表' AFTER `used_skin_id`;
-- +migrate Down
ALTER TABLE `hero` DROP COLUMN `used_skin_id`;
ALTER TABLE `hero` DROP COLUMN `activated_skin_list`;
