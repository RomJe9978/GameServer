-- +migrate Up
ALTER TABLE `story_email` ADD `end_at` int(10)  NOT NULL default '0' COMMENT '结束时间';

-- +migrate Down
ALTER TABLE `story_email` DROP COLUMN `end_at`;
