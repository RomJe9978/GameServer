
-- +migrate Up
ALTER TABLE `house` ADD COLUMN `v2_dress_json` text COMMENT 'v2服饰信息' AFTER `temp_attribute_list`;
ALTER TABLE `house` ADD COLUMN `v2_schedule_json` text COMMENT 'v2行程信息' AFTER `v2_dress_json`;
ALTER TABLE `house` ADD COLUMN `v2_special_schedule_json` text COMMENT 'v2特殊行程信息' AFTER `v2_schedule_json`;

-- +migrate Down
ALTER TABLE `house` DROP `v2_dress_json`;
ALTER TABLE `house` DROP `v2_schedule_json`;
ALTER TABLE `house` DROP `v2_special_schedule_json`;