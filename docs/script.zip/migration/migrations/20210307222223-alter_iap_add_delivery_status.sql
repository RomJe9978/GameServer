
-- +migrate Up
ALTER TABLE `iap` ADD `delivery_status` int (11) not null DEFAULT 0  COMMENT '发货状态，0：未发货 1：已发货 2：已补发 3：订单校验失败';

-- +migrate Down
ALTER TABLE `iap` DROP COLUMN `delivery_status`;