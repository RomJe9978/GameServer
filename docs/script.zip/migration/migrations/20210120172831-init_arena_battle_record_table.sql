
-- +migrate Up
CREATE TABLE `arena_battle_record` (
  `battle_id` bigint(20) unsigned NOT NULL COMMENT '快照所属玩家ID',
  `type` int(11) DEFAULT NULL COMMENT '战斗类型',
  `map_id` int(11) DEFAULT NULL COMMENT '关卡ID',
  `version` int(11) NOT NULL DEFAULT '1' COMMENT '快照数据版本',
  `data` mediumblob COMMENT '快照二进制数据',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`battle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `arena_battle_record`;