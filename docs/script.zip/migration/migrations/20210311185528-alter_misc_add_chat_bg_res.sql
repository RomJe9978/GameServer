-- +migrate Up
ALTER TABLE `misc` ADD `chat_bg_res` mediumtext  COMMENT '聊天背景';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `chat_bg_res`;
