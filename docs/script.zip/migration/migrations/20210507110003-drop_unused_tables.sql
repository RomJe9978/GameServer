-- +migrate Up

DROP TABLE IF EXISTS `activity_draw`;
DROP TABLE IF EXISTS `player_task`;
DROP TABLE IF EXISTS `player_scratch`;

-- +migrate Down
