
-- +migrate Up
ALTER TABLE `misc` ADD `hero_like_stage` TEXT COMMENT '玩家卡牌喜好度答题';

-- +migrate Down
ALTER TABLE `misc` DROP `hero_like_stage`;
