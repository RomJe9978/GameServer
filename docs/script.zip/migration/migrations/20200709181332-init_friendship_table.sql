
-- +migrate Up

CREATE TABLE IF NOT EXISTS `friendship` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `friend_list` varchar(255) DEFAULT NULL COMMENT '好友列表',
  `apply_list` varchar(255) DEFAULT NULL COMMENT '申请列表',
  `black_list` varchar(255) DEFAULT NULL COMMENT '黑名单',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '删除标记',
  PRIMARY KEY(`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='好友关系表';

-- +migrate Down
DROP TABLE IF EXISTS `friendship`;

