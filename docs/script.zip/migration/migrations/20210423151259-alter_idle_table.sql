
-- +migrate Up
ALTER TABLE `idle` ADD `guild_activeness_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '添加工会活跃度次数' AFTER `total_secs`;

-- +migrate Down
ALTER TABLE `idle` DROP `guild_activeness_times`;
