
-- +migrate Up
CREATE TABLE IF NOT EXISTS `fishing` (
      `player_id`           bigint(21)  unsigned    NOT NULL COMMENT '玩家ID',
      `refresh_times`       int(11)     unsigned    NOT NULL DEFAULT '0' COMMENT '刷新次数',
      `daily_refresh_time`  int(11)     unsigned    NOT NULL DEFAULT '0' COMMENT '刷新时间戳',
      `illustration_id`     int(11)     unsigned    NOT NULL DEFAULT '0' COMMENT '钓鱼图鉴ID',
      `illustration_score`  int(11)     unsigned    NOT NULL DEFAULT '0' COMMENT '钓鱼图鉴积分',
      `rewarded`            tinyint(1)              NOT NULL DEFAULT '0' COMMENT '图鉴是否领奖',
      `got_fish`            text CHARACTER SET utf8 COMMENT '获得的鱼列表',
      `update_at`           timestamp               NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at`           timestamp NULL DEFAULT NULL COMMENT  '创建时间',
      `invalid`             tinyint(4)              NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts`           int(11)                 NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts`           int(11)                 NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `fish_pond` (
      `player_id`               bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `pond_template_id`        int(11) unsigned NOT NULL DEFAULT '0' COMMENT '鱼塘模板id',
      `level_id`                int(11) unsigned NOT NULL DEFAULT '0' COMMENT '鱼塘等级ID',
      `worker_template_id`      int(11) unsigned NOT NULL DEFAULT '0' COMMENT '小人id',
      `total_fish_count`        int(11) unsigned NOT NULL DEFAULT '0' COMMENT '鱼数量',
      `total_collection_count`  int(11) unsigned NOT NULL DEFAULT '0' COMMENT '收藏品数量',
      `total_item_count`        int(11) unsigned NOT NULL DEFAULT '0' COMMENT '其他道具数量',
      `fish`                    text CHARACTER SET utf8 COMMENT '鱼列表',
      `collection`              text CHARACTER SET utf8 COMMENT '收藏品列表',
      `items`                   text CHARACTER SET utf8 COMMENT '其他道具列表',
      `update_at`               timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at`               timestamp NULL DEFAULT NULL COMMENT '创建时间',
      `invalid`                 tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts`               int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts`               int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`,`pond_template_id`),
      KEY `idx_update_at` (`update_ts`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `fishing`;
DROP TABLE IF EXISTS `fishpond`;
