
-- +migrate Up
CREATE TABLE `tiles_game` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `game_id` int(11) NOT NULL DEFAULT '0' COMMENT '游戏id',
  `left_power` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '剩余体力',
  `game_list` text COMMENT '关卡信息',
  `refresh_at` int(11) DEFAULT NULL COMMENT '刷新时间',
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`game_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='三消小游戏';
-- +migrate Down
