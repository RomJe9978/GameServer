-- +migrate Up
ALTER TABLE `gvg_guild` ADD `score` bigint(20)  NOT NULL default '0' COMMENT '积分';
ALTER TABLE `gvg_guild` ADD `total_score` bigint(20)  NOT NULL default '0' COMMENT '本赛季该公会总积分';

-- +migrate Down
ALTER TABLE `gvg_guild` DROP COLUMN `score`;
ALTER TABLE `gvg_guild` DROP COLUMN `total_score`;