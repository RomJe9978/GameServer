
-- +migrate Up
CREATE TABLE IF NOT EXISTS `house_furniture` (
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `amount` int(11) NOT NULL DEFAULT '1' COMMENT '代币数量',
      `data` text COMMENT '家具布局',
      `received_like_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '获得的点赞数量',
      `daily_like_list` text COMMENT '每日点赞过的玩家列表',
      `receive_ts` int(11) NOT NULL DEFAULT '0' COMMENT '同步代币时间戳',
      `pickup_ts` int(11) NOT NULL DEFAULT '0' COMMENT '上次领奖时间戳',
      `max_ts` int(11) NOT NULL DEFAULT '0' COMMENT '最大可领取奖励时间戳',
      `visit_list` text COMMENT '访问列表',
      `daily_sent_like_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '获得的点赞数量',
      `refresh_ts` int(11) NOT NULL DEFAULT '0' COMMENT '上次刷新时间戳',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
      `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `house` (
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL COMMENT '角色配置ID',
  `used` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在使用中',
  `dress_json` text COMMENT '穿戴信息',
  `schedule_json` text COMMENT '行程信息',
  `schedule_attribute_list` text COMMENT '行程属性',
  `schedule_reward` text COMMENT '未领取的行程奖励',
  `special_schedule_list` text COMMENT '已经触发过的特殊行程列表',
  `today_already_drop_special` tinyint(1) NOT NULL DEFAULT '0' COMMENT '今天是否已经掉落过特殊行程',
  `special_schedule_json` text COMMENT '待处理的特殊行程',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  `break_level` int(11) NOT NULL DEFAULT '0' COMMENT '突破等级',
  `favor` int(11) NOT NULL DEFAULT '0' COMMENT '喜爱度',
  `favor_level` int(11) DEFAULT NULL COMMENT '好感度等级',
  `today_interactive_count` int(11) DEFAULT NULL COMMENT '今日互动使用次数',
  `group_mood_id` int(11) DEFAULT NULL COMMENT '互动组id',
  `mood_id` int(11) DEFAULT NULL COMMENT '心情id',
  `refresh_at` int(11) DEFAULT NULL COMMENT '刷新时间',
  `deal_with_day` int(11) DEFAULT NULL,
  `temp_attribute_list` text COMMENT '行程属性',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `house_furniture`;
DROP TABLE IF EXISTS `house`;

