
-- +migrate Up
CREATE TABLE `activity_normal_lottery` (
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `lottery_info` text COMMENT '次数信息',
  `count` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '已抽奖次数',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='常规活动-抽奖';

-- +migrate Down
DROP TABLE IF EXISTS `activity_normal_lottery`;

