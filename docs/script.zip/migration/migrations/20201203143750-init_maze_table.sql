
-- +migrate Up
CREATE TABLE `maze` (
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `level` int(11) NOT NULL DEFAULT '0',
  `refresh_time` int(11) DEFAULT NULL COMMENT '刷新时间',
  `next_refresh_time` int(11) NOT NULL DEFAULT '0',
  `unlock_difficulty` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否解锁困难模式',
  `unlock_hell_difficulty` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否解锁地狱模式',
  `current_layer` int(11) NOT NULL DEFAULT '0',
  `current_point` int(11) NOT NULL DEFAULT '0',
  `max_layer` int(11) DEFAULT NULL,
  `map_id` int(11) DEFAULT NULL,
  `points` mediumtext COMMENT '地图点信息',
  `unchosen_cards` mediumtext COMMENT '待选择的技能卡牌信息',
  `card_bag` mediumtext COMMENT '技能卡包',
  `warriors` mediumblob COMMENT '玩家卡牌镜像信息',
  `monsters` mediumblob COMMENT '关卡怪信息',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `maze`;