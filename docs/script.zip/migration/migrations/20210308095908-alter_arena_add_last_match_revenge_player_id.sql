
-- +migrate Up
ALTER TABLE `arena` ADD `last_match_revenge_player_id` bigint (20) not null DEFAULT 0  COMMENT '上次匹配到的反击对手的ID';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `last_match_revenge_player_id`;