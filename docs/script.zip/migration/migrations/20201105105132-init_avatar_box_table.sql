
-- +migrate Up
CREATE TABLE `avatar_box` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家ID',
  `data` mediumtext COMMENT '头像框数据',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `avatar_box`;