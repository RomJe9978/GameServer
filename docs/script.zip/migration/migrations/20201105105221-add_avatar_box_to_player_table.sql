-- +migrate Up
ALTER TABLE `player` ADD COLUMN `avatar_box` int(11) NOT NULL DEFAULT '0' COMMENT '头像框ID' AFTER `name`;

-- +migrate Down

ALTER TABLE `player` DROP COLUMN `avatar_box`;