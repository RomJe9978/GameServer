
-- +migrate Up
CREATE TABLE `cs_arena` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家ID',
  `challenge_times` int(11) NOT NULL DEFAULT '0' COMMENT '当日已挑战次数',
  `max_stage` int(11) NOT NULL DEFAULT '0' COMMENT '历史最高段位',
  `buy_times` int(11) NOT NULL DEFAULT '0' COMMENT '购买次数',
  `reward_stage_list` mediumtext COMMENT '奖励段位列表',
  `to_sent_defeated_records` text,
  `last_update_formation_power` bigint(20) NOT NULL DEFAULT '0',
  `refresh_at` int(11) NOT NULL DEFAULT '0' COMMENT '竞技场数据刷新时间',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`player_id`),
  KEY `invalid` (`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `cs_arena`;