
-- +migrate Up
ALTER TABLE `new_year_flip_card` ADD `daily_score_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '每日翻盘信息' AFTER `infos`, ADD `issue_no` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '期号' AFTER `daily_score_info`;

-- +migrate Down
ALTER TABLE `new_year_flip_card` DROP `issue_no`;
ALTER TABLE `new_year_flip_card` DROP `daily_score_info`;
