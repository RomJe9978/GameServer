
-- +migrate Up
CREATE TABLE `title` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '头像框数据',
  `expire_at` int(11) NOT NULL DEFAULT '0' COMMENT '头像框数据',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE `player` ADD COLUMN `title` int(11) NOT NULL DEFAULT 0;

-- +migrate Down
DROP TABLE IF EXISTS `title`;
ALTER TABLE `player` DROP `title`;