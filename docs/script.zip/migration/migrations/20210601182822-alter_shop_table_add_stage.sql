-- +migrate Up
ALTER TABLE `shop` ADD `stage_id` int (11) not null DEFAULT 0 COMMENT '活动商店期数';

-- +migrate Down
ALTER TABLE `shop` DROP `stage_id`;
