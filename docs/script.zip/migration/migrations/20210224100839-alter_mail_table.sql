
-- +migrate Up
ALTER TABLE `mail` ADD `url` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '超链接跳转' AFTER `gmid`, ADD `url_name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '超链接名字标题' AFTER `url`;

-- +migrate Down
ALTER TABLE `mail` DROP `url`, DROP `url_name`;
