-- +migrate Up
ALTER TABLE `hero` ADD `dragon_soul_level` INT  NOT NULL DEFAULT '0' COMMENT '激活的龙魂等级' AFTER `activated_skin_list`;

-- +migrate Down
ALTER TABLE `hero` DROP `dragon_soul_level`;