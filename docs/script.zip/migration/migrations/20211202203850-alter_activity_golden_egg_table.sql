
-- +migrate Up
ALTER TABLE `activity_golden_egg` ADD `infos` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '砸蛋数据' AFTER `data`;
ALTER TABLE `activity_golden_egg` ADD `round` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '砸蛋第几轮' AFTER `infos`;

-- +migrate Down
ALTER TABLE `activity_golden_egg` DROP `round`;
ALTER TABLE `activity_golden_egg` DROP `infos`;
