
-- +migrate Up
ALTER TABLE `misc` ADD `offline_days` INT NOT NULL DEFAULT '0' COMMENT '离线天数(用于回访奖励，0点刷新)' AFTER `get_important_mail_once`;
ALTER TABLE `misc` ADD `offline_days_refresh_at` TIMESTAMP NULL DEFAULT NULL COMMENT '离线天数刷新时间' AFTER `offline_days`;

-- +migrate Down
ALTER TABLE `misc` DROP `offline_days_refresh_at`;
ALTER TABLE `misc` DROP `offline_days`;