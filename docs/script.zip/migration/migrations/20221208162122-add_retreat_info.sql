
-- +migrate Up
CREATE TABLE `retreat` (
  `id` bigint(21) unsigned NOT NULL,
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
  `type` int(11) NOT NULL COMMENT '阵容类型',
  `retreat_info` mediumtext COMMENT '先军撤退信息',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NOT NULL DEFAULT '2000-01-01 00:00:00' COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- +migrate Down
DROP TABLE IF EXISTS `retreat`;
