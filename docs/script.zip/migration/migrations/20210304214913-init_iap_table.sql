
-- +migrate Up
CREATE TABLE `iap` (
  `game_order_id` varchar(128) NOT NULL DEFAULT '' COMMENT '游戏订单ID',
  `order_id` varchar(128) NOT NULL DEFAULT '' COMMENT 'SDK平台订单ID',
  `player_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家ID',
  `ltid` varchar(128) NOT NULL DEFAULT '' COMMENT '龙腾ID',
  `server_id` int(11) DEFAULT NULL COMMENT '服务器ID',
  `pay_channel` int(11) NOT NULL DEFAULT '0' COMMENT '支付渠道（1:苹果支付，2：谷歌支付）',
  `product_id` varchar(128) NOT NULL DEFAULT '0' COMMENT '产品ID',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `goods_price` int(11) NOT NULL DEFAULT '0' COMMENT '商品价格',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `iap`;
