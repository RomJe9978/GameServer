
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `guild_activeness_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '已增加工会活跃度次数' AFTER `success_times`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `guild_activeness_times`;
