
-- +migrate Up
ALTER TABLE `task` ADD `newbie_tasks` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '新手任务列表' AFTER `weekly_rewards`, ADD `newbie_activeness` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '新手任务活跃度' AFTER `newbie_tasks`, ADD `newbie_rewards` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '新手任务奖励' AFTER `newbie_activeness`;

-- +migrate Down
ALTER TABLE `task` DROP `newbie_tasks`, `newbie_activeness`, `newbie_rewards`;
