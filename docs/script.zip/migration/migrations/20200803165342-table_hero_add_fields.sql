
-- +migrate Up

ALTER TABLE `hero` ADD `favor` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '好感度' AFTER `template_id`, ADD `stage_info` BLOB NULL DEFAULT NULL COMMENT '进阶信息' AFTER `favor`, ADD `refine_info` BLOB NULL DEFAULT NULL COMMENT '育成信息' AFTER `stage_info`, ADD `skill_list` BLOB NULL DEFAULT NULL COMMENT '技能列表' AFTER `refine_info`;

-- +migrate Down
ALTER TABLE `hero` DROP COLUMN `favor`;
ALTER TABLE `hero` DROP COLUMN `stage_info`;
ALTER TABLE `hero` DROP COLUMN `refine_info`;
ALTER TABLE `hero` DROP COLUMN `skill_list`;
