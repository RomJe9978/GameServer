
-- +migrate Up
ALTER TABLE `guild` ADD `applicants` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工会申请列表' AFTER `last_rename_at`;


-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `applicants`;
