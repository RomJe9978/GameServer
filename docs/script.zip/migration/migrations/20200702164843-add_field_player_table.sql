
-- +migrate Up
ALTER TABLE `player` ADD COLUMN `level` int(11) NOT NULL DEFAULT '0' COMMENT '玩家等级' AFTER `server_id`;
ALTER TABLE `player` ADD COLUMN `exp` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家经验' AFTER `level`;
ALTER TABLE `player` ADD COLUMN `gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家元宝持有量' AFTER `exp`;
ALTER TABLE `player` ADD COLUMN `coin` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家金币持有量' AFTER `gold`;
ALTER TABLE `player` ADD COLUMN `vip_level` int(11) NOT NULL DEFAULT '0' COMMENT 'vip 等级' AFTER `coin`;
ALTER TABLE `player` ADD COLUMN `vip_exp` bigint(20) NOT NULL DEFAULT '0' COMMENT 'vip 经验' AFTER `vip_level`;

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `level`;
ALTER TABLE `player` DROP COLUMN `exp`;
ALTER TABLE `player` DROP COLUMN `gold`;
ALTER TABLE `player` DROP COLUMN `coin`;
ALTER TABLE `player` DROP COLUMN `vip_level`;
ALTER TABLE `player` DROP COLUMN `vip_exp`;


