
-- +migrate Up
ALTER TABLE `player` ADD `fake_rate` int (10) not null DEFAULT 0  COMMENT '模拟器标识';
ALTER TABLE `player` ADD `country_code` varchar(256) default null COMMENT '国家码';
ALTER TABLE `player` ADD `lang` varchar(256) default null COMMENT '语言码';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `fake_rate`;
ALTER TABLE `player` DROP COLUMN `country_code`;
ALTER TABLE `player` DROP COLUMN `lang`;