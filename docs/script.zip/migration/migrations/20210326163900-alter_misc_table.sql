
-- +migrate Up
ALTER TABLE `misc` CHANGE `signed_count` `signed_count` BIGINT UNSIGNED NOT NULL DEFAULT '0';

-- +migrate Down
ALTER TABLE `misc` CHANGE `signed_count` `signed_count` INT UNSIGNED NOT NULL DEFAULT '0';
