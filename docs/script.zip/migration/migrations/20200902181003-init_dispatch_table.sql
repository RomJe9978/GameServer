
-- +migrate Up
CREATE TABLE IF NOT EXISTS `dispatch` (
      `player_id` bigint(20) UNSIGNED NOT NULL COMMENT '玩家唯一id',
      `dispatch_level` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '派遣等级',
      `dispatch_star` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当前派遣等级下的星级',
      `box_index` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '领取宝箱索引',
      `task_data` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '派遣任务json数据',
      `refresh_date` int(10) NULL DEFAULT NULL COMMENT '系统刷新日期',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '删除标记',
      PRIMARY KEY (`player_id`) USING BTREE
    
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '派遣表';

-- +migrate Down
DROP TABLE IF EXISTS `dispatch`;
