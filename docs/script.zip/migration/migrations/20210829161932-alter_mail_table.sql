
-- +migrate Up
ALTER TABLE `mail` ADD `version` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮件更新版本号' AFTER `url_name`;

-- +migrate Down
ALTER TABLE `mail` DROP `version`;
