
-- +migrate Up
ALTER TABLE `misc` ADD `pass_main_mission_fail` TEXT COMMENT '主线通关失败次数记录';

-- +migrate Down
ALTER TABLE `misc` DROP `pass_main_mission_fail`;