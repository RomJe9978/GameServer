
-- +migrate Up
CREATE TABLE IF NOT EXISTS `global_data` (
 `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动id',
 `data` text COMMENT '活动数据',
 `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
 `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
 `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '数据无效标记',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全局数据表';

-- +migrate Down
DROP TABLE IF EXISTS `global_data`;
