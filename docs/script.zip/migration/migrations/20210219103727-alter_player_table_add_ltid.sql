-- +migrate Up
ALTER TABLE `player` ADD `ltid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '龙腾ID';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `ltid`;