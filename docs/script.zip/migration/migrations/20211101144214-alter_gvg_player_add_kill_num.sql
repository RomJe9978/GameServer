
-- +migrate Up
ALTER TABLE `gvg_player` ADD `kill_num` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '本活动周期累计击杀';
ALTER TABLE `gvg_player` ADD `dispatch_num` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '本活动周期累计派遣';
ALTER TABLE `gvg_player` ADD `gvg_rank_activity_id` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '活动ID';

-- +migrate Down
ALTER TABLE `gvg_player` DROP `kill_num`;
ALTER TABLE `gvg_player` DROP `dispatch_num`;
ALTER TABLE `gvg_player` DROP `gvg_rank_activity_id`;
