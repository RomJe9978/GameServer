
-- +migrate Up
ALTER TABLE `global_mail` ADD `url_name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '链接名称' AFTER `url`;


-- +migrate Down
ALTER TABLE DROP `url_name`;
