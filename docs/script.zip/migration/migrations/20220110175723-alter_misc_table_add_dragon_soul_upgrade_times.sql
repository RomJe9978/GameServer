
-- +migrate Up
ALTER TABLE `misc` ADD `dragon_soul_upgrade_daily_times` INT NOT NULL DEFAULT '0' COMMENT '龙魂当日升级次数' AFTER `get_important_mail_once`;
ALTER TABLE `misc` ADD `dragon_soul_upgrade_day` INT NOT NULL DEFAULT '0' COMMENT '龙魂升级日期' AFTER `get_important_mail_once`;

-- +migrate Down
ALTER TABLE `misc` DROP `dragon_soul_upgrade_daily_times`;
ALTER TABLE `misc` DROP `dragon_soul_upgrade_day`;