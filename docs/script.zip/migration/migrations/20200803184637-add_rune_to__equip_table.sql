
-- +migrate Up
ALTER TABLE `equip` ADD `rune_id` int(11) NOT NULL DEFAULT '0' COMMENT '铭文ID' AFTER `enhance_exp`;
ALTER TABLE `equip` ADD `rune_level` int(11) NOT NULL DEFAULT '0' COMMENT '铭文等级' AFTER `rune_id`;

-- +migrate Down
ALTER TABLE `equip` DROP COLUMN `rune_id`;
ALTER TABLE `equip` DROP COLUMN `rune_level`;