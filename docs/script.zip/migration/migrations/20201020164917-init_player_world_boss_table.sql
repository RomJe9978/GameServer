
-- +migrate Up
CREATE TABLE `player_world_boss` (
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `current_stage` int(11) DEFAULT NULL COMMENT '当前挑战的世界boss',
  `max_damage` bigint(20) DEFAULT NULL COMMENT '本期最大伤害值',
  `last_max_damage` bigint(11) DEFAULT NULL COMMENT '上期最大伤害值',
  `challenge_data` mediumtext COMMENT '当前世界boss挑战记录JSON字符串',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `player_world_boss`;
