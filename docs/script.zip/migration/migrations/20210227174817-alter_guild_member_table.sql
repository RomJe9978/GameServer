
-- +migrate Up
ALTER TABLE `guild_member` ADD `weekly_activeness` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '周活跃度' AFTER `activeness_data`;

-- +migrate Down
ALTER TABLE `guild_member` DROP `weekly_activeness`;
