-- +migrate Up
ALTER TABLE `guild` ADD `last_activeness` int(10)  NOT NULL default '0' COMMENT '昨日激活信息';

-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `last_activeness`;