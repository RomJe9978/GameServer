-- +migrate Up
ALTER TABLE `gvg_guild` ADD `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公会建国称号';
ALTER TABLE `gvg_guild` ADD `flag` int(11) NOT NULL DEFAULT '0' COMMENT '公会旗帜';

-- +migrate Down
ALTER TABLE `gvg_guild` DROP COLUMN `title`;
ALTER TABLE `gvg_guild` DROP COLUMN `flag`;