
-- +migrate Up
ALTER TABLE `hero` ADD `shown_skin_id` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '展示的皮肤id' AFTER `used_skin_id`;

UPDATE `hero` SET `shown_skin_id` = `used_skin_id`;


-- +migrate Down
ALTER TABLE `hero` DROP `shown_skin_id`;
