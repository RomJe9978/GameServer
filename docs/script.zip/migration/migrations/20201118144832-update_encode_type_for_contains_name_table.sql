
-- +migrate Up
ALTER TABLE player MODIFY name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL  DEFAULT NULL COMMENT '玩家名称';
ALTER TABLE player MODIFY sign varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL  DEFAULT NULL COMMENT '玩家名称';
ALTER TABLE guild MODIFY name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL  DEFAULT NULL COMMENT '公会名称';

-- +migrate Down
