
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `date_int` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '参与组队副本的日期' AFTER `battle_record`, ADD `success_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '每日胜利次数' AFTER `date_int`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `date_int`, DROP `success_times`;
