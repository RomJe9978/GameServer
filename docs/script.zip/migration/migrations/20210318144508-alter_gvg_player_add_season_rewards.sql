-- +migrate Up
ALTER TABLE `gvg_player` ADD `season_rewards` MEDIUMTEXT   COMMENT '赛季奖励';

-- +migrate Down
ALTER TABLE `gvg_player` DROP COLUMN `season_rewards`;

