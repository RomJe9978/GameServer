
-- +migrate Up
CREATE TABLE IF NOT EXISTS `dungeon` (
  `id` bigint(20) unsigned NOT NULL COMMENT '副本唯一id',
  `dungeon_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '副本模板id',
  `type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '副本类型',
  `star` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '星级',
  `difficulty` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '难度',
  `refresh_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次刷新时间戳',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '生成时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='普通副本表';

-- +migrate Down
DROP TABLE IF EXISTS `dungeon`;
