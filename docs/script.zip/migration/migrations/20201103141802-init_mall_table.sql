
-- +migrate Up
CREATE TABLE `mall` (
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `mall_type` int(11) NOT NULL DEFAULT '0' COMMENT '充值商城类型',
  `level` int(11) NOT NULL DEFAULT '0',
  `refresh_time` int(11) DEFAULT NULL COMMENT '商店刷新时间',
  `next_refresh_time` int(11) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `item_list` varchar(512) DEFAULT NULL COMMENT '本期商品列表',
  `buy_list` mediumtext COMMENT '购买数据JSON记录',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`,`mall_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `mall`;
