
-- +migrate Up
CREATE TABLE IF NOT EXISTS `idle_fight` (
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `formation` text COMMENT '阵位信息',
      `fetters` text COMMENT '羁绊信息',
      `activity_timer_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动timerid',
      `mission_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '挂机关卡id',
      `max_chapter` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大通关章',
      `receive_ts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取离线奖励时间戳',
      `begin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '战斗开始时间戳',
      `end` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '战斗结束时间戳',
      `kill_num` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '击杀怪数量',
      `mode` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '挂机模式',
      `loops` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '循环次数',
      `reason` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '循环模式原因',
      `reward_list` text COMMENT '已领取通关奖励',
      `idle_rewards` text COMMENT '挂机累积奖励',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
      `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `idle_fight`;
