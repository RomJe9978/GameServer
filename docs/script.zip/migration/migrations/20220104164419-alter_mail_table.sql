
-- +migrate Up
ALTER TABLE `mail` ADD `platform_version` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '强更邮件版本号' AFTER `version`;
ALTER TABLE `global_mail` ADD `platform_version` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮件强更版本号' AFTER `version`;

-- +migrate Down
ALTER TABLE `mail` DROP `platform_version`;
ALTER TABLE `global_mail` DROP `platform_version`;
