
-- +migrate Up
ALTER TABLE `misc` ADD `treasure_pool_daily_reward_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '领取宝物抽奖奖励次数' AFTER `monthly_card_rewarded_box`;

-- +migrate Down
ALTER TABLE `misc` DROP `treasure_pool_daily_reward_times`;
