
-- +migrate Up
CREATE TABLE IF NOT EXISTS `friend_fight_battle_record` (
  `battle_id` bigint(21) unsigned NOT NULL COMMENT '战斗ID',
  `attacker` mediumblob COMMENT '好友切磋攻击方',
  `defender` mediumblob COMMENT '好友切磋防守方',
  `winner_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '胜利方ID',
  `attacker_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '攻击方ID',
  `defender_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '防守方ID',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) DEFAULT '0' COMMENT '更新时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`battle_id`),
  KEY `attacker_id` (`attacker_id`),
  KEY `defender_id` (`defender_id`),
  KEY `idx_update_at` (`update_ts`),
  KEY `idx_create_at` (`create_at`),
  KEY `idx_create_ts` (`create_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `friend_fight_battle_record`;