
-- +migrate Up
CREATE TABLE IF NOT EXISTS `player_dungeon` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `challenge_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '挑战次数',
  `challenge_dungeon_times` varchar(255) DEFAULT NULL COMMENT '普通副本挑战次数',
  `action_power` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '剩余行动力',
  `refresh_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次刷新时间戳',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '生成时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='普通副本表';

-- +migrate Down
DROP TABLE IF EXISTS `player_dungeon`;
