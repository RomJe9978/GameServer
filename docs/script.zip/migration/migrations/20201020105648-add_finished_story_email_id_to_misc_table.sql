
-- +migrate Up

ALTER TABLE `misc` ADD COLUMN `finished_story_email_id` mediumtext COMMENT '已完成的唯一剧情邮件ID' AFTER `drop_times`;

-- +migrate Down

ALTER TABLE `misc` DROP COLUMN `finished_story_email_id`;
