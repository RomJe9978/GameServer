
-- +migrate Up
CREATE TABLE `system_buff` (
  `id` bigint(21) unsigned NOT NULL COMMENT 'buffID',
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '配置id',
  `expire_at` int(11) DEFAULT NULL COMMENT '过期时间戳',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='system buff表';

-- +migrate Down
DROP TABLE IF EXISTS `buff`;