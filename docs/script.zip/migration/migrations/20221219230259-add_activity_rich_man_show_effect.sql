
-- +migrate Up
ALTER TABLE `rich_man` ADD `show_effect_level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '惠比寿是否展示' AFTER `consume_item`;
-- +migrate Down
ALTER TABLE `rich_man` DROP `show_effect_level`;