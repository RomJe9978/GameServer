
-- +migrate Up
ALTER TABLE `guild` CHANGE `name` `name` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '工会名称';

-- +migrate Down
ALTER TABLE `guild` CHANGE `name` `name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '工会名称';
