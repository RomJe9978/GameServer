
-- +migrate Up
ALTER TABLE `new_activity_task_info` ADD `puzzle_reward_list` TEXT COMMENT '拼图宝箱奖励' AFTER `rewards`;
-- +migrate Down
ALTER TABLE `new_activity_task_info` DROP `puzzle_reward_list`;