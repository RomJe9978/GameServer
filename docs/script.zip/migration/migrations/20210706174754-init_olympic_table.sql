
-- +migrate Up
CREATE TABLE IF NOT EXISTS `olympic` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `indexes` varchar(255) DEFAULT NULL COMMENT '领取列表',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `olympic`;
