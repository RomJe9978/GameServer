
-- +migrate Up
ALTER TABLE `valentine` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '刷新时间戳' AFTER `progress_reward_list`;

-- +migrate Down
ALTER TABLE `valentine` DROP `refresh_at`;
