-- +migrate Up
ALTER TABLE `player` ADD `main_scene_hero` int(10)  NOT NULL default '0' COMMENT '看板娘信息';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `main_scene_hero`;