
-- +migrate Up
ALTER TABLE `player` ADD `guild_id` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '所在工会id' AFTER `vip_exp`;

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `guild_id`;
