
-- +migrate Up
ALTER TABLE `idle` ADD `used_free_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '已使用免费挂机次数' AFTER `refresh_at`;

-- +migrate Down
ALTER TABLE `idle` DROP `used_free_times`;
