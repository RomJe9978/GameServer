
-- +migrate Up
ALTER TABLE `misc` ADD `invite_num` int (10) not null DEFAULT 0  COMMENT '玩家成功邀请玩家数';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `invite_num`;