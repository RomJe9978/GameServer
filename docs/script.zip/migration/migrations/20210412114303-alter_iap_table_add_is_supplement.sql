-- +migrate Up
ALTER TABLE `iap` ADD `is_supplement` tinyint (1) not null DEFAULT 0  COMMENT '当日活跃度';

-- +migrate Down
ALTER TABLE `iap` DROP COLUMN `is_supplement`;