
-- +migrate Up
CREATE TABLE IF NOT EXISTS `battle_pet_info` (
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
      `item_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '繁殖使用的道具',
      `cloning_pet_list` text COMMENT '繁殖宠物id列表',
      `start_ts` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始繁殖时间戳',
      `expired_ts` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '结束繁殖时间戳',
      `create_at` timestamp NULL DEFAULT NULL,
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      `invalid` int(11) NOT NULL DEFAULT '0',
      `create_ts` int(11) NOT NULL DEFAULT '0',
      `update_ts` int(11) NOT NULL DEFAULT '0',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='战宠繁殖信息表';

-- +migrate Down
DROP TABLE IF EXISTS `battle_pet_info`;
