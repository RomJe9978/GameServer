
-- +migrate Up
CREATE TABLE `formation` (
  `id` bigint(20) NOT NULL,
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `type` int(11) NOT NULL COMMENT '阵容类型',
  `name` varchar(128) DEFAULT NULL COMMENT '阵容名字',
  `hero_list` varchar(512) DEFAULT NULL COMMENT '阵容信息',
  `is_default` tinyint(1) DEFAULT NULL COMMENT '是否是默认阵容',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `formation`;