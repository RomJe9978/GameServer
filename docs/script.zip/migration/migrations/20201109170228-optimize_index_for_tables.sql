
-- +migrate Up
ALTER TABLE equip ADD INDEX valid_player (player_id, invalid);
ALTER TABLE formation ADD INDEX valid_player (player_id, invalid);
ALTER TABLE hero ADD INDEX valid_player (player_id, invalid);
ALTER TABLE item ADD INDEX valid_player (player_id, invalid);
ALTER TABLE mail ADD INDEX valid_player (player_id, invalid);
ALTER TABLE mission ADD INDEX valid_player (player_id, invalid);
ALTER TABLE soul ADD INDEX valid_player (player_id, invalid);
ALTER TABLE story_email ADD INDEX valid_player (player_id, invalid);
ALTER TABLE treasure ADD INDEX valid_player (player_id, invalid);

-- +migrate Down
ALTER TABLE equip DROP INDEX valid_player;
ALTER TABLE formation DROP INDEX valid_player;
ALTER TABLE hero DROP INDEX valid_player;
ALTER TABLE item DROP INDEX valid_player;
ALTER TABLE mail DROP INDEX valid_player;
ALTER TABLE mission DROP INDEX valid_player;
ALTER TABLE soul DROP INDEX valid_player;
ALTER TABLE story_email DROP INDEX valid_player;
ALTER TABLE treasure DROP INDEX valid_player;
