
-- +migrate Up

ALTER TABLE `soul` ADD COLUMN `tmp_random_attribute_map` varchar(255) NULL COMMENT '临时洗练属性' AFTER `unique_attribute`;
ALTER TABLE `soul` ADD COLUMN `tmp_unique_attribute` varchar(255) NULL COMMENT '临时洗练属性' AFTER `tmp_random_attribute_map`;

-- +migrate Down
ALTER TABLE `soul` DROP COLUMN `tmp_random_attribute_map`;
ALTER TABLE `soul` DROP COLUMN `tmp_unique_attribute`;
