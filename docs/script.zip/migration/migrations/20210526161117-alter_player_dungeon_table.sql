
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `first_passed_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '\'\'' COMMENT '首次通关副本列表' AFTER `max_difficulty`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `first_passed_list`;
