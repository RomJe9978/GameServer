
-- +migrate Up
CREATE TABLE IF NOT EXISTS `digger` (
      `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
      `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
      `bucket_info` text COMMENT 'worker信息',
      `collect_item_info` text COMMENT '累积采集道具信息',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='挖掘机';

-- +migrate Down
DROP TABLE IF EXISTS `digger`;
