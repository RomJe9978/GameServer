-- +migrate Up
ALTER TABLE `arena` DROP COLUMN `buy_challenge_times`;

-- +migrate Down
ALTER TABLE `arena` ADD `buy_challenge_times` int(10)  NOT NULL default '0' COMMENT '购买挑战次数';
