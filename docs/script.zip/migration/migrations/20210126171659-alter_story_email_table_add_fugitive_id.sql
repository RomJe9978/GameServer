-- +migrate Up
ALTER TABLE `story_email` ADD `fugitive_id` int(10)  NOT NULL default '0' COMMENT '抓捕对象';

-- +migrate Down
ALTER TABLE `story_email` DROP COLUMN `fugitive_id`;
