
-- +migrate Up

ALTER TABLE `formation` ADD COLUMN `sub_type` int(11) NOT NULL DEFAULT '0' COMMENT '阵容子类型' AFTER `type`;

-- +migrate Down

ALTER TABLE `formation` DROP COLUMN `sub_type`;
