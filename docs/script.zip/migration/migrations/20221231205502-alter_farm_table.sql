
-- +migrate Up

ALTER TABLE `farm` ADD `auto` TINYINT(4) UNSIGNED DEFAULT '0' COMMENT '自动播种开关' AFTER `worker_id`;
ALTER TABLE `farm` ADD `plant_queue` text COMMENT '自动播种队列' AFTER `auto`;

-- +migrate Down

ALTER TABLE `farm` DROP `auto`;
ALTER TABLE `farm` DROP `plant_queue`;
