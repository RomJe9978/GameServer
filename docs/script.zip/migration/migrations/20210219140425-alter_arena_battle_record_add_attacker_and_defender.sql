
-- +migrate Up
ALTER TABLE `arena_battle_record` ADD `attacker` MEDIUMBLOB NULL DEFAULT NULL COMMENT '竞技场攻击方';
ALTER TABLE `arena_battle_record` ADD `defender` MEDIUMBLOB NULL DEFAULT NULL COMMENT '竞技场防守方';
ALTER TABLE `arena_battle_record` ADD `winner_id` bigint(20)  NOT NULL default '0' COMMENT '胜利方ID';
ALTER TABLE `arena_battle_record` ADD `attacker_id` bigint(20)  NOT NULL default '0' COMMENT '攻击方ID';
ALTER TABLE `arena_battle_record` ADD `defender_id` bigint(20)  NOT NULL default '0' COMMENT '防守方ID';

-- +migrate Down
ALTER TABLE `arena_battle_record` DROP `attacker`;
ALTER TABLE `arena_battle_record` DROP `defender`;
ALTER TABLE `arena_battle_record` DROP `winner_id`;
ALTER TABLE `arena_battle_record` DROP `attacker_id`;
ALTER TABLE `arena_battle_record` DROP `defender_id`;
