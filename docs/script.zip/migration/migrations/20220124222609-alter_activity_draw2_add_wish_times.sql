
-- +migrate Up
ALTER TABLE `activity_draw2` ADD `wish_times` INT UNSIGNED NOT NULL DEFAULT '0'  COMMENT '卡池buff祝愿领奖次数' AFTER `free_times`;

-- +migrate Down
ALTER TABLE `activity_draw2` DROP `left_wish_times`;
