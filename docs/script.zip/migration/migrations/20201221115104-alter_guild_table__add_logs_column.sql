
-- +migrate Up
ALTER TABLE `guild` ADD `logs` MEDIUMBLOB NULL DEFAULT NULL COMMENT '工会日志' AFTER `authorities`;

-- +migrate Down
ALTER TABLE `guild` DROP `logs`;
