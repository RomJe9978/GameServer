
-- +migrate Up
CREATE TABLE `dig_treasure` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '挖宝id',
  `level` int(10) DEFAULT NULL COMMENT '当前层级',
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总积分',
  `score_rewards` text COMMENT '积分宝箱领取详情json',
  `lucky_level` int(10) DEFAULT NULL COMMENT '幸运层级',
  `flip_rewards` text COMMENT '已经翻开的格子信息json',
  `flip_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '翻牌次数',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='挖宝表';

CREATE TABLE `cake` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '挖宝id',
  `cake_level` int(10) DEFAULT NULL COMMENT '蛋糕等级',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='蛋糕表';

-- +migrate Down
ALTER TABLE `shop` DROP `dig_treasure`;
ALTER TABLE `shop` DROP `cake`;