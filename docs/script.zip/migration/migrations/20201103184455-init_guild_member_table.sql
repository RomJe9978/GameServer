
-- +migrate Up
CREATE TABLE IF NOT EXISTS `guild_member` (
 `player_id` bigint(20) unsigned NOT NULL COMMENT '工会玩家id',
 `guild_id` bigint(20) unsigned NOT NULL COMMENT '工会id',
 `post` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '玩家所在工会的职务',
 `weekly_activeness` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周活跃度',
 `week_first_day` int(10) unsigned DEFAULT NULL COMMENT '本周第一天日期20201031',
 `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
 `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
 `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
 PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工会成员表';

-- +migrate Down
DROP TABLE IF EXISTS `guild_member`;
