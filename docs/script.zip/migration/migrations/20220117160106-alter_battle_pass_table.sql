
-- +migrate Up
ALTER TABLE `battle_pass` ADD `login_at` TIMESTAMP NULL DEFAULT NULL COMMENT '登录战令发放积分日期' AFTER `senior_list`;

-- +migrate Down
ALTER TABLE `battle_pass` DROP `login_at`;
