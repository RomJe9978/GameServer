
-- +migrate Up
CREATE TABLE `gvg_guild` (
  `guild_id` bigint(20) unsigned NOT NULL COMMENT '公会ID',
  `capital_city_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '首都城池的ID',
  `declare_num` int(11) DEFAULT NULL COMMENT '宣战数量',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`guild_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='gvg公会表';

-- +migrate Down
DROP TABLE IF EXISTS `gvg_guild`;