-- +migrate Up
ALTER TABLE `shop` MODIFY `item_list` mediumtext COMMENT '本期商品列表';

-- +migrate Down
ALTER TABLE `shop` MODIFY `item_list` varchar(512);
