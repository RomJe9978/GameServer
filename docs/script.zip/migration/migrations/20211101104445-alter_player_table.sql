
-- +migrate Up
ALTER TABLE `player` ADD `active_login_days` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT 'n天内累积登录天数' AFTER `lang`;

-- +migrate Down
ALTER TABLE `player` DROP `active_login_days`;
