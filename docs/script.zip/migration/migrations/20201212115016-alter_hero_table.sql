
-- +migrate Up
ALTER TABLE `hero` CHANGE `template_id` `master_template_id` INT(11) UNSIGNED NOT NULL COMMENT '英雄母卡Id';


-- +migrate Down
ALTER TABLE `hero` CHANGE `master_template_id` `template_id` INT(11) UNSIGNED NOT NULL COMMENT '英雄模板Id';
