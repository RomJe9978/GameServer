
-- +migrate Up
ALTER TABLE `player` ADD COLUMN `left_rename_times` int(11) NOT NULL DEFAULT '0' COMMENT '剩余免费改名次数' AFTER `name`;

-- +migrate Down

ALTER TABLE `player` DROP COLUMN `left_rename_times`;