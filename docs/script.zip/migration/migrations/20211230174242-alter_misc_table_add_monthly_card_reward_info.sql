-- +migrate Up
ALTER TABLE `misc` ADD `monthly_card_total_login_days` INT NOT NULL DEFAULT '0' COMMENT '月卡累计登陆天数';
ALTER TABLE `misc` ADD `monthly_card_last_login_day` INT NOT NULL DEFAULT '0' COMMENT '月卡上次登录日期';
ALTER TABLE `misc` ADD `monthly_card_rewarded_box` MEDIUMTEXT COMMENT '月卡进度宝箱';
ALTER TABLE `monthly_card` ADD `left_reward_days` INT NOT NULL DEFAULT '0' COMMENT '月卡剩余领取天数';

-- +migrate Down
ALTER TABLE `misc` DROP `monthly_card_total_login_days`;
ALTER TABLE `misc` DROP `monthly_card_last_login_day`;
ALTER TABLE `misc` DROP `monthly_card_rewarded_box`;
ALTER TABLE `monthly_card` DROP `left_reward_days`;