
-- +migrate Up
ALTER TABLE `player` ADD `max_power` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '玩家历史最高战力' AFTER `power`;


-- +migrate Down
ALTER TABLE `player` DROP `max_power`;
