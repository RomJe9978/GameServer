
-- +migrate Up
CREATE TABLE `return_activity` (
  `player_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `times` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '回归活动次数',
  `record` TEXT COMMENT '活动记录',
  `invalid` TINYINT(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  `create_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` TIMESTAMP NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
  `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='回归活动表';

-- +migrate Down
DROP TABLE IF EXISTS `return_activity`;
