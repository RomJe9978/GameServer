
-- +migrate Up
ALTER TABLE `misc` ADD `login_reward_login_days` INT(11) NOT NULL DEFAULT '0' COMMENT '活动登陆奖励累计登陆天数' AFTER `quick_hammer_trial_expired_ts`;
ALTER TABLE `misc` ADD `login_reward_last_login_day` INT(11) NOT NULL DEFAULT '0' COMMENT '活动登陆奖励上次登陆日期' AFTER `login_reward_login_days`;

-- +migrate Down
ALTER TABLE `misc` DROP `login_reward_login_days`;
ALTER TABLE `misc` DROP `login_reward_last_login_day`;