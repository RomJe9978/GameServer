-- +migrate Up
ALTER TABLE `gvg_city` ADD `occupy_ts` int(10)  NOT NULL default '0' COMMENT '占领时间';

-- +migrate Down
ALTER TABLE `gvg_city` DROP COLUMN `occupy_ts`;
