-- +migrate Up
ALTER TABLE `arena` ADD `add_guild_activeness_times` int (11) not null DEFAULT 0  COMMENT '当日增加公会活跃度次数';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `add_guild_activeness_times`;