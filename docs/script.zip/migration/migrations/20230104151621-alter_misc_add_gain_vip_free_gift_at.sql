
-- +migrate Up
ALTER TABLE `misc` ADD `gain_vip_free_gift_at` int(11) NOT NULL DEFAULT '0' COMMENT '领取VIP免费礼包时间';

-- +migrate Down
ALTER TABLE `misc` DROP `gain_vip_free_gift_at`;