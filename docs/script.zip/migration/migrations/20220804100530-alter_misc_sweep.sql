-- +migrate Up
ALTER TABLE `maze` ADD `challenge_type` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '本赛季挑战模式' AFTER `extra_lv`;
ALTER TABLE `maze` ADD `discovery_reward_str` TEXT COMMENT '本赛季一键扫荡奖励信息' AFTER `challenge_type`;
ALTER TABLE `maze` ADD `challenge_top_level` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '通关的最高等级' AFTER `discovery_reward_str`;

-- +migrate Down
ALTER TABLE `maze` DROP `challenge_type`;
ALTER TABLE `maze` DROP `discovery_reward_str`;
ALTER TABLE `maze` DROP `challenge_top_level`;