-- +migrate Up
ALTER TABLE `gvg_city` ADD `attacker_guild_id` bigint(20)  NOT NULL default '0' COMMENT '上次发生战斗时首次攻击方公会ID';
ALTER TABLE `gvg_city` ADD `defender_guild_id` bigint(20)  NOT NULL default '0' COMMENT '上次发生战斗时首次防守方公会ID';
ALTER TABLE `gvg_city` ADD `attack_stage_record` mediumblob COMMENT '上次发生战斗时攻击阶段战斗记录';
ALTER TABLE `gvg_city` ADD `counter_attack_stage_record` mediumblob COMMENT '上次发生战斗时防守阶段战斗记录';

-- +migrate Down
ALTER TABLE `gvg_city` DROP COLUMN `attacker_guild_id`;
ALTER TABLE `gvg_city` DROP COLUMN `defender_guild_id`;
ALTER TABLE `gvg_city` DROP COLUMN `attack_stage_record`;
ALTER TABLE `gvg_city` DROP COLUMN `counter_attack_stage_record`;