
-- +migrate Up
CREATE TABLE IF NOT EXISTS `mall_stage_point` (
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `stage_id` int(11) unsigned DEFAULT '0' COMMENT '赛季id',
  `type` int(11) unsigned DEFAULT '0' COMMENT '类型',
  `points` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '总积分',
  `reward_list` varchar(255) DEFAULT NULL COMMENT '奖励领取列表',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `valid_player` (`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='礼包阶段性奖励';

-- +migrate Down
DROP TABLE IF EXISTS `mall_stage_point`;

