-- +migrate Up
ALTER TABLE `maze` ADD `difficulty` int(11) NOT NULL DEFAULT '0' COMMENT '难度信息' AFTER `map_id`;
ALTER TABLE `maze` ADD `layer_boss` mediumtext COMMENT '每层的boss' AFTER `difficulty`;

-- +migrate Down
ALTER TABLE `maze` DROP COLUMN `difficulty`;
ALTER TABLE `maze` DROP COLUMN `layer_boss`;