
-- +migrate Up
ALTER TABLE `guild` ADD `authorities` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工会权限Json' AFTER `applicants`;

-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `authorities`;
