
-- +migrate Up
ALTER TABLE `player` ADD `name` VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '玩家名字' AFTER `id`, ADD `avatar` VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '玩家头像' AFTER `name`;
ALTER TABLE `player` ADD `title_id` INT UNSIGNED NULL COMMENT '玩家称号id' AFTER `vip_exp`, ADD `sign` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '签名' AFTER `title_id`;

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `name`;
ALTER TABLE `player` DROP COLUMN `avatar`;
ALTER TABLE `player` DROP COLUMN `title_id`;
ALTER TABLE `player` DROP COLUMN `sign`;
