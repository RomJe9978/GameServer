
-- +migrate Up
CREATE TABLE IF NOT EXISTS `fund` (
 `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
 `unlock_senior` tinyint(3) unsigned DEFAULT '0' COMMENT '解锁高定',
 `picked_common_list` varchar(255) DEFAULT NULL COMMENT '普通已领取列表',
 `picked_senior_list` varchar(255) DEFAULT NULL COMMENT '高定已领取列表',
 `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
 `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
 `invalid` tinyint(4) NOT NULL COMMENT '删除标记',
 PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='成长基金';

-- +migrate Down
DROP TABLE IF EXISTS `fund`;
