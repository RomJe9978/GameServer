-- +migrate Up
ALTER TABLE `red_point` ADD `version` int (11) not null DEFAULT 0 COMMENT '红点数据版本';

-- +migrate Down
ALTER TABLE `red_point` DROP `version`;