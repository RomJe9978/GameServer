-- +migrate Up
ALTER TABLE `maze` ADD `backup_warriors` mediumblob COMMENT '备用卡牌信息' AFTER `warriors`;
ALTER TABLE `maze` ADD `backup_monsters` mediumblob COMMENT '备用怪物信息' AFTER `monsters`;
ALTER TABLE `maze` ADD `battle_info` mediumblob COMMENT '未确认的战斗信息' AFTER `backup_monsters`;
ALTER TABLE `maze` ADD `refreshed_events` mediumtext COMMENT '已刷新时间列表' AFTER `unchosen_cards`;

-- +migrate Down
ALTER TABLE `maze` DROP COLUMN `backup_warriors`;
ALTER TABLE `maze` DROP COLUMN `backup_monsters`;
ALTER TABLE `maze` DROP COLUMN `battle_info`;
ALTER TABLE `maze` DROP COLUMN `refreshed_events`;
