
-- +migrate Up
CREATE TABLE `global_misc` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动id',
  `data` mediumtext COMMENT '活动数据',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '数据无效标记',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='全局数据表';

-- +migrate Down
DROP TABLE IF EXISTS `global_misc`;