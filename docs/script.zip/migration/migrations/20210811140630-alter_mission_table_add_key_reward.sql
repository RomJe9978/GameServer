
-- +migrate Up
ALTER TABLE `mission` ADD `reward_missions` MEDIUMTEXT COMMENT '未领取的节点奖励';

-- +migrate Down
ALTER TABLE `mission` DROP `reward_missions`;
