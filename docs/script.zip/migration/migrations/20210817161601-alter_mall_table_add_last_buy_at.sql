-- +migrate Up
ALTER TABLE `mall` ADD `last_buy_at` MEDIUMTEXT COMMENT '最后一次购买时间';

-- +migrate Down
ALTER TABLE `mall` DROP `last_buy_at`;