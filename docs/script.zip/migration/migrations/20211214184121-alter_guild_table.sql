
-- +migrate Up
ALTER TABLE `guild` ADD `free_rename_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '工会免费命名次数' AFTER `last_activeness`;

-- +migrate Down
ALTER TABLE `guild` DROP `free_rename_times`;
