
-- +migrate Up
ALTER TABLE `activity_manual_lottery` CHANGE `guarantee_lottery_info` `guarantee_lottery_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '保底次数';
ALTER TABLE `activity_manual_lottery` CHANGE `group_list` `group_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '奖品组';

ALTER TABLE `activity_scratch` CHANGE `scratch_info` `scratch_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '次数信息';

ALTER TABLE `continuous_recharge` CHANGE `recharge_reward_info` `recharge_reward_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '奖励领取列表';

ALTER TABLE `cum_consume` CHANGE `reward_list` `reward_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '奖励领取列表';

ALTER TABLE `fund` CHANGE `picked_common_list` `picked_common_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '普通已领取列表';
ALTER TABLE `fund` CHANGE `picked_senior_list` `picked_senior_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '高定已领取列表';

ALTER TABLE `guild_member` CHANGE `activeness_data` `activeness_data` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;

ALTER TABLE `hero` CHANGE `refine_attribute_list` `refine_attribute_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '育成属性列';
ALTER TABLE `hero` CHANGE `temp_refine_attribute_list` `temp_refine_attribute_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '育成临时属性';
ALTER TABLE `hero` CHANGE `activated_skin_list` `activated_skin_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '英雄激活的皮肤列表';

ALTER TABLE `hero_journal` CHANGE `story_list` `story_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '已激活故事列表';
ALTER TABLE `hero_journal` CHANGE `story_reward_list` `story_reward_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '已领取故事奖励列表';

ALTER TABLE `soul` CHANGE `master_attribute_list` `master_attribute_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '主属性列表';
ALTER TABLE `soul` CHANGE `random_attribute_list` `random_attribute_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '随机属性列表';
ALTER TABLE `soul` CHANGE `unique_attribute` `unique_attribute` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '无双属性';
ALTER TABLE `soul` CHANGE `tmp_random_attribute_map` `tmp_random_attribute_map` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '临时洗练属性';
ALTER TABLE `soul` CHANGE `tmp_unique_attribute` `tmp_unique_attribute` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '临时洗练属性';

ALTER TABLE `special_treasure` CHANGE `zhanling` `zhanling` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '战令';
ALTER TABLE `treasure_kizuna` CHANGE `got_list` `got_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '已领取羁绊列表';

ALTER TABLE `wish` CHANGE `refine_list` `refine_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '试炼列表';
ALTER TABLE `wish` CHANGE `god_list` `god_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '激活神信息';

-- +migrate Down
