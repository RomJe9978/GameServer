
-- +migrate Up
ALTER TABLE `tiles_game` ADD `score_list` TEXT COMMENT '积分规则' AFTER `game_list`;

-- +migrate Down
ALTER TABLE `tiles_game` DROP `score_list`;
