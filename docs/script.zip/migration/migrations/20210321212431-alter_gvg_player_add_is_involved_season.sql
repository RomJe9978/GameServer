-- +migrate Up
ALTER TABLE `gvg_player` ADD `is_involved_season` tinyint(1) NOT NULL DEFAULT '1' COMMENT '本赛季是否参与过';

-- +migrate Down
ALTER TABLE `gvg_player` DROP COLUMN `is_involved_season`;

