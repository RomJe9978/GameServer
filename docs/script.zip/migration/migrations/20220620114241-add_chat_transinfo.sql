
-- +migrate Up
ALTER TABLE `chat` ADD `lan_msg` MEDIUMTEXT COMMENT '翻译结果' AFTER `msg`;

-- +migrate Down
ALTER TABLE `chat` DROP `lan_msg`;
