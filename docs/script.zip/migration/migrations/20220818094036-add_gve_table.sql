
-- +migrate Up
CREATE TABLE `gve_city` (
  `id` bigint(20) unsigned NOT NULL COMMENT '城池ID',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `npc_level` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '城池状态',
  `occupy_guild_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '占领该城池的公会 取值为-1或guild_id取值',
  `occupy_ts` int(10) NOT NULL DEFAULT '0' COMMENT '占领时间',
  `attacker_teams` mediumtext COMMENT '攻击公会',
  `defender_teams` mediumtext COMMENT '防御公会',
  `battle_record` mediumblob COMMENT '上次发生战斗时攻击阶段战斗记录',
  `hero_info_snapshot` mediumblob COMMENT '卡牌镜像',
  `logs` mediumblob COMMENT '城池日志',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`),
  KEY `idx_update_at` (`update_ts`),
  KEY `cityId_guildId` (`city_id`,`guild_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gvg城池表';

CREATE TABLE `gve_guild` (
  `guild_id` bigint(21) unsigned NOT NULL COMMENT '公会ID',
  `logs` mediumblob,
  `score` bigint(21) NOT NULL DEFAULT '0' COMMENT '积分',
  `difficulty` int(11) NOT NULL DEFAULT '0' COMMENT '段位',
  `update_score_at` timestamp NULL DEFAULT NULL,
  `is_involved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '当日是否有资格参与',
  `record_log_day` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`guild_id`),
  KEY `score` (`score`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gvg公会表';

CREATE TABLE `gve_guild_player` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
  `hero_status` mediumtext COMMENT '卡牌状态',
  `dispatch_team_num` int(11) NOT NULL DEFAULT '0',
  `hero_infos` mediumblob COMMENT '卡牌快照',
  `score` bigint(20) NOT NULL DEFAULT '0',
  `update_score_at` timestamp NULL DEFAULT NULL,
  `rewarded_city_ids` mediumtext,
  `guild_id` bigint(20) NOT NULL DEFAULT '0',
  `is_involved_season` tinyint(1) NOT NULL DEFAULT '1' COMMENT '本赛季是否参与过',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gvg玩家表';

-- +migrate Down
DROP TABLE IF EXISTS `gve_city`;
DROP TABLE IF EXISTS `gve_guild`;
DROP TABLE IF EXISTS `gve_guild_player`;