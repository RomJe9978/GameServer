
-- +migrate Up
ALTER TABLE `battle_level_record` ADD COLUMN `issue_no` int(11) NOT NULL DEFAULT 0;

-- +migrate Down
ALTER TABLE `battle_level_record` DROP `issue_no`;
