
-- +migrate Up
ALTER TABLE `privilege_card` ADD `extra_expired_at` int (11) not null DEFAULT 0  COMMENT '额外奖励过期时间';

-- +migrate Down
ALTER TABLE `privilege_card` DROP COLUMN `extra_expired_at`;