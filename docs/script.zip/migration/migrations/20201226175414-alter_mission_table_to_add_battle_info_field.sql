-- +migrate Up
ALTER TABLE `mission` ADD `data` mediumblob COMMENT '快照二进制数据';

-- +migrate Down
ALTER TABLE `mission` DROP COLUMN `data`;