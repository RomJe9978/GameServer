
-- +migrate Up
ALTER TABLE `activity_draw_luck` CHANGE `sub_pool_id` `rankId` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '抽奖排行榜Id';

ALTER TABLE `activity_draw_luck` ADD `sub_pool_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '子奖池Id' AFTER `rankId`;

-- +migrate Down
ALTER TABLE `activity_draw_luck` DROP `sub_pool_id`;

ALTER TALBE `activity_draw_luck` CHANGE `rankId` `sub_pool_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '子奖池Id';
