-- +migrate Up
ALTER TABLE `equip` ADD `enhance_times_by_level` varchar(512) DEFAULT NULL COMMENT '每级强化次数' AFTER `rune_level`;

-- +migrate Down
ALTER TABLE `equip` DROP COLUMN `enhance_times_by_level`;
