-- +migrate Up
ALTER TABLE `activity_normal_lottery` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '刷新时间戳';

-- +migrate Down
ALTER TABLE `activity_normal_lottery` DROP `refresh_at`;
