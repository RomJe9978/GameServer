-- +migrate Up
ALTER TABLE `item` ADD `expire_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '道具过期时间';

-- +migrate Down
ALTER TABLE `item` DROP `expire_at`;