
-- +migrate Up
CREATE TABLE `recharge_rebate` (
  `player_id` bigint(21) unsigned NOT NULL,
  `stage_id` int(11) NOT NULL DEFAULT '0',
  `last_update_at` int(11) NOT NULL DEFAULT '0',
  `reward_list` text,
  `recharge_list` text,
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `recharge_rebate`;