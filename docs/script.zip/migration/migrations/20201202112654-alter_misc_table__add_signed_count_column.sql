
-- +migrate Up
ALTER TABLE `misc` ADD `signed_count` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `signed`;


-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `signed_count`;
