
-- +migrate Up
CREATE TABLE IF NOT EXISTS `battle_pass` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '战令模板id',
  `level` int(10) unsigned DEFAULT '0' COMMENT '战令等级',
  `exp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当前等级战令经验',
  `senior_bought` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已购买高级战令',
  `senior_score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '高级战令宝箱累积积分',
  `common_list` text COMMENT '已领取普通奖励',
  `senior_list` text COMMENT '已领取高级奖励',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '删除标记',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='战令表';

-- +migrate Down
DROP TABLE IF EXISTS `battle_pass`;
