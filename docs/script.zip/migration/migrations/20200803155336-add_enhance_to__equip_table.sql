-- +migrate Up
ALTER TABLE `equip` ADD `rand_seed` int(11) NOT NULL DEFAULT '0' COMMENT '强化暴击种子' AFTER `hero_id`;
ALTER TABLE `equip` ADD `enhance_level` int(11) NOT NULL DEFAULT '0' COMMENT '当前强化等级' AFTER `rand_seed`;
ALTER TABLE `equip` ADD `enhance_times` int(11) NOT NULL DEFAULT '0' COMMENT '强化总次数' AFTER `enhance_level`;
ALTER TABLE `equip` ADD `enhance_exp` int(11) NOT NULL DEFAULT '0' COMMENT '强化经验值' AFTER `enhance_times`;

-- +migrate Down
ALTER TABLE `equip` DROP COLUMN `rand_seed`;
ALTER TABLE `equip` DROP COLUMN `enhance_level`;
ALTER TABLE `equip` DROP COLUMN `enhance_times`;
ALTER TABLE `equip` DROP COLUMN `enhance_exp`;