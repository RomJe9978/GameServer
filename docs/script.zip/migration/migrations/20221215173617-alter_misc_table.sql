
-- +migrate Up
ALTER TABLE `misc` ADD `hero_transfer` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '武将育成转换';
ALTER TABLE `misc` ADD `hero_transfer_src_id` BIGINT(21) UNSIGNED NOT NULL DEFAULT '0' COMMENT '武将育成转换id';
ALTER TABLE `misc` ADD `hero_transfer_des_id` BIGINT(21) UNSIGNED NOT NULL DEFAULT '0' COMMENT '武将育成转换id';

-- +migrate Down
ALTER TABLE `misc` DROP `hero_transfer`;
ALTER TABLE `misc` DROP `hero_transfer_src_id`;
ALTER TABLE `misc` DROP `hero_transfer_des_id`;
