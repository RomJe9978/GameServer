
-- +migrate Up
ALTER TABLE `mail` ADD `expireAt` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '过期时间戳' AFTER `extra`;


-- +migrate Down
ALTER TABLE `mail` DROP `expireAt`;
