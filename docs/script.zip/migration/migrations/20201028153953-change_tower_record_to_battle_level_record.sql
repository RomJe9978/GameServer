
-- +migrate Up
ALTER TABLE tower_record RENAME TO battle_level_record;
ALTER TABLE battle_level_record CHANGE COLUMN tower_level battle_level INT;

-- +migrate Down
ALTER TABLE battle_level_record RENAME TO tower_record;
ALTER TABLE battle_level_record CHANGE COLUMN battle_level tower_level INT;