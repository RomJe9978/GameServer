
-- +migrate Up
ALTER TABLE `misc` ADD `last_quit_guild_at` TIMESTAMP NULL DEFAULT NULL COMMENT '上次退出工会的时间' AFTER `finished_story_email_id`;

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `last_quit_guild_at`;
