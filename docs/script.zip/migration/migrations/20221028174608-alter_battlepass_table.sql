
-- +migrate Up
ALTER TABLE `battle_pass` ADD `ultimate_list` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '顶级列表' AFTER `senior_list`;
ALTER TABLE `battle_pass` ADD `ultimate_bought` TINYINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否购买顶级战令' AFTER `senior_bought`;

-- +migrate Down
ALTER TABLE `battle_pass` DROP `ultimate_list`;
ALTER TABLE `battle_pass` DROP `ultimate_bought`;
