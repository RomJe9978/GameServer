
-- +migrate Up

ALTER TABLE `player_world_boss` ADD COLUMN `battle_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '本期造成最大伤害的battle id' AFTER `last_max_damage`;
ALTER TABLE `player_world_boss` ADD COLUMN `last_battle_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '上期造成最大伤害的battle id' AFTER `battle_id`;

-- +migrate Down

ALTER TABLE `player_world_boss` DROP COLUMN `battle_id`;
ALTER TABLE `player_world_boss` DROP COLUMN `last_battle_id`;