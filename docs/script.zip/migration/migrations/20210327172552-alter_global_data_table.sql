
-- +migrate Up
ALTER TABLE `global_data` ADD `issue_no` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '活动期号' AFTER `data`;
ALTER TABLE `global_data` ADD `start_time` TIMESTAMP NULL DEFAULT NULL COMMENT '活动开始时间' AFTER `issue_no`, ADD `end_time` TIMESTAMP NULL DEFAULT NULL COMMENT '活动结束时间' AFTER `start_time`;

-- +migrate Down
ALTER TABLE `global_data` DROP `issue_no`;
ALTER TABLE `global_data` DROP `start_time`, `end_time`;
