
-- +migrate Up
ALTER TABLE `misc` ADD `surprised_award_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '彩蛋奖励id列表' AFTER `login_7days`;

-- +migrate Down
ALTER TABLE `misc` DROP `surprised_award_list`;
