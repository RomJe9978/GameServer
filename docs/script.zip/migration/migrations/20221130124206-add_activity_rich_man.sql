
-- +migrate Up
CREATE TABLE `rich_man` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '模版id',
  `chess_id` int(11) NOT NULL DEFAULT '0' COMMENT '棋子皮肤id',
  `current_map_list` text COMMENT '当前地图信息',
  `before_map_list` text COMMENT '上次地图信息',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `mode` int(11) NOT NULL DEFAULT '0' COMMENT '模式',
  `reward_info` text COMMENT '层级奖励信息',
  `round` int(11) NOT NULL DEFAULT '1' COMMENT '圈数',
  `reward_data` text COMMENT '奖励信息',
  `level_up_effect` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '升级地块是否生效',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='大富翁';

CREATE TABLE `rich_man_record` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '模版id',
  `record` text COMMENT '日志信息',
  `temp_record_id` bigint(21) NOT NULL DEFAULT '0',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='大富翁日志';
-- +migrate Down
