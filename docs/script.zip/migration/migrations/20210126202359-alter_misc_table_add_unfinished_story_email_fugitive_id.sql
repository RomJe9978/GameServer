
-- +migrate Up

ALTER TABLE `misc` ADD COLUMN `unfinished_story_email_fugitive_id` mediumtext COMMENT '为完成的剧情邮件对象ID' AFTER `finished_story_email_id`;

-- +migrate Down

ALTER TABLE `misc` DROP COLUMN `unfinished_story_email_fugitive_id`;