
-- +migrate Up
ALTER TABLE `misc` ADD `total_power` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '累计最高战力';

-- +migrate Down
ALTER TABLE `misc` DROP `total_power`;
