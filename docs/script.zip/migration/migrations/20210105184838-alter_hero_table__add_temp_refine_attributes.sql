
-- +migrate Up
ALTER TABLE `hero` ADD `temp_refine_attribute_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '育成临时属性' AFTER `refine_attribute_list`;

-- +migrate Down
ALTER TABLE `hero` DROP `temp_refine_attribute_list`;
