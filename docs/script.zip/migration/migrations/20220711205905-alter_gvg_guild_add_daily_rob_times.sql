
-- +migrate Up
ALTER TABLE `gvg_guild` ADD COLUMN `daily_rob_times` int(11) NOT NULL DEFAULT 0;

-- +migrate Down
DROP TABLE IF EXISTS `gvg_guild`;