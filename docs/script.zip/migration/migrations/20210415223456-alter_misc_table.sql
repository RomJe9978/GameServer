
-- +migrate Up
ALTER TABLE `misc` ADD `privilege_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '特权变化信息，挂机计算奖励使用' AFTER `chat_bg_res`;

-- +migrate Down
ALTER TABLE `misc` DROP `privilege_info`;
