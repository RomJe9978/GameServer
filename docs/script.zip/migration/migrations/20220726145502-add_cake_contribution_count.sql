
-- +migrate Up
ALTER TABLE `cake` ADD `contribution_count` BIGINT DEFAULT NULL COMMENT '捐献次数' AFTER `cake_level`;

-- +migrate Down
ALTER TABLE `cake` DROP `contribution_count`;
