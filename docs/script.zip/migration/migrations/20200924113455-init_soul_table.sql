
-- +migrate Up
CREATE TABLE IF NOT EXISTS `soul` (
  `id` bigint(20) unsigned NOT NULL COMMENT '战魂唯一id',
  `player_id` bigint(20) unsigned DEFAULT '0' COMMENT '玩家唯一id',
  `template_id` int(10) unsigned DEFAULT '0' COMMENT '战魂模板id',
  `hero_id` bigint(20) unsigned DEFAULT '0' COMMENT '英雄id',
  `strength_level` int(10) unsigned DEFAULT '0' COMMENT '战魂强化等级',
  `strength_exp` int(10) unsigned DEFAULT '0' COMMENT '战魂当前强化强化下的经验',
  `master_attribute_list` varchar(255) DEFAULT NULL COMMENT '主属性列表',
  `random_attribute_list` varchar(255) DEFAULT NULL COMMENT '随机属性列表',
  `unique_attribute` varchar(255) DEFAULT NULL COMMENT '无双属性',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(3) unsigned DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `soul`;
