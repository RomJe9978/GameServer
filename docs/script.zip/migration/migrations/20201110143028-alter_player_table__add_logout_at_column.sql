
-- +migrate Up
ALTER TABLE `player` ADD `logout_at` TIMESTAMP NULL DEFAULT NULL COMMENT '最近登出时间戳' AFTER `sign`;

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `logout_at`;
