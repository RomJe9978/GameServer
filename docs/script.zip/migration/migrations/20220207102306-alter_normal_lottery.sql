
-- +migrate Up
ALTER TABLE `activity_normal_lottery` ADD `free_times` INT(11) NOT NULL DEFAULT '0'  COMMENT '免费次数';
ALTER TABLE `activity_normal_lottery` ADD `activity_id` INT(11) NOT NULL DEFAULT '0'  COMMENT '活动id';
ALTER TABLE `activity_normal_lottery` ADD `issue_no` INT(11) NOT NULL DEFAULT '0'  COMMENT '活动期号';

-- +migrate Down
ALTER TABLE `activity_normal_lottery` DROP `free_times`;
ALTER TABLE `activity_normal_lottery` DROP `activity_id`;
ALTER TABLE `activity_normal_lottery` DROP `issue_no`;

