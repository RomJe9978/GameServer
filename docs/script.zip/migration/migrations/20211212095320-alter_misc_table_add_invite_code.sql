-- +migrate Up
ALTER TABLE `misc` ADD `has_bind_invite_code` TINYINT  NOT NULL DEFAULT '0' COMMENT '是否绑定了邀请码' AFTER `exp_buff_expired`;
ALTER TABLE `misc` ADD `invite_code_rewards` MEDIUMTEXT COMMENT '邀请码任务奖励领取信息'  AFTER `has_bind_invite_code`;
ALTER TABLE `misc` ADD `invite_code_complete` MEDIUMTEXT COMMENT '邀请码任务完成情况'  AFTER `invite_code_rewards`;

-- +migrate Down
ALTER TABLE `misc` DROP `has_bind_invite_code`;
ALTER TABLE `misc` DROP `invite_code_rewards`;
ALTER TABLE `misc` DROP `invite_code_complete`;