
-- +migrate Up
ALTER TABLE `misc` ADD `signin_refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '签到刷新时间戳' AFTER `signed_count`;

-- +migrate Down
ALTER TABLE `misc` DROP `signin_refresh_at`;
