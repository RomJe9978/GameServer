
-- +migrate Up
ALTER TABLE `task` DROP `task_data`;
ALTER TABLE `task` ADD `master_tasks` BLOB NULL DEFAULT NULL COMMENT '主线任务PB' AFTER `player_id`, ADD `daily_tasks` BLOB NULL DEFAULT NULL COMMENT '日常任务PB' AFTER `master_tasks`, ADD `weekly_tasks` BLOB NULL DEFAULT NULL COMMENT '周常任务PB' AFTER `daily_tasks`;

-- +migrate Down
ALTER TABLE `task` DROP `master_tasks`, DROP `daily_tasks`, DROP `weekly_tasks`;
ALTER TABLE `task` ADD `task_data` BLOB NULL DEFAULT NULL COMMENT '任务PB' AFTER `player_id`;


