
-- +migrate Up
ALTER TABLE `player_dungeon` CHANGE `first_passed_list` `first_passed_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '首次通关副本列表';

-- +migrate Down
ALTER TABLE `player_dungeon` CHANGE `first_passed_list` `first_passed_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '\'\'' COMMENT '首次通关副本列表';
