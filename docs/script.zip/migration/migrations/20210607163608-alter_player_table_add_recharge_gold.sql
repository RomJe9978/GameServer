
-- +migrate Up
ALTER TABLE `player` ADD `recharge_gold` bigint (20) not null DEFAULT 0  COMMENT '充值元宝存量';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `recharge_gold`;