
-- +migrate Up
ALTER TABLE `cs_arena` ADD COLUMN `default_season` int(11) NOT NULL DEFAULT 0 AFTER `player_id`;
ALTER TABLE `cs_arena` ADD COLUMN `type` int(11) NOT NULL DEFAULT 0 AFTER `cur_season`;
ALTER TABLE `cs_arena` MODIFY COLUMN `cur_season` int(11) NOT NULL DEFAULT 0 AFTER `default_season`;
ALTER TABLE `cs_arena` DROP PRIMARY KEY;
ALTER TABLE `cs_arena` ADD PRIMARY KEY (`player_id`, `default_season`) USING BTREE;
ALTER TABLE `formation` ADD COLUMN `hero_team` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL AFTER `hero_list`;

-- +migrate Down
