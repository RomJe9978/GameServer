
-- +migrate Up
DROP TABLE IF EXISTS `task`;
CREATE TABLE IF NOT EXISTS `task` (
      `player_id` bigint(20) UNSIGNED NOT NULL COMMENT '玩家唯一id',
      `master_tasks` text COMMENT '主线任务Json',
      `daily_tasks` text COMMENT '日常任务Json',
      `daily_task_refresh_at` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '日常任务刷新上次刷新时间戳',
      `daily_activeness` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '日常活跃度',
      `daily_rewards` text COMMENT '日常任务奖励Json',
      `weekly_tasks` text COMMENT '周常任务Json',
      `weekly_task_refresh_at` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '周常任务上次刷新时间戳',
      `weekly_activeness` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '周常活跃度',
      `weekly_rewards` text COMMENT '周常任务活跃度奖励Json',
      `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '生成时间戳',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否失效',
      PRIMARY KEY (`player_id`),
      KEY `player_id` (`player_id`,`invalid`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `task`;
