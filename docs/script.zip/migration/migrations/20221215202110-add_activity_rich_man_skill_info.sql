
-- +migrate Up
ALTER TABLE `rich_man` ADD `skill_info` text COMMENT '技能获取详情' AFTER `level_up_effect`;
ALTER TABLE `rich_man` ADD `consume_item` text COMMENT '消耗道具' AFTER `skill_info`;

-- +migrate Down
ALTER TABLE `rich_man` DROP `skill_info`;
ALTER TABLE `rich_man` DROP `consume_item`;
