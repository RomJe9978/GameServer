
-- +migrate Up
CREATE TABLE `event_add_exp` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '模版id',
  `rewards` text COMMENT '奖励信息',
  `total_seconds` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累积挂机时间',
  `last_query_at` timestamp NULL DEFAULT NULL COMMENT '上次请求活动挂机奖励时间戳',
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动武将加成经验表';

-- +migrate Down
DROP TABLE IF EXISTS `event_add_exp`;