
-- +migrate Up
CREATE TABLE IF NOT EXISTS `idle` (
      `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
      `exp` int(11) unsigned DEFAULT '0' COMMENT '挂机经验',
      `coin` int(11) unsigned DEFAULT '0' COMMENT '挂机金币',
      `gold_speed_up_times` int(11) DEFAULT '0' COMMENT '元宝加速次数',
      `item_speed_up_times` int(11) DEFAULT '0' COMMENT '道具加速次数',
      `rewards` text COMMENT '普通挂机奖励',
      `last_query_at` timestamp NULL DEFAULT NULL COMMENT '上次请求挂机奖励时间戳',
      `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间戳',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(1) DEFAULT '0' COMMENT '删除标识',
      PRIMARY KEY (`player_id`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `idle`;
