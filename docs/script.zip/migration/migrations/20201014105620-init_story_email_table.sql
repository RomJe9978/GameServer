
-- +migrate Up
CREATE TABLE `story_email` (
  `id` bigint(11) NOT NULL DEFAULT '0' COMMENT '唯一ID',
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `type` int(11) DEFAULT NULL COMMENT '邮件类型',
  `email_template_id` int(11) NOT NULL COMMENT '邮件系统模板ID',
  `status` int(11) DEFAULT NULL COMMENT '剧情邮件状态',
  `email_items` mediumtext COMMENT '子邮件列表 JSON字符串',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `story_email`;
