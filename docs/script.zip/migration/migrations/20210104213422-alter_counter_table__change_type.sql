
-- +migrate Up
ALTER TABLE `counter` CHANGE `data` `data` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '计数数据';

-- +migrate Down
ALTER TABLE `counter` CHANGE `data` `data` MEDIUMBLOB NULL DEFAULT NULL COMMENT '计数数据';

