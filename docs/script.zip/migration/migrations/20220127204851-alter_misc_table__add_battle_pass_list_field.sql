
-- +migrate Up
ALTER TABLE `misc` ADD `battle_pass_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '已激活的新服战令列表' AFTER `monthly_card_rewarded_box`;

-- +migrate Down
ALTER TABLE `misc` DROP `battle_pass_list`;
