
-- +migrate Up
CREATE TABLE IF NOT EXISTS `valentine` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '情人节刮卡模板id',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '刮奖次数',
  `reset_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已重置次数',
  `select_reward_info` text COMMENT '选择奖励信息',
  `open_list` text,
  `card_reward_list` text,
  `picked_card_reward_list` text,
  `progress_reward_list` text,
  `guarantee` int(10) unsigned DEFAULT '0',
  `puzzle_reward_list` text,
  `flip_card_infos` text COMMENT '情人节翻牌小游戏数据',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='情人节活动';

-- +migrate Down
DROP TABLE IF EXISTS `valentine`;
