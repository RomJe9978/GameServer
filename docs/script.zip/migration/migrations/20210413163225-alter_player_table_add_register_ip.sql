
-- +migrate Up
ALTER TABLE `player` ADD `register_ip` char(128) default null COMMENT '注册IP';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `register_ip`;