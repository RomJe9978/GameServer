
-- +migrate Up
CREATE TABLE `gve_player` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
  `guild_id` bigint(20) NOT NULL DEFAULT '0',
  `match_guild_infos` mediumtext COMMENT '匹配的公会信息',
  `rob_num` int(11) NOT NULL DEFAULT '0',
  `task_score` int(11) NOT NULL DEFAULT '0',
  `battle_score` int(11) NOT NULL DEFAULT '0',
  `total_score` bigint(20) NOT NULL DEFAULT '0',
  `update_score_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gvg玩家表';

CREATE TABLE `gve_task` (
  `id` bigint(21) unsigned NOT NULL COMMENT '任务ID',
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
  `guild_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '公会ID',
  `template_id` int(11) NOT NULL COMMENT '押镖任务配置ID',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '刷新日期',
  `res_info` mediumtext COMMENT '资源信息',
  `start_at` int(20) NOT NULL DEFAULT '0' COMMENT '开始时间戳',
  `end_at` int(11) NOT NULL DEFAULT '0' COMMENT '结束时间戳',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `battle_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '战斗ID',
  `reward_item_str` mediumtext,
  `hero_list` mediumtext COMMENT '押镖任务卡牌列表',
  `warrior_status` mediumtext COMMENT '卡牌状态',
  `progress` mediumtext COMMENT '进度信息',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `res_num` int(11) NOT NULL DEFAULT '0',
  `res_type` int(11) NOT NULL DEFAULT '0',
  `robbed_res_num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `gve_task_battle_record` (
  `battle_id` bigint(21) unsigned NOT NULL COMMENT '快照所属玩家ID',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  `data` mediumblob,
  `attacker` mediumblob COMMENT '竞技场攻击方',
  `defender` mediumblob COMMENT '竞技场防守方',
  `winner_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '胜利方ID',
  `attacker_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '攻击方ID',
  `defender_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '防守方ID',
  `task_template_id` int(11) NOT NULL DEFAULT '0' COMMENT '战斗攻击者名次变化',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `res_item` mediumtext,
  PRIMARY KEY (`battle_id`),
  KEY `attacker_id` (`attacker_id`),
  KEY `defender_id` (`defender_id`),
  KEY `idx_update_at` (`update_ts`),
  KEY `idx_create_at` (`create_at`),
  KEY `idx_create_ts` (`create_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `gvg_daily_battle_record` (
  `city_id` int(11) NOT NULL DEFAULT '0',
  `day` int(11) NOT NULL DEFAULT '0',
  `winner_guild_id` bigint(21) NOT NULL DEFAULT '0' COMMENT '上次战斗最终胜利方公会ID',
  `attack_stage_record` mediumblob COMMENT '上次发生战斗时攻击阶段战斗记录',
  `counter_attack_stage_record` mediumblob COMMENT '上次发生战斗时防守阶段战斗记录',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`city_id`,`day`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gvg城池表';

CREATE TABLE `system_buff` (
  `id` bigint(21) unsigned NOT NULL COMMENT 'buffID',
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '配置id',
  `expire_at` int(11) DEFAULT NULL COMMENT '过期时间戳',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='system buff表';

CREATE TABLE `global_misc` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动id',
  `data` mediumtext COMMENT '活动数据',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '数据无效标记',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='全局数据表';

ALTER TABLE `gvg_city` ADD COLUMN `scheduled_attack_at` int(11) NOT NULL DEFAULT 0 AFTER `update_ts`;
ALTER TABLE `gvg_guild` ADD COLUMN `logs` mediumblob NULL AFTER `max_host_num`;
ALTER TABLE `gvg_guild` ADD COLUMN `res_num` bigint(20) NOT NULL DEFAULT 0 AFTER `update_ts`;
ALTER TABLE `gvg_guild` ADD COLUMN `material_buff` int(11) NOT NULL DEFAULT 0 AFTER `res_num`;
ALTER TABLE `gvg_guild` ADD COLUMN `daily_rob_res_num` int(11) NOT NULL DEFAULT 0 AFTER `material_buff`;
ALTER TABLE `gvg_guild` ADD COLUMN `record_log_day` int(11) NOT NULL DEFAULT 0 AFTER `daily_rob_res_num`;
ALTER TABLE `gvg_guild` ADD COLUMN `daily_effect` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '每日生效的效果' AFTER `record_log_day`;
ALTER TABLE `gvg_guild` ADD COLUMN `daily_effect_reward` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '每日效果奖励' AFTER `daily_effect`;
ALTER TABLE `gvg_guild` ADD COLUMN `hero_status` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL AFTER `daily_effect_reward`;
ALTER TABLE `gvg_guild` MODIFY COLUMN `teams` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '公会托管的队伍信息' AFTER `host_heroes`;
ALTER TABLE `gvg_player` ADD COLUMN `daily_kill_num` int(11) NOT NULL DEFAULT 0 AFTER `hero_status_new`;
ALTER TABLE `gvg_player` ADD COLUMN `daily_dispatch_num` int(11) NOT NULL DEFAULT 0 AFTER `daily_kill_num`;
ALTER TABLE `gvg_player` ADD COLUMN `hero_infos` mediumblob COMMENT '卡牌快照';
ALTER TABLE `misc` ADD COLUMN `chat_mbox_gain_at` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL AFTER `chat_mbox`;

-- +migrate Down
DROP TABLE IF EXISTS `gve_player`;
DROP TABLE IF EXISTS `gve_task`;
DROP TABLE IF EXISTS `gve_task_battle_record`;
DROP TABLE IF EXISTS `gvg_daily_battle_record`;
DROP TABLE IF EXISTS `system_buff`;
DROP TABLE IF EXISTS `global_misc`;