
-- +migrate Up

CREATE TABLE IF NOT EXISTS `task` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `task_data` mediumblob NOT NULL COMMENT '任务PB数据',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否失效',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down

DROP TABLE IF EXISTS `task`;
