
-- +migrate Up
CREATE TABLE `cum_recharge` (
  `player_id` bigint(22) unsigned NOT NULL,
  `stage_id` int(11) NOT NULL DEFAULT '0',
  `cum_recharge` int(11) NOT NULL DEFAULT '0',
  `times` int(11) NOT NULL DEFAULT '0',
  `reward_list` text,
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `cum_recharge`;