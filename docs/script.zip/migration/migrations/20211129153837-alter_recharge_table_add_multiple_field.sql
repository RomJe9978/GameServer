
-- +migrate Up
ALTER TABLE `recharge` ADD `multiple_begin_ts` MEDIUMTEXT COMMENT '多个档位开启时间';
ALTER TABLE `recharge` ADD `multiple_reward_list` MEDIUMTEXT COMMENT '多个档位领取奖励信息';

-- +migrate Down
ALTER TABLE `recharge` DROP `multiple_begin_ts`;
ALTER TABLE `recharge` DROP `multiple_reward_list`;