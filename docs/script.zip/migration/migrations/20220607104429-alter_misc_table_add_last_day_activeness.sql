
-- +migrate Up
ALTER TABLE `misc` ADD `last_day_activeness` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '昨日任务活跃度' AFTER `battle_pass_list`;

-- +migrate Down
ALTER TABLE `misc` DROP `last_day_activeness`;
