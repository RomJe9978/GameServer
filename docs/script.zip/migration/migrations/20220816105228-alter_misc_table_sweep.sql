-- +migrate Up
ALTER TABLE `misc` ADD `last_cs_condition_tower_level` INT(11) NOT NULL DEFAULT '0' COMMENT '条件爬塔跨服上次挑战层级' AFTER `login_reward_last_login_day`;
ALTER TABLE `misc` ADD `last_condition_tower_level` INT(11) NOT NULL DEFAULT '0' COMMENT '条件爬塔本服上次挑战层级' AFTER `last_cs_condition_tower_level`;

-- +migrate Down
ALTER TABLE `misc` DROP `last_cs_condition_tower_level`;
ALTER TABLE `misc` DROP `last_condition_tower_level`;