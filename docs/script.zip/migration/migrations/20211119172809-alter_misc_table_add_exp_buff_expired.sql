-- +migrate Up
ALTER TABLE `misc` ADD `exp_buff_expired` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '经验buff 道具过期时间';

-- +migrate Down
ALTER TABLE `misc` DROP `exp_buff_expired`;