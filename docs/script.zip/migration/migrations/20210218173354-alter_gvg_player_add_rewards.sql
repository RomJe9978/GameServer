-- +migrate Up
ALTER TABLE `gvg_player` ADD `city_rewards` MEDIUMTEXT   COMMENT '占领城池奖励';
ALTER TABLE `gvg_player` ADD `destroy_state_rewards` MEDIUMTEXT   COMMENT '灭国奖励';
ALTER TABLE `gvg_player` ADD `found_state_rewards` MEDIUMTEXT   COMMENT '建国奖励';

-- +migrate Down
ALTER TABLE `gvg_player` DROP COLUMN `city_rewards`;
ALTER TABLE `gvg_player` DROP COLUMN `destroy_state_rewards`;
ALTER TABLE `gvg_player` DROP COLUMN `found_state_rewards`;
