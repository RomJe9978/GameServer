-- +migrate Up
ALTER TABLE `arena` ADD `to_sent_defeated_records` MEDIUMTEXT   COMMENT '待发送的被击败记录';
ALTER TABLE `arena` ADD `last_defeated_record` MEDIUMBLOB NULL DEFAULT NULL COMMENT '最后一次被击败记录' ;

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `to_sent_defeated_records`;
ALTER TABLE `arena` DROP COLUMN `last_defeated_record`;
