
-- +migrate Up
ALTER TABLE `worker` ADD `times` INT(11) UNSIGNED NOT NULL DEFAULT '1' COMMENT '放置次数' AFTER `timeout`;

-- +migrate Down
ALTER TABLE `workder` DROP `times`;
