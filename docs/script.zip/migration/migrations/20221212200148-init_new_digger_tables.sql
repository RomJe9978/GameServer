
-- +migrate Up
CREATE TABLE `new_digger` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `new_dig_event_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模板id',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级表ID',
  `score` bigint(20) NOT NULL DEFAULT '0' COMMENT '积分',
  `box_info` text CHARACTER SET utf8 COMMENT '宝箱奖励记录',
  `flip_info` text CHARACTER SET utf8 COMMENT '翻牌记录',
  `gift_group_info` text CHARACTER SET utf8 COMMENT '奖励池记录',
  `opened_gift_group_info` text CHARACTER SET utf8 COMMENT '已开奖励记录',
  `pass_level_info` text CHARACTER SET utf8 COMMENT '门记录',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`new_dig_event_id`),
  KEY `idx_update_at` (`update_ts`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新挖宝表';


-- +migrate Down
