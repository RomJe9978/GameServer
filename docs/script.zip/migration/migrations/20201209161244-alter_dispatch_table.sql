
-- +migrate Up
ALTER TABLE `dispatch` CHANGE `refresh_date` `refresh_time` INT UNSIGNED NULL DEFAULT '0' COMMENT '系统刷新日期';


-- +migrate Down
ALTER TABLE `dispatch` CHANGE `refresh_time` `refresh_date` INT UNSIGNED NULL DEFAULT '0' COMMENT '系统刷新日期';
