
-- +migrate Up
CREATE TABLE IF NOT EXISTS `player_scratch` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `scratch_info` varchar(255) DEFAULT NULL COMMENT '次数信息',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='嘟嘟赏_刮刮乐';

-- +migrate Down
DROP TABLE IF EXISTS `player_scratch`;
