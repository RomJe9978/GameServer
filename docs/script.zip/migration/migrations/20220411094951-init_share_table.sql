
-- +migrate Up
CREATE TABLE `share` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `record` TEXT COMMENT '活动记录',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='分享表';

-- +migrate Down
DROP TABLE IF EXISTS `share`;
