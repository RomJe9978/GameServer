
-- +migrate Up
ALTER TABLE `mail` ADD `type` INT NOT NULL DEFAULT '0' COMMENT '邮件类型';

-- +migrate Down
ALTER TABLE `mail` DROP `type`;