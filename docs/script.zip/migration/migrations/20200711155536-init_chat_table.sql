
-- +migrate Up
CREATE TABLE IF NOT EXISTS `chat` (
  `chat_id` bigint(20) unsigned NOT NULL,
  `type` int(11) NOT NULL COMMENT '聊天消息类型',
  `msg` blob COMMENT '聊天消息体',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法数据',
  PRIMARY KEY (`chat_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `chat`;
