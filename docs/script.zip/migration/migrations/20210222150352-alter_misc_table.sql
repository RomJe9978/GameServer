
-- +migrate Up

ALTER TABLE `misc` ADD `login_7days` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '7日登陆奖励位图' AFTER `max_mail_id`;

-- +migrate Down
ALTER TABLE `misc` DROP `login_7days`;
