
-- +migrate Up
CREATE TABLE IF NOT EXISTS `npc_love` (
  `npc_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'NPC模板id',
  `love_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`npc_id`),
  KEY `valid_player` (`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `npc_love`;
