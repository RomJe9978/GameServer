
-- +migrate Up
ALTER TABLE `misc` ADD `has_reward_once` TINYINT  NOT NULL DEFAULT '0' COMMENT '是否领取了补偿奖励' AFTER `privilege_info`;

-- +migrate Down
ALTER TABLE `misc` DROP `has_reward_once`;
