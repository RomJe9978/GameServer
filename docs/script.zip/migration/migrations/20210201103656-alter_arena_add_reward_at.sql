-- +migrate Up
ALTER TABLE `arena` ADD `reward_at` bigint(20) unsigned NOT NULL default '0' COMMENT '上次发奖时间';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `reward_at`;