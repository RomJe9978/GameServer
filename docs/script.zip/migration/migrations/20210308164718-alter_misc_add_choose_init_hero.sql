
-- +migrate Up
ALTER TABLE `misc` ADD `choose_init_hero` int (11) not null DEFAULT 0  COMMENT '选择初始化的卡';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `choose_init_hero`;