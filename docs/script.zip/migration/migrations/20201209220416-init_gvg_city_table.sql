
-- +migrate Up
CREATE TABLE `gvg_city` (
  `id` int(20) unsigned NOT NULL COMMENT '城池ID',
  `occupy_guild_id` bigint(20)  NOT NULL DEFAULT '0' COMMENT '占领城池的公会ID',
  `mark_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '标记ID',
  `attacker_teams` mediumtext COMMENT '攻击公会',
  `defender_teams` mediumtext COMMENT '防御公会',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '城池状态',
  `countdown_end_at` int(11) NOT NULL DEFAULT '0' COMMENT '倒计时',
  `auction` mediumtext COMMENT '竞拍信息',
  `declared_guild_ids` mediumtext COMMENT '宣战的公会信息',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='gvg城池表';

-- +migrate Down
DROP TABLE IF EXISTS `gvg_city`;