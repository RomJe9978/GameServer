
-- +migrate Up
ALTER TABLE `player` ADD `is_mute` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否被禁言' AFTER `is_baned`;


-- +migrate Down
ALTER TABLE `player` DROP `is_mute`;
