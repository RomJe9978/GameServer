-- +migrate Up
ALTER TABLE `player` ADD `cvn` int(11) NOT NULL DEFAULT '0' COMMENT 'cvn码';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `cvn`;
