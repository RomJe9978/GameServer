
-- +migrate Up
CREATE TABLE IF NOT EXISTS `equip` (
  `id` bigint(20) unsigned NOT NULL COMMENT '装备ID',
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `template_id` int(11) NOT NULL COMMENT '装备配置ID',
  `hero_id` bigint(11) NOT NULL DEFAULT '0' COMMENT '装备穿着的佣兵ID',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `equip`;
