
-- +migrate Up
CREATE TABLE `server_statistics` (
  `id` int(11) NOT NULL,
  `total_roles` int(11) NOT NULL DEFAULT '0',
  `total_devices` int(11) NOT NULL DEFAULT '0',
  `total_pay_roles` int(11) NOT NULL DEFAULT '0',
  `total_pay_devices` int(11) NOT NULL DEFAULT '0',
  `total_pay_money` int(11) NOT NULL DEFAULT '0',
  `daily_new_roles` int(11) NOT NULL DEFAULT '0',
  `daily_new_devices` int(11) NOT NULL DEFAULT '0',
  `daily_active_roles` int(11) NOT NULL DEFAULT '0',
  `daily_pay_roles` int(11) NOT NULL DEFAULT '0',
  `daily_pay_devices` int(11) NOT NULL DEFAULT '0',
  `daily_pay_money` int(11) NOT NULL DEFAULT '0',
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  `date_str` varchar(256) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;

-- +migrate Down
DROP TABLE IF EXISTS `server_statistics`;