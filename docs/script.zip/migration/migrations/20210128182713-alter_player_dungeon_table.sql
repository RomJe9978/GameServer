
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `battle_record` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '挑战记录' AFTER `refresh_at`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `battle_record`;
