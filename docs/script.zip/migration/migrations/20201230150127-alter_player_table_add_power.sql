-- +migrate Up
ALTER TABLE `player` ADD `power` bigint(20) unsigned NOT NULL default '0' COMMENT '玩家总战力';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `power`;