-- +migrate Up
ALTER TABLE `arena` ADD `rank_list` MEDIUMTEXT  COMMENT '上次匹配到的排行榜列表';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `rank_list`;
