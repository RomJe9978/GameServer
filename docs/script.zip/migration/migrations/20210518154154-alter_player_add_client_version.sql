
-- +migrate Up
ALTER TABLE `player` ADD `client_ver` varchar(256) default null COMMENT '客户端版本';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `client_ver`;
