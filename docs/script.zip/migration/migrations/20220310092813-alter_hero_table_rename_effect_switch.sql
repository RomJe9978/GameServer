
-- +migrate Up
ALTER TABLE `hero` CHANGE `is_effect_open` `is_effect_close` TINYINT NOT NULL DEFAULT 0 COMMENT '是否关闭特效';

-- +migrate Down
ALTER TABLE `hero` CHANGE `is_effect_close` `is_effect_open` TINYINT NOT NULL DEFAULT 0 COMMENT ''是否关闭特效'';
