
-- +migrate Up
CREATE TABLE IF NOT EXISTS `battle_pet_list` (
      `id` bigint(20) unsigned NOT NULL COMMENT '宠物唯一id',
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '连携模板id',
      `name` varchar(255) DEFAULT NULL COMMENT '名字',
      `generation` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '世代',
      `clone_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '繁殖次数',
      `talent_skill_list` text CHARACTER SET utf8 COMMENT '天赋技能',
      `random_skill_list` text CHARACTER SET utf8 COMMENT '随机技能',
      `refine_data` blob COMMENT '洗练数据',
      `bucket_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '放置id',
      `setup_ts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '放置时间戳',
      `locked` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否锁定',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='战宠表';

-- +migrate Down
DROP TABLE IF EXISTS `battle_pet_list`;
