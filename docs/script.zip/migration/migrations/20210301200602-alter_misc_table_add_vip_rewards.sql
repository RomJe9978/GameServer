-- +migrate Up
ALTER TABLE `misc` ADD `vip_rewards` mediumtext  COMMENT 'vip奖励信息';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `vip_rewards`;
