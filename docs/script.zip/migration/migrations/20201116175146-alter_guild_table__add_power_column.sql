
-- +migrate Up
ALTER TABLE `guild` ADD `power` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '工会战力' AFTER `join_conds`;
ALTER TABLE `guild` ADD INDEX( `power` );


-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `power`;
ALTER TABLE `guild` DROP INDEX `power` ;
