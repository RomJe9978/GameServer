
-- +migrate Up
CREATE TABLE `gvg_player` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家ID',
  `hero_status` mediumtext COMMENT '卡牌状态',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='gvg玩家表';

-- +migrate Down
DROP TABLE IF EXISTS `gvg_player`;