-- +migrate Up
ALTER TABLE `gvg_guild` ADD `declare_city_num` int(11) NOT NULL DEFAULT '0' COMMENT '可宣战城数量';

-- +migrate Down
ALTER TABLE `gvg_guild` DROP COLUMN `declare_city_num`;
