-- +migrate Up
ALTER TABLE `shop` ADD COLUMN `pay_refresh_times` int(11) NOT NULL DEFAULT '0' COMMENT '付费刷新次数' AFTER `next_refresh_time`;

-- +migrate Down

ALTER TABLE `shop` DROP COLUMN `pay_refresh_times`;