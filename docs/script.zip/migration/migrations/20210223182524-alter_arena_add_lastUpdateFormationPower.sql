-- +migrate Up
ALTER TABLE `arena` ADD `last_update_formation_power` bigint(20)  NOT NULL default '0' COMMENT '上次更新阵容的战力值';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `last_update_formation_power`;