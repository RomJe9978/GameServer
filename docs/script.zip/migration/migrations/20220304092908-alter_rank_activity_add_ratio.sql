-- +migrate Up
ALTER TABLE `rank_activity` ADD `ratio` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '积分倍率万分比';

-- +migrate Down
ALTER TABLE `rank_activity` DROP `ratio`;