
-- +migrate Up
CREATE TABLE IF NOT EXISTS `global_mail` (
  `mail_id` bigint(20) unsigned NOT NULL COMMENT '邮件唯一id',
  `mail_type` varchar(64) DEFAULT '''reward''' COMMENT '邮件类型 奖励邮件 -- rewad；通知邮件 -- notify; 广告邮件 -- ad；社区邮件 -- community; 版本更新邮件 --verson',
  `title` varchar(255) DEFAULT '''''' COMMENT '邮件标题',
  `content` text COMMENT '邮件内容',
  `reward` text COMMENT '附件',
  `gmid` bigint(10) unsigned NOT NULL DEFAULT '0' COMMENT 'GM标识的邮件id',
  `version` varchar(255) DEFAULT NULL COMMENT '版本号',
  `url` varchar(255) DEFAULT NULL COMMENT 'url跳转链接',
  `expire_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间戳',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '生成时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否失效',
  PRIMARY KEY (`mail_id`),
  KEY `valid_player` (`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件表';

-- +migrate Down
DROP TABLE IF EXISTS `global_mail`;
