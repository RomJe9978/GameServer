
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `issue` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '组队副本期号' AFTER `refresh_at`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `issue`;
