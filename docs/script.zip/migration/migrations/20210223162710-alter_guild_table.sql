
-- +migrate Up
ALTER TABLE `guild` ADD `daily_mail_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '每日邮件已发送次数' AFTER `authorities`;

-- +migrate Down
ALTER TABLE `guild` DROP `daily_mail_times`;
