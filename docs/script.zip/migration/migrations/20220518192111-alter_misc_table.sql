
-- +migrate Up
ALTER TABLE `misc` ADD `quick_hammer_trial_expired_ts` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '一键强化试用到期时间戳' AFTER `battle_pass_list`;

-- +migrate Down
ALTER TABLE `misc` DROP `quick_hammer_trial_expired_ts`;
