-- +migrate Up
ALTER TABLE `mission` ADD COLUMN `is_unlocked` tinyint(1) NOT NULL DEFAULT '1' COMMENT '关卡是否解锁标识' AFTER `pass_times`;

-- +migrate Down

ALTER TABLE `mission` DROP COLUMN `is_unlocked`;