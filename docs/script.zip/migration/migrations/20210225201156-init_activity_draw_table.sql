
-- +migrate Up
CREATE TABLE IF NOT EXISTS `activity_draw` (
 `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
 `hero_pool_data` text COMMENT '武将卡池',
 `equip_pool_data` text COMMENT '装备卡池',
 `treasure_pool_data` text COMMENT '宝物卡池',
 `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
 `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
 `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
 PRIMARY KEY (`player_id`),
 KEY `valid_player` (`player_id`,`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `activity_draw`;
