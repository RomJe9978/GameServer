
-- +migrate Up
ALTER TABLE `player` ADD `is_gdpr_ban_user` TINYINT  NOT NULL DEFAULT '0';

CREATE TABLE `gdpr_ban_player` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '工会玩家id',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
  `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工会成员表';

-- +migrate Down
ALTER TABLE `player` DROP `is_gdpr_ban_user`;
DROP TABLE IF EXISTS `gdpr_ban_player`;