
-- +migrate Up
ALTER TABLE `arena_battle_record` ADD `rank_change` INT  NOT NULL DEFAULT '0' COMMENT '战斗攻击者名次变化';

-- +migrate Down
ALTER TABLE `arena_battle_record` DROP `rank_change`;