-- +migrate Up
ALTER TABLE `gvg_guild` ADD `host_heroes` mediumtext COMMENT '托管卡牌信息' AFTER `declare_num`;

-- +migrate Down
ALTER TABLE `gvg_guild` DROP COLUMN `host_heroes`;