
-- +migrate Up
ALTER TABLE `arena` ADD `no1_reward_days` INT  NOT NULL DEFAULT '0' COMMENT '排名第一上次奖励的天数';

-- +migrate Down
ALTER TABLE `arena` DROP `no1_reward_days`;