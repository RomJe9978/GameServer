
-- +migrate Up
ALTER TABLE `guild` ADD `appoint_title` MEDIUMTEXT COMMENT '公会封赏信息';

-- +migrate Down
ALTER TABLE `guild` DROP `appoint_title`;