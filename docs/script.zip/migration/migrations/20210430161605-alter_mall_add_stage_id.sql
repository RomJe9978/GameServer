-- +migrate Up
ALTER TABLE `mall` ADD `stage_id` int (11) not null DEFAULT 0 COMMENT '活动商城期数';

-- +migrate Down
ALTER TABLE `mall` DROP `stage_id`;
