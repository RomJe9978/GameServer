-- +migrate Up
ALTER TABLE `player` MODIFY `avatar` int(11) NOT NULL DEFAULT '0';

-- +migrate Down
ALTER TABLE `player` MODIFY `avatar` varchar(255);
