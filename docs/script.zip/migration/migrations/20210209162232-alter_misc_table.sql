
-- +migrate Up
ALTER TABLE `misc` ADD `max_mail_id` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '已领取GM后台最大邮件id' AFTER `dispatch_hero_list`;

-- +migrate Down
ALTER TABLE DROP `max_mail_id`;
