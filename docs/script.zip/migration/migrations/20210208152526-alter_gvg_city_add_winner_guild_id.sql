-- +migrate Up
ALTER TABLE `gvg_city` ADD `winner_guild_id` bigint(20)  NOT NULL default '0' COMMENT '上次战斗最终胜利方公会ID';

-- +migrate Down
ALTER TABLE `gvg_city` DROP COLUMN `winner_guild_id`;