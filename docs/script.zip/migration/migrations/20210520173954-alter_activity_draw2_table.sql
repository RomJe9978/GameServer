
-- +migrate Up
ALTER TABLE `activity_draw2` ADD `draw_targets` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '\'\'' COMMENT '宝物抽奖目标' AFTER `status`;

-- +migrate Down
ALTER TABLE `activity_draw2` DROP `draw_targets`;
