
-- +migrate Up
ALTER TABLE `rank_activity` ADD `reward_get` TINYINT  NOT NULL DEFAULT '0' COMMENT '是否领取了任务奖励';

-- +migrate Down
ALTER TABLE `rank_activity` DROP `reward_get`;
