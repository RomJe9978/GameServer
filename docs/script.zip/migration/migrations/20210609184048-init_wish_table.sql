-- +migrate Up
CREATE TABLE IF NOT EXISTS `wish` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `progress` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '满意度',
  `god` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '神id',
  `bucket_list` text COMMENT '许愿列表',
  `refine_list` varchar(255) DEFAULT NULL COMMENT '试炼列表',
  `god_list` varchar(255) DEFAULT NULL COMMENT '激活神信息',
  `first_item_list` text COMMENT '首次使用道具列表',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='抽奖幸运表';

-- +migrate Down
DROP TABLE IF EXISTS `wish`;
