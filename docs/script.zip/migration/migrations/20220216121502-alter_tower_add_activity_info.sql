
-- +migrate Up
ALTER TABLE `tower` ADD `activity_id` INT NOT NULL DEFAULT '0'  COMMENT '活动id' AFTER `condition_tower_formation`;
ALTER TABLE `tower` ADD `issueNo` INT NOT NULL DEFAULT '0'  COMMENT '活动期号' AFTER `activity_id`;


-- +migrate Down
ALTER TABLE `tower` DROP `activity_id`;
ALTER TABLE `tower` DROP `issueNo`;
