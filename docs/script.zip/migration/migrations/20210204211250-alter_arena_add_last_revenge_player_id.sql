-- +migrate Up
ALTER TABLE `arena` ADD `last_revenge_player_id` bigint(20) unsigned NOT NULL default '0' COMMENT '上次击败自己的玩家';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `last_revenge_player_id`;