
-- +migrate Up
ALTER TABLE `misc` ADD `get_battle_bass_score_at` TIMESTAMP NULL DEFAULT NULL COMMENT '领取新年战令积分时间' AFTER `newbie_draw_n`;

-- +migrate Down
ALTER TABLE `misc` DROP `get_battle_bass_score_at`;
