
-- +migrate Up
ALTER TABLE `iap` CHANGE `goods_price` `goods_price` float not null DEFAULT 0 COMMENT '商品价格';
-- +migrate Down
