
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `stage` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '组队副本体力领取阶段' AFTER `first_passed_list`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `stage`;
