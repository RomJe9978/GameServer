
-- +migrate Up
ALTER TABLE `house_furniture` ADD `visit_time_info` MEDIUMTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '访问时间' AFTER `visit_list`;

-- +migrate Down
ALTER TABLE `house_furniture` DROP `visi_time_info`;
