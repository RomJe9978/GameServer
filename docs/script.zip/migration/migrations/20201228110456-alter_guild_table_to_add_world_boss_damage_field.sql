-- +migrate Up
ALTER TABLE `guild` ADD `max_world_boss_damage` bigint(20) unsigned NOT NULL default '0' COMMENT '本期公会world boss最大伤害';
ALTER TABLE `guild` ADD `last_max_world_boss_damage` bigint(20) unsigned NOT NULL  default '0' COMMENT '上期公会world boss最大伤害';

-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `max_world_boss_damage`;
ALTER TABLE `guild` DROP COLUMN `last_max_world_boss_damage`;