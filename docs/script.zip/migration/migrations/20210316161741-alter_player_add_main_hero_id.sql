
-- +migrate Up
ALTER TABLE `player` ADD `main_hero_id` int (11) not null DEFAULT 0  COMMENT '选择的主角ID';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `main_hero_id`;