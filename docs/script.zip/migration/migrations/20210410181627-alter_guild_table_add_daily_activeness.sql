-- +migrate Up
ALTER TABLE `guild` ADD `daily_activeness` int (11) not null DEFAULT 0  COMMENT '当日活跃度';

-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `daily_activeness`;