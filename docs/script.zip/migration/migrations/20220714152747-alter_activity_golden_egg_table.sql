
-- +migrate Up
ALTER TABLE `activity_golden_egg` ADD `deposit` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '存钱罐' AFTER `best_record_data`;

-- +migrate Down
ALTER TABLE `activity_golden_egg` DROP `deposit`;
