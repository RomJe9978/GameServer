-- +migrate Up
ALTER TABLE `gvg_city` ADD `scheduled_attack_at` INT NOT NULL DEFAULT '0' COMMENT '集中进攻开始时间' ;

-- +migrate Down
ALTER TABLE `gvg_city` DROP `scheduled_attack_at`;
