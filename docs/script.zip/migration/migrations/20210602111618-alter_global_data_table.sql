
-- +migrate Up
ALTER TABLE `global_data` ADD `status` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '活动状态' AFTER `issue_no`;

-- +migrate Down
ALTER TABLE `global_data` DROP `status`;
