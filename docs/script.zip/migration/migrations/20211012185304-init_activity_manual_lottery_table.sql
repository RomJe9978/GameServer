-- +migrate Up
CREATE TABLE IF NOT EXISTS `activity_manual_lottery` (
  `player_id` bigint(21) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `lottery_type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '自选奖励抽奖类型',
  `lottery_info` text COMMENT '次数信息',
  `guarantee_lottery_info` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '保底次数',
  `group_list` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '奖品组',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '抽奖次数',
  `issue` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '活动期号',
  `lottery_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '自选奖励抽奖模板id',
  `guarantee_list` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '随机保底次数',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`lottery_type`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自选奖励抽奖';

-- +migrate Down
DROP TABLE IF EXISTS `activity_manual_lottery`;
