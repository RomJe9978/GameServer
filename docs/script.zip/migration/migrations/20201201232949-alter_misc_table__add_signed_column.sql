
-- +migrate Up
ALTER TABLE `misc` ADD `signed` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '签到位图' AFTER `last_quit_guild_at`;


-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `signed`;
