
-- +migrate Up
CREATE TABLE `arena` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家ID',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '当前排名',
  `best_rank` int(11) NOT NULL DEFAULT '0' COMMENT '历史最高排名',
  `no1_rank_days` int(11) NOT NULL DEFAULT '0' COMMENT '第一名累计天数',
  `no1_rank_time` int(11) NOT NULL DEFAULT '0' COMMENT '第一名更新时间',
  `challenge_times` int(11) NOT NULL DEFAULT '0' COMMENT '当日已挑战次数',
  `buy_challenge_times` int(11) NOT NULL DEFAULT '0' COMMENT '购买的挑战次数',
  `buy_times` int(11) NOT NULL DEFAULT '0' COMMENT '购买次数',
  `defend_heroes` mediumblob COMMENT '防守阵容快照',
  `refresh_at` int(11) NOT NULL DEFAULT '0' COMMENT '竞技场数据刷新时间',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `arena`;