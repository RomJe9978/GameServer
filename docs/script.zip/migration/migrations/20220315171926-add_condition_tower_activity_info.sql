
-- +migrate Up
ALTER TABLE `new_activity_task_info` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '刷新时间戳' AFTER `puzzle_reward_list`;

ALTER TABLE `tower` ADD `activity_id` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '活动ID' AFTER `condition_tower_formation`;
ALTER TABLE `tower` ADD `issueNo` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '期号' AFTER `activity_id`;

ALTER TABLE `buff` ADD `total_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '生效剩余次数' AFTER `expire_at`;

-- +migrate Down
ALTER TABLE `new_activity_task_info` DROP `refresh_at`;
ALTER TABLE `tower` DROP `activity_id`;
ALTER TABLE `tower` DROP `issueNo`;
ALTER TABLE `buff` DROP `total_times`;