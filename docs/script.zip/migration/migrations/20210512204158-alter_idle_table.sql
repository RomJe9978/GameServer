
-- +migrate Up
ALTER TABLE `idle` ADD `max_idle_at` TIMESTAMP NULL DEFAULT NULL COMMENT '最大挂机时间点 'AFTER `total_secs`;

-- +migrate Down
ALTER TABLE `idle` DROP `max_idle_at`;
