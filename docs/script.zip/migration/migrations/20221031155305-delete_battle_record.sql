
-- +migrate Up
delete from `battle_level_record` where `type`= 54;
delete from `battle_record` where `type` = 54;
-- +migrate Down
