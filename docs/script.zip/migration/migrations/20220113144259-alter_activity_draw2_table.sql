
-- +migrate Up
ALTER TABLE `activity_draw2` ADD `draw_target_v2` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '宝物UP道具' AFTER `draw_targets`;
ALTER TABLE `activity_draw2` ADD `up_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '宝物UP抽奖次数' AFTER `draw_target_v2`;
ALTER TABLE `activity_draw2` ADD `up_fixed` TINYINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '宝物UP次数是否已修正' AFTER `up_times`;

-- +migrate Down
ALTER TABLE `activity_draw2` DROP `up_fixed`;
ALTER TABLE `activity_draw2` DROP `up_times`;
ALTER TABLE `activity_draw2` DROP `draw_target_v2`;
