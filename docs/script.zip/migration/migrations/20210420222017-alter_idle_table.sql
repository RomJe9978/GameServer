
-- +migrate Up
ALTER TABLE `idle` ADD `total_secs` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '累积挂机时间' AFTER `used_free_times`;

-- +migrate Down
ALTER TABLE `idle` DROP `total_secs`;
