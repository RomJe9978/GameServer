
-- +migrate Up
ALTER TABLE `misc` ADD `chat_bg` VARCHAR(255) DEFAULT NULL COMMENT '聊天背景图' AFTER `chat_stranger`;

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `chat_bg`;
