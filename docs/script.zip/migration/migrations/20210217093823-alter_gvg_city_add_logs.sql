
-- +migrate Up
ALTER TABLE `gvg_city` ADD `logs` MEDIUMBLOB NULL DEFAULT NULL COMMENT '城池日志' AFTER `winner_guild_id`;

-- +migrate Down
ALTER TABLE `gvg_city` DROP `logs`;
