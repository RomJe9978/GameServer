
-- +migrate Up
ALTER TABLE `global_mail` ADD `registered` TINYINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否发送新新注册玩家' AFTER `expire_at`;

-- +migrate Down
ALTER TABLE `global_mail` DROP `registered`;
