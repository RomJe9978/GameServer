
-- +migrate Up
ALTER TABLE `hero` ADD `nick_name` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '卡牌名字';
ALTER TABLE `hero` ADD `is_effect_close` TINYINT  NOT NULL DEFAULT '0' COMMENT '卡牌是否开启了特效';

-- +migrate Down
ALTER TABLE `hero` DROP `nick_name`;
ALTER TABLE `hero` DROP `is_effect_close`;