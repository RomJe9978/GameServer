
-- +migrate Up
ALTER TABLE `player_dungeon` ADD `max_difficulty` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '通过的最大副本难度' AFTER `success_times`;

-- +migrate Down
ALTER TABLE `player_dungeon` DROP `max_difficulty`;
