
-- +migrate Up
ALTER TABLE `friendship` CHANGE `friend_list` `friend_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '好友列表';
ALTER TABLE `friendship` CHANGE `apply_list` `apply_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '申请列表';
ALTER TABLE `friendship` CHANGE `black_list` `black_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '黑名单';

-- +migrate Down
ALTER TABLE `friendship` CHANGE `friend_list` `friend_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '好友列表';
ALTER TABLE `friendship` CHANGE `apply_list` `apply_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '申请列表';
ALTER TABLE `friendship` CHANGE `black_list` `black_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '黑名单';
