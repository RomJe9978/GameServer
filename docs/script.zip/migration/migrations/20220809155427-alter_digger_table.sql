
-- +migrate Up
ALTER TABLE `digger` ADD `score` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '积分，用于计算掉落次数' AFTER `collect_item_info`;

-- +migrate Down
ALTER TABLE `digger` DROP `score`;
