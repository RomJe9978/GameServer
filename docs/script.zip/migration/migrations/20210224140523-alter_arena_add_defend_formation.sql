
-- +migrate Up
ALTER TABLE `arena` DROP `attacker`;
ALTER TABLE `arena` DROP `defender`;
ALTER TABLE `arena` ADD `defend_formation` MEDIUMBLOB NULL DEFAULT NULL COMMENT '防守阵容';

-- +migrate Down
ALTER TABLE `arena` DROP `attacker`;

