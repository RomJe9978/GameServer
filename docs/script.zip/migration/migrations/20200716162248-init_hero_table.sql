
-- +migrate Up
CREATE TABLE IF NOT EXISTS `hero` (
  `id` bigint(20) unsigned NOT NULL COMMENT '佣兵ID',
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `template_id` int(11) NOT NULL COMMENT '佣兵配置ID',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `hero`;
