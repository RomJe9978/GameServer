
-- +migrate Up
CREATE TABLE IF NOT EXISTS `worker` (
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'worker模板id',
      `action` int(11) NOT NULL DEFAULT '0' COMMENT '正在做什么',
      `work_at` int(11) NOT NULL DEFAULT '0' COMMENT '开始时间戳',
      `timeout` int(11) NOT NULL DEFAULT '0' COMMENT '结束时间戳',
      `energy` int(11) NOT NULL DEFAULT '0' COMMENT '已使用体力',
      `refresh_at` int(11) NOT NULL DEFAULT '0' COMMENT '刷新时间戳',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`,`template_id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='worker表';

-- +migrate Down
DROP TABLE IF EXISTS `worker`;
