
-- +migrate Up
DROP TABLE IF EXISTS `mail`;

CREATE TABLE IF NOT EXISTS `mail` (
 `mail_id` bigint(20) unsigned NOT NULL COMMENT '邮件唯一id',
 `template_id` int(10) unsigned DEFAULT '0' COMMENT '邮件模板id',
 `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
 `sender_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '邮件来源',
 `sender_name` varchar(255) DEFAULT '''''' COMMENT '发送者名字',
 `avatar` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送者头像id',
 `title` varchar(255) DEFAULT '''''' COMMENT '邮件标题',
 `content` text COMMENT '邮件内容',
 `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件领取状态',
 `attachment` text COMMENT '附件',
 `extra` varchar(255) DEFAULT '''''' COMMENT '邮件额外参数，例如排行榜名次',
 `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '生成时间戳',
 `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
 `invalid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否失效',
 PRIMARY KEY (`mail_id`),
 KEY `valid_player` (`player_id`,`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件表';

-- +migrate Down
DROP TABLE IF EXISTS `mail`;
