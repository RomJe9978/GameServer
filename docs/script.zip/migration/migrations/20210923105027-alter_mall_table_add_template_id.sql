
-- +migrate Up
ALTER TABLE `mall` ADD `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '子商城ID';
alter table mall drop PRIMARY KEY;
alter table mall ADD PRIMARY KEY (`player_id`,`mall_type`,`template_id`);
-- +migrate Down
