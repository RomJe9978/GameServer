
-- +migrate Up
ALTER TABLE `dispatch` ADD `refresh_count` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '已刷新次数' AFTER `refresh_time`;


-- +migrate Down
ALTER TABLE `dispatch` DROP `refresh_count`;
