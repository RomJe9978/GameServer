
-- +migrate Up
ALTER TABLE `hero` ADD `dragon_soul_used_dan_times` MEDIUMTEXT COMMENT '龙魂丹使用信息';

-- +migrate Down
ALTER TABLE `hero` DROP `dragon_soul_used_dan_times`;
