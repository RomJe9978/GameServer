
-- +migrate Up
ALTER TABLE `guild` ADD `chairman_timestamps` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '会长继位时间戳' AFTER `chairman_id`;

-- +migrate Down
ALTER TABLE `guild` DROP `chairman_timestamps`;
