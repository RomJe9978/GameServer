
-- +migrate Up
CREATE TABLE IF NOT EXISTS `hero_shard` (
  `id` bigint(20) unsigned NOT NULL COMMENT '武将碎片唯一id',
  `player_id` bigint(20) NOT NULL COMMENT '玩家id',
  `template_id` int(11) NOT NULL COMMENT '武将碎片模板id',
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '碎片数量',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `hero_shard`;
