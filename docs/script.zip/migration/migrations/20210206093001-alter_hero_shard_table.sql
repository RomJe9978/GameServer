
-- +migrate Up
ALTER TABLE `hero_shard` ADD `status` INT UNSIGNED NULL DEFAULT '0' COMMENT '图鉴状态' AFTER `count`;


-- +migrate Down
ALTER TABLE `hero_shard` DROP `status`;
