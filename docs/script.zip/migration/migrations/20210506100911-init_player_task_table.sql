-- +migrate Up
DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `task_type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '任务类型',
  `tasks` text COMMENT '主线任务Json',
  `activeness` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日常活跃度',
  `rewards` text COMMENT '日常任务奖励Json',
  `refresh_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日常任务刷新上次刷新时间戳',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '生成时间戳',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否失效',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`,`task_type`),
  KEY `player_id` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `task`;
