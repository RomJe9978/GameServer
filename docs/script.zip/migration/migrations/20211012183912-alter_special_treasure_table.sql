
-- +migrate Up
ALTER TABLE `special_treasure` ADD `maze_unlock` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '累积未触发解锁东山迷局第4层难度次数' AFTER `lowest_score_times`;

-- +migrate Down
ALTER TABLE `special_treasure` DROP `maze_unlock`;
