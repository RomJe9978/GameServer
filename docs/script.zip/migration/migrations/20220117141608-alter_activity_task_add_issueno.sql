
-- +migrate Up
ALTER TABLE `new_activity_task_info` ADD `issueNo` INT NOT NULL DEFAULT '0' COMMENT '活动期号' AFTER `activity_id`;
ALTER TABLE `buff` MODIFY COLUMN `activity_id` varchar(64) COMMENT '活动信息';

-- +migrate Down
ALTER TABLE `new_activity_task_info` DROP `issueNo`;