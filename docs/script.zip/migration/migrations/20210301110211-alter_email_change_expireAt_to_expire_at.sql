
-- +migrate Up
ALTER TABLE mail CHANGE `expireAt` `expire_at` int(11) NOT NULL DEFAULT '0' COMMENT '过期时间';

-- +migrate Down