
-- +migrate Up
ALTER TABLE `hero` DROP COLUMN `skill_list`;

-- +migrate Down
ALTER TABLE `hero` ADD COLUMN `skill_list` varchar(255) default NULL AFTER `refine_attribute_list`;
