
-- +migrate Up
ALTER TABLE `player` ADD `unban_at` int(11) not null default 0 COMMENT '预计解封时间戳';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `unban_at`;