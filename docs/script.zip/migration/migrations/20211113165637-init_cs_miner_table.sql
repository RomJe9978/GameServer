
-- +migrate Up
CREATE TABLE IF NOT EXISTS `cs_miner` (
      `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
      `season_issue_no` int(10) unsigned DEFAULT '0' COMMENT '跨服占矿赛季id',
      `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
      `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL COMMENT '删除标记',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `idx_update_at` (`update_ts`)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='跨服占矿玩家数据表'; 

-- +migrate Down
DROP TABLE IF EXISTS `cs_miner`;
