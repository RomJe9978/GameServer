-- +migrate Up
ALTER TABLE `mission` ADD COLUMN `refresh_at` int(11) NOT NULL DEFAULT '0' COMMENT '上次挑战次数刷新时间' AFTER `pass_times`;

-- +migrate Down

ALTER TABLE `mission` DROP COLUMN `refresh_at`;