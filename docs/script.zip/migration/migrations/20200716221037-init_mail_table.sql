
-- +migrate Up

CREATE TABLE IF NOT EXISTS `mail` (
  `mail_id` bigint(20) unsigned NOT NULL COMMENT '邮件唯一id',
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `from_id` bigint(20) unsigned NOT NULL COMMENT '邮件来源',
  `title` varchar(255) DEFAULT NULL COMMENT '邮件标题',
  `content` varchar(255) DEFAULT NULL COMMENT '邮件内容',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件领取状态',
  `attachment` mediumtext COMMENT '附件',
  `create_at` int(11) NOT NULL COMMENT '生成时间戳',
  `update_at` int(11) NOT NULL COMMENT '更新时间',
  `invalid` tinyint(1) NOT NULL COMMENT '是否失效',
  PRIMARY KEY (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件表';

-- +migrate Down
DROP TABLE IF EXISTS `mail`;
