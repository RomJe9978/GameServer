
-- +migrate Up
CREATE TABLE `activity_dungeon` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '模版id',
  `dungeon_list` text COMMENT '副本列表',
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动副本';

CREATE TABLE `activity_boss` (
  `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家唯一id',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '模版id',
  `boss_id` int(11) NOT NULL DEFAULT '0' COMMENT 'bossId',
  `challenge_time` int(11) NOT NULL DEFAULT '0' COMMENT '已经挑战的次数',
  `refresh_at` int(11) DEFAULT NULL COMMENT '刷新时间',
  `max_damage` bigint(21) NOT NULL DEFAULT '0' COMMENT '最大伤害',
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动boss';

ALTER TABLE `misc` ADD `activity_dungeon_last_json` TEXT COMMENT '活动副本上期通关难度信息';

-- +migrate Down
ALTER TABLE `misc` DROP `activity_dungeon_last_json`;