
-- +migrate Up
ALTER TABLE `cs_miner` ADD `add_buff_times` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '本期跨服占矿已使用buff次数' AFTER `season_issue_no`;

-- +migrate Down
ALTER TABLE `cs_miner` DROP `add_buff_times`;
