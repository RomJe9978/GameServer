
-- +migrate Up
CREATE TABLE IF NOT EXISTS `treasure_kizuna` (
      `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
      `activated_list` text COMMENT '已激活羁绊Id列表',
      `got_list` varchar(255) DEFAULT NULL COMMENT '已领取羁绊列表',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`),
      KEY `valid_player` (`player_id`,`invalid`),
      KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `treasure_kizuna`;
