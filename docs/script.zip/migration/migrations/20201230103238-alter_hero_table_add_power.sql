-- +migrate Up
ALTER TABLE `hero` ADD `power` bigint(20) unsigned NOT NULL default '0' COMMENT '卡牌总战力';

-- +migrate Down
ALTER TABLE `hero` DROP COLUMN `power`;