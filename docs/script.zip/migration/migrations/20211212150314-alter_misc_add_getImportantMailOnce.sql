
-- +migrate Up
ALTER TABLE `misc` ADD `get_important_mail_once` TINYINT  NOT NULL DEFAULT '0'  COMMENT '是否一键领取重要邮件';

-- +migrate Down
ALTER TABLE `misc` DROP `get_important_mail_once`;
