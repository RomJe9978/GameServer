
-- +migrate Up
ALTER TABLE `rich_man` ADD `before_show_effect_level` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '惠比寿显示快照' AFTER `show_effect_level`;
ALTER TABLE `rich_man` ADD `before_level_up_effect` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '惠比寿生效快照' AFTER `before_show_effect_level`;

-- +migrate Down
ALTER TABLE `rich_man` DROP `before_show_effect_level`;
ALTER TABLE `rich_man` DROP `before_level_up_effect`;