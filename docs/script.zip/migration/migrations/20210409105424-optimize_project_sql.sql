
-- +migrate Up

-- add index
ALTER TABLE `player` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `player` ADD INDEX `level` (`level`);
ALTER TABLE `player` ADD INDEX `serverid` (`server_id`);
ALTER TABLE `player` ADD INDEX `client_server_invalid` (`client_id`,`server_id`,`invalid`);

ALTER TABLE `mail` ADD INDEX `gmid` (`gmid`);
ALTER TABLE `global_mail` ADD INDEX `gmid` (`gmid`);

ALTER TABLE `chat` ADD INDEX `type` (`type`);
ALTER TABLE `chat` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `hero` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `hero` ADD INDEX `power` (`power`);
ALTER TABLE `hero` ADD INDEX `master_template_id` (`master_template_id`);
ALTER TABLE `mission` ADD INDEX `map_id` (`map_id`);
ALTER TABLE `guild` ADD INDEX `activeness` (`activeness`);
ALTER TABLE `guild` ADD INDEX `last_activeness` (`last_activeness`);
ALTER TABLE `guild` ADD INDEX `last_max_world_boss_damage` (`last_max_world_boss_damage`);
ALTER TABLE `guild` ADD INDEX `max_world_boss_damage` (`max_world_boss_damage`);
ALTER TABLE `guild` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `dungeon` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `gvg_guild` ADD INDEX `score` (`score`);
ALTER TABLE `gvg_guild` ADD INDEX `total_score` (`total_score`);
ALTER TABLE `arena` ADD INDEX `rank` (`rank`);
ALTER TABLE `arena` ADD INDEX `invalid` (`invalid`);
ALTER TABLE `arena_battle_record` ADD INDEX `attacker_id` (`attacker_id`);
ALTER TABLE `arena_battle_record` ADD INDEX `defender_id` (`defender_id`);
ALTER TABLE `treasure` ADD INDEX `invalid` (`invalid`);

ALTER TABLE `iap` ADD `id` bigint(21) unsigned AUTO_INCREMENT primary key NOT NULL  COMMENT '序号';
ALTER TABLE `iap` ADD INDEX `idx_order` (`game_order_id`,`order_id`);
ALTER TABLE `iap` ADD INDEX `valid_player` (`player_id`,`invalid`);

-- update mail table add create_ts & update_ts

ALTER TABLE `activity_draw_luck` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `activity_draw_luck` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `activity_draw_luck` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `activity_draw2` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `activity_draw2` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `activity_draw2` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `activity_golden_egg` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `activity_golden_egg` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `activity_golden_egg` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `activity_scratch` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `activity_scratch` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `activity_scratch` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `arena` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `arena` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `arena` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `arena_battle_record` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `arena_battle_record` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `arena_battle_record` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `arena_npc` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `arena_npc` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `arena_npc` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `avatar_box` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `avatar_box` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `avatar_box` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `battle_level_record` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `battle_level_record` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `battle_level_record` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `battle_record` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `battle_record` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `battle_record` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `chat` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `chat` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `chat` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `counter` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `counter` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `counter` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `dispatch` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `dispatch` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `dispatch` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `drop_meta` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `drop_meta` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `drop_meta` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `dungeon` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `dungeon` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `dungeon` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `dungeon_battle_record` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `dungeon_battle_record` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `dungeon_battle_record` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `equip` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `equip` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `equip` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `formation` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `formation` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `formation` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `friendship` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `friendship` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `friendship` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `fund` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `fund` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `fund` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `global_data` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `global_data` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `global_data` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `global_mail` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `global_mail` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `global_mail` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `guild` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `guild` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `guild` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `guild_member` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `guild_member` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `guild_member` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `gvg_city` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `gvg_city` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `gvg_city` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `gvg_guild` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `gvg_guild` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `gvg_guild` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `gvg_player` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `gvg_player` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `gvg_player` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `hero` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `hero` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `hero` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `hero_journal` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `hero_journal` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `hero_journal` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `hero_shard` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `hero_shard` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `hero_shard` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `iap` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `iap` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `iap` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `idle` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `idle` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `idle` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `item` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `item` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `item` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `kizuna` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `kizuna` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `kizuna` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `mail` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `mail` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `mail` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `main_hero` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `main_hero` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `main_hero` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `mall` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `mall` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `mall` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `master` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `master` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `master` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `maze` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `maze` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `maze` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `misc` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `misc` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `misc` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `mission` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `mission` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `mission` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `monthly_card` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `monthly_card` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `monthly_card` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `npc_love` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `npc_love` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `npc_love` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `player` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `player` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `player` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `player_document` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `player_document` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `player_document` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `player_dungeon` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `player_dungeon` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `player_dungeon` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `player_scratch` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `player_scratch` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `player_scratch` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `player_world_boss` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `player_world_boss` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `player_world_boss` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `privilege_card` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `privilege_card` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `privilege_card` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `server_refresh_info` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `server_refresh_info` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `server_refresh_info` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `shop` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `shop` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `shop` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `snapshot` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `snapshot` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `snapshot` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `soul` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `soul` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `soul` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `special_treasure` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `special_treasure` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `special_treasure` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `story` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `story` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `story` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `story_email` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `story_email` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `story_email` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `task` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `task` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `task` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `tower` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `tower` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `tower` ADD INDEX `idx_update_at` (`update_ts`);

ALTER TABLE `treasure` ADD `create_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳';
ALTER TABLE `treasure` ADD `update_ts` INT(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳';
ALTER TABLE `treasure` ADD INDEX `idx_update_at` (`update_ts`);