
-- +migrate Up
ALTER TABLE `misc` ADD `dispatch_hero_list` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '正在派遣任务中的英雄列表' AFTER `signed_count`;

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `dispatch_hero_list`;
