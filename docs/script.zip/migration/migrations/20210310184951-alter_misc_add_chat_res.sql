-- +migrate Up
ALTER TABLE `misc` ADD `chat_mbox` mediumtext  COMMENT '聊天气泡';
ALTER TABLE `misc` ADD `chat_emoji` mediumtext  COMMENT '聊天小表情';
ALTER TABLE `misc` ADD `chat_sticker` mediumtext  COMMENT '聊天大表情';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `chat_mbox`;
ALTER TABLE `misc` DROP COLUMN `chat_emoji`;
ALTER TABLE `misc` DROP COLUMN `chat_sticker`;
