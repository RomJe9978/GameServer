
-- +migrate Up
CREATE TABLE `main_hero` (
 `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
 `character_tpl_id` int(10) unsigned NOT NULL COMMENT '主角模板id',
 `favor` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '好感度',
 `official_position` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '官职等级',
 `destiny_data` blob COMMENT '命运',
 `create_at` timestamp NULL DEFAULT NULL COMMENT '生成时间戳',
 `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
 `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否失效',
 PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主角表';

-- +migrate Down
DROP TABLE IF EXISTS `main_hero`;
