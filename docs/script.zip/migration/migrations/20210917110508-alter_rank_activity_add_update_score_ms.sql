
-- +migrate Up
ALTER TABLE `rank_activity` ADD `update_score_ms` timestamp NULL DEFAULT NULL COMMENT '上次更新分数时间';

-- +migrate Down
ALTER TABLE `rank_activity` DROP COLUMN `update_score_ms`;
