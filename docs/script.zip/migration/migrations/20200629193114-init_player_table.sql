
-- +migrate Up
CREATE TABLE `player` (
  `id` bigint(11) unsigned NOT NULL,
  `client_id` varchar(128) DEFAULT NULL COMMENT '客户端账号ID',
  `device_id` varchar(128) DEFAULT NULL COMMENT '客户端设备ID',
  `platform` varchar(32) DEFAULT NULL COMMENT '客户端操作系统平台：Android,iOS',
  `server_id` int(11) DEFAULT NULL COMMENT '区服ID',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `player`;