
-- +migrate Up
CREATE TABLE IF NOT EXISTS `hero` (
      `id` bigint(20) unsigned NOT NULL COMMENT '佣兵ID',
      `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
      `template_id` int(11) NOT NULL COMMENT '佣兵配置ID',
      `favor` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '好感度',
      `random_seed` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '随机数种子',
      `stage` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '进阶等级',
      `star` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '星级',
      `exp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当前星级下的经验',
      `add_exp_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '增加升星经验次数',
      `refine_level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '育成重数',
      `refine_attribute_list` varchar(255) DEFAULT NULL COMMENT '育成属性列',
      `skill_list` varchar(255) DEFAULT NULL COMMENT '技能列表',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `hero`;
