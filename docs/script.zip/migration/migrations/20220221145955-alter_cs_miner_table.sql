
-- +migrate Up
ALTER TABLE `cs_miner` ADD `common_reward_ts` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '普通拾荒者领取时间戳' AFTER `add_buff_times`; 
ALTER TABLE `cs_miner` ADD `senior_reward_ts` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '高级拾荒者领取时间戳' AFTER `common_reward_ts`; 
ALTER TABLE `cs_miner` ADD `daily_occupied_score` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '每日占领矿点累积积分' AFTER `senior_reward_ts`;
ALTER TABLE `cs_miner` ADD `daily_time_score_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '每日占领矿点时间累积积分' AFTER `daily_occupied_score`; 
ALTER TABLE `cs_miner` ADD `total_seconds` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '累积发奖时长' AFTER `daily_time_score_info`;
ALTER TABLE `cs_miner` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '每日刷新时间戳' AFTER `total_seconds`;

-- +migrate Down
ALTER TABLE `cs_miner` DROP `common_reward_ts`, DROP `senior_reward_ts`, DROP `daily_occupied_score`, DROP `daily_time_score_info`, DROP `total_seconds`;
