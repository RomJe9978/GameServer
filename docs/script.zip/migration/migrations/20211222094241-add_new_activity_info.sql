
-- +migrate Up
CREATE TABLE `new_activity_info` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `activity_id` int(10) NOT NULL DEFAULT '0' COMMENT '活动id',
  `activity_type` int(10) NOT NULL DEFAULT '0' COMMENT '活动类型',
  `issueNo` int(10) NOT NULL DEFAULT '0' COMMENT '活动期号',
  `status` int(10) NOT NULL DEFAULT '0' COMMENT '活动状态',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`player_id`,`activity_id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='活动表';

CREATE TABLE `new_activity_task_info` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `activity_id` int(10) NOT NULL DEFAULT '0' COMMENT '活动id',
  `tasks` text COMMENT '主线任务Json' COMMENT '活动关联的任务信息',
  `activeness` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日常活跃度',
  `rewards` text COMMENT '任务奖励Json',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`player_id`,`activity_id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='活动任务表';

CREATE TABLE `buff` (
  `id` bigint(20) unsigned NOT NULL COMMENT 'buffID',
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家唯一id',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'buff来源',
  `activity_id` int(10) NOT NULL DEFAULT '0' COMMENT '活动id',
  `template_id` int(10) NOT NULL DEFAULT '0' COMMENT '配置id',
  `expire_at` int(11) DEFAULT NULL COMMENT '过期时间戳',
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `valid_player` (`player_id`,`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='buff表';

-- +migrate Down
DROP TABLE IF EXISTS `new_activity_info`;
DROP TABLE IF EXISTS `new_activity_task_info`;
DROP TABLE IF EXISTS `buff`;


