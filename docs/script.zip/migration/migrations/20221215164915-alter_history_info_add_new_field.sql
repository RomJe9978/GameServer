
-- +migrate Up
ALTER TABLE `history_info` ADD COLUMN `field_40` int(11) NOT NULL DEFAULT 0;
ALTER TABLE `history_info` ADD COLUMN `field_41` int(11) NOT NULL DEFAULT 0;

-- +migrate Down
ALTER TABLE `history_info` DROP `field_40`;
ALTER TABLE `history_info` DROP `field_41`;