
-- +migrate Up
CREATE TABLE IF NOT EXISTS `activity_draw2` (
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '奖池模板子id',
  `pool_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '奖池模板id',
  `draw_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '抽奖次数',
  `left_bless_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '剩余庇佑次数',
  `free_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已使用免费次数',
  `status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '状态（邂逅）',
  `start_time` timestamp NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` timestamp NULL DEFAULT NULL COMMENT '结束时间',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`,`template_id`),
  KEY `valid_player` (`player_id`,`invalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `activity_draw2`;
