-- +migrate Up
ALTER TABLE `maze` ADD `extra_lv` int (11) not null DEFAULT 0 COMMENT '玩家自身难度';

-- +migrate Down
ALTER TABLE `maze` DROP `extra_lv`;