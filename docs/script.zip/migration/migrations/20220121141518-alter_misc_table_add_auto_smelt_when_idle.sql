
-- +migrate Up
ALTER TABLE `misc` ADD `auto_smelt_when_idle` TINYINT  NOT NULL DEFAULT '0' COMMENT '挂机时是否自动熔炼' AFTER `privilege_info`;

-- +migrate Down
ALTER TABLE `misc` DROP `auto_smelt_when_idle`;