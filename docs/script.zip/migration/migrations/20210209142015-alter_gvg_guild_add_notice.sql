-- +migrate Up
ALTER TABLE `gvg_guild` ADD `notice` varchar (1024)   COMMENT '宣战公告';

-- +migrate Down
ALTER TABLE `gvg_guild` DROP COLUMN `notice`;