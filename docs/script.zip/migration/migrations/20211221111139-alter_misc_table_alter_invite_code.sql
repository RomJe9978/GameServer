
-- +migrate Up
ALTER TABLE `misc` ADD `bind_invite_code` INT NOT NULL DEFAULT '0' COMMENT '绑定的邀请码' AFTER `exp_buff_expired`;

-- +migrate Down
ALTER TABLE `misc` DROP `bind_invite_code`;