
-- +migrate Up
ALTER TABLE `shop` ADD `score_rewards` TEXT COMMENT '商店积分奖励ID' AFTER `score`;

-- +migrate Down
ALTER TABLE `shop` DROP `score_rewards`;
