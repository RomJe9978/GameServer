
-- +migrate Up
ALTER TABLE `hero` ADD `sp_skill` MEDIUMTEXT COMMENT '激活的sp武将技能列表';
ALTER TABLE `hero` ADD `sp_skill_trans_attr` MEDIUMTEXT COMMENT '激活的sp武将技能转换列表';

-- +migrate Down
ALTER TABLE `hero` DROP `sp_skill`;
ALTER TABLE `hero` DROP `sp_skill_trans_attr`;