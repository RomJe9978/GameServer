
-- +migrate Up
ALTER TABLE `player` ADD COLUMN `topk_power` bigint(21) NOT NULL DEFAULT 0;

-- +migrate Down
ALTER TABLE `player` DROP `topk_power`;