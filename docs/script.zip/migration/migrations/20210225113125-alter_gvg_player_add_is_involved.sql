
-- +migrate Up
ALTER TABLE `gvg_player` ADD `is_involved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '当日是否已参与';

-- +migrate Down
ALTER TABLE `gvg_player` DROP `is_involved`;