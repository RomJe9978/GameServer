-- +migrate Up
ALTER TABLE `battle_level_record` MODIFY `rank_data` text DEFAULT NULL COMMENT '排行战斗信息';

-- +migrate Down
ALTER TABLE `battle_level_record` MODIFY `rank_data` varchar(512) DEFAULT NULL COMMENT '排行战斗信息';