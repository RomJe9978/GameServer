
-- +migrate Up
ALTER TABLE `misc` ADD `has_mute_update_rewarded` TINYINT  NOT NULL DEFAULT '0' COMMENT '是否领取了静默更新奖励' AFTER `privilege_info`;

-- +migrate Down
ALTER TABLE `misc` DROP `has_mute_update_rewarded`;

