-- +migrate Up
DROP TABLE IF EXISTS `rank_activity`;
CREATE TABLE `rank_activity` (
  `id` bigint(21) unsigned NOT NULL,
  `player_id` bigint(11) NOT NULL,
  `rank_id` int(11) NOT NULL DEFAULT 0,
  `score` int(11) NOT NULL DEFAULT 0,
  `reward_list` text DEFAULT NULL,
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT 0,
  `create_ts` int(11) NOT NULL DEFAULT 0,
  `update_ts` int(11) NOT NULL DEFAULT 0,
  `open_ts` int(11) NOT NULL DEFAULT 0,
  `end_ts` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- +migrate Down
DROP TABLE IF EXISTS `rank_activity`;
CREATE TABLE `rank_activity` (
  `player_id` bigint(21) unsigned NOT NULL,
  `rank_id` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `reward_list` text,
  `update_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `invalid` tinyint(4) NOT NULL DEFAULT '0',
  `create_ts` int(11) NOT NULL DEFAULT '0',
  `update_ts` int(11) NOT NULL DEFAULT '0',
  `open_ts` int(11) NOT NULL DEFAULT '0',
  `end_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_ts` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;