
-- +migrate Up
CREATE TABLE `tower_record` (
  `type` int(11) NOT NULL COMMENT '阵容类型',
  `tower_level` int(11) NOT NULL DEFAULT '0' COMMENT '当前等级信息',
  `first_pass` varchar(512) NOT NULL,
  `rank_data` varchar(512) DEFAULT NULL COMMENT '排行战斗信息',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`type`,`tower_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `tower_record`;