
-- +migrate Up
ALTER TABLE `guild_member` ADD `guild_power` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '玩家贡献的工会战力' AFTER `weekly_activeness`;

-- +migrate Down
ALTER TABLE `guild_member` DROP `guild_power`;
