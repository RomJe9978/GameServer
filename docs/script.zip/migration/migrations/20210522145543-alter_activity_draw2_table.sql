
-- +migrate Up
ALTER TABLE `activity_draw2` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '上次刷新时间戳' AFTER `end_time`;

-- +migrate Down
ALTER TABLE `activity_draw2` DROP `refresh_at`;
