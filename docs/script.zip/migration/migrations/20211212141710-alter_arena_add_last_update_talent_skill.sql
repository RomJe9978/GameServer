-- +migrate Up
ALTER TABLE `arena` ADD `last_update_talent_skill` MEDIUMTEXT COMMENT '上次更新阵容的天赋技能列表' ;
ALTER TABLE `cs_arena` ADD `last_update_talent_skill` MEDIUMTEXT COMMENT '上次更新阵容的天赋技能列表' ;

-- +migrate Down
ALTER TABLE `arena` DROP `last_update_talent_skill`;
ALTER TABLE `cs_arena` DROP `last_update_talent_skill`;
