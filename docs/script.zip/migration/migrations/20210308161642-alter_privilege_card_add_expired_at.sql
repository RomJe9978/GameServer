
-- +migrate Up
ALTER TABLE `privilege_card` ADD `expired_at` int (11) not null DEFAULT 0  COMMENT '奖励过期时间';

-- +migrate Down
ALTER TABLE `privilege_card` DROP COLUMN `expired_at`;