
-- +migrate Up
ALTER TABLE `player` ADD `update_level_at` TIMESTAMP NULL DEFAULT NULL COMMENT '更新等级时间戳' AFTER `level`;

-- +migrate Down
ALTER TABLE `player` DROP `update_level_at`;