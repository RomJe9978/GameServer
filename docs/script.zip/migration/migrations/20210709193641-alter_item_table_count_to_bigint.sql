
-- +migrate Up
ALTER TABLE item change `count`  `count` bigint(20);

-- +migrate Down
ALTER TABLE item change  `count` `count` int;