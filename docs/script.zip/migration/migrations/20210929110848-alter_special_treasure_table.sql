
-- +migrate Up
ALTER TABLE `special_treasure` ADD `lowest_score_times` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '抽奖最低次数' AFTER `turn_table`;

-- +migrate Down
ALTER TABLE `special_treasure` DROP `lowest_score_times`;
