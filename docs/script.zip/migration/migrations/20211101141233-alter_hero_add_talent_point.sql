-- +migrate Up
ALTER TABLE `hero` ADD `talent_point`  MEDIUMTEXT COMMENT '天赋点信息';

-- +migrate Down
ALTER TABLE `hero` DROP `talent_point`;