
-- +migrate Up
ALTER TABLE `guild` DROP `chairman_name`;


-- +migrate Down
ALTER TABLE `guild` ADD `chairman_name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '会长名字' AFTER `chairman_id`;
