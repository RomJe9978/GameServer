-- +migrate Up
ALTER TABLE `misc` ADD `chat_bubble` int(10)  NOT NULL default '0' COMMENT '当前在使用的聊天气泡ID';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `chat_bubble`;
