
-- +migrate Up

ALTER TABLE `misc` ADD COLUMN `finished_story_email_event_id` mediumtext COMMENT '已完成的唯一剧情邮件事件ID' AFTER `finished_story_email_id`;

-- +migrate Down

ALTER TABLE `misc` DROP COLUMN `finished_story_email_event_id`;