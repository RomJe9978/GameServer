
-- +migrate Up
CREATE TABLE IF NOT EXISTS `weapon` (
    `id` bigint(20) unsigned NOT NULL COMMENT '宠物唯一id',
    `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
    `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '专属模板id',
    `hero_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '英雄id',
    `level` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '强化等级',
    `star` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '星级',
    `break_through_level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '突破等级',
    `war_groove_info` text COMMENT '战纹信息',
    `score` bigint(20) unsigned DEFAULT '0' COMMENT '评分',
    `effect_open` int(11) unsigned DEFAULT '0' COMMENT '特效开关',
    `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
    `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
    `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
    `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
    `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
    PRIMARY KEY (`id`),
    KEY `idx_update_at` (`update_ts`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='专属武器表';

CREATE TABLE IF NOT EXISTS `weapon_journal` (
    `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
    `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '专属武器模板id',
    `activated_voice_list` text COMMENT '已激活列表',
    `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
    `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
    `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
    `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
    PRIMARY KEY (`player_id`,`template_id`) USING BTREE,
    KEY `idx_update_at` (`update_ts`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `illustration` (
      `player_id` bigint(21) unsigned NOT NULL COMMENT '玩家ID',
      `template_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图鉴类型id',
      `activated_list` text COMMENT '已激活列表',
      `received_list` text COMMENT '已领取列表',
      `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
      `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
      `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
      PRIMARY KEY (`player_id`,`template_id`) USING BTREE,
      KEY `idx_update_at` (`update_ts`) USING BTREE
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `hero` ADD `weapon_id` BIGINT UNSIGNED DEFAULT 0 COMMENT '专属武器id' AFTER `fetter_id`;
ALTER TABLE `misc` ADD `weapon_finish_task_list` TEXT COMMENT '专武任务领取列表';

-- +migrate Down
DROP TABLE IF EXISTS `weapon`;
DROP TABLE IF EXISTS `weapon_journal`;
DROP TABLE IF EXISTS `illustration`;
ALTER TABLE `hero` DROP `weapon_id`;
ALTER TABLE `misc` DROP `weapon_finish_task_list`;
