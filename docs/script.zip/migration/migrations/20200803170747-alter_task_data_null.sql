
-- +migrate Up
ALTER TABLE `task` CHANGE `task_data` `task_data` MEDIUMBLOB NULL DEFAULT NULL COMMENT '任务PB数据';
-- +migrate Down
