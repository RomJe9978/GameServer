-- +migrate Up
ALTER TABLE `player` ADD `is_baned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否被禁' AFTER `sign`;


-- +migrate Down
ALTER TABLE `player` DROP COLUMN `is_baned`;