-- +migrate Up
CREATE TABLE IF NOT EXISTS `continuous_recharge` (
  `player_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '玩家id',
  `issue` int(10) unsigned DEFAULT '0' COMMENT '活动期号',
  `recharge_days` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计完成充值天数',
  `daily_recharge_val` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日常充值进度',
  `recharge_reward_info` varchar(255) DEFAULT NULL COMMENT '奖励领取列表',
  `refresh_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次刷新时间',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `valid_player` (`invalid`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `continuous_recharge`;
