
-- +migrate Up
ALTER TABLE `olympic` ADD `crit` TINYINT UNSIGNED NOT NULL DEFAULT '0' COMMENT '今日应援暴击' AFTER `indexes`, ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '刷新时间' AFTER `crit`;

-- +migrate Down
ALTER TABLE `olympic` DROP `crit`, DROP `fresh_at`;
