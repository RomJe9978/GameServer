
-- +migrate Up

ALTER TABLE `idle` ADD COLUMN `last_pickup_at` timestamp NULL DEFAULT NULL COMMENT '上次领取奖励时间戳' AFTER `last_query_at`;

-- +migrate Down

ALTER TABLE `idle` DROP COLUMN `last_pickup_at`;
