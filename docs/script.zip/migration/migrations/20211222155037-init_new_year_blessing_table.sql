
-- +migrate Up
 CREATE TABLE IF NOT EXISTS `new_year_blessing` (
  `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '祝福次数',
  `reward_list` text COMMENT '已领取奖励',
  `global_reward_list` text COMMENT '领取全服奖励列表',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL COMMENT '删除标记',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  PRIMARY KEY (`player_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新年活动祝福';

-- +migrate Down
DROP TABLE IF EXISTS `new_year_blessing`;
