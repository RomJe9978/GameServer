
-- +migrate Up
CREATE TABLE IF NOT EXISTS `treasure` (
      `id` bigint(20) NOT NULL COMMENT '宝物唯一id',
      `template_id` int(11) DEFAULT '0' COMMENT '宝物模板id',
      `player_id` bigint(20) DEFAULT '0' COMMENT '玩家唯一id',
      `star` int(11) DEFAULT '0' COMMENT '宝物星级',
      `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间戳',
      `update_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
      `invalid` tinyint(4) DEFAULT '0' COMMENT '删除标识',
      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `treasure`;
