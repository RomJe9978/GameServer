
-- +migrate Up
ALTER TABLE `kizuna` ADD `got_list` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '已领取羁绊列表' AFTER `activated_list`;

-- +migrate Down
ALTER TABLE `kizuna` DROP `got_list`;
