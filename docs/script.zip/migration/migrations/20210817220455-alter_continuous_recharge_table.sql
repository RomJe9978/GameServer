
-- +migrate Up
ALTER TABLE `continuous_recharge` ADD `daily_recharge_info` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '每日充值' AFTER `recharge_reward_info`;

-- +migrate Down
ALTER TABLE `continuous_recharge` DROP `daily_recharge_info`;
