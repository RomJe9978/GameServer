
-- +migrate Up
CREATE TABLE IF NOT EXISTS `counter` (
  `player_id` bigint(20) UNSIGNED NOT NULL COMMENT '玩家唯一id',
  `data` mediumblob COMMENT '计数数据',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间戳',
  `update_at` timestamp NOT NULL DEFAULT '1999-12-31 16:00:00' COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL COMMENT '删除标记',
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玩家计数表';

-- +migrate Down
DROP TABLE IF EXISTS `counter`;
