-- +migrate Up
ALTER TABLE `gvg_player` ADD `season_rank` int(11) not null default 0  COMMENT '赛季奖励';

-- +migrate Down
ALTER TABLE `gvg_player` DROP COLUMN `season_rank`;