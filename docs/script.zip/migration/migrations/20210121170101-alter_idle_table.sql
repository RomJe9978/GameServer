
-- +migrate Up
ALTER TABLE `idle` ADD `refresh_at` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '刷新时间戳' AFTER `last_pickup_at`;

-- +migrate Down
ALTER TABLE `idle` DROP `refresh_at`;
