-- +migrate Up
ALTER TABLE `misc` ADD `notify_switch` mediumtext  COMMENT '推送开关';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `notify_switch`;