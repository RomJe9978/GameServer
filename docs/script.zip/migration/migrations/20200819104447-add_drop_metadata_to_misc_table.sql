
-- +migrate Up
ALTER TABLE `misc` ADD `drop_times` VARCHAR(512) DEFAULT NULL COMMENT '掉落组掉落次数信息' AFTER `chat_bg`;

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `drop_times`;
