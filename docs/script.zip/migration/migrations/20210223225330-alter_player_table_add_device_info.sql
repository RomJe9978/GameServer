-- +migrate Up
ALTER TABLE `player` ADD `device` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备信息';
ALTER TABLE `player` ADD `device_os` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备系统';

-- +migrate Down
ALTER TABLE `player` DROP COLUMN `device`;
ALTER TABLE `player` DROP COLUMN `device_os`;