
-- +migrate Up
ALTER TABLE `arena` DROP COLUMN `defend_heroes`;
-- +migrate Down
