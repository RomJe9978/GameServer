
-- +migrate Up
ALTER TABLE `hero` ADD `tasking` tinyint(4) unsigned DEFAULT '0' COMMENT '英雄处于派遣任务' AFTER `activated_skin_list`;

-- +migrate Down
ALTER TABLE `hero` DROP COLUMN `tasking`;
