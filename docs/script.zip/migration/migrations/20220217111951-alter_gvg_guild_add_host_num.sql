-- +migrate Up
ALTER TABLE `gvg_guild` ADD `max_host_num` INT NOT NULL DEFAULT '0' COMMENT '最大托管人数' AFTER `host_heroes`;
ALTER TABLE `gvg_guild` ADD `min_host_num` INT NOT NULL DEFAULT '0' COMMENT '最小托管人数' AFTER `host_heroes`;
ALTER TABLE `gvg_guild` ADD `teams` MEDIUMTEXT COMMENT '公会托管的队伍信息';

-- +migrate Down
ALTER TABLE `gvg_guild` DROP `max_host_num`;
ALTER TABLE `gvg_guild` DROP `min_host_num`;
ALTER TABLE `gvg_guild` DROP `teams`;