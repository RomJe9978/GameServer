
-- +migrate Up
ALTER TABLE `guild` ADD `chairman_name` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '会长名字' AFTER `chairman_id`;

-- +migrate Down
ALTER TABLE `guild` DROP COLUMN `chairman_name`;
