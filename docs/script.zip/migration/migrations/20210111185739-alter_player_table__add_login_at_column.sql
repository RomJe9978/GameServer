
-- +migrate Up
ALTER TABLE `player` ADD `login_at` TIMESTAMP NULL DEFAULT NULL COMMENT '登录时间戳' AFTER `sign`;


-- +migrate Down
ALTER TABLE `player` DROP `login_at`;
