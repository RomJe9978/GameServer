
-- +migrate Up
ALTER TABLE `guild_member` ADD `activeness_data` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL AFTER `week_first_day`;
ALTER TABLE `guild_member` DROP `weekly_activeness`;

-- +migrate Down
ALTER TABLE `guild_member` ADD `weekly_activeness` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '周活跃度' AFTER `week_first_day`;
ALTER TABLE `guild_member` DROP `activeness_data`;
