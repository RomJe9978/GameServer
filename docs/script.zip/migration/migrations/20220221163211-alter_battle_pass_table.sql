
-- +migrate Up
ALTER TABLE `battle_pass` ADD `issue_no` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '跨服占矿战令期号' AFTER `login_at`;

-- +migrate Down
ALTER TABLE `battle_pass` DROP `issue_no`;
