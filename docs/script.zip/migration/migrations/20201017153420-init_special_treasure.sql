
-- +migrate Up
CREATE TABLE IF NOT EXISTS `special_treasure` (
      `player_id` bigint(20) unsigned NOT NULL COMMENT '玩家唯一id',
      `swallow_gold_beast` varchar(255) DEFAULT NULL COMMENT '吞金兽',
      `zhanling` varchar(255) DEFAULT NULL COMMENT '战令',
      `turn_table` mediumtext COMMENT '转盘',
      `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
      `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
      `invalid` tinyint(1) unsigned DEFAULT '0' COMMENT '删除标识',
      PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `special_treasure`;
