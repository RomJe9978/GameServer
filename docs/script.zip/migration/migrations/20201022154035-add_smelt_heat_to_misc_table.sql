
-- +migrate Up
ALTER TABLE `misc` ADD COLUMN `equip_smelt_heat` int(11) NOT NULL DEFAULT '0' COMMENT '装备熔炼热度' AFTER `drop_times`;

-- +migrate Down

ALTER TABLE `misc` DROP COLUMN `equip_smelt_heat`;
