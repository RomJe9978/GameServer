
-- +migrate Up
ALTER TABLE `misc` ADD `newbie_draw_open` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '新手卡池开启时间戳' AFTER `privilege_info`;
ALTER TABLE `misc` ADD `newbie_draw_n` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '新手卡池领取奖励个数' AFTER `newbie_draw_open`;

-- +migrate Down
ALTER TABLE `misc` DROP `newbie_draw_n`;
ALTER TABLE `misc` DROP `newbie_draw_open`;
