
-- +migrate Up
CREATE TABLE `server_refresh_info` (
  `type` int(20) NOT NULL COMMENT '刷新类型',
  `template_id` int(11) NOT NULL COMMENT '具体刷新条目ID',
  `refresh_at` int(11) NOT NULL DEFAULT '0' COMMENT '刷新时间',
  `next_refresh_at` int(11) NOT NULL DEFAULT '0',
  `configured_start` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `invalid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`type`,`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `server_refresh_info`;
