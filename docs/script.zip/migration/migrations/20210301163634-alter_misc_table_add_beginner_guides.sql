-- +migrate Up
ALTER TABLE `misc` ADD `beginner_guides` mediumtext  COMMENT '新书引导进度信息';

-- +migrate Down
ALTER TABLE `misc` DROP COLUMN `beginner_guides`;
