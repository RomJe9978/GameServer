
-- +migrate Up
CREATE TABLE IF NOT EXISTS `guild` (
 `id` bigint(20) unsigned NOT NULL COMMENT '工会唯一id',
 `name` varchar(255) NOT NULL COMMENT '工会名称',
 `chairman_id` bigint(20) unsigned DEFAULT NULL COMMENT '当前会长id',
 `level` int(10) unsigned DEFAULT '1' COMMENT '工会等级',
 `exp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '工会经验',
 `founder_id` bigint(20) unsigned DEFAULT NULL COMMENT '工会创建者id',
 `founder_name` varchar(255) DEFAULT NULL COMMENT '创建者名字',
 `logo` smallint(5) unsigned DEFAULT NULL COMMENT '工会logo',
 `announcement` text COMMENT '工会公告',
 `activeness` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总活跃度',
 `week_first_day` int(10) unsigned DEFAULT NULL COMMENT '本周第一天日期20201031',
 `weekly_activeness` int(10) unsigned DEFAULT '0' COMMENT '周活跃度',
 `join_conds` varchar(255) DEFAULT NULL COMMENT '加入条件',
 `check_needed` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要审核',
 `last_rename_at` timestamp NULL DEFAULT NULL COMMENT '上次改名时间',
 `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间戳',
 `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间戳',
 `invalid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工会表';

-- +migrate Down
DROP TABLE IF EXISTS `guild`;
