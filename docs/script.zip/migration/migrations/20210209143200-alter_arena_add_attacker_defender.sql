-- +migrate Up
ALTER TABLE `arena` ADD `attacker` mediumblob  COMMENT '攻击者';
ALTER TABLE `arena` ADD `defender` mediumblob  COMMENT '防守者';

-- +migrate Down
ALTER TABLE `arena` DROP COLUMN `attacker`;
ALTER TABLE `arena` DROP COLUMN `defender`;