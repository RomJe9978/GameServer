
-- +migrate Up
ALTER TABLE `misc` ADD `has_bind_platform` TINYINT  NOT NULL DEFAULT '0' COMMENT '是否绑定了第三方平台' AFTER `privilege_info`;
ALTER TABLE `misc` ADD `has_bind_rewarded` TINYINT NOT NULL DEFAULT '0' COMMENT '是否已经两江' AFTER `has_bind_platform`;

-- +migrate Down
ALTER TABLE `misc` DROP `has_bind_platform`;
ALTER TABLE `misc` DROP `has_bind_rewarded`;
