
-- +migrate Up
ALTER TABLE `mail` ADD `gmid` BIGINT UNSIGNED NOT NULL DEFAULT '0' COMMENT 'GM后台生成的唯一id' AFTER `extra`;


-- +migrate Down
ALTER TABLE `mail` DROP `gmid`;
