
-- +migrate Up
ALTER TABLE `hero` ADD `fetter_id` INT UNSIGNED NOT NULL DEFAULT '0' COMMENT '武将参与连携' AFTER `power`;

-- +migrate Down
ALTER TABLE `hero` DROP `fetter_id`;
