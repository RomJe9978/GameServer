
-- +migrate Up

CREATE TABLE `arena_npc` (
  `npc_id` int(11)  NOT NULL COMMENT '怪物ID',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '当前排名',
  `update_at` timestamp NULL DEFAULT NULL COMMENT '数据更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '数据创建时间',
  `invalid` tinyint(1) DEFAULT NULL COMMENT '数据是否非法',
  PRIMARY KEY (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `arena_npc`;