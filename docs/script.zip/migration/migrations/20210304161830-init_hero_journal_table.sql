
-- +migrate Up
CREATE TABLE IF NOT EXISTS `hero_journal` (
  `player_id` bigint(20) NOT NULL COMMENT '玩家ID',
  `hero_master_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '武将母卡模板id',
  `favor` int(10) unsigned DEFAULT '0' COMMENT '亲密度',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '攻略等级',
  `voice_list` text COMMENT '已激活语音列表',
  `voice_reward_list` text COMMENT '已领取语音奖励列表',
  `story_list` varchar(255) DEFAULT NULL COMMENT '已激活故事列表',
  `story_reward_list` varchar(255) DEFAULT NULL COMMENT '已领取故事奖励列表',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '更新时间戳',
  `invalid` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否非法',
  PRIMARY KEY (`player_id`,`hero_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `hero_journal`;
