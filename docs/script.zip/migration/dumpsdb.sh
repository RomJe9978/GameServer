#!/bin/bash

mysqldump -h 172.18.28.13 -uroot -p$1 -d projectx_dev > projectx.sql
mysqldump -h 172.18.28.13 -uroot -p$1 -d projectx_world > projectx_world.sql
