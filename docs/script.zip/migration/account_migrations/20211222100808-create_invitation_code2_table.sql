
-- +migrate Up
CREATE TABLE `invitation_code2` (
  `invitee_id` bigint(20) NOT NULL COMMENT '被邀请者玩家ID',
  `invitee_ltid` varchar(128) NOT NULL DEFAULT '' COMMENT '龙腾ID',
  `invitee_power` bigint(20) NOT NULL COMMENT '被邀请者玩家最高战力',
  `inviter_code` bigint(20) NOT NULL COMMENT '邀请者的邀请码',
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `create_ts` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `update_ts` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间戳',
  `invalid` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`invitee_id`),
  KEY `idx_update_at` (`update_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- +migrate Down
DROP TABLE IF EXISTS `invitation_code2`;