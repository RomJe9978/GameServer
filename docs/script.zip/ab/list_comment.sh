#!/bin/sh

ab -c 10 -n 2000 -p  list_comment.json -T application/json  https://shcomment.menaapp.net/list_comment