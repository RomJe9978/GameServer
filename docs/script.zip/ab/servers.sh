#!/bin/sh

ab -c 100 -n 5000 https://shaccount.menaapp.net/servers