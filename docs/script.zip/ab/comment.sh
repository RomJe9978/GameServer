#!/bin/sh

ab -c 10 -n 2000 -p  comment.json -T application/json  https://shcomment.menaapp.net/comment