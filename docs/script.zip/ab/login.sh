#!/bin/sh

ab -c 10 -n 5000 -p  login.json -T application/json  https://shaccount.menaapp.net/login