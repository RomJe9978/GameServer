package com.skilltool.data;

import java.util.List;
import java.util.Map;

/**
 * warrior某个点的快照数据
 *
 * @author liuxuanjie
 * @date 2023/6/28 12:09
 */
public class UiWarriorSnapshotData {
    /**
     * 快照标识
     */
    private int snapMark;

    /**
     * 谁的快照
     */
    private int warriorMark;

    /**
     * 快照时，是否存活
     */
    private boolean isAlive;

    /**
     * 快照时的血量
     */
    private long curHp;

    /**
     * 快照时的“樱释数据
     * ”
     */
    private UiMusouData uiMusouData;

    /**
     * 当前快照所有的buff数据
     */
    private List<UiBuffData> buffDataList;

    /**
     * 当前快照所有的mark数据
     */
    private List<UiMarkData> markDataList;

    /**
     * 快照时候的属性数据
     */
    private Map<UiDataEnum.AttributeSnapshotEnum, Map<Integer, UiAttributeData>> attributeSnapshotMap;

    /**
     * 快照时候的Attr数据
     */
    private Map<Integer, UiAttrSnapshotData> attrSnapshotDataMap;

    /**
     * 属性计算过程的数据
     */
    private Map<Integer, UiCalculateAttributeData> calculateAttributeDataMap;

    /**
     * 伤害计算过程
     */
    private UiDamageCalculateData damageCalculateData;

    public int getSnapMark() {
        return snapMark;
    }

    public void setSnapMark(int snapMark) {
        this.snapMark = snapMark;
    }

    public int getWarriorMark() {
        return warriorMark;
    }

    public void setWarriorMark(int warriorMark) {
        this.warriorMark = warriorMark;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void setAlive(boolean alive) {
        isAlive = alive;
    }

    public long getCurHp() {
        return curHp;
    }

    public void setCurHp(long curHp) {
        this.curHp = curHp;
    }

    public UiMusouData getUiMusouData() {
        return uiMusouData;
    }

    public void setUiMusouData(UiMusouData uiMusouData) {
        this.uiMusouData = uiMusouData;
    }

    public List<UiBuffData> getBuffDataList() {
        return buffDataList;
    }

    public void setBuffDataList(List<UiBuffData> buffDataList) {
        this.buffDataList = buffDataList;
    }

    public List<UiMarkData> getMarkDataList() {
        return markDataList;
    }

    public void setMarkDataList(List<UiMarkData> markDataList) {
        this.markDataList = markDataList;
    }

    public Map<UiDataEnum.AttributeSnapshotEnum, Map<Integer, UiAttributeData>> getAttributeSnapshotMap() {
        return attributeSnapshotMap;
    }

    public void setAttributeSnapshotMap(Map<UiDataEnum.AttributeSnapshotEnum, Map<Integer, UiAttributeData>> attributeSnapshotMap) {
        this.attributeSnapshotMap = attributeSnapshotMap;
    }

    public Map<Integer, UiAttrSnapshotData> getAttrSnapshotDataMap() {
        return attrSnapshotDataMap;
    }

    public void setAttrSnapshotDataMap(Map<Integer, UiAttrSnapshotData> attrSnapshotDataMap) {
        this.attrSnapshotDataMap = attrSnapshotDataMap;
    }

    public Map<Integer, UiCalculateAttributeData> getCalculateAttributeDataMap() {
        return calculateAttributeDataMap;
    }

    public void setCalculateAttributeDataMap(Map<Integer, UiCalculateAttributeData> calculateAttributeDataMap) {
        this.calculateAttributeDataMap = calculateAttributeDataMap;
    }

    public UiDamageCalculateData getDamageCalculateData() {
        return damageCalculateData;
    }

    public void setDamageCalculateData(UiDamageCalculateData damageCalculateData) {
        this.damageCalculateData = damageCalculateData;
    }
}
