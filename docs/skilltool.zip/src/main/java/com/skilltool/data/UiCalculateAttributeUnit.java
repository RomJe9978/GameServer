package com.skilltool.data;

/**
 * 特定时机“计算属性”
 *
 * @author RomJe
 */
public class UiCalculateAttributeUnit extends AbstractRecordUnit {
    /**
     * 该记录会放在被攻击的人身上
     */
    private int defenderMark;

    /**
     * 攻击者标识，可能为null
     */
    private int attackerMark;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.CALCULATE_ATTRIBUTE;
    }

    public int getDefenderMark() {
        return defenderMark;
    }

    public void setDefenderMark(int defenderMark) {
        this.defenderMark = defenderMark;
    }

    public int getAttackerMark() {
        return attackerMark;
    }

    public void setAttackerMark(int attackerMark) {
        this.attackerMark = attackerMark;
    }
}
