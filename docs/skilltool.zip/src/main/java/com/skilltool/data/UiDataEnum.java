package com.skilltool.data;

/**
 * 所有数据中用到的“枚举”常量
 *
 * <p>为了保证工具类所在包的闭包性，这里将枚举常量单独提取出来，放在这个类
 * 中,也就是用到程序中的所有数据类，都必须在这里映射，工具包内所有的“约定常
 * 量”不允许直接使用程序中的枚举常量。
 *
 * @author liuxuanjie
 * @date 2023/6/30 14:56
 */
public class UiDataEnum {
    /**
     * "一条记录"的类型
     */
    public enum RecordEnum {
        SKILL(true),
        ATTR(true),
        BUFF(false),
        ATTRIBUTE(false),
        DAMAGE(true),
        HEAL(true),
        MARK(false),
        BATTLE_EVENT(false),
        CALCULATE_ATTRIBUTE(false),
        ONCE_DAMAGE_CALCULATE(false),
        ;

        /**
         * 是否是嵌套结构
         */
        private boolean isNest;

        RecordEnum(boolean isNest) {
            this.isNest = isNest;
        }

        public boolean isNest() {
            return isNest;
        }
    }

    /**
     * mark更新类型
     */
    public enum MarkUpdateEnum {
        DEFAULT(0, "无"),
        ADD_MARK(1, "添加mark"),
        REMOVE_MARK(2, "移除mark"),
        EXTEND_MARK(3, "延长mark"),
        ;

        private int type;
        private String desc;

        MarkUpdateEnum(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public String getDesc() {
            return desc;
        }

        public static MarkUpdateEnum enumOf(int type) {
            for (MarkUpdateEnum markUpdateEnum : MarkUpdateEnum.values()) {
                if (markUpdateEnum.getType() == type) {
                    return markUpdateEnum;
                }
            }
            return MarkUpdateEnum.DEFAULT;
        }
    }

    /**
     * buff更新类型
     */
    public enum BuffUpdateEnum {
        DEFAULT(0, "无"),
        ADD_BUFF(1, "添加buff"),
        REMOVE_BUFF(2, "移除buff"),
        EXTEND_BUFF(3, "延长buff"),
        ;

        private int type;
        private String desc;

        BuffUpdateEnum(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public String getDesc() {
            return desc;
        }

        public static BuffUpdateEnum enumOf(int type) {
            for (BuffUpdateEnum buffUpdateEnum : BuffUpdateEnum.values()) {
                if (buffUpdateEnum.getType() == type) {
                    return buffUpdateEnum;
                }
            }
            return BuffUpdateEnum.DEFAULT;
        }
    }

    /**
     * 导致buff变化的原因
     */
    public enum BuffReasonEnum {
        SKILL(0, "技能"),
        ATTR_EFFECT(1, "Attr效果"),
        ATTACK_EFFECT(2, "Attack触发");

        private int type;
        private String desc;

        BuffReasonEnum(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public String getDesc() {
            return desc;
        }

        public static BuffReasonEnum enumOf(int type) {
            for (BuffReasonEnum buffReasonEnum : BuffReasonEnum.values()) {
                if (buffReasonEnum.getType() == type) {
                    return buffReasonEnum;
                }
            }
            return BuffReasonEnum.SKILL;
        }
    }

    /**
     * “属性快照分类”的枚举
     */
    public enum AttributeSnapshotEnum {
        EMPTY(0, "空"),
        MAIN(1, "主属性"),
        ONCE_USED(2, "临时属性(伤害后清理)"),
        DYNAMIC(3, "全场动态临时属性"),
        SKILL_ADDITIONAL(4, "特殊技能附加属性(手动清理)"),
        AFTER_SKILL_CLEAR(5, "技能结束清理的属性"),
        AFTER_ACTION_CLEAR(6, "单位行动结束清理的属性"),
        BUFF_ATTRIBUTES(7, "Buff属性"),
        AFTER_ATTACK_CLEAR_ATTRIBUTES(8, "攻击结束后清理属性"),
        MARK_ATTRIBUTES(9, "Mark属性"),
        AFTER_LOSE_CLEAR(10, "ATTR失去后清理的属性"),
        MUSOU_ATTRIBUTES(11, "樱释属性"),
        END_BATTLE_CLEAR(12, "战斗结束后清理的属性");

        private int type;
        private String desc;

        AttributeSnapshotEnum(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public static AttributeSnapshotEnum enumOf(int type) {
            for (AttributeSnapshotEnum attributeSnapshotEnum : AttributeSnapshotEnum.values()) {
                if (attributeSnapshotEnum.getType() == type) {
                    return attributeSnapshotEnum;
                }
            }
            return AttributeSnapshotEnum.EMPTY;
        }
    }

    /**
     * 光环的“枚举类型”
     */
    public enum HaloPilarEnum {
        ATTACK(1 << 13, "攻击方光环"),
        DEFENSE(1 << 14, "防御方光环"),
        ;

        /**
         * 光环标识
         */
        private int locationMark;

        /**
         * 统一双端名称
         */
        private String name;

        HaloPilarEnum(int locationMark, String name) {
            this.locationMark = locationMark;
            this.name = name;
        }

        public int getLocationMark() {
            return locationMark;
        }

        public String getName() {
            return name;
        }
    }

    public enum AnalysisTypeEnum {
        SKILL(1, "SKILL"),
        BUFF(2, "BUFF"),
        MARK(3, "MARK"),
        MUSOU(4, "MUSOU"),
        ;

        private int type;

        private String markStr;

        AnalysisTypeEnum(int type, String markStr) {
            this.type = type;
            this.markStr = markStr;
        }

        public int getType() {
            return type;
        }

        public String getMarkStr() {
            return markStr;
        }
    }
}
