package com.skilltool.data;

import java.util.List;

/**
 * "静态检测配置"的结果
 *
 * @author liuxuanjie
 * @date 2023/7/14 10:23
 */
public class UiCheckResult {
    /**
     * 所有错误信息(每一个元素是一条独立的记录)
     */
    private List<String> errorList;

    /**
     * 所有程序已经实现的“触发时机”枚举值（从小到大排序）
     */
    private List<Integer> attrTimingEnumList;

    /**
     * 所有程序已经实现的“旧版判定条件”枚举值（从小到大排序）
     */
    private List<Integer> attrOldJudgmentEnumList;

    /**
     * 所有程序已经实现的“新版本判定条件”枚举值（从小到大排序）
     */
    private List<Integer> attrNewJudgmentEnumList;

    /**
     * 所有程序已经实现的“attr效果”枚举值（从小到大排序）
     */
    private List<Integer> attrEffectEnumList;

    /**
     * 所有程序已经实现的“attr生效目标“枚举值（从小到大排序）
     */
    private List<Integer> attrTargetEnumList;

    public List<String> getErrorList() {
        return errorList;
    }

    public void setErrorList(List<String> errorList) {
        this.errorList = errorList;
    }

    public List<Integer> getAttrTimingEnumList() {
        return attrTimingEnumList;
    }

    public void setAttrTimingEnumList(List<Integer> attrTimingEnumList) {
        this.attrTimingEnumList = attrTimingEnumList;
    }

    public List<Integer> getAttrOldJudgmentEnumList() {
        return attrOldJudgmentEnumList;
    }

    public void setAttrOldJudgmentEnumList(List<Integer> attrOldJudgmentEnumList) {
        this.attrOldJudgmentEnumList = attrOldJudgmentEnumList;
    }

    public List<Integer> getAttrNewJudgmentEnumList() {
        return attrNewJudgmentEnumList;
    }

    public void setAttrNewJudgmentEnumList(List<Integer> attrNewJudgmentEnumList) {
        this.attrNewJudgmentEnumList = attrNewJudgmentEnumList;
    }

    public List<Integer> getAttrEffectEnumList() {
        return attrEffectEnumList;
    }

    public void setAttrEffectEnumList(List<Integer> attrEffectEnumList) {
        this.attrEffectEnumList = attrEffectEnumList;
    }

    public List<Integer> getAttrTargetEnumList() {
        return attrTargetEnumList;
    }

    public void setAttrTargetEnumList(List<Integer> attrTargetEnumList) {
        this.attrTargetEnumList = attrTargetEnumList;
    }
}
