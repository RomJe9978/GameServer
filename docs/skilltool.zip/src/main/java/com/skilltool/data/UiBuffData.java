package com.skilltool.data;

/**
 * @author liuxuanjie
 * @date 2023/6/28 12:04
 */
public class UiBuffData {
    /**
     * 配置Id
     */
    private int buffTemplateId;

    /**
     * buff来源标识
     */
    private int sourceMark;

    /**
     * 初始回合数
     */
    private int initRound;

    /**
     * 剩余回合数
     */
    private int remainRound;

    public int getBuffTemplateId() {
        return buffTemplateId;
    }

    public void setBuffTemplateId(int buffTemplateId) {
        this.buffTemplateId = buffTemplateId;
    }

    public int getSourceMark() {
        return sourceMark;
    }

    public void setSourceMark(int sourceMark) {
        this.sourceMark = sourceMark;
    }

    public int getInitRound() {
        return initRound;
    }

    public void setInitRound(int initRound) {
        this.initRound = initRound;
    }

    public int getRemainRound() {
        return remainRound;
    }

    public void setRemainRound(int remainRound) {
        this.remainRound = remainRound;
    }
}
