package com.skilltool.data;

/**
 * 一条“伤害”的记录
 *
 * @author liuxuanjie
 * @date 2023/7/17 14:22
 */
public class UiDamageUnit extends AbstractNestRecordUnit {
    /**
     * 攻击者标识
     */
    private int attackerMark;

    /**
     * 被攻击者标识
     */
    private int defenderMark;

    /**
     * 伤害类型
     */
    private String damageType;

    /**
     * 造成伤害的技能Id
     */
    private int skillId;

    /**
     * 总伤害
     */
    private long totalDamage;

    /**
     * 总的hp伤害
     */
    private long totalHpDamage;

    /**
     * 总的伤害溢出
     */
    private long totalOverFlowDamage;

    /**
     * 被“攻击者”的turn damage
     */
    private long turnDamage;

    /**
     * 攻击结果
     */
    private String attackResult;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.DAMAGE;
    }

    public int getAttackerMark() {
        return attackerMark;
    }

    public void setAttackerMark(int attackerMark) {
        this.attackerMark = attackerMark;
    }

    public int getDefenderMark() {
        return defenderMark;
    }

    public void setDefenderMark(int defenderMark) {
        this.defenderMark = defenderMark;
    }

    public String getDamageType() {
        return damageType;
    }

    public void setDamageType(String damageType) {
        this.damageType = damageType;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public long getTotalDamage() {
        return totalDamage;
    }

    public void setTotalDamage(long totalDamage) {
        this.totalDamage = totalDamage;
    }

    public long getTotalHpDamage() {
        return totalHpDamage;
    }

    public void setTotalHpDamage(long totalHpDamage) {
        this.totalHpDamage = totalHpDamage;
    }

    public long getTotalOverFlowDamage() {
        return totalOverFlowDamage;
    }

    public void setTotalOverFlowDamage(long totalOverFlowDamage) {
        this.totalOverFlowDamage = totalOverFlowDamage;
    }

    public long getTurnDamage() {
        return turnDamage;
    }

    public void setTurnDamage(long turnDamage) {
        this.turnDamage = turnDamage;
    }

    public String getAttackResult() {
        return attackResult;
    }

    public void setAttackResult(String attackResult) {
        this.attackResult = attackResult;
    }
}
