package com.skilltool.data;

import java.util.List;

/**
 * 分析attr的配置解析结果
 *
 * @author liuxuanjie
 * @date 2023/7/12 20:49
 */
public class UiAnalysisAttrResult {
    /**
     * 配置id
     */
    private int attrTemplateId;

    /**
     * 解析的“触发时机”列表
     */
    private List<String> timingList;

    /**
     * 解析的“判定条件”
     */
    private String judgmentStr;

    /**
     * 解析的”效果作用目标“
     */
    private String effectTargetList;

    /**
     * 解析的“具体效果”
     */
    private String effectStr;

    /**
     * 解析的“持续时间”
     */
    private String durationStr;

    public int getAttrTemplateId() {
        return attrTemplateId;
    }

    public void setAttrTemplateId(int attrTemplateId) {
        this.attrTemplateId = attrTemplateId;
    }

    public List<String> getTimingList() {
        return timingList;
    }

    public void setTimingList(List<String> timingList) {
        this.timingList = timingList;
    }

    public String getJudgmentStr() {
        return judgmentStr;
    }

    public void setJudgmentStr(String judgmentStr) {
        this.judgmentStr = judgmentStr;
    }

    public String getEffectTargetList() {
        return effectTargetList;
    }

    public void setEffectTargetList(String effectTargetList) {
        this.effectTargetList = effectTargetList;
    }

    public String getEffectStr() {
        return effectStr;
    }

    public void setEffectStr(String effectStr) {
        this.effectStr = effectStr;
    }

    public String getDurationStr() {
        return durationStr;
    }

    public void setDurationStr(String durationStr) {
        this.durationStr = durationStr;
    }
}
