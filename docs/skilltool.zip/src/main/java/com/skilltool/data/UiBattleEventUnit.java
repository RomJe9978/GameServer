package com.skilltool.data;

import java.util.List;

/**
 * 记录战斗时机的记录单元
 *
 * @author RomJe
 */
public class UiBattleEventUnit extends AbstractRecordUnit {
    /**
     * 卡牌唯一标识号
     */
    private int warriorMark;

    /**
     * 原始战斗事件名称
     */
    private String battleEventName;

    /**
     * 该战斗事件可以触发的attr时机点
     */
    private List<Integer> attrTimingList;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.BATTLE_EVENT;
    }

    public int getWarriorMark() {
        return warriorMark;
    }

    public void setWarriorMark(int warriorMark) {
        this.warriorMark = warriorMark;
    }

    public String getBattleEventName() {
        return battleEventName;
    }

    public void setBattleEventName(String battleEventName) {
        this.battleEventName = battleEventName;
    }

    public List<Integer> getAttrTimingList() {
        return attrTimingList;
    }

    public void setAttrTimingList(List<Integer> attrTimingList) {
        this.attrTimingList = attrTimingList;
    }
}
