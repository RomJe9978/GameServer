package com.skilltool.data;

import java.util.List;

/**
 * 一条记录Attr-effect的最小单元
 *
 * @author liuxuanjie
 * @date 2023/6/27 10:45
 */
public class UiAttrEffectUnit extends AbstractNestRecordUnit {

    private int attrTemplateId;

    private int attrSource;

    private int effectId;

    /**
     * attr的owner
     */
    private long ownerWarriorMark;

    /**
     * attr的生效目标
     */
    private List<Integer> targetWarriorMarkList;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.ATTR;
    }

    public int getAttrTemplateId() {
        return attrTemplateId;
    }

    public void setAttrTemplateId(int attrTemplateId) {
        this.attrTemplateId = attrTemplateId;
    }

    public int getAttrSource() {
        return attrSource;
    }

    public void setAttrSource(int attrSource) {
        this.attrSource = attrSource;
    }

    public int getEffectId() {
        return effectId;
    }

    public void setEffectId(int effectId) {
        this.effectId = effectId;
    }

    public long getOwnerWarriorMark() {
        return ownerWarriorMark;
    }

    public void setOwnerWarriorMark(long ownerWarriorMark) {
        this.ownerWarriorMark = ownerWarriorMark;
    }

    public List<Integer> getTargetWarriorMarkList() {
        return targetWarriorMarkList;
    }

    public void setTargetWarriorMarkList(List<Integer> targetWarriorMarkList) {
        this.targetWarriorMarkList = targetWarriorMarkList;
    }
}
