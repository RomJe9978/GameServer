package com.skilltool.data;

import java.util.Map;

/**
 * @author liuxuanjie
 * @date 2023/6/27 10:50
 */
public class UiRoundData {

    private int roundMark;

    /**
     * 本回合每个位置的“首个战士”的数据
     * key: 位置标识（光环有特殊枚举编码）,value: 该位置的"首个战士"数据
     */
    private Map<Integer, UiWarriorData> firstWarriorMap;

    /**
     * 本回合每个位置的“替补战士”的数据
     * 注意，只有真正“替换”商场了，才会有数据
     */
    private Map<Integer, UiWarriorData> replaceWarriorMap;

    public int getRoundMark() {
        return roundMark;
    }

    public void setRoundMark(int roundMark) {
        this.roundMark = roundMark;
    }

    public Map<Integer, UiWarriorData> getFirstWarriorMap() {
        return firstWarriorMap;
    }

    public void setFirstWarriorMap(Map<Integer, UiWarriorData> firstWarriorMap) {
        this.firstWarriorMap = firstWarriorMap;
    }

    public Map<Integer, UiWarriorData> getReplaceWarriorMap() {
        return replaceWarriorMap;
    }

    public void setReplaceWarriorMap(Map<Integer, UiWarriorData> replaceWarriorMap) {
        this.replaceWarriorMap = replaceWarriorMap;
    }
}
