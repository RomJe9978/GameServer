package com.skilltool.data;

/**
 * 一条“回复”的记录
 *
 * @author liuxuanjie
 * @date 2023/7/17 14:27
 */
public class UiHealUnit extends AbstractNestRecordUnit {
    /**
     * 回复别人的warrior标识
     */
    private int attackerMark;

    /**
     * “被回复”的warrior标识
     */
    private int defenderMark;

    /**
     * 造成回复的技能id
     */
    private int skillId;

    /**
     * 计算出的“预回复值”，并非实际回复值
     */
    private long preHealValue;

    /**
     * 实际“回复”的血量
     */
    private long realValue;

    /**
     * 是否暴击
     */
    private boolean isCritical;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.HEAL;
    }

    public int getAttackerMark() {
        return attackerMark;
    }

    public void setAttackerMark(int attackerMark) {
        this.attackerMark = attackerMark;
    }

    public int getDefenderMark() {
        return defenderMark;
    }

    public void setDefenderMark(int defenderMark) {
        this.defenderMark = defenderMark;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public long getPreHealValue() {
        return preHealValue;
    }

    public void setPreHealValue(long preHealValue) {
        this.preHealValue = preHealValue;
    }

    public long getRealValue() {
        return realValue;
    }

    public void setRealValue(long realValue) {
        this.realValue = realValue;
    }

    public boolean isCritical() {
        return isCritical;
    }

    public void setCritical(boolean critical) {
        isCritical = critical;
    }
}
