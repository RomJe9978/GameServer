package com.skilltool.data;

/**
 * @author liuxuanjie
 * @date 2023/7/4 10:02
 */
public class UiMusouData {
    /**
     * 樱释配置ID
     */
    private int musouId;

    /**
     * 樱释点数
     */
    private int point;

    /**
     * 已经持续的回合数
     */
    private int continuedRound;

    /**
     * 是否处于“樱释状态”
     */
    private boolean isMusouState;

    public int getMusouId() {
        return musouId;
    }

    public void setMusouId(int musouId) {
        this.musouId = musouId;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }

    public int getContinuedRound() {
        return continuedRound;
    }

    public void setContinuedRound(int continuedRound) {
        this.continuedRound = continuedRound;
    }

    public boolean isMusouState() {
        return isMusouState;
    }

    public void setMusouState(boolean musouState) {
        isMusouState = musouState;
    }
}
