package com.skilltool.data;

/**
 * 具有“嵌套”结构的记录单元
 * <p>继承此类的记录单元，一定是“开始”“结束”成对出现的
 *
 * @author liuxuanjie
 * @date 2023/7/6 10:46
 */
public abstract class AbstractNestRecordUnit extends AbstractRecordUnit {
    /**
     * 对于“开始记录”，该值是“结束记录”的序号
     * 对于“结束记录”，该值是“开始记录”的序号
     */
    private int sideSequence;

    public boolean isStartRecord() {
        return this.getSequence() < this.getSideSequence();
    }

    public int getSideSequence() {
        return sideSequence;
    }

    public void setSideSequence(int sideSequence) {
        this.sideSequence = sideSequence;
    }
}
