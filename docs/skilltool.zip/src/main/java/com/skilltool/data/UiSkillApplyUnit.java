package com.skilltool.data;

/**
 * @author liuxuanjie
 * @date 2023/7/5 11:21
 */
public class UiSkillApplyUnit extends AbstractNestRecordUnit {
    /**
     * 记录对应的warrior标识
     */
    private int warriorMark;

    /**
     * 技能配置ID
     */
    private int skillId;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.SKILL;
    }

    public int getWarriorMark() {
        return warriorMark;
    }

    public void setWarriorMark(int warriorMark) {
        this.warriorMark = warriorMark;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }
}
