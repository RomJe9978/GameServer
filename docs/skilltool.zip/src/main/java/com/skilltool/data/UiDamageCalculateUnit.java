package com.skilltool.data;

/**
 * 一次伤害计算记录,强调计算过程
 *
 * @author RomJe
 */
public class UiDamageCalculateUnit extends AbstractRecordUnit {
    /**
     * 攻击者标识
     */
    private int attackMark;

    /**
     * 防守者标识
     */
    private int defenderMark;

    /**
     * 本次伤害公式计算结果
     */
    private long onceDamage;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.ONCE_DAMAGE_CALCULATE;
    }

    public int getAttackMark() {
        return attackMark;
    }

    public void setAttackMark(int attackMark) {
        this.attackMark = attackMark;
    }

    public int getDefenderMark() {
        return defenderMark;
    }

    public void setDefenderMark(int defenderMark) {
        this.defenderMark = defenderMark;
    }

    public long getOnceDamage() {
        return onceDamage;
    }

    public void setOnceDamage(long onceDamage) {
        this.onceDamage = onceDamage;
    }
}
