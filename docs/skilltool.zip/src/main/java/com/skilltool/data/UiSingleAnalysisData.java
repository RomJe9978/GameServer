package com.skilltool.data;

import java.util.List;
import java.util.Map;

/**
 * 单一类型的分析结果
 *
 * @author RomJe
 */
public class UiSingleAnalysisData {
    private int id;
    private List<Integer> attrList;
    private Map<Integer, UiAnalysisAttrResult> attrDescribeMap;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Integer> getAttrList() {
        return attrList;
    }

    public void setAttrList(List<Integer> attrList) {
        this.attrList = attrList;
    }

    public Map<Integer, UiAnalysisAttrResult> getAttrDescribeMap() {
        return attrDescribeMap;
    }

    public void setAttrDescribeMap(Map<Integer, UiAnalysisAttrResult> attrDescribeMap) {
        this.attrDescribeMap = attrDescribeMap;
    }
}
