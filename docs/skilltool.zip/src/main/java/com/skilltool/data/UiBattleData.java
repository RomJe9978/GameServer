package com.skilltool.data;

import java.util.Map;

/**
 * @author liuxuanjie
 * @date 2023/6/27 14:22
 */
public class UiBattleData {
    /**
     * 所有记录的回合数据
     */
    private Map<Integer, UiRoundData> roundDataMap;

    /**
     * 存在的最大回合数
     */
    private int maxRound;

    /**
     * 备注，战斗记录数据中一些程序“魔数”
     */
    private String notes;

    public Map<Integer, UiRoundData> getRoundDataMap() {
        return roundDataMap;
    }

    public void setRoundDataMap(Map<Integer, UiRoundData> roundDataMap) {
        this.roundDataMap = roundDataMap;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getMaxRound() {
        return maxRound;
    }

    public void setMaxRound(int maxRound) {
        this.maxRound = maxRound;
    }
}
