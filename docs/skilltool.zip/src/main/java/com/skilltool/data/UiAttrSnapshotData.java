package com.skilltool.data;

/**
 * attr快照
 *
 * @author liuxuanjie
 * @date 2023/7/6 17:40
 */
public class UiAttrSnapshotData {

    private int attrTemplateId;

    private int attrSource;

    /**
     * elementType的name
     */
    private String elementTypeStr;

    /**
     * elementType的id
     */
    private int elementId;

    /**
     * 快照时刻记录的生效次数
     */
    private int recordCount;

    public int getAttrTemplateId() {
        return attrTemplateId;
    }

    public void setAttrTemplateId(int attrTemplateId) {
        this.attrTemplateId = attrTemplateId;
    }

    public int getAttrSource() {
        return attrSource;
    }

    public void setAttrSource(int attrSource) {
        this.attrSource = attrSource;
    }

    public String getElementTypeStr() {
        return elementTypeStr;
    }

    public void setElementTypeStr(String elementTypeStr) {
        this.elementTypeStr = elementTypeStr;
    }

    public int getElementId() {
        return elementId;
    }

    public void setElementId(int elementId) {
        this.elementId = elementId;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }
}
