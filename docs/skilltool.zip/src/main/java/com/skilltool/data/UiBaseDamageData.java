package com.skilltool.data;

/**
 * 一次伤害的基础伤害部分
 *
 * @author RomJe
 */
public class UiBaseDamageData {
    /**
     * 攻击者的攻击力
     */
    private long attackValue;

    /**
     * 防守方物理/魔法防护减免
     */
    private double defenderReduce;

    /**
     * 防守方的护甲减免
     */
    private double defenderArmorReduce;

    /**
     * 伤害倍数
     */
    private long ratio;

    /**
     * 基础计算结果
     */
    private long finalBaseDamage;

    public static UiBaseDamageData newInstance() {
        return new UiBaseDamageData();
    }

    public long getAttackValue() {
        return attackValue;
    }

    public void setAttackValue(long attackValue) {
        this.attackValue = attackValue;
    }

    public double getDefenderReduce() {
        return defenderReduce;
    }

    public void setDefenderReduce(double defenderReduce) {
        this.defenderReduce = defenderReduce;
    }

    public double getDefenderArmorReduce() {
        return defenderArmorReduce;
    }

    public void setDefenderArmorReduce(double defenderArmorReduce) {
        this.defenderArmorReduce = defenderArmorReduce;
    }

    public long getFinalBaseDamage() {
        return finalBaseDamage;
    }

    public void setFinalBaseDamage(long finalBaseDamage) {
        this.finalBaseDamage = finalBaseDamage;
    }

    public long getRatio() {
        return ratio;
    }

    public void setRatio(long ratio) {
        this.ratio = ratio;
    }
}
