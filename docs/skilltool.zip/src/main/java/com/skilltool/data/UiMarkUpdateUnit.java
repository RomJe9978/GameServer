package com.skilltool.data;

/**
 * 一条“mark-实际更新”的最小数据单元
 *
 * @author liuxuanjie
 * @date 2023/6/30 14:32
 */
public class UiMarkUpdateUnit extends AbstractRecordUnit {
    /**
     * mark的配置id
     */
    private int markTemplateId;

    /**
     * mark的来源
     */
    private int sourceWarriorMark;

    /**
     * 可以理解为mark在谁身上
     */
    private int targetWarriorMark;

    /**
     * mark的更新类型
     */
    private UiDataEnum.MarkUpdateEnum markUpDateEnum;

    /**
     * buff的更新原因
     */
    private String reason;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.MARK;
    }

    public int getMarkTemplateId() {
        return markTemplateId;
    }

    public void setMarkTemplateId(int markTemplateId) {
        this.markTemplateId = markTemplateId;
    }

    public int getSourceWarriorMark() {
        return sourceWarriorMark;
    }

    public void setSourceWarriorMark(int sourceWarriorMark) {
        this.sourceWarriorMark = sourceWarriorMark;
    }

    public int getTargetWarriorMark() {
        return targetWarriorMark;
    }

    public void setTargetWarriorMark(int targetWarriorMark) {
        this.targetWarriorMark = targetWarriorMark;
    }

    public UiDataEnum.MarkUpdateEnum getMarkUpDateEnum() {
        return markUpDateEnum;
    }

    public void setMarkUpDateEnum(UiDataEnum.MarkUpdateEnum markUpDateEnum) {
        this.markUpDateEnum = markUpDateEnum;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
