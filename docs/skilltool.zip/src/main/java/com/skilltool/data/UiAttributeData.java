package com.skilltool.data;

import java.util.List;

/**
 * @author liuxuanjie
 * @date 2023/7/3 11:47
 */
public class UiAttributeData {

    private int attributeId;

    private String attributeName;

    private String attributeDescribe;

    private List<Long> valueList;

    public int getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(int attributeId) {
        this.attributeId = attributeId;
    }

    public String getAttributeDescribe() {
        return attributeDescribe;
    }

    public void setAttributeDescribe(String attributeDescribe) {
        this.attributeDescribe = attributeDescribe;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public List<Long> getValueList() {
        return valueList;
    }

    public void setValueList(List<Long> valueList) {
        this.valueList = valueList;
    }
}
