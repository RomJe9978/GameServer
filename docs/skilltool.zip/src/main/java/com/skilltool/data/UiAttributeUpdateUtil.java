package com.skilltool.data;

import java.util.List;

/**
 * @author liuxuanjie
 * @date 2023/7/3 11:04
 */
public class UiAttributeUpdateUtil extends AbstractRecordUnit {
    /**
     * 战士标识
     */
    private int warriorMark;

    /**
     * 本条记录涉及的所有属性变化
     */
    private List<UiAttributeData> attributeDataList;

    /**
     * 更新的具体描述
     */
    private String updateDescribe;

    /**
     * 涉及代码的描述
     */
    private String codeDescribe;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.ATTRIBUTE;
    }

    public int getWarriorMark() {
        return warriorMark;
    }

    public void setWarriorMark(int warriorMark) {
        this.warriorMark = warriorMark;
    }

    public List<UiAttributeData> getAttributeDataList() {
        return attributeDataList;
    }

    public void setAttributeDataList(List<UiAttributeData> attributeDataList) {
        this.attributeDataList = attributeDataList;
    }

    public String getUpdateDescribe() {
        return updateDescribe;
    }

    public void setUpdateDescribe(String updateDescribe) {
        this.updateDescribe = updateDescribe;
    }

    public String getCodeDescribe() {
        return codeDescribe;
    }

    public void setCodeDescribe(String codeDescribe) {
        this.codeDescribe = codeDescribe;
    }
}
