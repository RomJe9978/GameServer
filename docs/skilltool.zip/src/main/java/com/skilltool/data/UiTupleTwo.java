package com.skilltool.data;

/**
 * 两元组
 *
 * @author liuxuanjie
 * @date 2023/7/12 21:03
 */
public class UiTupleTwo<K, V> {
    /**
     * 双元组的两个值
     */
    private K first;
    private V value;

    public K getFirst() {
        return first;
    }

    public void setFirst(K first) {
        this.first = first;
    }

    public V getValue() {
        return value;
    }

    public void setValue(V value) {
        this.value = value;
    }
}
