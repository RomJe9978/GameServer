package com.skilltool.data;

import java.util.Map;

/**
 * UI展示战士数据
 *
 * @author liuxuanjie
 * @date 2023/6/27 10:43
 */
public class UiWarriorData {
    /**
     * 战士所在的位置
     */
    private int location;

    /**
     * 是否是攻击方“光环柱”
     */
    private boolean isAttackHalo;

    /**
     * 是否是防御方“光环柱”
     */
    private boolean isDefendHalo;

    /**
     * 唯一标识一个warrior实例
     */
    private int warriorMark;

    /**
     * 对应卡牌名称
     */
    private String name;

    /**
     * 当前Warrior触发的战斗时机
     * key：记录的唯一序号，value：战斗事件的记录
     */
    private Map<Integer, UiBattleEventUnit> battleEventUnitMap;

    /**
     * 当前Warrior的单回合内的Skill记录
     * key：记录的唯一序号，value：skill的记录
     */
    private Map<Integer, UiSkillApplyUnit> skillUnitMap;

    /**
     * 当前Warrior的单回合内的Attr记录
     * key：记录的唯一序号，value：attr的记录
     */
    private Map<Integer, UiAttrEffectUnit> attrEffectUnitMap;

    /**
     * 当前Warrior的单回合内的Buff记录
     * key：记录的唯一序号，value：buff的记录
     */
    private Map<Integer, UiBuffUpdateUnit> buffUpdateUnitMap;

    /**
     * 当前Warrior的单回合内的Buff记录
     * key：记录的唯一序号，value：buff的记录
     */
    private Map<Integer, UiMarkUpdateUnit> markUpdateUnitMap;

    /**
     * 当前Warrior的单回合内的属性记录
     * key：记录的唯一序号，value：buff的记录
     */
    private Map<Integer, UiAttributeUpdateUtil> attributeUpdateUtilMap;

    /**
     * “属性计算”记录（不会再进行属性修改时候的伤害真正计算前）
     */
    private Map<Integer, UiCalculateAttributeUnit> calculateAttributeUnitMap;

    /**
     * 一次伤害计算公式的计算记录
     */
    private Map<Integer, UiDamageCalculateUnit> damageCalculateUnitMap;

    /**
     * 当前Warrior的“被攻击”记录
     * key：记录的唯一序号，value："伤害记录"绑定的是被伤害的一方
     */
    private Map<Integer, UiDamageUnit> damageUnitMap;

    /**
     * 当前warrior的“被回复”记录
     * key：记录的唯一序号，value：“回复记录”绑定的是被回复的一方
     */
    private Map<Integer, UiHealUnit> healUnitMap;

    /**
     * 当前回合关注的快照数据
     * key：快照时间点的标识，value：快照数据
     */
    private Map<Integer, UiWarriorSnapshotData> snapshotDataMap;

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }

    public boolean isAttackHalo() {
        return isAttackHalo;
    }

    public void setAttackHalo(boolean attackHalo) {
        isAttackHalo = attackHalo;
    }

    public boolean isDefendHalo() {
        return isDefendHalo;
    }

    public void setDefendHalo(boolean defendHalo) {
        isDefendHalo = defendHalo;
    }

    public int getWarriorMark() {
        return warriorMark;
    }

    public void setWarriorMark(int warriorMark) {
        this.warriorMark = warriorMark;
    }

    public Map<Integer, UiWarriorSnapshotData> getSnapshotDataMap() {
        return snapshotDataMap;
    }

    public void setSnapshotDataMap(Map<Integer, UiWarriorSnapshotData> snapshotDataMap) {
        this.snapshotDataMap = snapshotDataMap;
    }

    public Map<Integer, UiBattleEventUnit> getBattleEventUnitMap() {
        return battleEventUnitMap;
    }

    public void setBattleEventUnitMap(Map<Integer, UiBattleEventUnit> battleEventUnitMap) {
        this.battleEventUnitMap = battleEventUnitMap;
    }

    public Map<Integer, UiSkillApplyUnit> getSkillUnitMap() {
        return skillUnitMap;
    }

    public void setSkillUnitMap(Map<Integer, UiSkillApplyUnit> skillUnitMap) {
        this.skillUnitMap = skillUnitMap;
    }

    public Map<Integer, UiAttrEffectUnit> getAttrEffectUnitMap() {
        return attrEffectUnitMap;
    }

    public void setAttrEffectUnitMap(Map<Integer, UiAttrEffectUnit> attrEffectUnitMap) {
        this.attrEffectUnitMap = attrEffectUnitMap;
    }

    public Map<Integer, UiBuffUpdateUnit> getBuffUpdateUnitMap() {
        return buffUpdateUnitMap;
    }

    public void setBuffUpdateUnitMap(Map<Integer, UiBuffUpdateUnit> buffUpdateUnitMap) {
        this.buffUpdateUnitMap = buffUpdateUnitMap;
    }

    public Map<Integer, UiMarkUpdateUnit> getMarkUpdateUnitMap() {
        return markUpdateUnitMap;
    }

    public void setMarkUpdateUnitMap(Map<Integer, UiMarkUpdateUnit> markUpdateUnitMap) {
        this.markUpdateUnitMap = markUpdateUnitMap;
    }

    public Map<Integer, UiAttributeUpdateUtil> getAttributeUpdateUtilMap() {
        return attributeUpdateUtilMap;
    }

    public void setAttributeUpdateUtilMap(Map<Integer, UiAttributeUpdateUtil> attributeUpdateUtilMap) {
        this.attributeUpdateUtilMap = attributeUpdateUtilMap;
    }

    public Map<Integer, UiCalculateAttributeUnit> getCalculateAttributeUnitMap() {
        return calculateAttributeUnitMap;
    }

    public void setCalculateAttributeUnitMap(Map<Integer, UiCalculateAttributeUnit> calculateAttributeUnitMap) {
        this.calculateAttributeUnitMap = calculateAttributeUnitMap;
    }

    public Map<Integer, UiDamageCalculateUnit> getDamageCalculateUnitMap() {
        return damageCalculateUnitMap;
    }

    public void setDamageCalculateUnitMap(Map<Integer, UiDamageCalculateUnit> damageCalculateUnitMap) {
        this.damageCalculateUnitMap = damageCalculateUnitMap;
    }

    public Map<Integer, UiDamageUnit> getDamageUnitMap() {
        return damageUnitMap;
    }

    public void setDamageUnitMap(Map<Integer, UiDamageUnit> damageUnitMap) {
        this.damageUnitMap = damageUnitMap;
    }

    public Map<Integer, UiHealUnit> getHealUnitMap() {
        return healUnitMap;
    }

    public void setHealUnitMap(Map<Integer, UiHealUnit> healUnitMap) {
        this.healUnitMap = healUnitMap;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
