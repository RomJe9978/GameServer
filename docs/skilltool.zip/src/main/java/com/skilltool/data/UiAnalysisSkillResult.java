package com.skilltool.data;

import java.util.Map;

/**
 * 分析技能配置结果数据
 *
 * @author liuxuanjie
 * @date 2023/7/11 12:05
 */
public class UiAnalysisSkillResult {
    /**
     * 所有类型的所有分析结果
     */
    private Map<UiDataEnum.AnalysisTypeEnum, UiSingleAnalysisData> typeAnalysisMap;

    /**
     * 技能目标分析结果
     */
    private String skillTargetStr;

    public Map<UiDataEnum.AnalysisTypeEnum, UiSingleAnalysisData> getTypeAnalysisMap() {
        return typeAnalysisMap;
    }

    public void setTypeAnalysisMap(Map<UiDataEnum.AnalysisTypeEnum, UiSingleAnalysisData> typeAnalysisMap) {
        this.typeAnalysisMap = typeAnalysisMap;
    }

    public String getSkillTargetStr() {
        return skillTargetStr;
    }

    public void setSkillTargetStr(String skillTargetStr) {
        this.skillTargetStr = skillTargetStr;
    }
}
