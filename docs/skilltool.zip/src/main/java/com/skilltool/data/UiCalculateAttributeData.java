package com.skilltool.data;

import java.util.List;
import java.util.Objects;

/**
 * 属性计算的数据
 *
 * @author RomJe
 */
public class UiCalculateAttributeData {
    /**
     * 计算结果
     */
    private long result;

    /**
     * 初始值
     */
    private long rawValue;

    /**
     * 增益百分比值
     */
    private long addPercentValue;

    /**
     * 增益连乘百分比
     */
    private List<Long> addMultiPercentList;

    /**
     * 增益值
     */
    private long addValue;

    /**
     * 减益值
     */
    private long subtractValue;

    /**
     * 减益连乘百分比
     */
    private List<Long> subtractMultiPercentList;

    public static UiCalculateAttributeData newInstance() {
        return new UiCalculateAttributeData();
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append(this.result).append(" = ");
        if (this.addValue != 0 || this.subtractValue != 0) {
            result.append(" [ ");
        }

        result.append(this.rawValue);

        if (this.addPercentValue != 0) {
            result.append(" * (1 + ").append(this.addPercentValue).append(" / 10000)");
        }

        if (Objects.nonNull(this.addMultiPercentList)) {
            for (long multiValue : this.addMultiPercentList) {
                result.append(" * (1 + ").append(multiValue).append(" / 10000)");
            }
        }

        if (this.addValue != 0) {
            result.append(" + ").append(this.addValue);
        }

        if (this.subtractValue != 0) {
            result.append(" - ").append(this.subtractValue);
        }

        if (this.addValue != 0 || this.subtractValue != 0) {
            result.append(" ] ");
        }

        if (Objects.nonNull(this.subtractMultiPercentList)) {
            for (long multiValue : this.subtractMultiPercentList) {
                result.append(" * (1 - ").append(multiValue).append(" / 10000)");
            }
        }
        return result.toString();
    }

    public long getResult() {
        return result;
    }

    public void setResult(long result) {
        this.result = result;
    }

    public long getRawValue() {
        return rawValue;
    }

    public void setRawValue(long rawValue) {
        this.rawValue = rawValue;
    }

    public long getAddPercentValue() {
        return addPercentValue;
    }

    public void setAddPercentValue(long addPercentValue) {
        this.addPercentValue = addPercentValue;
    }

    public List<Long> getAddMultiPercentList() {
        return addMultiPercentList;
    }

    public void setAddMultiPercentList(List<Long> addMultiPercentList) {
        this.addMultiPercentList = addMultiPercentList;
    }

    public long getAddValue() {
        return addValue;
    }

    public void setAddValue(long addValue) {
        this.addValue = addValue;
    }

    public long getSubtractValue() {
        return subtractValue;
    }

    public void setSubtractValue(long subtractValue) {
        this.subtractValue = subtractValue;
    }

    public List<Long> getSubtractMultiPercentList() {
        return subtractMultiPercentList;
    }

    public void setSubtractMultiPercentList(List<Long> subtractMultiPercentList) {
        this.subtractMultiPercentList = subtractMultiPercentList;
    }
}
