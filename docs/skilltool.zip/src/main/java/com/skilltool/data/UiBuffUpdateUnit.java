package com.skilltool.data;

/**
 * 一条“buff-实际更新”的最小数据单元
 *
 * @author liuxuanjie
 * @date 2023/6/30 14:32
 */
public class UiBuffUpdateUnit extends AbstractRecordUnit {
    /**
     * buff的配置id
     */
    private int buffTemplateId;

    /**
     * buff的来源
     */
    private int sourceWarriorMark;

    /**
     * 可以理解为buff在谁身上
     */
    private int targetWarriorMark;

    /**
     * buff的更新类型
     */
    private UiDataEnum.BuffUpdateEnum buffUpdateEnum;

    /**
     * buff的更新原因
     */
    private String reason;

    @Override
    public UiDataEnum.RecordEnum getRecordEnum() {
        return UiDataEnum.RecordEnum.BUFF;
    }

    public int getBuffTemplateId() {
        return buffTemplateId;
    }

    public void setBuffTemplateId(int buffTemplateId) {
        this.buffTemplateId = buffTemplateId;
    }

    public int getSourceWarriorMark() {
        return sourceWarriorMark;
    }

    public void setSourceWarriorMark(int sourceWarriorMark) {
        this.sourceWarriorMark = sourceWarriorMark;
    }

    public int getTargetWarriorMark() {
        return targetWarriorMark;
    }

    public void setTargetWarriorMark(int targetWarriorMark) {
        this.targetWarriorMark = targetWarriorMark;
    }

    public UiDataEnum.BuffUpdateEnum getBuffUpdateEnum() {
        return buffUpdateEnum;
    }

    public void setBuffUpdateEnum(UiDataEnum.BuffUpdateEnum buffUpdateEnum) {
        this.buffUpdateEnum = buffUpdateEnum;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
