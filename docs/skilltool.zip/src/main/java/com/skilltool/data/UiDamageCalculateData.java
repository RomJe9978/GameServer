package com.skilltool.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 一次伤害计算数据
 *
 * @author RomJe
 */
public class UiDamageCalculateData {
    /**
     * 基础伤害过程
     */
    private UiBaseDamageData baseDamageData;

    /**
     * 伤害计算前的伤害
     */
    private long beforeDamage;

    /**
     * 是否暴击
     */
    private boolean isCrit;

    /**
     * 攻击方造成的暴击伤害增益
     */
    private long attackCritDamageAddPercent;

    /**
     * 防守方受到的暴击伤害增益
     */
    private long defenderCritDamagedAddPercent;

    /**
     * 攻击者普通攻击伤害增加
     */
    private long attackNormalDamageAdd;

    /**
     * 攻击者技能伤害系数减少
     */
    private long attackSkillDamageRatioReduce;

    /**
     * 攻击者技能伤害系数增加
     */
    private long attackSkillDamageRatioAdd;

    /**
     * 防守方受到的技能伤害系数减少
     */
    private long defenderSkillDamagedRatioReduce;

    /**
     * 防守方受到的技能伤害系数增加
     */
    private long defenderSkillDamagedRatioAdd;

    /**
     * 最终伤害2
     */
    private float finalDamage2;

    //................ 技能加倍属性 ............................

    /**
     * 是否格挡成功
     */
    private boolean parrySuccess;

    /**
     * 最终格挡效果
     */
    private float parryEffect;

    /**
     * 计算完格挡之后的结果
     */
    private float finalDamage3;

    //................. 格挡伤害信息 ..........................

    /**
     * 攻击方伤害增益
     */
    private List<Long> attackAddList;

    /**
     * 攻击者物理伤害增益
     */
    private List<Long> attackPhysicAddList;

    /**
     * 攻击者法术伤害增益
     */
    private List<Long> attackMagicAddList;

    /**
     * 攻击方对特定防御方类型的伤害增益
     */
    private List<Long> attackToDefenderAddList;

    /**
     * 防守方受到的伤害增益
     */
    private List<Long> defenderAddList;

    /**
     * 防守者受到的物理伤害增益
     */
    private List<Long> defenderPhysicAddList;

    /**
     * 防守者受到的法术伤害增益
     */
    private List<Long> defenderMagicAddList;

    /**
     * 防守方受到特定防御方类型的伤害增益
     */
    private List<Long> defenderToAttackerAddList;

    // ..........最终伤害增益效果END..........................

    /**
     * 攻击方伤害减益
     */
    private List<Long> attackReduceList;

    /**
     * 攻击方对特定武将的伤害减益
     */
    private List<Long> attackToDefenderReduceList;

    /**
     * 攻击方造成的物理伤害减益
     */
    private List<Long> attackPhysicReduceList;

    /**
     * 攻击方造成的法术伤害减益
     */
    private List<Long> attackMagicReduceList;

    /**
     * 攻击方是否无视敌方402伤害减低属性
     */
    private boolean attackIgnoreDefenderReduce;

    /**
     * 攻击方是否无视敌方物理伤害减低
     */
    private boolean attackIgnoreDefenderPhysicReduce;

    /**
     * 防守方受到的伤害减益
     */
    private List<Long> defenderReduceList;

    /**
     * 防守方受到特定武将的伤害减益
     */
    private List<Long> defenderToAttackerReduceList;

    /**
     * 防守方受到的暴击伤害减益
     */
    private List<Long> defenderCritReduceList;

    /**
     * 防守方受到的物理伤害减益
     */
    private List<Long> defenderPhysicReduceList;

    /**
     * 防守方受到的法术伤害减益
     */
    private List<Long> defenderMagicReduceList;

    // ..........最终伤害减益效果END..........................
    /**
     * 最终属性伤害
     */
    private float finalAttributeDamage;

    /**
     * 攻击者最终属性伤害增益
     */
    private List<Long> attackAttributeParseAddList;

    /**
     * 攻击者最终属性伤害减益
     */
    private List<Long> attackAttributeParseReduceList;

    /**
     * 最终伤害4
     */
    private long finalDamage4;

    // ..........最终属性伤害增益END..........................

    public String parseBaseDamage() {
        if (Objects.isNull(this.baseDamageData)) {
            return "";
        }

        StringBuilder result = new StringBuilder("基础伤害计算： ");
        result.append(this.baseDamageData.getFinalBaseDamage()).append(" = ").append(this.baseDamageData.getAttackValue());
        result.append(" * ");
        result.append(this.baseDamageData.getRatio()).append("/10000");
        result.append(" * ");
        result.append("(1 - ").append(this.baseDamageData.getDefenderReduce()).append(")");
        result.append(" * ");
        result.append("(1 - ").append(this.baseDamageData.getDefenderArmorReduce()).append(")");
        return result.toString();
    }

    public String parseFinalDamage2() {
        StringBuilder result = new StringBuilder("伤害2公式： ");
        result.append(String.format("%.2f", this.finalDamage2)).append(" = ").append(this.beforeDamage);
        if (this.isCrit) {
            result.append(" * ");
            result.append("【");
            result.append("max(0, ").append(this.attackCritDamageAddPercent).append("/10000)");
            result.append(" + ");
            result.append("max(0, ").append(this.defenderCritDamagedAddPercent).append("/10000)");
            result.append("】");
        }

        result.append(" * ");
        result.append("(1 + ").append(this.attackNormalDamageAdd).append("/10000)");

        result.append(" * ");
        result.append("(1 - ").append(this.attackSkillDamageRatioReduce).append("/10000");
        result.append(" - ").append(this.defenderSkillDamagedRatioReduce).append("/10000)");

        result.append(" * ");
        result.append("(1 + ").append(this.attackSkillDamageRatioAdd).append("/10000");
        result.append(" + ").append(this.defenderSkillDamagedRatioAdd).append("/10000)");
        return result.toString();
    }

    public String parseFinalDamage3() {
        StringBuilder result = new StringBuilder("伤害3公式： ");
        result.append((long) this.finalDamage3).append(" = ").append((long) this.finalDamage2);
        if (this.parrySuccess) {
            result.append(" * ");
            result.append("(1 - ").append(String.format("%.2f", this.parryEffect)).append(")");
        }
        return result.toString();
    }

    public String parseFinalDamage4() {
        StringBuilder result = new StringBuilder("伤害4公式： ");
        result.append(this.finalDamage4).append(" = ").append((long) this.finalDamage3);
        result.append(" * ");
        result.append("【 ").append(parseFinalAddEffect()).append(" 】");
        result.append(" * ");
        result.append("【 ").append(parseFinalReduceEffect()).append(" 】");
        result.append(" * ");
        result.append("【 ").append(parseFinalAttributeDamage()).append(" 】");
        return result.toString();
    }

    public String parseFinalAddEffect() {
        StringBuilder result = new StringBuilder("1");
        List<Long> allList = new ArrayList<>();
        addAll(allList, this.attackAddList);
        addAll(allList, this.attackPhysicAddList);
        addAll(allList, this.attackMagicAddList);
        addAll(allList, this.attackToDefenderAddList);
        addAll(allList, this.defenderAddList);
        addAll(allList, this.defenderPhysicAddList);
        addAll(allList, this.defenderMagicAddList);
        addAll(allList, this.defenderToAttackerAddList);
        for (Long value : allList) {
            result.append(" + ").append(value).append(" / 10000");
        }
        return result.toString();
    }

    public String parseFinalReduceEffect() {
        StringBuilder result = new StringBuilder("1");

        List<Long> allList = new ArrayList<>();
        addAll(allList, this.attackReduceList);
        addAll(allList, this.attackToDefenderReduceList);
        addAll(allList, this.attackPhysicReduceList);
        addAll(allList, this.attackMagicReduceList);

        addAll(allList, this.defenderReduceList);
        addAll(allList, this.defenderToAttackerReduceList);
        addAll(allList, this.defenderCritReduceList);
        addAll(allList, this.defenderPhysicReduceList);
        addAll(allList, this.defenderMagicReduceList);

        for (Long value : allList) {
            result.append(" * ").append(fillReduceCalculate(value));
        }
        return result.toString();
    }

    public String parseFinalAttributeDamage() {
        StringBuilder result = new StringBuilder("max{0, 1");
        if (Objects.nonNull(this.attackAttributeParseAddList)) {
            for (long value : this.attackAttributeParseAddList) {
                result.append(" + ").append(value).append("/10000");
            }
        }
        if (Objects.nonNull(this.attackAttributeParseReduceList)) {
            for (long value : this.attackAttributeParseReduceList) {
                result.append(" - ").append(value).append("/10000");
            }
        }
        result.append("}");
        return result.toString();
    }

    private String fillReduceCalculate(long value) {
        return "max{0.1, min(1, 1-" + value + "/10000)}";
    }

    private <T> void addAll(List<T> resultList, List<T> addList) {
        if (Objects.isNull(resultList)) {
            return;
        }

        if (Objects.isNull(addList) || addList.isEmpty()) {
            return;
        }

        resultList.addAll(addList);
    }

    public UiBaseDamageData getBaseDamageData() {
        return baseDamageData;
    }

    public void setBaseDamageData(UiBaseDamageData baseDamageData) {
        this.baseDamageData = baseDamageData;
    }

    public List<Long> getAttackAddList() {
        return attackAddList;
    }

    public void setAttackAddList(List<Long> attackAddList) {
        this.attackAddList = attackAddList;
    }

    public List<Long> getAttackPhysicAddList() {
        return attackPhysicAddList;
    }

    public void setAttackPhysicAddList(List<Long> attackPhysicAddList) {
        this.attackPhysicAddList = attackPhysicAddList;
    }

    public List<Long> getAttackMagicAddList() {
        return attackMagicAddList;
    }

    public void setAttackMagicAddList(List<Long> attackMagicAddList) {
        this.attackMagicAddList = attackMagicAddList;
    }

    public List<Long> getAttackToDefenderAddList() {
        return attackToDefenderAddList;
    }

    public void setAttackToDefenderAddList(List<Long> attackToDefenderAddList) {
        this.attackToDefenderAddList = attackToDefenderAddList;
    }

    public List<Long> getDefenderAddList() {
        return defenderAddList;
    }

    public void setDefenderAddList(List<Long> defenderAddList) {
        this.defenderAddList = defenderAddList;
    }

    public List<Long> getDefenderPhysicAddList() {
        return defenderPhysicAddList;
    }

    public void setDefenderPhysicAddList(List<Long> defenderPhysicAddList) {
        this.defenderPhysicAddList = defenderPhysicAddList;
    }

    public List<Long> getDefenderMagicAddList() {
        return defenderMagicAddList;
    }

    public void setDefenderMagicAddList(List<Long> defenderMagicAddList) {
        this.defenderMagicAddList = defenderMagicAddList;
    }

    public List<Long> getDefenderToAttackerAddList() {
        return defenderToAttackerAddList;
    }

    public void setDefenderToAttackerAddList(List<Long> defenderToAttackerAddList) {
        this.defenderToAttackerAddList = defenderToAttackerAddList;
    }

    public List<Long> getAttackReduceList() {
        return attackReduceList;
    }

    public void setAttackReduceList(List<Long> attackReduceList) {
        this.attackReduceList = attackReduceList;
    }

    public List<Long> getAttackToDefenderReduceList() {
        return attackToDefenderReduceList;
    }

    public void setAttackToDefenderReduceList(List<Long> attackToDefenderReduceList) {
        this.attackToDefenderReduceList = attackToDefenderReduceList;
    }

    public List<Long> getAttackPhysicReduceList() {
        return attackPhysicReduceList;
    }

    public void setAttackPhysicReduceList(List<Long> attackPhysicReduceList) {
        this.attackPhysicReduceList = attackPhysicReduceList;
    }

    public List<Long> getAttackMagicReduceList() {
        return attackMagicReduceList;
    }

    public void setAttackMagicReduceList(List<Long> attackMagicReduceList) {
        this.attackMagicReduceList = attackMagicReduceList;
    }

    public boolean isAttackIgnoreDefenderReduce() {
        return attackIgnoreDefenderReduce;
    }

    public void setAttackIgnoreDefenderReduce(boolean attackIgnoreDefenderReduce) {
        this.attackIgnoreDefenderReduce = attackIgnoreDefenderReduce;
    }

    public boolean isAttackIgnoreDefenderPhysicReduce() {
        return attackIgnoreDefenderPhysicReduce;
    }

    public void setAttackIgnoreDefenderPhysicReduce(boolean attackIgnoreDefenderPhysicReduce) {
        this.attackIgnoreDefenderPhysicReduce = attackIgnoreDefenderPhysicReduce;
    }

    public List<Long> getDefenderReduceList() {
        return defenderReduceList;
    }

    public void setDefenderReduceList(List<Long> defenderReduceList) {
        this.defenderReduceList = defenderReduceList;
    }

    public List<Long> getDefenderCritReduceList() {
        return defenderCritReduceList;
    }

    public void setDefenderCritReduceList(List<Long> defenderCritReduceList) {
        this.defenderCritReduceList = defenderCritReduceList;
    }

    public List<Long> getDefenderPhysicReduceList() {
        return defenderPhysicReduceList;
    }

    public void setDefenderPhysicReduceList(List<Long> defenderPhysicReduceList) {
        this.defenderPhysicReduceList = defenderPhysicReduceList;
    }

    public List<Long> getDefenderMagicReduceList() {
        return defenderMagicReduceList;
    }

    public void setDefenderMagicReduceList(List<Long> defenderMagicReduceList) {
        this.defenderMagicReduceList = defenderMagicReduceList;
    }

    public float getFinalAttributeDamage() {
        return finalAttributeDamage;
    }

    public void setFinalAttributeDamage(float finalAttributeDamage) {
        this.finalAttributeDamage = finalAttributeDamage;
    }

    public List<Long> getAttackAttributeParseAddList() {
        return attackAttributeParseAddList;
    }

    public void setAttackAttributeParseAddList(List<Long> attackAttributeParseAddList) {
        this.attackAttributeParseAddList = attackAttributeParseAddList;
    }

    public List<Long> getAttackAttributeParseReduceList() {
        return attackAttributeParseReduceList;
    }

    public void setAttackAttributeParseReduceList(List<Long> attackAttributeParseReduceList) {
        this.attackAttributeParseReduceList = attackAttributeParseReduceList;
    }

    public List<Long> getDefenderToAttackerReduceList() {
        return defenderToAttackerReduceList;
    }

    public void setDefenderToAttackerReduceList(List<Long> defenderToAttackerReduceList) {
        this.defenderToAttackerReduceList = defenderToAttackerReduceList;
    }

    public long getBeforeDamage() {
        return beforeDamage;
    }

    public void setBeforeDamage(long beforeDamage) {
        this.beforeDamage = beforeDamage;
    }

    public boolean isCrit() {
        return isCrit;
    }

    public void setCrit(boolean crit) {
        isCrit = crit;
    }

    public long getAttackCritDamageAddPercent() {
        return attackCritDamageAddPercent;
    }

    public void setAttackCritDamageAddPercent(long attackCritDamageAddPercent) {
        this.attackCritDamageAddPercent = attackCritDamageAddPercent;
    }

    public long getDefenderCritDamagedAddPercent() {
        return defenderCritDamagedAddPercent;
    }

    public void setDefenderCritDamagedAddPercent(long defenderCritDamagedAddPercent) {
        this.defenderCritDamagedAddPercent = defenderCritDamagedAddPercent;
    }

    public boolean isParrySuccess() {
        return parrySuccess;
    }

    public void setParrySuccess(boolean parrySuccess) {
        this.parrySuccess = parrySuccess;
    }

    public long getAttackNormalDamageAdd() {
        return attackNormalDamageAdd;
    }

    public void setAttackNormalDamageAdd(long attackNormalDamageAdd) {
        this.attackNormalDamageAdd = attackNormalDamageAdd;
    }

    public long getAttackSkillDamageRatioReduce() {
        return attackSkillDamageRatioReduce;
    }

    public void setAttackSkillDamageRatioReduce(long attackSkillDamageRatioReduce) {
        this.attackSkillDamageRatioReduce = attackSkillDamageRatioReduce;
    }

    public long getAttackSkillDamageRatioAdd() {
        return attackSkillDamageRatioAdd;
    }

    public void setAttackSkillDamageRatioAdd(long attackSkillDamageRatioAdd) {
        this.attackSkillDamageRatioAdd = attackSkillDamageRatioAdd;
    }

    public long getDefenderSkillDamagedRatioReduce() {
        return defenderSkillDamagedRatioReduce;
    }

    public void setDefenderSkillDamagedRatioReduce(long defenderSkillDamagedRatioReduce) {
        this.defenderSkillDamagedRatioReduce = defenderSkillDamagedRatioReduce;
    }

    public long getDefenderSkillDamagedRatioAdd() {
        return defenderSkillDamagedRatioAdd;
    }

    public void setDefenderSkillDamagedRatioAdd(long defenderSkillDamagedRatioAdd) {
        this.defenderSkillDamagedRatioAdd = defenderSkillDamagedRatioAdd;
    }

    public float getFinalDamage2() {
        return finalDamage2;
    }

    public void setFinalDamage2(float finalDamage2) {
        this.finalDamage2 = finalDamage2;
    }

    public float getParryEffect() {
        return parryEffect;
    }

    public void setParryEffect(float parryEffect) {
        this.parryEffect = parryEffect;
    }

    public float getFinalDamage3() {
        return finalDamage3;
    }

    public void setFinalDamage3(float finalDamage3) {
        this.finalDamage3 = finalDamage3;
    }

    public long getFinalDamage4() {
        return finalDamage4;
    }

    public void setFinalDamage4(long finalDamage4) {
        this.finalDamage4 = finalDamage4;
    }
}
