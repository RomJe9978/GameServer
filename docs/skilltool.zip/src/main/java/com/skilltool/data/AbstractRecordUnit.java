package com.skilltool.data;

/**
 * 最上层抽象出来的“一条记录单元”
 *
 * @author liuxuanjie
 * @date 2023/6/30 15:33
 */
public abstract class AbstractRecordUnit {
    /**
     * 该条记录的序号
     */
    private int sequence;

    /**
     * 最外层“嵌套结构”的开始序号，如果没有嵌套，则为-1
     * 例如：(5开始)(7开始)(8)(7结束)(5结束)(9),那么此时8
     * 的nestBeginSequence为5，9的nestBeginSequence为-1
     */
    private int nestBeginSequence;

    /**
     * 该条记录的类型
     */
    public abstract UiDataEnum.RecordEnum getRecordEnum();

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public int getNestBeginSequence() {
        return nestBeginSequence;
    }

    public void setNestBeginSequence(int nestBeginSequence) {
        this.nestBeginSequence = nestBeginSequence;
    }
}
