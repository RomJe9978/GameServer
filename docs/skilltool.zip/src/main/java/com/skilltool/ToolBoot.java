package com.skilltool;

import com.skilltool.function.MainViewer;

/**
 * @author liuxuanjie
 */
public class ToolBoot {

    public static void boot() {
        MainViewer.getInstance().start();
    }

    public static void main(String[] args) {
        ToolBoot.boot();
    }
}