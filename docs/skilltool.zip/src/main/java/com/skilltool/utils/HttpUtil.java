package com.skilltool.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;

/**
 * http工具类
 *
 * @author liuxuanjie
 * @date 2023/6/29 17:55
 */
public class HttpUtil {
    /**
     * 发送http请求
     *
     * @return 返回http结果中的<code>data</code>数据
     */
    public static String sendGetData(String urlStr, Map<String, String> paramMap) {
        try {
            String response = sendGet(urlStr, paramMap);
            JSONObject jsonResponse = JSON.parseObject(response);
            return jsonResponse.getString("data");
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 发送http请求，<code>Get</code>方式
     *
     * @param paramMap 参数map。<code>null</code>代表没有参数
     * @return 返回http回复的所有内容
     */
    public static String sendGet(String urlStr, Map<String, String> paramMap) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

            JSONObject json = new JSONObject();
            if (Objects.isNull(paramMap) || paramMap.isEmpty()) {
                json.put("default", "default");
            } else {
                json.putAll(paramMap);
            }

            byte[] postDataBytes = json.toString().getBytes(StandardCharsets.UTF_8);
            conn.setDoOutput(true);
            OutputStream outputStream = conn.getOutputStream();
            outputStream.write(postDataBytes);
            outputStream.flush();
            outputStream.close();

            // 返回的数据
            InputStream inputStream = conn.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } catch (IOException e) {
            return null;
        }
    }
}
