package com.skilltool.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 字符串相关操作工具类
 *
 * @author liuxuanjie
 * @date 2023/6/29 16:26
 */
public class StringUtil {
    /**
     * 内部常量，工具类保证闭包
     */
    private final static String BLANK_SPACE = " ";

    /**
     * 判断字符串是否为空
     */
    public static boolean isEmpty(String value) {
        return Objects.isNull(value) || value.isEmpty();
    }

    public static boolean nonEmpty(String value) {
        return !isEmpty(value);
    }

    /**
     * 生成一个指定长度的“空格”字符串
     * <p>每一个位置全部都是“空格”
     */
    public static String blankSpaceStr(int size) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(BLANK_SPACE);
        }
        return sb.toString();
    }

    /**
     * 默认“空格”填充
     * {@link #paddingForNumber(int, int, boolean, String)
     */
    public static String paddingForNumber(int number, int size, boolean leftAline) {
        return paddingForNumber(number, size, leftAline, BLANK_SPACE);
    }

    /**
     * 将指定数字转换成指定长度的字符串，不足的部分用“指定字符”填充
     *
     * @param size        填充之后的长度
     * @param leftAline   true：左对齐“3...”，false：右对齐“...3”
     * @param paddingChar 填充的字符
     */
    public static String paddingForNumber(int number, int size, boolean leftAline, String paddingChar) {
        String numStr = String.valueOf(number);
        if (leftAline) {
            numStr = String.format("%-" + size + "s", numStr);
        } else {
            numStr = String.format("%" + size + "s", numStr);
        }

        // 长度为1，且不是空格，因为本身就是空格
        if (Objects.nonNull(paddingChar) && paddingChar.length() == 1) {
            if (!BLANK_SPACE.equals(paddingChar)) {
                numStr = numStr.replace(BLANK_SPACE, paddingChar);
            }
        }
        return numStr;
    }

    /**
     * 给指定的字符串添加换行符，使得每行的长度一致，且每行前面有指定的缩进(首行不缩进)
     */
    public static String paddingLineAndIndent(String str, int lineSize, int indentCount) {
        return str;
//        if (Objects.isNull(str) || str.length() <= lineSize) {
//            return str;
//        }
//
//        String indentStr = blankSpaceStr(indentCount);
//        StringBuilder stringBuilder = new StringBuilder();
//
//        while (str.length() > lineSize) {
//            String firstLine = str.substring(0, lineSize);
//            stringBuilder.append(firstLine).append("\n");
//
//            str = indentStr + str.substring(lineSize);
//        }
//
//        // 别忘记了最后一行
//        if (str.length() != indentCount) {
//            stringBuilder.append(str);
//        }
//
//        return stringBuilder.toString();
    }

    /**
     * 搜索子串在字符串中的位置,所有位置
     *
     * @return 两个一组，表示一个子串的开始位置和结束位置
     */
    public static List<Integer> searchSubString(String text, String subString) {
        if (isEmpty(text) || isEmpty(subString)) {
            return null;
        }

        List<Integer> result = new ArrayList<>();
        int index = text.indexOf(subString);
        while (index != -1) {
            result.add(index);
            int endIndex = index + subString.length();
            result.add(endIndex);

            index = text.indexOf(subString, endIndex + 1);
        }
        return result;
    }

    /**
     * 把字符串按照指定的分隔符分割成int数组
     *
     * @return 失败返回null
     */
    public static int[] splitInt(String str, String splitChar) {
        if (Objects.isNull(str) || str.isEmpty() || Objects.isNull(splitChar) || splitChar.isEmpty()) {
            return null;
        }

        try {
            String[] strArr = str.split(splitChar);
            int[] intArr = new int[strArr.length];
            for (int i = 0, iSize = strArr.length; i < iSize; i++) {
                intArr[i] = Integer.parseInt(strArr[i]);
            }
            return intArr;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
