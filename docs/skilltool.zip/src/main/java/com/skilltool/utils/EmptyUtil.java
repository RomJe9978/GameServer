package com.skilltool.utils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * 检查<code>isEmpty</code>的工具
 *
 * @author liuxuanjie
 * @date 2023/6/28 14:37
 */
public class EmptyUtil {
    public static boolean nonEmpty(String str) {
        return Objects.nonNull(str) && !str.isEmpty();
    }

    public static <K, V> boolean nonEmpty(Map<K, V> map) {
        return Objects.nonNull(map) && !map.isEmpty();
    }

    public static <V> boolean nonEmpty(List<V> list) {
        return Objects.nonNull(list) && !list.isEmpty();
    }

    public static <V> boolean nonEmpty(Set<V> set) {
        return Objects.nonNull(set) && !set.isEmpty();
    }

    public static <V> boolean isEmpty(List<V> list) {
        return !nonEmpty(list);
    }

    public static <K, V> boolean isEmpty(Map<K, V> map) {
        return !nonEmpty(map);
    }
}
