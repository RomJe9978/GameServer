package com.skilltool.utils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author liuxuanjie
 * @date 2023/6/29 18:43
 */
public class CollectionUtil {

    /**
     * “去重追加“放入map中的list
     * <p>如果map中已经存在key，则将value追加到list中
     */
    public static <K, V> void appendValueUnique(Map<K, List<V>> map, K key, List<V> value) {
        if (Objects.isNull(map) || Objects.isNull(key) || Objects.isNull(value)) {
            return;
        }

        if (map.containsKey(key)) {
            addUnique(map.get(key), value);
        } else {
            map.put(key, value);
        }
    }

    /**
     * 将<code>addList</code>中的元素添加到<code>result</code>中
     * 去重添加，当<code>result</code>中不存在时才会添加
     */
    public static <V> void addUnique(List<V> result, List<V> addList) {
        if (Objects.isNull(result) || Objects.isNull(addList) || addList.isEmpty()) {
            return;
        }

        for (V v : addList) {
            addUnique(result, v);
        }
    }

    /**
     * 去重添加元素
     * @param element 允许为<code>null</code>
     */
    public static <V> void addUnique(List<V> result, V element) {
        if (Objects.isNull(result)) {
            return;
        }

        if (!result.contains(element)) {
            result.add(element);
        }
    }
}
