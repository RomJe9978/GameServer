package com.skilltool.function.help;

import com.skilltool.function.GlobalConst;

/**
 * @author liuxuanjie
 * @date 2023/7/20 17:07
 */
public class HelpViewConst {

    public final static String OPERATION_INSTRUCTIONS = "使用说明";

    public final static String HELP_OPERATION_TEXT =
            "[注意事项]" + "\n" +
                    "  1.所有功能的使用请确保[服务器战斗日志开关]处于开启[true]状态！\n" +
                    "  2.所有功能的使用连接地址默认为[本地地址],如果调试自己的服务器，无需修改！\n" +
                    "\n";

    public final static String HELP_OPERATION_CHECK_CONFIG_TEXT =
            "[" + GlobalConst.CHECK_CONFIG_PANEL + "]\n" +
                    "\n";

    public final static String HELP_OPERATION_EFFECT_ANALYSIS_TEXT =
            "[" + GlobalConst.ANALYSIS_PANEL_NAME + "]\n" +
                    "\n";

    public final static String HELP_OPERATION_FIGHT_DEBUG_TEXT =
            "[" + GlobalConst.FIGHT_PANEL_NAME + "]\n" +
                    "  1.左下角鼠标左键点击[开始]即可拉取[指定地址]的最后一场战斗数据！\n" +
                    "  2.在使用过程中，再次点击[开始]会重置所有信息，并重新拉取最后一场战斗数据！\n" +
                    "  3.所有最终被展示的[记录]的最左侧都有其[唯一ID]，作为其在当前回合内的唯一标识！\n" +
                    "  4.每一个位置的[按钮]对应唯一[颜色]，并与文本展示中的[文本展示颜色]一一匹配！\n" +
                    "  5.只有点击了指定位置的[按钮]，才会展示对应位置所记录的所有信息！\n" +
                    "  6.点击[检索]按钮后，会将所有回合与被检索内容相关的[位置]用[红框]标识！\n" +
                    "  7.[隐藏无关]点击后，就只会展示[被实际检索]出来的记录！\n" +
                    "  8.[隐藏属性]点击后，就会把所有[属性变更]相关的记录隐藏起来！\n" +
                    "  9.每一个位置按钮[右键]点击后，会出现位置对应武将的快照信息，使用[记录ID]可以搜索指定记录时刻的快照！\n" +
                    "\n";

    // ======================================= 名词说明 ==============================================================

    public final static String DEFINITION_INSTRUCTIONS = "名词说明";
    public final static String HELP_DEFINITION_TEXT =
            "[说明]" + "\n" +
                    "  1.由于记录信息内部有很多服务器定义的数值，该部分内容是为了解释某些程序具体实现的含义！\n" +
                    "\n";

    /**
     * 配置检查的名词说明相关
     */
    public final static String HELP_DEFINITION_CHECK_CONFIG_PREFIX = "\n[" + GlobalConst.CHECK_CONFIG_PANEL + "]\n";
    public final static String HELP_DEFINITION_CHECK_CONFIG_DEFAULT_TEXT =
            "  1.如需详细信息，请先使用[" + GlobalConst.CHECK_CONFIG_PANEL + "]功能，拉取服务器数据！\n";

    /**
     * 效果解析的名词说明相关
     */
    public final static String HELP_DEFINITION_EFFECT_ANALYSIS_TEXT =
            "\n[" + GlobalConst.ANALYSIS_PANEL_NAME + "]\n" +
                    "  1.[卡牌]代表被解析的技能或ATTR所属的武将\n" +
                    "  2.[TTT]代表在一次战斗交互参与双方中与[卡牌]对立的另一方\n" +
                    "\n";

    /**
     * 战斗调试的名词说明相关
     */
    public final static String HELP_DEFINITION_FIGHT_DEBUG_PREFIX = "\n[" + GlobalConst.FIGHT_PANEL_NAME + "]\n";
    public final static String HELP_DEFINITION_FIGHT_DEBUG_DEFAULT_TEXT =
            "  1.如需详细信息，请先使用[" + GlobalConst.FIGHT_PANEL_NAME + "]功能，拉取服务器数据！\n";
}
