package com.skilltool.function.fight.view;

import com.skilltool.data.*;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.StringUtil;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 战斗文本的转换器
 * <p>服务器“实例类”信息转换成“想要展示的文本格式”
 *
 * @author liuxuanjie
 * @date 2023/7/6 11:23
 */
public class FightTextParser {
    /**
     * 将一条“记录”转化成为“文本”
     *
     * @param indent   当前记录的这一行需要缩进多少个“单位”。非正数表示“无缩进”
     * @param lineSize 每行多少个字符(超过字符之后换行)
     */
    public static String parseRecordUnit(AbstractRecordUnit recordUnit, int indent, int lineSize) {
        if (Objects.isNull(recordUnit) || lineSize <= 0) {
            return null;
        }

        switch (recordUnit.getRecordEnum()) {
            case BATTLE_EVENT:
                return parseEventUnitString((UiBattleEventUnit) recordUnit, indent, lineSize);
            case SKILL:
                return parseSkillUnitString((UiSkillApplyUnit) recordUnit, indent, lineSize);
            case ATTR:
                return parseAttrUnitString((UiAttrEffectUnit) recordUnit, indent, lineSize);
            case BUFF:
                return parseBuffUnitString((UiBuffUpdateUnit) recordUnit, indent, lineSize);
            case MARK:
                return parseMarkUnitString((UiMarkUpdateUnit) recordUnit, indent, lineSize);
            case ATTRIBUTE:
                return parseAttributeUnitString((UiAttributeUpdateUtil) recordUnit, indent, lineSize);
            case CALCULATE_ATTRIBUTE:
                return parseCalculateAttributeUnitString((UiCalculateAttributeUnit) recordUnit, indent, lineSize);
            case ONCE_DAMAGE_CALCULATE:
                return parseCalculateDamageUnitString((UiDamageCalculateUnit) recordUnit, indent, lineSize);
            case DAMAGE:
                return parseDamageUnitString((UiDamageUnit) recordUnit, indent, lineSize);
            case HEAL:
                return parseHealUnitString((UiHealUnit) recordUnit, indent, lineSize);
            default:
                return null;
        }
    }

    private static String parseCalculateDamageUnitString(UiDamageCalculateUnit damageCalculateUnit, int indent, int lineSize) {
        if (Objects.isNull(damageCalculateUnit)) {
            return "";
        }

        String fixedStr = structRecordFixString(damageCalculateUnit.getSequence(), indent, lineSize);
        String prefix = "[伤害计算]";
        fixedStr += prefix + ":";
        String totalStr = fixedStr +
                "攻击者：" + parseWarriorName(damageCalculateUnit.getAttackMark()) +
                ", 防守者：" + parseWarriorName(damageCalculateUnit.getDefenderMark()) +
                ", 本次伤害计算结果：" + damageCalculateUnit.getOnceDamage() +
                ", 计算过程查看被攻击者快照，当前处于暴击事件后，此时属性不会再进行任何变化！";
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseCalculateAttributeUnitString(UiCalculateAttributeUnit uiCalculateAttributeUnit, int indent, int lineSize) {
        if (Objects.isNull(uiCalculateAttributeUnit)) {
            return "";
        }

        String fixedStr = structRecordFixString(uiCalculateAttributeUnit.getSequence(), indent, lineSize);
        String prefix = "[属性计算]";
        fixedStr += prefix + ":";
        String totalStr = fixedStr +
                "攻击者：" + parseWarriorName(uiCalculateAttributeUnit.getAttackerMark()) +
                ", 防守者：" + parseWarriorName(uiCalculateAttributeUnit.getDefenderMark()) +
                ", 此时战斗属性不会再进行修改！";
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseEventUnitString(UiBattleEventUnit uiBattleEventUnit, int indent, int lineSize) {
        if (Objects.isNull(uiBattleEventUnit)) {
            return "";
        }

        String fixedStr = structRecordFixString(uiBattleEventUnit.getSequence(), indent, lineSize);
        String prefix = "[事件触发]";
        fixedStr += prefix + ":";
        String totalStr = fixedStr +
                parseWarriorName(uiBattleEventUnit.getWarriorMark()) +
                ", 战斗事件：" + uiBattleEventUnit.getBattleEventName() +
                ", 触发Attr时机点：" + uiBattleEventUnit.getAttrTimingList();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseHealUnitString(UiHealUnit uiHealUnit, int indent, int lineSize) {
        if (Objects.isNull(uiHealUnit)) {
            return null;
        }

        // 构造"开始"或"结束"的前缀
        String prefix = "";
        if (uiHealUnit.isStartRecord()) {
            prefix = "[回复开始" + StringUtil.paddingForNumber(uiHealUnit.getSequence(), 4, false) + "]";
        } else {
            prefix = "[回复结束" + StringUtil.paddingForNumber(uiHealUnit.getSideSequence(), 4, false) + "]";
        }
        // 组合上述固定部分
        String fixedStr = structRecordFixString(uiHealUnit.getSequence(), indent, lineSize) + prefix + ":";

        // 组合技能信息
        String totalStr = fixedStr +
                "回复者:" + parseWarriorName(uiHealUnit.getAttackerMark()) +
                ", 被回复者：" + parseWarriorName(uiHealUnit.getDefenderMark()) +
                ", 技能ID：" + uiHealUnit.getSkillId() +
                ", 预回复值：" + uiHealUnit.getPreHealValue() +
                ", 实际回复值：" + uiHealUnit.getRealValue();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    /**
     * 解析“伤害记录”
     */
    private static String parseDamageUnitString(UiDamageUnit uiDamageUnit, int indent, int lineSize) {
        if (Objects.isNull(uiDamageUnit)) {
            return null;
        }

        // 构造"开始"或"结束"的前缀
        String prefix = "";
        if (uiDamageUnit.isStartRecord()) {
            prefix = "[伤害开始" + StringUtil.paddingForNumber(uiDamageUnit.getSequence(), 4, false) + "]";
        } else {
            prefix = "[伤害结束" + StringUtil.paddingForNumber(uiDamageUnit.getSideSequence(), 4, false) + "]";
        }
        // 组合上述固定部分
        String fixedStr = structRecordFixString(uiDamageUnit.getSequence(), indent, lineSize) + prefix + ":";

        // 组合技能信息
        String totalStr = fixedStr +
                "攻击者:" + parseWarriorName(uiDamageUnit.getAttackerMark()) +
                ", 被攻击者：" + parseWarriorName(uiDamageUnit.getDefenderMark()) +
                ", 技能ID：" + uiDamageUnit.getSkillId() +
                ", 伤害类型：" + uiDamageUnit.getDamageType();
        // 伤害结束，需要更多更复杂的信息记录
        if (!uiDamageUnit.isStartRecord()) {
            totalStr = totalStr +
                    ", 总伤害：" + uiDamageUnit.getTotalDamage() +
                    ", 总的HP伤害：" + uiDamageUnit.getTotalHpDamage() +
                    ", 总的伤害溢出：" + uiDamageUnit.getTotalOverFlowDamage() +
                    ", 被攻击的turn伤害：" + uiDamageUnit.getTurnDamage() +
                    ", 伤害结果：" + uiDamageUnit.getAttackResult();
        }
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseSkillUnitString(UiSkillApplyUnit skillApplyUnit, int indent, int lineSize) {
        if (Objects.isNull(skillApplyUnit)) {
            return null;
        }

        // 构造"开始"或"结束"的前缀
        String prefix = "";
        if (skillApplyUnit.isStartRecord()) {
            prefix = "[技能开始" + StringUtil.paddingForNumber(skillApplyUnit.getSequence(), 4, false) + "]";
        } else {
            prefix = "[技能结束" + StringUtil.paddingForNumber(skillApplyUnit.getSideSequence(), 4, false) + "]";
        }
        // 组合上述固定部分
        String fixedStr = structRecordFixString(skillApplyUnit.getSequence(), indent, lineSize) + prefix + ":";

        // 组合技能信息
        String totalStr = fixedStr +
                "释放者:" + parseWarriorName(skillApplyUnit.getWarriorMark()) + ", " +
                SelectEnum.SKILL.getSelectPrefix() + skillApplyUnit.getSkillId();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseAttrUnitString(UiAttrEffectUnit attrEffectUnit, int indent, int lineSize) {
        if (Objects.isNull(attrEffectUnit)) {
            return null;
        }

        // 构造"开始"或"结束"的前缀
        String prefix = "";
        if (attrEffectUnit.isStartRecord()) {
            prefix = "[Attr开始" + StringUtil.paddingForNumber(attrEffectUnit.getSequence(), 4, false) + "]";
        } else {
            prefix = "[Attr结束" + StringUtil.paddingForNumber(attrEffectUnit.getSideSequence(), 4, false) + "]";
        }
        // 组合上述固定部分
        String fixedStr = structRecordFixString(attrEffectUnit.getSequence(), indent, lineSize) + prefix + ":";

        // 构造整个信息
        String totalStr = fixedStr +
                "owner:" + parseWarriorName((int) attrEffectUnit.getOwnerWarriorMark()) + ", " +
                SelectEnum.ATTR.getSelectPrefix() + attrEffectUnit.getAttrTemplateId() + ", " +
                "attrSource:" + parseWarriorName(attrEffectUnit.getAttrSource()) + ", " +
                "effectId:" + attrEffectUnit.getEffectId() + ", " +
                "target:" + parseWarriorName(attrEffectUnit.getTargetWarriorMarkList());
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseWarriorName(List<Integer> warriorMarkList) {
        if (EmptyUtil.isEmpty(warriorMarkList)) {
            return "null";
        }
        return warriorMarkList.stream().map(FightTextParser::parseWarriorName).collect(Collectors.toList()).toString();
    }

    private static String parseAttributeUnitString(UiAttributeUpdateUtil attributeUpdateUtil, int indent, int lineSize) {
        if (Objects.isNull(attributeUpdateUtil)) {
            return null;
        }

        StringBuilder attributeSb = new StringBuilder();
        List<UiAttributeData> attributeDataList = attributeUpdateUtil.getAttributeDataList();
        if (EmptyUtil.nonEmpty(attributeDataList)) {
            attributeSb.append("{");
            for (UiAttributeData attributeData : attributeDataList) {
                attributeSb.append(parseAttributeData(attributeData));
            }
            attributeSb.append("}");
        }

        String fixedStr = structRecordFixString(attributeUpdateUtil.getSequence(), indent, lineSize);
        fixedStr += "[属性变化]:";
        String totalStr = fixedStr + parseWarriorName(attributeUpdateUtil.getWarriorMark()) +
                ", " + attributeUpdateUtil.getUpdateDescribe() +
                ", " + attributeSb +
                ", " + attributeUpdateUtil.getCodeDescribe();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseBuffUnitString(UiBuffUpdateUnit buffUpdateUnit, int indent, int lineSize) {
        if (Objects.isNull(buffUpdateUnit)) {
            return null;
        }

        String fixedStr = structRecordFixString(buffUpdateUnit.getSequence(), indent, lineSize);
        String prefix = "[" + buffUpdateUnit.getBuffUpdateEnum().getDesc() + "]";
        fixedStr += prefix + ":";
        String totalStr = fixedStr +
                parseWarriorName(buffUpdateUnit.getTargetWarriorMark()) +
                ", " + buffUpdateUnit.getBuffUpdateEnum().getDesc() +
                ", (" + SelectEnum.BUFF.getSelectPrefix() + buffUpdateUnit.getBuffTemplateId() + ")" +
                ", " + "来源于：" + parseWarriorName(buffUpdateUnit.getSourceWarriorMark()) +
                ", " + "原因：" + buffUpdateUnit.getReason();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    private static String parseMarkUnitString(UiMarkUpdateUnit markUpdateUnit, int indent, int lineSize) {
        String fixedStr = structRecordFixString(markUpdateUnit.getSequence(), indent, lineSize);
        String prefix = "[" + markUpdateUnit.getMarkUpDateEnum().getDesc() + "]";
        fixedStr += prefix + ":";
        String totalStr = fixedStr +
                parseWarriorName(markUpdateUnit.getTargetWarriorMark()) +
                ", " + markUpdateUnit.getMarkUpDateEnum().getDesc() +
                ", (" + SelectEnum.MARK.getSelectPrefix() + markUpdateUnit.getMarkTemplateId() + ")" +
                ", " + "来源于：" + parseWarriorName(markUpdateUnit.getSourceWarriorMark()) +
                ", " + "原因：" + markUpdateUnit.getReason();
        return StringUtil.paddingLineAndIndent(totalStr, lineSize, fixedStr.length() + 1);
    }

    /**
     * 构造“一条记录”的固定部分
     */
    private static String structRecordFixString(int sequence, int indent, int lineSize) {
        // 填充序号
        String sequenceStr = StringUtil.paddingForNumber(sequence, FightViewConst.SEQUENCE_PADDING_LENGTH, false);
        // 先计算缩进
        String indentStr = indent > 0 ? StringUtil.blankSpaceStr(indent * FightViewConst.NEST_PADDING_LENGTH) : "";
        return sequenceStr + indentStr;
    }

    public static String parseSnapshotData(UiWarriorSnapshotData uiWarriorSnapshotData) {
        if (Objects.isNull(uiWarriorSnapshotData)) {
            return null;
        }
        String sequenceStr = StringUtil.paddingForNumber(uiWarriorSnapshotData.getSnapMark(), 5, false);
        return "对应序号：" + "[" + sequenceStr + "]" + ":\n" +
                StringUtil.blankSpaceStr(4) + "是否存活：" + uiWarriorSnapshotData.isAlive() + "\n" +
                StringUtil.blankSpaceStr(4) + "快照时血量：" + uiWarriorSnapshotData.getCurHp() + "\n" +
                StringUtil.blankSpaceStr(4) + "Attr信息：\n" +
                parseAllAttrMap(uiWarriorSnapshotData.getAttrSnapshotDataMap(), 8) + "\n" +
                StringUtil.blankSpaceStr(4) + "Buff信息：\n" +
                parseBuffListData(uiWarriorSnapshotData.getBuffDataList(), 8) + "\n" +
                StringUtil.blankSpaceStr(4) + "Mark信息：\n" +
                parseMarkListData(uiWarriorSnapshotData.getMarkDataList(), 8) + "\n" +
                StringUtil.blankSpaceStr(4) + "属性信息：\n" +
                parseAllAttributeMap(uiWarriorSnapshotData.getAttributeSnapshotMap()) + "\n" +
                StringUtil.blankSpaceStr(4) + "属性计算：\n" +
                parseAllCalculateAttribute(uiWarriorSnapshotData.getCalculateAttributeDataMap(), 8) + "\n" +
                StringUtil.blankSpaceStr(4) + "伤害计算：\n" +
                parseCalculateDamage(uiWarriorSnapshotData.getDamageCalculateData(), 8) + "\n" +
                StringUtil.blankSpaceStr(4) + "樱释信息：\n" +
                StringUtil.blankSpaceStr(8) + parseMusouData(uiWarriorSnapshotData.getUiMusouData()) + "\n";
    }

    private static String parseCalculateDamage(UiDamageCalculateData damageCalculateData, int padding) {
        if (Objects.isNull(damageCalculateData)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }

        String paddingStr = StringUtil.blankSpaceStr(padding);
        StringBuilder result = new StringBuilder();
        result.append(paddingStr).append(damageCalculateData.parseBaseDamage()).append("\n");
        result.append(paddingStr).append(damageCalculateData.parseFinalDamage2()).append("\n");
        result.append(paddingStr).append(damageCalculateData.parseFinalDamage3()).append("\n");
        result.append(paddingStr).append(damageCalculateData.parseFinalDamage4()).append("\n");

        UiBaseDamageData baseDamageData = damageCalculateData.getBaseDamageData();
        if (Objects.nonNull(baseDamageData)) {
            result.append("\n");
            result.append(paddingStr).append("攻击者攻击力：").append(baseDamageData.getAttackValue()).append("\n");
            result.append(paddingStr).append("攻击系数：").append(baseDamageData.getRatio()).append("\n");
            result.append(paddingStr).append("防守方物理/法术防御减免：").append(baseDamageData.getDefenderReduce()).append("\n");
            result.append(paddingStr).append("防守方护甲减免：").append(baseDamageData.getDefenderArmorReduce()).append("\n");
        }

        result.append("\n");
        result.append(paddingStr).append("是否暴击：").append(damageCalculateData.isCrit()).append("\n");
        result.append(paddingStr).append("攻击方造成的暴击伤害增益：").append(damageCalculateData.getAttackCritDamageAddPercent()).append("\n");
        result.append(paddingStr).append("防守方被造成的暴击伤害增益：").append(damageCalculateData.getDefenderCritDamagedAddPercent()).append("\n");
        result.append(paddingStr).append("攻击方普通攻击伤害增加：").append(damageCalculateData.getAttackNormalDamageAdd()).append("\n");
        result.append(paddingStr).append("攻击方技能伤害系数增加：").append(damageCalculateData.getAttackSkillDamageRatioAdd()).append("\n");
        result.append(paddingStr).append("攻击方技能伤害系数减少：").append(damageCalculateData.getAttackSkillDamageRatioReduce()).append("\n");
        result.append(paddingStr).append("防守方受到的技能伤害系数增加：").append(damageCalculateData.getDefenderSkillDamagedRatioAdd()).append("\n");
        result.append(paddingStr).append("防守方受到的技能伤害系数减少：").append(damageCalculateData.getDefenderSkillDamagedRatioReduce()).append("\n");

        result.append("\n");
        result.append(paddingStr).append("是否格挡成功：").append(damageCalculateData.isParrySuccess()).append("\n");
        result.append(paddingStr).append("最终格挡效果：").append((long) damageCalculateData.getParryEffect()).append("\n");

        result.append("\n");
        result.append(paddingStr).append("攻击方伤害增益：").append(damageCalculateData.getAttackAddList()).append("\n");
        result.append(paddingStr).append("攻击方物理伤害增益(仅物理伤害有值)：").append(damageCalculateData.getAttackPhysicAddList()).append("\n");
        result.append(paddingStr).append("攻击方法术伤害增益(仅法术伤害有值)：").append(damageCalculateData.getAttackMagicAddList()).append("\n");
        result.append(paddingStr).append("攻击方对防御方类型的伤害增益：").append(damageCalculateData.getAttackToDefenderAddList()).append("\n");
        result.append("\n");
        result.append(paddingStr).append("防守方受到的伤害增益：").append(damageCalculateData.getDefenderAddList()).append("\n");
        result.append(paddingStr).append("防守方受到的物理伤害增益(仅物理伤害有值)：").append(damageCalculateData.getDefenderPhysicAddList()).append("\n");
        result.append(paddingStr).append("防守方受到的法术伤害增益(仅法术伤害有值)：").append(damageCalculateData.getDefenderMagicAddList()).append("\n");
        result.append(paddingStr).append("防守方受到攻击方类型的伤害增益：").append(damageCalculateData.getDefenderToAttackerAddList()).append("\n");
        result.append("\n");
        result.append(paddingStr).append("攻击方伤害减益：").append(damageCalculateData.getAttackReduceList()).append("\n");
        result.append(paddingStr).append("攻击方物理伤害减益(仅物理伤害有值)：").append(damageCalculateData.getAttackPhysicReduceList()).append("\n");
        result.append(paddingStr).append("攻击方法术伤害减益(仅法术伤害有值)：").append(damageCalculateData.getAttackMagicReduceList()).append("\n");
        result.append(paddingStr).append("攻击方对防御方类型的伤害减益：").append(damageCalculateData.getAttackToDefenderReduceList()).append("\n");
        result.append(paddingStr).append("攻击方是否无视敌方402伤害降低属性：").append(damageCalculateData.isAttackIgnoreDefenderReduce()).append("\n");
        result.append(paddingStr).append("攻击方是否无视敌方物理伤害降低：").append(damageCalculateData.isAttackIgnoreDefenderPhysicReduce()).append("\n");
        result.append("\n");
        result.append(paddingStr).append("防守方受到的伤害减益(如果攻击方无视敌方402伤害降低属性，此项无值)：").append(damageCalculateData.getDefenderReduceList()).append("\n");
        result.append(paddingStr).append("防守方受到的物理伤害减益(如果攻击方无视，此项无值)：").append(damageCalculateData.getDefenderPhysicReduceList()).append("\n");
        result.append(paddingStr).append("防守方受到的法术伤害减益(仅法术伤害有值)：").append(damageCalculateData.getDefenderMagicReduceList()).append("\n");
        result.append(paddingStr).append("防守方受到的暴击伤害减益(仅暴击伤害有值)：").append(damageCalculateData.getDefenderCritReduceList()).append("\n");
        result.append(paddingStr).append("防守方受到的攻击方类型的伤害减益：").append(damageCalculateData.getDefenderToAttackerReduceList()).append("\n");
        result.append("\n");
        result.append(paddingStr).append("攻击者最终属性伤害增益：").append(damageCalculateData.getAttackAttributeParseAddList()).append("\n");
        result.append(paddingStr).append("攻击者最终属性伤害减益：").append(damageCalculateData.getAttackAttributeParseReduceList()).append("\n");
        result.append("\n");
        return result.toString();
    }

    private static String parseAllCalculateAttribute(Map<Integer, UiCalculateAttributeData> calculateAttributeDataMap, int padding) {
        if (EmptyUtil.isEmpty(calculateAttributeDataMap)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }

        List<Integer> idList = new ArrayList<>(calculateAttributeDataMap.keySet());
        Collections.sort(idList);

        StringBuilder sb = new StringBuilder();
        idList.forEach((attributeId) -> {
            sb.append(StringUtil.blankSpaceStr(padding));
            sb.append(parseCalculateAttributeSnapShot(attributeId, calculateAttributeDataMap.get(attributeId)));
            sb.append("\n");
        });
        return sb.toString();
    }

    private static String parseCalculateAttributeSnapShot(int attributeId, UiCalculateAttributeData uiCalculateAttributeData) {
        if (Objects.isNull(uiCalculateAttributeData)) {
            return "";
        }
        return "属性Id：" + attributeId + ", " + uiCalculateAttributeData.toString();
    }

    private static String parseAllAttrMap(Map<Integer, UiAttrSnapshotData> attrSnapShotMap, int padding) {
        if (EmptyUtil.isEmpty(attrSnapShotMap)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }

        StringBuilder sb = new StringBuilder();
        attrSnapShotMap.forEach((attrId, uiAttrSnapshotData) -> {
            sb.append(StringUtil.blankSpaceStr(padding));
            sb.append(parseAttrSnapShot(uiAttrSnapshotData));
            sb.append("\n");
        });
        return sb.toString();
    }

    private static String parseAttrSnapShot(UiAttrSnapshotData attrSnapshotData) {
        return "(" + "ATTR_ID：" + attrSnapshotData.getAttrTemplateId() +
                ", " + "来源:" + parseWarriorName(attrSnapshotData.getAttrSource()) +
                ", " + attrSnapshotData.getElementTypeStr() +
                ", " + attrSnapshotData.getElementId() +
                ", " + "记录次数：" + attrSnapshotData.getRecordCount() +
                ")";
    }

    private static String parseAllAttributeMap(Map<UiDataEnum.AttributeSnapshotEnum, Map<Integer, UiAttributeData>> totalMap) {
        if (EmptyUtil.isEmpty(totalMap)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }

        StringBuilder sb = new StringBuilder();
        for (UiDataEnum.AttributeSnapshotEnum snapshotEnum : UiDataEnum.AttributeSnapshotEnum.values()) {
            if (snapshotEnum == UiDataEnum.AttributeSnapshotEnum.EMPTY) {
                continue;
            }

            sb.append(StringUtil.blankSpaceStr(4)).append(snapshotEnum.getDesc()).append(",\n");
            Map<Integer, UiAttributeData> attributeMap = totalMap.get(snapshotEnum);
            if (EmptyUtil.nonEmpty(attributeMap)) {
                sb.append(parseAttributeMap(attributeMap, 8));
            }
        }
        return sb.toString();
    }

    private static String parseAttributeMap(Map<Integer, UiAttributeData> attributeDataMap, int padding) {
        StringBuilder sb = new StringBuilder();
        if (EmptyUtil.nonEmpty(attributeDataMap)) {
            for (Map.Entry<Integer, UiAttributeData> entry : attributeDataMap.entrySet()) {
                sb.append(StringUtil.blankSpaceStr(padding)).append(parseAttributeData(entry.getValue())).append(",\n");
            }
        }
        return sb.toString();
    }

    private static String parseBuffListData(List<UiBuffData> buffDataList, int padding) {
        StringBuilder sb = new StringBuilder();
        if (EmptyUtil.nonEmpty(buffDataList)) {
            for (UiBuffData uiBuffData : buffDataList) {
                sb.append(StringUtil.blankSpaceStr(padding)).append(parseBuffData(uiBuffData)).append(",\n");
            }
        }
        return sb.toString();
    }

    private static String parseMarkListData(List<UiMarkData> buffDataList, int padding) {
        StringBuilder sb = new StringBuilder();
        if (EmptyUtil.nonEmpty(buffDataList)) {
            for (UiMarkData uiMarkData : buffDataList) {
                sb.append(StringUtil.blankSpaceStr(padding)).append(parseBuffData(uiMarkData)).append(",\n");
            }
        }
        return sb.toString();
    }

    private static String parseBuffData(UiBuffData uiBuffData) {
        if (Objects.isNull(uiBuffData)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }
        return "(" + SelectEnum.BUFF.getSelectPrefix() + uiBuffData.getBuffTemplateId() +
                ", 初始回合数：" + uiBuffData.getInitRound() +
                ", 剩余回合数：" + uiBuffData.getRemainRound() +
                ", buff来源：" + parseWarriorName(uiBuffData.getSourceMark()) +
                ")";
    }

    private static String parseBuffData(UiMarkData uiMarkData) {
        if (Objects.isNull(uiMarkData)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }
        return "(" + SelectEnum.MARK.getSelectPrefix() + uiMarkData.getBuffTemplateId() +
                ", 初始回合数：" + uiMarkData.getInitRound() +
                ", 剩余回合数：" + uiMarkData.getRemainRound() +
                ", buff来源：" + parseWarriorName(uiMarkData.getSourceMark()) +
                ")";
    }

    private static String parseAttributeData(UiAttributeData uiAttributeData) {
        if (Objects.isNull(uiAttributeData)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }
        return "(" + SelectEnum.ATTRIBUTE.getSelectPrefix() + uiAttributeData.getAttributeId() +
                ", " + "属性值:" + uiAttributeData.getValueList().toString() +
                ", " + uiAttributeData.getAttributeName() +
                ", " + uiAttributeData.getAttributeDescribe() +
                ")";
    }

    private static String parseMusouData(UiMusouData uiMusouData) {
        if (Objects.isNull(uiMusouData)) {
            return FightViewConst.EMPTY_DATA_STRING;
        }
        return "(" + "樱释ID：" + uiMusouData.getMusouId() +
                ", " + "樱释状态:" + (uiMusouData.isMusouState() ? "是" : "否") +
                ", " + "樱释点：" + uiMusouData.getPoint() +
                ")";
    }

    public static String parseWarriorName(int warriorMark) {
        Map<Integer, Integer> roundLocationMap = UiFightService.getInstance().getRoundLocationByWarriorMark(warriorMark);
        if (EmptyUtil.isEmpty(roundLocationMap)) {
            return "";
        }

        WarriorFightData warriorFightData = null;
        for (Map.Entry<Integer, Integer> entry : roundLocationMap.entrySet()) {
            List<WarriorFightData> warriorFightDataList = UiFightService.getInstance().listWarriorData(entry.getKey(), entry.getValue());
            if (EmptyUtil.isEmpty(warriorFightDataList)) {
                continue;
            }

            for (WarriorFightData data : warriorFightDataList) {
                if (Objects.isNull(data)) {
                    continue;
                }

                if (data.getWarriorMark() == warriorMark) {
                    warriorFightData = data;
                }
            }
        }

        if (Objects.isNull(warriorFightData)) {
            return "";
        }

        if (warriorFightData.isAttacker()) {
            return FightViewConst.ATTACK_NAME + warriorFightData.getName();
        } else {
            return FightViewConst.DEFEND_NAME + warriorFightData.getName();
        }
    }
}
