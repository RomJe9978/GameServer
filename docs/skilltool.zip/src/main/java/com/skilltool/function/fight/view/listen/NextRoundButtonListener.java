package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ”下一回合“按钮监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 11:38
 */
public class NextRoundButtonListener implements ActionListener {

    private boolean isPulling = false;

    @Override
    public void actionPerformed(ActionEvent e) {
        if (this.isPulling) {
            return;
        }

        if (UiFightService.getInstance().isMaxRound()) {
            JOptionPane.showMessageDialog(null, "已经到最大回合！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (UiFightService.getInstance().requirePull()) {
            this.isPulling = true;
            int next = UiFightService.getInstance().getNextRequestRound();
            UiFightService.getInstance().pullServerData(next, next + UiFightService.getInstance().getPullCount(), false);
            this.isPulling = false;
        }
        UiFightService.getInstance().setNextRoundMark();

        // 更新详情信息面板
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
