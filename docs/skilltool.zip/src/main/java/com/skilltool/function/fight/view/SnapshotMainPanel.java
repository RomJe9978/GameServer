package com.skilltool.function.fight.view;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.listen.CloseSnapshotButtonListener;
import com.skilltool.function.fight.view.panel.SnapshotRetrievalPanel;
import com.skilltool.function.fight.view.panel.SnapshotTextPanel;

import javax.swing.*;
import java.awt.*;

/**
 * 快照详情的面板
 *
 * @author liuxuanjie
 * @date 2023/7/4 16:09
 */
public class SnapshotMainPanel extends JPanel {
    /**
     * 自身主面板属于哪个Viewer管理
     */
    private final SnapshotViewer snapshotViewer;

    /**
     * 快照检索面板
     */
    private final SnapshotRetrievalPanel retrievalPanel;

    /**
     * 文本面板
     */
    private final SnapshotTextPanel textPanel;

    private final JButton closeButton;

    public SnapshotMainPanel(SnapshotViewer snapshotViewer) {
        super();
        this.snapshotViewer = snapshotViewer;
        this.setLayout(new BorderLayout());

        this.retrievalPanel = new SnapshotRetrievalPanel(this);
        this.add(this.retrievalPanel, BorderLayout.NORTH);

        this.textPanel = new SnapshotTextPanel(this);
        this.add(this.textPanel, BorderLayout.CENTER);

        this.closeButton = new JButton(FightViewConst.SNAPSHOT_CLOSE_NAME);
        this.closeButton.addActionListener(new CloseSnapshotButtonListener(this.snapshotViewer));
        this.add(this.closeButton, BorderLayout.SOUTH);
    }

    public void refreshSnapshotPanel() {
        String snapshotInfo = UiFightService.getInstance().generateSnapshotInfo(getLocationMark());
        this.textPanel.refreshSnapshot(snapshotInfo);
    }

    public int getLocationMark() {
        return this.snapshotViewer.getLocationMark();
    }

    public void reset() {
        this.textPanel.reset();
    }
}
