package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;

import javax.swing.*;
import java.awt.*;

/**
 * 快照文本面板
 *
 * @author liuxuanjie
 * @date 2023/7/4 16:59
 */
public class SnapshotTextPanel extends AbstractCustomizePanel {

    private final JTextArea textArea;
    private final JScrollPane scrollPane;

    public SnapshotTextPanel(JPanel parentPanel) {
        super(parentPanel);
        this.setLayout(new GridBagLayout());

        this.textArea = new JTextArea();
        this.textArea.setEditable(false);
        this.textArea.setBackground(new Color(255, 192, 203));
        // 将文本域设置为等宽字体
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        this.textArea.setFont(font);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;

        this.scrollPane = new JScrollPane(this.textArea);
        this.add(this.scrollPane, gbc);
    }

    public void refreshSnapshot(String text) {
        this.textArea.setText(text);
    }

    public void reset() {
        this.textArea.setText("");
    }
}
