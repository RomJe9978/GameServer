package com.skilltool.function.check.view;

/**
 * @author liuxuanjie
 * @date 2023/7/14 10:13
 */
public class CheckViewConst {

    //============================== 工具栏页签 ========================================

    public final static int ADDRESS_FIELD_LENGTH = 10;

    public final static String DEFAULT_ADDRESS = "127.0.0.1:9090";

    public final static String OBTAIN_BUTTON = "获取结果";
}
