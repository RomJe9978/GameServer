package com.skilltool.function.analysis.view.listen;

import com.skilltool.data.UiDataEnum;
import com.skilltool.function.analysis.logic.UiAnalysisService;
import com.skilltool.function.analysis.view.AnalysisMainPanel;
import com.skilltool.function.analysis.view.panel.AnalysisRetrievalPanel;
import com.skilltool.utils.StringUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author liuxuanjie
 * @date 2023/7/11 11:27
 */
public class AnalysisSkillButtonListener implements ActionListener {
    /**
     * 关联的面板
     */
    private final AnalysisRetrievalPanel retrievalPanel;

    public AnalysisSkillButtonListener(AnalysisRetrievalPanel analysisRetrievalPanel) {
        this.retrievalPanel = analysisRetrievalPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        UiAnalysisService.getInstance().clear();

        String addressStr = AnalysisMainPanel.getInstance().getToolBarPanel().getInputAddress();
        UiAnalysisService.getInstance().setAddress(addressStr);

        try {
            for (UiDataEnum.AnalysisTypeEnum analysisTypeEnum : UiDataEnum.AnalysisTypeEnum.values()) {
                String inputStr = this.retrievalPanel.mapTextFieldByType(analysisTypeEnum).getText();
                if (StringUtil.isEmpty(inputStr)) {
                    continue;
                }
                int inputId = Integer.parseInt(inputStr);
                UiAnalysisService.getInstance().recordTypeInput(analysisTypeEnum, inputId);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "请输入有效的数字！", "错误", JOptionPane.ERROR_MESSAGE);
        }

        if (UiAnalysisService.getInstance().nonInputEmpty()) {
            UiAnalysisService.getInstance().gmAnalysisSkill();
        } else {
            JOptionPane.showMessageDialog(null, "请输入一个检索的信息！", "错误", JOptionPane.ERROR_MESSAGE);
        }

        AnalysisMainPanel.getInstance().refreshAll();
    }
}
