package com.skilltool.function.analysis.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.analysis.view.AnalysisMainPanel;
import com.skilltool.function.analysis.view.AnalysisViewConst;

import javax.swing.*;

/**
 * 配置验证的工具栏
 *
 * @author liuxuanjie
 * @date 2023/7/11 9:33
 */
public class AnalysisToolBarPanel extends AbstractCustomizePanel<AnalysisMainPanel> {
    /**
     * 地址文本域
     */
    private final JTextField addressField;

    public AnalysisToolBarPanel(AnalysisMainPanel parentPanel) {
        super(parentPanel);

        this.addressField = new JTextField(AnalysisViewConst.ADDRESS_FIELD_LENGTH);
        this.addressField.setText(AnalysisViewConst.DEFAULT_ADDRESS);

        this.add(this.addressField);
    }

    public String getInputAddress() {
        return this.addressField.getText();
    }
}
