package com.skilltool.function.check.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.check.logic.UiCheckService;
import com.skilltool.function.check.view.CheckMainPanel;

import javax.swing.*;
import java.awt.*;

/**
 * 检查功能的文本展示窗口
 *
 * @author liuxuanjie
 * @date 2023/7/14 10:03
 */
public class CheckTextPanel extends AbstractCustomizePanel<CheckMainPanel> {
    /**
     * 战斗详情信息文本域
     */
    private JTextArea textArea;

    /**
     * 增加滚动条
     */
    private JScrollPane scrollPane;

    public CheckTextPanel(CheckMainPanel parentPanel) {
        super(parentPanel);

        this.setLayout(new GridBagLayout());
        this.textArea = new JTextArea();
        this.textArea.setEditable(false);
        this.textArea.setBackground(new Color(255, 192, 203));
        // 将文本域设置为等宽字体
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        textArea.setFont(font);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;

        this.scrollPane = new JScrollPane(textArea);
        this.add(this.scrollPane, gbc);
    }

    public void refreshText() {
        this.textArea.setText(UiCheckService.getInstance().generateCheckText());
    }
}
