package com.skilltool.function.analysis.view;

/**
 * @author liuxuanjie
 * @date 2023/7/11 9:23
 */
public class AnalysisViewConst {

    //============================== 检索页签 ========================================

    public final static String SKILL_LABEL_TEXT = "skill_id";
    public final static int SKILL_INPUT_FIELD_SIZE = 10;

    public final static String BUFF_LABEL_TEXT = "buff_id";
    public final static int BUFF_INPUT_FIELD_SIZE = 10;

    public final static String MARK_LABEL_TEXT = "mark_id";
    public final static int MARK_INPUT_FIELD_SIZE = 10;

    public final static String MUSOU_LABEL_TEXT = "musou_id";
    public final static int MUSOU_INPUT_FIELD_SIZE = 10;

    public final static String RETRIEVAL_BUTTON = "开始分析";

    public final static String DESCRIBE_OWNER = "卡牌";
    public final static String DESCRIBE_TARGET = "TTT";

    //============================== 工具栏页签 ========================================

    public final static int ADDRESS_FIELD_LENGTH = 10;

    public final static String DEFAULT_ADDRESS = "127.0.0.1:9090";
}
