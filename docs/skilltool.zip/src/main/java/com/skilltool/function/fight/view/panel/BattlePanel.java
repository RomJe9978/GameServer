package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.GlobalConst;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.LocationEnum;
import com.skilltool.function.fight.view.listen.FightWarriorButtonListener;
import com.skilltool.utils.EmptyUtil;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Set;

/**
 * 战斗信息页面
 * <p>这里有一个位置信息：攻方位置编号是0.2.4.6.8.10，而防守方位置编号是
 * 1.3.5.7.9.11。攻击光环为{@link GlobalConst#ATTACK_HALO_LOCATION_MARK}，
 * 防守方光环为{@link GlobalConst#DEFEND_HALO_LOCATION_MARK}。
 *
 * @author liuxuanjie
 * @date 2023/6/25 10:45
 */
public class BattlePanel extends AbstractCustomizePanel {
    /**
     * 左中右三个面板布局
     */
    private final JPanel attackPanel;
    private final BattleTextPanel detailsPanel;
    private final JPanel defendPanel;

    /**
     * 攻守双方的具体战士
     */
    private final JButton[] attackerButtons;
    private final JButton[] defenderButtons;

    /**
     * 攻守双方的光环
     */
    private final JButton attackHaloButton;
    private final JButton defendHaloButton;

    public BattlePanel(JPanel parentPanel) {
        super(parentPanel);
        this.setBackground(Color.GREEN);

        // 设置网格布局
        this.setLayout(new GridBagLayout());

        this.attackPanel = new JPanel();
        this.attackPanel.setBackground(Color.GREEN);
        this.attackPanel.setLayout(new GridLayout(7, 1));
        this.add(this.attackPanel);

        this.attackerButtons = new JButton[GlobalConst.ATTACKER_POS_NUM];
        for (int i = 0, iSize = GlobalConst.ATTACKER_POS_NUM; i < iSize; i++) {
            this.attackerButtons[i] = new JButton(FightViewConst.ATTACK_NAME + (i * 2));
            this.attackerButtons[i].addMouseListener(new FightWarriorButtonListener(this, i * 2));
            this.attackPanel.add(this.attackerButtons[i]);
        }
        // 攻击方光环
        this.attackHaloButton = new JButton(FightViewConst.ATTACK_HALO_LABEL);
        this.attackHaloButton.addMouseListener(new FightWarriorButtonListener(this, GlobalConst.ATTACK_HALO_LOCATION_MARK));
        this.attackPanel.add(this.attackHaloButton);

        this.detailsPanel = new BattleTextPanel(this);
        this.detailsPanel.setBackground(Color.PINK);
        this.add(this.detailsPanel);

        this.defendPanel = new JPanel();
        this.defendPanel.setBackground(Color.GREEN);
        this.defendPanel.setLayout(new GridLayout(7, 1));
        this.add(this.defendPanel);

        this.defenderButtons = new JButton[GlobalConst.DEFENDER_POS_NUM];
        for (int i = 0, iSize = GlobalConst.DEFENDER_POS_NUM; i < iSize; i++) {
            this.defenderButtons[i] = new JButton(FightViewConst.DEFEND_NAME + (i * 2 + 1));
            this.defenderButtons[i].addMouseListener(new FightWarriorButtonListener(this, i * 2 + 1));
            this.defendPanel.add(this.defenderButtons[i]);
        }
        // 防御方光环
        this.defendHaloButton = new JButton(FightViewConst.DEFEND_HALO_LABEL);
        this.defendHaloButton.addMouseListener(new FightWarriorButtonListener(this, GlobalConst.DEFEND_HALO_LOCATION_MARK));
        this.defendPanel.add(this.defendHaloButton);

        // 设置左中右三个面板的布局
        GridBagConstraints gbc1 = new GridBagConstraints();
        gbc1.gridx = 0;
        gbc1.gridy = 0;
        gbc1.weightx = FightViewConst.FIGHT_PANEL_LEFT_PERCENT;
        gbc1.weighty = 1.0;
        gbc1.fill = GridBagConstraints.BOTH;
        this.add(attackPanel, gbc1);

        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.gridx = 1;
        gbc2.gridy = 0;
        gbc2.weightx = FightViewConst.FIGHT_PANEL_CENTER_PERCENT;
        gbc2.weighty = 1.0;
        gbc2.fill = GridBagConstraints.BOTH;
        this.add(detailsPanel, gbc2);

        GridBagConstraints gbc3 = new GridBagConstraints();
        gbc3.gridx = 2;
        gbc3.gridy = 0;
        gbc3.weightx = FightViewConst.FIGHT_PANEL_RIGHT_PERCENT;
        gbc3.weighty = 1.0;
        gbc3.fill = GridBagConstraints.BOTH;
        this.add(defendPanel, gbc3);
    }

    public void reset() {
        this.detailsPanel.reset();
    }

    /**
     * 刷新位置按钮
     */
    public void refreshLocationButton() {
        // 把所有先恢复成默认状态
        for (int i = 0, iSize = this.attackerButtons.length; i < iSize; i++) {
            this.attackerButtons[i].setBorder(BorderFactory.createLineBorder(Color.GRAY));
            setButtonText(this.attackerButtons[i], i * 2);
            this.attackerButtons[i].setBackground(FightViewConst.BUTTON_DEFAULT_BACK_GROUND);
        }
        for (int i = 0, iSize = this.defenderButtons.length; i < iSize; i++) {
            this.defenderButtons[i].setBorder(BorderFactory.createLineBorder(Color.GRAY));
            setButtonText(this.defenderButtons[i], i * 2 + 1);
            this.defenderButtons[i].setBackground(FightViewConst.BUTTON_DEFAULT_BACK_GROUND);
        }
        this.attackHaloButton.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        this.attackHaloButton.setBackground(FightViewConst.BUTTON_DEFAULT_BACK_GROUND);
        setButtonText(this.attackHaloButton, GlobalConst.ATTACK_HALO_LOCATION_MARK);
        this.defendHaloButton.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        this.defendHaloButton.setBackground(FightViewConst.BUTTON_DEFAULT_BACK_GROUND);
        setButtonText(this.defendHaloButton, GlobalConst.DEFEND_HALO_LOCATION_MARK);

        // 刷新所有位置的展示
        List<Integer> lockList = UiFightService.getInstance().getLockLocationList();
        if (EmptyUtil.nonEmpty(lockList)) {
            lockList.forEach(locationMark -> {
                JButton jButton = this.getLocationButton(locationMark);
                jButton.setBackground(LocationEnum.getColor(locationMark));
            });
        }

        // 高亮当前回合"检索"的位置
        Set<Integer> lightSet = UiFightService.getInstance().listCurRoundRetrievalLocation();
        if (EmptyUtil.nonEmpty(lightSet)) {
            lightSet.forEach(value -> this.getLocationButton(value).setBorder(BorderFactory.createLineBorder(FightViewConst.SELECT_LIGHT_COLOR, 10)));
        }
    }

    public void setButtonText(JButton jButton, int locationMark) {
        List<String> markList = UiFightService.getInstance().listCurRoundWarriorName(locationMark);
        if (EmptyUtil.isEmpty(markList)) {
            jButton.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);
            return;
        }

        if (markList.size() == 1) {
            jButton.setText(markList.get(0).toString());
        } else if (markList.size() > 1) {
            StringBuilder sb = new StringBuilder();
            sb.append("<html>");
            markList.forEach(mark -> sb.append(mark).append("<br>"));
            sb.append("</html>");
            jButton.setText(sb.toString());
        }
    }

    /**
     * 刷新详细信息面板
     */
    public void refreshDetailsPanel() {
        // 生成详细信息
        String text = UiFightService.getInstance().generateDetailInfo();
        // 检索“用户输入”信息
        UiFightService.getInstance().doSelectInput(text);
        // 检索“用户锁定”信息
        UiFightService.getInstance().doSearchLockLocationWarriorMark(text);
        // 刷新面板
        this.detailsPanel.refreshText(text);
    }

    public JButton getLocationButton(int locationMark) {
        if (locationMark == GlobalConst.ATTACK_HALO_LOCATION_MARK) {
            return this.attackHaloButton;
        } else if (locationMark == GlobalConst.DEFEND_HALO_LOCATION_MARK) {
            return this.defendHaloButton;
        } else if (locationMark % 2 == 0) {
            return this.attackerButtons[locationMark / 2];
        } else {
            return this.defenderButtons[locationMark / 2];
        }
    }
}
