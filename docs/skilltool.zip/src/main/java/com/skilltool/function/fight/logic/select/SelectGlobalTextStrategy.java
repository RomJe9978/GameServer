package com.skilltool.function.fight.logic.select;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.function.fight.view.FightTextParser;
import com.skilltool.utils.CollectionUtil;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author liuxuanjie
 * @date 2023/7/19 11:40
 */
public class SelectGlobalTextStrategy extends AbstractSelectStrategy {
    @Override
    public List<AbstractRecordUnit> selectBy(String value, WarriorFightData data) {
        if (StringUtil.isEmpty(value) || Objects.isNull(data)) {
            return null;
        }

        List<AbstractRecordUnit> allUnit = data.listAllRecordUnit();
        if (EmptyUtil.isEmpty(allUnit)) {
            return null;
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (AbstractRecordUnit abstractRecordUnit : allUnit) {
            String text = FightTextParser.parseRecordUnit(abstractRecordUnit, 0, Integer.MAX_VALUE);
            if (Objects.isNull(text)) {
                continue;
            }

            if (text.contains(value)) {
                CollectionUtil.addUnique(resultList, abstractRecordUnit);
            }
        }
        return resultList;
    }
}
