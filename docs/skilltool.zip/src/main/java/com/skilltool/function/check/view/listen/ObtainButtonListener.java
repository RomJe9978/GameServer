package com.skilltool.function.check.view.listen;

import com.skilltool.function.check.logic.UiCheckService;
import com.skilltool.function.check.view.CheckMainPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author liuxuanjie
 * @date 2023/7/14 10:46
 */
public class ObtainButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        UiCheckService.getInstance().clear();

        // todo:解析地址
        String address = CheckMainPanel.getInstance().getToolBarPanel().getInputAddress();
        UiCheckService.getInstance().setAddress(address);

        // 获取数据
        boolean result = UiCheckService.getInstance().obtainCheckResult();

        // 刷新面板即可
        CheckMainPanel.getInstance().refreshAll();
    }
}
