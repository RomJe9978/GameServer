package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.LocationEnum;
import com.skilltool.function.fight.view.SnapshotViewer;
import com.skilltool.function.fight.view.panel.BattlePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.Objects;

/**
 * 战斗中的“warrior”监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 14:37
 */
public class FightWarriorButtonListener implements MouseListener {
    private final BattlePanel battlePanel;

    /**
     * 快照窗口
     */
    private SnapshotViewer snapshotViewer;

    /**
     * 当前监听器监听的是哪一个位置
     */
    private int locationMark;

    public FightWarriorButtonListener(BattlePanel battlePanel, int locationMark) {
        this.battlePanel = battlePanel;
        this.locationMark = locationMark;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("mouseClicked");
        if (e.getButton() == MouseEvent.BUTTON1) {
            this.onClickLeftMouse();
        } else if (e.getButton() == MouseEvent.BUTTON3) {
            this.onClickRightMouse();
        }
    }

    private void onClickLeftMouse() {
        System.out.println("onClickLeftMouse");
        List<Integer> lockLocationList = UiFightService.getInstance().getLockLocationList();
        if (lockLocationList.contains(this.locationMark)) {
            lockLocationList.remove(Integer.valueOf(this.locationMark));
        } else {
            lockLocationList.add(this.locationMark);
        }

        // 更新详情信息面板
        System.out.println("点击左键，准备更新");
        FightMainPanel.getInstance().refreshBattlePanel();
    }

    private void onClickRightMouse() {
        if (Objects.isNull(this.snapshotViewer)) {
            this.snapshotViewer = new SnapshotViewer(this.locationMark);
        }

        JButton jButton = this.battlePanel.getLocationButton(this.locationMark);
        Point buttonLocationOnScreen = jButton.getLocationOnScreen();
        int x = buttonLocationOnScreen.x;
        int y = buttonLocationOnScreen.y;
        if (LocationEnum.isAttackLocation(this.locationMark)) {
            x += (jButton.getWidth() + 10);
        } else {
            x -= (FightViewConst.SNAPSHOT_VIEW_WIDTH + 10);
        }

        // 刷新信息
        this.snapshotViewer.setLocation(x, y);
        this.snapshotViewer.getSnapshotMainPanel().refreshSnapshotPanel();
        this.snapshotViewer.open();
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
//        System.out.println("mouseEntered");
    }

    @Override
    public void mouseExited(MouseEvent e) {
//        System.out.println("mouseExited");
    }
}
