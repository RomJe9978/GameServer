package com.skilltool.function.fight.logic.select;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.data.UiAttrEffectUnit;
import com.skilltool.data.UiDataEnum;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 检索Attr的方式
 *
 * @author liuxuanjie
 * @date 2023/6/27 16:40
 */
public class SelectAttrStrategy extends AbstractSelectStrategy {

    @Override
    public List<AbstractRecordUnit> selectBy(String value, WarriorFightData data) {
        if (StringUtil.isEmpty(value) || Objects.isNull(data)) {
            return null;
        }

        List<AbstractRecordUnit> recordUnitList = data.listRecordUnitBy(UiDataEnum.RecordEnum.ATTR);
        if (Objects.isNull(recordUnitList) || recordUnitList.isEmpty()) {
            return null;
        }

        int number = 0;
        try {
            number = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (AbstractRecordUnit recordUnit : recordUnitList) {
            if (Objects.isNull(recordUnit)) {
                continue;
            }

            UiAttrEffectUnit attrUnit = (UiAttrEffectUnit) recordUnit;
            if (attrUnit.getAttrTemplateId() == number) {
                resultList.add(attrUnit);
            }
        }
        return resultList;
    }
}
