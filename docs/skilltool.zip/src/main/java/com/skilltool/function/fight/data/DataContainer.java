package com.skilltool.function.fight.data;

import lombok.Getter;
import lombok.Setter;

import java.util.*;

/**
 * 视图所依赖的容器数据
 *
 * @author liuxuanjie
 * @date 2023/6/25 14:22
 */
public class DataContainer {
    /**
     * 所有回合的数据
     * 数组下标从0开始，对应的回合数为数组下标
     * <p>特例：下标0表示"战斗开始后，第一回合开始前的数据"
     */
    @Getter
    private final List<RoundData> roundDataList = new ArrayList<>();

    /**
     * 一个warriorMark在所有回合中的所有位置标识
     * key:战士数据，value:{回合标识：位置标识}
     */
    @Getter
    private final Map<Integer, Map<Integer, Integer>> warriorMarkMap = new HashMap<>();

    /**
     * 战斗备注
     */
    @Getter
    @Setter
    private String fightNotes;

    public DataContainer() {
    }

    public void addRoundData(RoundData roundData) {
        this.roundDataList.add(roundData);
    }

    public void clear() {
        this.roundDataList.clear();
        this.warriorMarkMap.clear();
    }

    public RoundData getRoundData(int roundMark) {
        return roundMark < 0 || roundMark > this.getMaxRound()
                ? null : this.roundDataList.get(roundMark);
    }

    public int getMaxRound() {
        return this.roundDataList.size() - 1;
    }

    public void recordWarriorLocation(int warriorMark, int roundMark, int locationMark) {
        Map<Integer, Integer> roundLocationMap = this.warriorMarkMap.get(warriorMark);
        if (Objects.isNull(roundLocationMap)) {
            roundLocationMap = new HashMap<>(32);
            this.warriorMarkMap.put(warriorMark, roundLocationMap);
        }
        roundLocationMap.put(roundMark, locationMark);
    }

    public List<WarriorFightData> listWarriorDataBy(int roundMark, int location) {
        RoundData roundData = this.getRoundData(roundMark);
        if (Objects.isNull(roundData)) {
            return null;
        }
        return roundData.listWarriorDataBy(location);
    }

    @Override
    public String toString() {
        return "DataContainer{" +
                "roundDataList=" + roundDataList +
                '}';
    }
}
