package com.skilltool.function.gm;

import lombok.Getter;

/**
 * @author RomJe
 */
@Getter
public enum GmSwitchEnum {
    USE_TOOL(0, "是否使用战斗工具", "/gm_battle_debug_tool"),
    RECORD_DAMAGE(1, "是否记录伤害计算过程", "/gm_battle_debug_tool_damage"),
    ;

    private int type;
    private String describe;
    private String url;

    GmSwitchEnum(int type, String describe, String url) {
        this.type = type;
        this.describe = describe;
        this.url = url;
    }
}
