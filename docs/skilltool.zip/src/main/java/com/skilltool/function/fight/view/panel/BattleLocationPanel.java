package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.listen.FightWarriorButtonListener;
import com.skilltool.utils.EmptyUtil;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * 一个具体战斗位置的面板
 *
 * @author liuxuanjie
 * @date 2023/7/6 14:53
 */
public class BattleLocationPanel extends AbstractCustomizePanel<BattlePanel> {
    /**
     * 关联的位置
     */
    private final int locationMark;

    private final JButton firstButton;
    private final JButton replaceButton;

    public BattleLocationPanel(BattlePanel parentPanel, int locationMark) {
        super(parentPanel);
        this.locationMark = locationMark;
        this.setLayout(new BorderLayout());

        this.firstButton = new JButton();
        this.firstButton.addMouseListener(new FightWarriorButtonListener(parentPanel, locationMark));
        this.add(this.firstButton, BorderLayout.CENTER);

        this.replaceButton = new JButton();
        this.replaceButton.addMouseListener(new FightWarriorButtonListener(parentPanel, locationMark));
        this.add(this.replaceButton, BorderLayout.EAST);
    }

    public void refresh() {
        List<Integer> warriorMarkList = UiFightService.getInstance().listCurRoundWarriorMarkBy(this.locationMark);
        if (EmptyUtil.isEmpty(warriorMarkList)) {
            this.firstButton.setBackground(Color.BLACK);
            this.add(this.firstButton, BorderLayout.CENTER);
            this.remove(this.replaceButton);
        } else if (warriorMarkList.size() == 1) {
            this.add(this.firstButton, BorderLayout.CENTER);
            this.remove(this.replaceButton);
        } else if (warriorMarkList.size() == 2) {
            this.add(this.firstButton, BorderLayout.CENTER);
            this.add(this.replaceButton, BorderLayout.EAST);
        }

        this.repaint();
    }
}
