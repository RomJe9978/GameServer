package com.skilltool.function.fight.data;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.data.UiDataEnum;
import com.skilltool.data.UiWarriorSnapshotData;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.function.fight.view.FightTextParser;
import com.skilltool.function.fight.view.LocationEnum;
import com.skilltool.utils.CollectionUtil;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.StringUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

/**
 * warrior战斗标识的数据
 *
 * @author liuxuanjie
 * @date 2023/6/25 17:37
 */
public class WarriorFightData {
    /**
     * 来自Server的唯一标识
     */
    @Getter
    private int warriorMark;

    /**
     * 所在位置标识
     */
    @Getter
    private int locationMark;

    /**
     * 卡牌展示的名称
     */
    @Getter
    @Setter
    private String name;

    /**
     * 所有类型的所有记录
     * key：记录类型，value：{key：记录id，value：记录的数据}
     * <p>如有新的类型添加，需要在{@link FightTextParser#parseRecordUnit(AbstractRecordUnit, int, int)}
     * 中添加对应的“文本解析方式”，由于此处变化不大，且类型有限，所有未考虑较繁琐的“策略模式”
     */
    @Getter
    @Setter
    private Map<UiDataEnum.RecordEnum, Map<Integer, AbstractRecordUnit>> recordMap;

    /**
     * 快照数据
     */
    @Getter
    @Setter
    private Map<Integer, UiWarriorSnapshotData> uiWarriorSnapshotDataMap;

    public WarriorFightData(int warriorMark, int locationMark) {
        this.warriorMark = warriorMark;
        this.locationMark = locationMark;
    }

    /**
     * 是否是"攻击方"阵营
     */
    public boolean isAttacker() {
        return LocationEnum.isAttackLocation(this.locationMark);
    }

    public List<AbstractRecordUnit> select() {
        Map<SelectEnum, String> selectMap = UiFightService.getInstance().getInputSelectEnumMap();
        if (Objects.isNull(selectMap) || selectMap.isEmpty()) {
            return null;
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (Map.Entry<SelectEnum, String> entry : selectMap.entrySet()) {
            if (StringUtil.isEmpty(entry.getValue())) {
                continue;
            }
            List<AbstractRecordUnit> curSelectList = entry.getKey().getSelectStrategy().selectBy(entry.getValue(), this);
            if (EmptyUtil.nonEmpty(curSelectList)) {
                CollectionUtil.addUnique(resultList, curSelectList);
            }
        }
        return resultList;
    }

    public List<AbstractRecordUnit> listRecordUnitBy(UiDataEnum.RecordEnum recordEnum) {
        if (Objects.isNull(recordMap) || recordMap.isEmpty()) {
            return null;
        }

        Map<Integer, AbstractRecordUnit> recordUnitMap = this.recordMap.get(recordEnum);
        if (Objects.isNull(recordUnitMap) || recordUnitMap.isEmpty()) {
            return null;
        }

        List<AbstractRecordUnit> result = new ArrayList<>();
        for (Map.Entry<Integer, AbstractRecordUnit> recordUnitEntry : recordUnitMap.entrySet()) {
            AbstractRecordUnit recordUnit = recordUnitEntry.getValue();
            if (Objects.isNull(recordUnit)) {
                continue;
            }
            result.add(recordUnit);
        }
        return result;
    }

    public AbstractRecordUnit getRecordBySequence(int sequence) {
        if (Objects.isNull(recordMap) || recordMap.isEmpty()) {
            return null;
        }

        for (Map.Entry<UiDataEnum.RecordEnum, Map<Integer, AbstractRecordUnit>> recordEntry : recordMap.entrySet()) {
            Map<Integer, AbstractRecordUnit> recordUnitMap = recordEntry.getValue();
            if (Objects.isNull(recordUnitMap) || recordUnitMap.isEmpty()) {
                continue;
            }

            AbstractRecordUnit recordUnit = recordUnitMap.get(sequence);
            if (Objects.nonNull(recordUnit)) {
                return recordUnit;
            }
        }
        return null;
    }

    /**
     * 列出所有的“记录单元”
     */
    public List<AbstractRecordUnit> listAllRecordUnit() {
        if (EmptyUtil.isEmpty(this.recordMap)) {
            return Collections.emptyList();
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (Map.Entry<UiDataEnum.RecordEnum, Map<Integer, AbstractRecordUnit>> entry : recordMap.entrySet()) {
            Map<Integer, AbstractRecordUnit> recordUnitMap = entry.getValue();
            if (EmptyUtil.nonEmpty(recordUnitMap)) {
                resultList.addAll(recordUnitMap.values());
            }
        }
        return resultList;
    }

    @Override
    public String toString() {
        return "WarriorFightData{" +
                "warriorMark=" + warriorMark +
                ", locationMark=" + locationMark +
                '}';
    }
}
