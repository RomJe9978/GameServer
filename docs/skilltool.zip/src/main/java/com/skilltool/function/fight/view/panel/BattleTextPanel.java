package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.function.fight.view.FightMainPanel;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.LocationEnum;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 战斗详情信息文本面板
 *
 * @author liuxuanjie
 * @date 2023/6/25 16:23
 */
public class BattleTextPanel extends AbstractCustomizePanel {
    private final DefaultHighlighter.DefaultHighlightPainter painter;

    /**
     * 战斗详情信息文本域
     */
    private JTextArea textArea;

    /**
     * 增加滚动条
     */
    private JScrollPane scrollPane;

    public BattleTextPanel(JPanel parentPanel) {
        super(parentPanel);
        this.painter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);

        this.setLayout(new GridBagLayout());
        this.textArea = new JTextArea();
        this.textArea.setEditable(false);
        this.textArea.setBackground(new Color(255, 192, 203));
        // 将文本域设置为等宽字体
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        textArea.setFont(font);
        // 让自身监听缩放事件
        this.textArea.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                SwingUtilities.invokeLater(() -> {
                    super.componentResized(e);
                    // 注意“像素”和“字符”的转换
                    int lineCharsCount = (e.getComponent().getWidth()) / 8 + 4;
                    UiFightService.getInstance().setFightAreaLineSize(lineCharsCount);
                    FightMainPanel.getInstance().refreshBattlePanel();
                });
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;

        this.scrollPane = new JScrollPane(textArea);
        this.add(this.scrollPane, gbc);
    }

    public void reset() {
        // 重置一下，每行最大字符数
        int lineCharsCount = (this.getWidth()) / 8 + 4;
        UiFightService.getInstance().setFightAreaLineSize(lineCharsCount);
    }

    public void refreshText(String text) {
        if (Objects.isNull(text)) {
            this.textArea.setText(FightViewConst.DEFAULT_DETAILS_WARN);
            return;
        }

        // 默认从文本开始展示内容
        this.textArea.setText(text);

        // 移除之前的所有高亮显示
        Highlighter highlighter = this.textArea.getHighlighter();
        highlighter.removeAllHighlights();

        // 检索用户输入，展示高亮(记录第一个检索的位置，用于后续锁定位置)
        int firstIndex = -1;
        Map<SelectEnum, List<Integer>> lightMap = UiFightService.getInstance().getRetrievalInputTextMap();
        for (Map.Entry<SelectEnum, List<Integer>> entry : lightMap.entrySet()) {
            List<Integer> indexList = entry.getValue();
            if (Objects.isNull(indexList) || indexList.isEmpty()) {
                continue;
            }

            if (indexList.size() % 2 != 0) {
                continue;
            }

            for (int i = 0, iSize = indexList.size(); i < iSize; i++) {
                int start = indexList.get(i);
                firstIndex = firstIndex <= 0 ? start : Math.min(firstIndex, start);

                i++;
                int end = indexList.get(i);

                try {
                    highlighter.addHighlight(start, end, painter);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // 检索锁定位置，展示高亮
        Map<Integer, List<Integer>> lockMap = UiFightService.getInstance().getSelectLockLocationWarriorMarkMap();
        for (Map.Entry<Integer, List<Integer>> entry : lockMap.entrySet()) {
            List<Integer> indexList = entry.getValue();
            if (Objects.isNull(indexList) || indexList.isEmpty()) {
                continue;
            }

            if (indexList.size() % 2 != 0) {
                continue;
            }

            for (int i = 0, iSize = indexList.size(); i < iSize; i++) {
                int start = indexList.get(i);
                i++;
                int end = indexList.get(i);

                try {
                    highlighter.addHighlight(start, end, new DefaultHighlighter.DefaultHighlightPainter(LocationEnum.getColor(entry.getKey())));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // 使用 invokeLater 延迟滚动条位置的调整
        int finalFirstIndex = firstIndex;
        SwingUtilities.invokeLater(() -> {
            JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
            if (finalFirstIndex > 0) {
                try {
                    Rectangle rect = textArea.modelToView(finalFirstIndex);
                    int startY = rect.y;
                    verticalScrollBar.setValue(startY);
                    verticalScrollBar.setValueIsAdjusting(true);
                } catch (BadLocationException e) {
                    e.printStackTrace();
                }
            } else {
                verticalScrollBar.setValue(verticalScrollBar.getMinimum());
            }
        });
    }

}
