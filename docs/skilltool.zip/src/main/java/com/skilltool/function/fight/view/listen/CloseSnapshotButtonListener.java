package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.view.SnapshotViewer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 关闭快照按钮的监听器
 *
 * @author liuxuanjie
 * @date 2023/7/4 16:49
 */
public class CloseSnapshotButtonListener implements ActionListener {
    /**
     * 关联的“viewer”
     */
    private final SnapshotViewer snapshotViewer;

    public CloseSnapshotButtonListener(SnapshotViewer snapshotViewer) {
        this.snapshotViewer = snapshotViewer;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("关闭快照按钮被点击了！");
        // todo:后续做一些清理工作
        this.snapshotViewer.close();
    }
}
