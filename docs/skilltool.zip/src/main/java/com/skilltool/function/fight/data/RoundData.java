package com.skilltool.function.fight.data;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.utils.EmptyUtil;
import lombok.Getter;

import java.util.*;

/**
 * 每一回合的数据
 *
 * @author liuxuanjie
 * @date 2023/6/25 14:22
 */
public class RoundData {
    /**
     * 回合标识，从1开始
     */
    @Getter
    private int roundMark;

    /**
     * 该回合下的所有位置数据
     * key：位置的一个唯一标识，value：位置数据
     */
    private Map<Integer, LocationData> locationDataMap = new HashMap<>(16);

    public static RoundData createInstance(int roundMark) {
        return new RoundData(roundMark);
    }

    /**
     * 用于{@link #listAllData()}方法的缓存
     * 注意，回合数据一旦创建，就不会再变化，所以这里可以使用缓存
     */
    private List<WarriorFightData> allWarriorDataCache = new ArrayList<>(16);

    public RoundData(int roundMark) {
        this.roundMark = roundMark;
    }

    /**
     * 根据位置标识获取对应的warrior数据列表
     *
     * @return 位置不合法的时候，返回<code>null</code>
     */
    public List<WarriorFightData> listWarriorDataBy(int locationMark) {
        LocationData locationData = this.locationDataMap.get(locationMark);
        if (Objects.isNull(locationData)) {
            return null;
        }
        return locationData.listAllWarriorData();
    }

    /**
     * @return 返回内部缓存，只读，不可写
     */
    public List<WarriorFightData> listAllData() {
        if (EmptyUtil.isEmpty(this.locationDataMap)) {
            return null;
        }

        // 如果缓存不为空，直接返回，不需要重新计算
        if (EmptyUtil.nonEmpty(this.allWarriorDataCache)) {
            return this.allWarriorDataCache;
        }

        // 首次获取时计算
        this.locationDataMap.forEach((locationMark, locationData) -> {
            List<WarriorFightData> tempList = locationData.listAllWarriorData();
            if (EmptyUtil.nonEmpty(tempList)) {
                this.allWarriorDataCache.addAll(tempList);
            }
        });
        return this.allWarriorDataCache;
    }

    /**
     * 给当前位置增添数据
     */
    public void offerWarriorData(WarriorFightData warriorFightData) {
        if (Objects.isNull(warriorFightData)) {
            return;
        }

        int location = warriorFightData.getLocationMark();
        LocationData locationData = this.locationDataMap.get(location);
        if (Objects.isNull(locationData)) {
            locationData = LocationData.createInstance(location);
            this.locationDataMap.put(location, locationData);
        }

        locationData.addWarriorData(warriorFightData);

        // 多记录一个映射关系
        UiFightService.getInstance().recordWarriorLocation(warriorFightData.getWarriorMark(), this.roundMark, location);
    }
}
