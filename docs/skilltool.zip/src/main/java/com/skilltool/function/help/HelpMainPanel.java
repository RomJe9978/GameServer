package com.skilltool.function.help;

import com.skilltool.function.help.panel.HelpDefinePanel;
import com.skilltool.function.help.panel.HelpUsedPanel;
import com.skilltool.function.help.panel.listen.HelpDefineButtonListener;
import com.skilltool.function.help.panel.listen.HelpUsedButtonListener;

import javax.swing.*;
import java.awt.*;

/**
 * “帮助”页签的主界面
 *
 * @author liuxuanjie
 * @date 2023/7/20 17:05
 */
public class HelpMainPanel extends JPanel {
    private final static HelpMainPanel INSTANCE = new HelpMainPanel();

    /**
     * 模拟菜单栏
     */
    private final CardLayout cardLayout;
    private final JPanel cardsPanel;
    private final JPanel menuPanel;

    /**
     * 使用说明面板
     */
    private final HelpUsedPanel helpUsedPanel;

    /**
     * 名词解释面板
     */
    private final HelpDefinePanel helpDefinePanel;

    private HelpMainPanel() {
        super();
        this.cardLayout = new CardLayout();
        setLayout(new BorderLayout());

        // 创建菜单面板
        this.menuPanel = new JPanel();
        JButton button1 = new JButton(HelpViewConst.OPERATION_INSTRUCTIONS);
        button1.addActionListener(new HelpUsedButtonListener());
        JButton button2 = new JButton(HelpViewConst.DEFINITION_INSTRUCTIONS);
        button2.addActionListener(new HelpDefineButtonListener());
        this.menuPanel.add(button1);
        this.menuPanel.add(button2);

        // 创建卡片面板
        this.cardsPanel = new JPanel(this.cardLayout);
        this.helpUsedPanel = new HelpUsedPanel(this);
        this.helpDefinePanel = new HelpDefinePanel(this);
        this.cardsPanel.add(this.helpUsedPanel, HelpViewConst.OPERATION_INSTRUCTIONS);
        this.cardsPanel.add(this.helpDefinePanel, HelpViewConst.DEFINITION_INSTRUCTIONS);

        this.add(this.menuPanel, BorderLayout.NORTH);
        this.add(this.cardsPanel, BorderLayout.CENTER);
    }

    public void refreshOperationPanel() {
        this.helpUsedPanel.refreshText();
        this.cardLayout.show(this.cardsPanel, HelpViewConst.OPERATION_INSTRUCTIONS);
    }

    public void refreshDefinePanel() {
        this.helpDefinePanel.refreshText();
        this.cardLayout.show(this.cardsPanel, HelpViewConst.DEFINITION_INSTRUCTIONS);
    }

    public static HelpMainPanel getInstance() {
        return INSTANCE;
    }
}
