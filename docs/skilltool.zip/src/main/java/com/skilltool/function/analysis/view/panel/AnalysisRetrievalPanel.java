package com.skilltool.function.analysis.view.panel;

import com.skilltool.data.UiDataEnum;
import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.analysis.view.AnalysisMainPanel;
import com.skilltool.function.analysis.view.AnalysisViewConst;
import com.skilltool.function.analysis.view.listen.AnalysisSkillButtonListener;
import lombok.Getter;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * “配置验证”功能的检索panel
 *
 * @author liuxuanjie
 * @date 2023/7/11 9:19
 */
public class AnalysisRetrievalPanel extends AbstractCustomizePanel<AnalysisMainPanel> {

    private final Map<UiDataEnum.AnalysisTypeEnum, JLabel> labelMap;
    @Getter
    private final Map<UiDataEnum.AnalysisTypeEnum, JTextField> textFieldMap;
    private final JButton retrievalButton;

    public AnalysisRetrievalPanel(AnalysisMainPanel parentPanel) {
        super(parentPanel);
        this.setLayout(new FlowLayout());

        this.labelMap = new HashMap<>();
        this.textFieldMap = new HashMap<>();
        for (UiDataEnum.AnalysisTypeEnum analysisTypeEnum : UiDataEnum.AnalysisTypeEnum.values()) {
            JLabel label = new JLabel(analysisTypeEnum.getMarkStr());
            JTextField textField = new JTextField(10);
            this.labelMap.put(analysisTypeEnum, label);
            this.textFieldMap.put(analysisTypeEnum, textField);

            this.add(label);
            this.add(textField);
        }

        this.retrievalButton = new JButton(AnalysisViewConst.RETRIEVAL_BUTTON);
        this.retrievalButton.addActionListener(new AnalysisSkillButtonListener(this));
        this.add(this.retrievalButton);
    }
    
    public JTextField mapTextFieldByType(UiDataEnum.AnalysisTypeEnum analysisTypeEnum) {
        if (Objects.isNull(analysisTypeEnum)) {
            return null;
        }
        return this.textFieldMap.get(analysisTypeEnum);
    }
}
