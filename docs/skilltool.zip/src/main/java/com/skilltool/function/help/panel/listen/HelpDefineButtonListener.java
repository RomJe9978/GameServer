package com.skilltool.function.help.panel.listen;

import com.skilltool.function.help.HelpMainPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author liuxuanjie
 * @date 2023/7/20 17:57
 */
public class HelpDefineButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        HelpMainPanel.getInstance().refreshDefinePanel();
    }
}
