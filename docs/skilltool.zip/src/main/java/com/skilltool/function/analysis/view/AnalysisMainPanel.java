package com.skilltool.function.analysis.view;

import com.skilltool.function.analysis.view.panel.AnalysisRetrievalPanel;
import com.skilltool.function.analysis.view.panel.AnalysisTextPanel;
import com.skilltool.function.analysis.view.panel.AnalysisToolBarPanel;
import lombok.Getter;

import javax.swing.*;
import java.awt.*;

/**
 * “配置验证”主界面
 *
 * @author liuxuanjie
 * @date 2023/7/10 16:03
 */
public class AnalysisMainPanel extends JPanel {
    /**
     * “检索输入”
     */
    private final AnalysisRetrievalPanel retrievalPanel;

    /**
     * “文本展示”
     */
    private final AnalysisTextPanel textPanel;

    /**
     * “工具栏”
     */
    @Getter
    private final AnalysisToolBarPanel toolBarPanel;

    private final static AnalysisMainPanel INSTANCE = new AnalysisMainPanel();

    private AnalysisMainPanel() {
        super();
        this.setLayout(new BorderLayout());

        this.retrievalPanel = new AnalysisRetrievalPanel(this);
        this.add(this.retrievalPanel, BorderLayout.NORTH);

        this.textPanel = new AnalysisTextPanel(this);
        this.add(this.textPanel, BorderLayout.CENTER);

        this.toolBarPanel = new AnalysisToolBarPanel(this);
        this.add(this.toolBarPanel, BorderLayout.SOUTH);
    }

    public static AnalysisMainPanel getInstance() {
        return INSTANCE;
    }

    public void refreshAll() {
        SwingUtilities.invokeLater(this.textPanel::refreshText);
    }
}
