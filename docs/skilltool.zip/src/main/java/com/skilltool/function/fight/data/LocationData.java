package com.skilltool.function.fight.data;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 每一个“位置数据”的抽象
 *
 * @author liuxuanjie
 * @date 2023/7/5 20:29
 */
public class LocationData {
    /**
     * 位置唯一标识
     */
    private final int locationMark;

    /**
     * 该位置”首个“战士数据
     */
    @Getter
    @Setter
    private WarriorFightData firstWarriorData;

    /**
     * 该位置”替补“战士数据
     * 只有"替补"真正“替换上场”才会有该数据
     */
    @Getter
    @Setter
    private WarriorFightData replaceWarriorData;

    public LocationData(int locationMark) {
        this.locationMark = locationMark;
    }

    public static LocationData createInstance(int locationMark) {
        return new LocationData(locationMark);
    }

    /**
     * 获取该位置的所有战士数据
     */
    public List<WarriorFightData> listAllWarriorData() {
        if (Objects.nonNull(this.firstWarriorData)) {
            List<WarriorFightData> resultList = new ArrayList<>();
            resultList.add(this.firstWarriorData);

            if (Objects.nonNull(this.replaceWarriorData)) {
                resultList.add(this.replaceWarriorData);
            }
            return resultList;
        }
        return null;
    }

    /**
     * 给当前位置添加战士数据
     */
    public void addWarriorData(WarriorFightData warriorFightData) {
        if (Objects.isNull(warriorFightData)) {
            return;
        }

        // 优先设置首个战士数据
        if (Objects.isNull(this.firstWarriorData)) {
            this.firstWarriorData = warriorFightData;
        } else if (Objects.isNull(this.replaceWarriorData)) {
            this.replaceWarriorData = warriorFightData;
        } else {
            throw new RuntimeException("该位置已经有两个战士了，无法再添加");
        }
    }
}
