package com.skilltool.function.check.logic;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.skilltool.data.UiCheckResult;
import com.skilltool.function.GlobalConst;
import com.skilltool.function.check.view.CheckResultParser;
import com.skilltool.utils.HttpUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

/**
 * "配置检测"功能的“逻辑服务”
 *
 * @author liuxuanjie
 * @date 2023/7/14 10:17
 */
public class UiCheckService {
    /**
     * 获取“检测结果”的地址
     */
    @Setter
    private String address;

    /**
     * 服务器拉取的结果
     */
    @Getter
    private UiCheckResult uiCheckResult;

    private final static UiCheckService INSTANCE = new UiCheckService();

    private UiCheckService() {
    }

    public void clear() {
        this.address = null;
        this.uiCheckResult = null;
    }

    public static UiCheckService getInstance() {
        return INSTANCE;
    }

    public boolean obtainCheckResult() {
        String serverUrl = GlobalConst.HTTP_PREFIX + this.address + GlobalConst.HTTP_API_URL_CHECK;
        String respondData = HttpUtil.sendGetData(serverUrl, null);
        if (Objects.isNull(respondData)) {
            return false;
        }

        JSONObject pullData = JSON.parseObject(respondData);
        String jsonData = pullData.getString(GlobalConst.CHECK_RESPONSE_KEY);
        this.uiCheckResult = JSON.parseObject(jsonData, UiCheckResult.class);
        System.out.println(this.uiCheckResult);
        return false;
    }

    /**
     * 生成“检测”的文本结果
     */
    public String generateCheckText() {
        return CheckResultParser.parseCheckResult(this.uiCheckResult, 20);
    }
}
