package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.listen.*;

import javax.swing.*;
import java.awt.*;

/**
 * @author liuxuanjie
 * @date 2023/6/25 10:48
 */
public class BattleToolBarPanel extends AbstractCustomizePanel {
    private final JTextField roundTextField;

    private final JTextField pullCountFiled;

    private final JButton startButton;
    private final JButton showAttrTimingButton;

    private final JButton lastRoundButton;
    private final JButton nextRoundButton;
    private final JButton jumpRoundButton;

    public BattleToolBarPanel(JPanel parentPanel) {
        super(parentPanel);

        JTextField addressText = new JTextField(FightViewConst.TOOL_BAR_ADDRESS_TEXT_LENGTH);
        addressText.setText(FightViewConst.TOOL_BAR_DEFAULT_ADDRESS);
        this.roundTextField = new JTextField(FightViewConst.TOOL_BAR_JUMP_TEXT_LENGTH);

        this.pullCountFiled = new JTextField(FightViewConst.TOOL_BAR_PULL_COUNT_LENGTH);
        this.pullCountFiled.setText(FightViewConst.TOOL_BAR_DEFAULT_PULL_COUNT);

        this.startButton = new JButton(FightViewConst.TOOL_BAR_START);
        this.startButton.addActionListener(new StartButtonListener(addressText, pullCountFiled));
        this.lastRoundButton = new JButton(FightViewConst.TOOL_BAR_LAST_ROUND);
        this.lastRoundButton.addActionListener(new LastRoundButtonListener());
        this.nextRoundButton = new JButton(FightViewConst.TOOL_BAR_NEXT_ROUND);
        this.nextRoundButton.addActionListener(new NextRoundButtonListener());
        this.jumpRoundButton = new JButton(FightViewConst.TOOL_BAR_JUMP_STEP);
        this.jumpRoundButton.addActionListener(new JumpRoundButtonListener(this.roundTextField));

        // 设置一下按钮的布局
        this.setLayout(new BorderLayout());

        JPanel leftPanel = new JPanel();
        leftPanel.add(addressText);
        leftPanel.add(this.pullCountFiled);
        leftPanel.add(this.startButton);
        this.showAttrTimingButton = new JButton(FightViewConst.TOOL_BAR_SHOW_ATTR_TIMING_BUTTON);
        this.showAttrTimingButton.addActionListener(new ShowAttrTimingButtonListener());
        leftPanel.add(showAttrTimingButton);
        this.add(leftPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel();
        rightPanel.add(this.lastRoundButton);
        rightPanel.add(this.nextRoundButton);
        this.add(rightPanel, BorderLayout.CENTER);

        JPanel centerPanel = new JPanel();
        centerPanel.add(new JLabel(FightViewConst.TOOL_BAR_ROUND_LABEL));
        centerPanel.add(this.roundTextField);
        centerPanel.add(this.jumpRoundButton);
        this.add(centerPanel, BorderLayout.EAST);
    }

    public void refreshRoundText() {
        int roundMark = UiFightService.getInstance().getCurRound();
        this.roundTextField.setText(String.valueOf(roundMark));
    }
}
