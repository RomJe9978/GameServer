package com.skilltool.function;

import com.skilltool.function.analysis.view.AnalysisMainPanel;
import com.skilltool.function.check.view.CheckMainPanel;
import com.skilltool.function.fight.view.FightMainPanel;
import com.skilltool.function.gm.GmMainPanel;
import com.skilltool.function.help.HelpMainPanel;
import lombok.Getter;

import javax.swing.*;

/**
 * 后台调试工具的整个战斗的主窗口
 *
 * @author liuxuanjie
 * @date 2023/6/25 9:50
 */
public class MainViewer {
    @Getter
    private JFrame mainFrame;

    private JTabbedPane tabbedPane;

    private final static MainViewer INSTANCE = new MainViewer();

    private MainViewer() {
        super();
    }

    public static MainViewer getInstance() {
        return INSTANCE;
    }

    private void initialize() {
        // 构造主窗口
        this.mainFrame = new JFrame(GlobalConst.MAIN_VIEW_TITLE);
        this.mainFrame.setLocation(GlobalConst.MAIN_FRAME_LOCATION_X, GlobalConst.MAIN_FRAME_LOCATION_Y);
        this.mainFrame.setSize(GlobalConst.MAIN_FRAME_WIDTH, GlobalConst.MAIN_FRAME_HEIGHT);
        this.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 组合功能窗口
        this.tabbedPane = new JTabbedPane();
        this.tabbedPane.addTab(GlobalConst.CHECK_CONFIG_PANEL, CheckMainPanel.getInstance());
        this.tabbedPane.addTab(GlobalConst.ANALYSIS_PANEL_NAME, AnalysisMainPanel.getInstance());
        this.tabbedPane.addTab(GlobalConst.FIGHT_PANEL_NAME, FightMainPanel.getInstance());
        this.tabbedPane.addTab(GlobalConst.TOOL_GM_NAME, GmMainPanel.getInstance());
        this.tabbedPane.addTab(GlobalConst.FUNCTION_HELP, HelpMainPanel.getInstance());
        this.mainFrame.add(this.tabbedPane);
    }

    public void start() {
        this.initialize();
        this.mainFrame.setVisible(true);
    }
}
