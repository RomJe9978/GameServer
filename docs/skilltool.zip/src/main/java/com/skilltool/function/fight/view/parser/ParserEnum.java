package com.skilltool.function.fight.view.parser;

/**
 * 一条记录的转换枚举
 *
 * @author liuxuanjie
 * @date 2023/7/11 10:51
 */
public class ParserEnum {
}
