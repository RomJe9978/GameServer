package com.skilltool.function.check.view;

import com.skilltool.data.UiCheckResult;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.StringUtil;

import java.util.List;
import java.util.Objects;

/**
 * @author liuxuanjie
 * @date 2023/7/14 10:53
 */
public class CheckResultParser {

    public static String parseCheckResult(UiCheckResult uiCheckResult, int indent) {
        if (Objects.isNull(uiCheckResult)) {
            return StringUtil.blankSpaceStr(indent) + "您没有拉取到任何数据！";
        }

        List<String> errorList = uiCheckResult.getErrorList();
        if (EmptyUtil.isEmpty(errorList)) {
            return StringUtil.blankSpaceStr(indent) + "没有任何静态检测的错误！";
        }

        StringBuilder sb = new StringBuilder();
        for (String info : errorList) {
            sb.append(StringUtil.blankSpaceStr(indent)).append(info).append("\n");
        }
        return sb.toString();
    }

    /**
     * 解析“程序中已实现的有效的枚举”
     *
     * @param indent 行首“填充多少个空格”用来保持格式
     */
    public static String parseValidEnumResult(UiCheckResult uiCheckResult, int indent) {
        if (Objects.isNull(uiCheckResult)) {
            return "";
        }
        String fillStr = StringUtil.blankSpaceStr(indent);
        return fillStr + "所有程序中已经实现的枚举值展示：\n" +
                fillStr + "判定时机：" + uiCheckResult.getAttrTimingEnumList() + "\n" +
                fillStr + "判定条件(旧)：" + uiCheckResult.getAttrOldJudgmentEnumList() + "\n" +
                fillStr + "判定条件(新)：" + uiCheckResult.getAttrNewJudgmentEnumList() + "\n" +
                fillStr + "生效目标选择：" + uiCheckResult.getAttrTargetEnumList() + "\n" +
                fillStr + "效果类型：" + uiCheckResult.getAttrEffectEnumList() +
                "\n";
    }
}
