package com.skilltool.function.fight.view;

import com.skilltool.function.GlobalConst;
import lombok.Getter;

import java.awt.*;
import java.util.Objects;

/**
 * ”位置“枚举
 *
 * @author liuxuanjie
 * @date 2023/6/29 20:30
 */
@Getter
public enum LocationEnum {

    /**
     * 6个攻击者
     */
    ATTACKER_1(0, true, new Color(224, 102, 255)),
    ATTACKER_2(2, true, new Color(135, 206, 250)),
    ATTACKER_3(4, true, new Color(2, 150, 2)),
    ATTACKER_4(6, true, new Color(0, 128, 220)),
    ATTACKER_5(8, true, new Color(140, 240, 0)),
    ATTACKER_6(10, true, new Color(64, 128, 90)),

    /**
     * 攻击方光环
     */
    ATTACK_HALO(GlobalConst.ATTACK_HALO_LOCATION_MARK, true, new Color(100, 100, 130)),

    /**
     * 6个防守者
     */
    DEFENDER_1(1, false, new Color(176, 48, 96)),
    DEFENDER_2(3, false, new Color(128, 120, 0)),
    DEFENDER_3(5, false, new Color(255, 128, 0)),
    DEFENDER_4(7, false, new Color(140, 255, 140)),
    DEFENDER_5(9, false, new Color(255, 105, 150)),
    DEFENDER_6(11, false, new Color(255, 200, 144)),

    /**
     * 防守方光环
     */
    DEFEND_HALO(GlobalConst.DEFEND_HALO_LOCATION_MARK, false, new Color(130, 100, 100)),
    ;

    /**
     * 位置唯一标识
     */
    private int locationMark;

    /**
     * 是否是攻击者位置
     */
    private boolean isAttacker;

    /**
     * 位置匹配的颜色
     */
    private Color selfColor;

    LocationEnum(int locationMark, boolean isAttacker, Color selfColor) {
        this.locationMark = locationMark;
        this.isAttacker = isAttacker;
        this.selfColor = selfColor;
    }

    public static LocationEnum enumOf(int locationMark) {
        for (LocationEnum locationEnum : LocationEnum.values()) {
            if (locationEnum.getLocationMark() == locationMark) {
                return locationEnum;
            }
        }
        return null;
    }

    public static Color getColor(int locationMark) {
        return Objects.requireNonNull(enumOf(locationMark)).getSelfColor();
    }

    public static boolean isAttackLocation(int locationMark) {
        LocationEnum locationEnum = enumOf(locationMark);
        assert locationEnum != null;
        return locationEnum.isAttacker;
    }
}
