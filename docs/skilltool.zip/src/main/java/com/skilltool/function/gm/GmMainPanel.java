package com.skilltool.function.gm;

import lombok.Getter;

import javax.swing.*;
import java.awt.*;

/**
 * @author RomJe
 */
public class GmMainPanel extends JPanel {
    private final static GmMainPanel INSTANCE = new GmMainPanel();

    private final JPanel[] panels;
    private final JLabel[] labels;
    @Getter
    private final JTextField[] infoFields;

    @Getter
    private final JTextField submitField;
    private final JButton submitButton;

    private GmMainPanel() {
        super();

        GmSwitchEnum[] allEnum = GmSwitchEnum.values();
        this.setLayout(new GridLayout(allEnum.length + 1, 1));

        this.panels = new JPanel[allEnum.length];
        this.labels = new JLabel[allEnum.length];
        this.infoFields = new JTextField[allEnum.length];
        for (int i = 0, iSize = allEnum.length; i < iSize; i++) {
            this.labels[i] = new JLabel(allEnum[i].getDescribe());
            this.infoFields[i] = new JTextField(10);
            this.infoFields[i].setText("0");

            this.panels[i] = new JPanel();
            this.panels[i].add(labels[i]);
            this.panels[i].add(infoFields[i]);
            this.add(this.panels[i]);
        }

        JPanel submitPanel = new JPanel();
        this.submitField = new JTextField(10);
        this.submitField.setText("127.0.0.1:9090");
        this.submitButton = new JButton("提交");
        this.submitButton.addActionListener(new SubmitButtonListener());

        submitPanel.add(this.submitField);
        submitPanel.add(this.submitButton);
        this.add(submitPanel);
    }

    public static GmMainPanel getInstance() {
        return INSTANCE;
    }
}
