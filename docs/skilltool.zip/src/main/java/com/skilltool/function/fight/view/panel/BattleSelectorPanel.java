package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.listen.BattleSelectButtonListener;
import com.skilltool.function.fight.view.listen.HideAttributeButtonListener;
import com.skilltool.function.fight.view.listen.HideButtonListener;
import lombok.Getter;

import javax.swing.*;
import java.awt.*;

/**
 * 战斗检索器：输入对应的选择内容进行查询
 *
 * @author liuxuanjie
 * @date 2023/6/25 10:34
 */
@Getter
public class BattleSelectorPanel extends AbstractCustomizePanel {
    /**
     * 选择框
     */
    private final JLabel textLabel;
    private final JTextField textField;

    private final JLabel skillLabel;
    private final JTextField skillField;

    private final JLabel attrLabel;
    private final JTextField attrField;

    private final JLabel attributeLabel;
    private final JTextField attributeField;

    private final JLabel buffLabel;
    private final JTextField buffField;

    private final JButton searchButton;
    private final JButton hideUnrelatedButton;
    private final JButton hideAttributeButton;

    public BattleSelectorPanel(JPanel parentPanel) {
        super(parentPanel);

        this.textLabel = new JLabel(SelectEnum.GLOBAL.getSelectPrefix());
        this.textField = new JTextField(FightViewConst.SELECTOR_TEXT_LENGTH);
        this.add(this.textLabel);
        this.add(this.textField);

        this.skillLabel = new JLabel(SelectEnum.SKILL.getSelectPrefix());
        this.skillField = new JTextField(FightViewConst.SELECTOR_TEXT_LENGTH);
        this.add(skillLabel);
        this.add(this.skillField);

        this.attrLabel = new JLabel(SelectEnum.ATTR.getSelectPrefix());
        this.attrField = new JTextField(FightViewConst.SELECTOR_TEXT_LENGTH);
        this.add(attrLabel);
        this.add(this.attrField);

        this.attributeLabel = new JLabel(SelectEnum.ATTRIBUTE.getSelectPrefix());
        this.attributeField = new JTextField(FightViewConst.SELECTOR_TEXT_LENGTH);
        this.add(attributeLabel);
        this.add(this.attributeField);

        this.buffLabel = new JLabel(SelectEnum.BUFF.getSelectPrefix());
        this.buffField = new JTextField(FightViewConst.SELECTOR_TEXT_LENGTH);
        this.add(buffLabel);
        this.add(this.buffField);

        this.searchButton = new JButton(FightViewConst.SELECT_SEARCH_BUTTON);
        this.searchButton.addActionListener(new BattleSelectButtonListener(this));
        this.add(searchButton);

        this.hideUnrelatedButton = new JButton(FightViewConst.SELECT_HIDE_BUTTON);
        this.hideUnrelatedButton.addActionListener(new HideButtonListener(this.hideUnrelatedButton));
        this.add(hideUnrelatedButton);

        this.hideAttributeButton = new JButton(FightViewConst.SELECT_HIDE_ATTRIBUTE_BUTTON);
        this.hideAttributeButton.addActionListener(new HideAttributeButtonListener());
        this.add(hideAttributeButton);
    }

    public void refreshHideUnrelatedButton() {
        // 隐藏之后，更新按钮颜色
        if (UiFightService.getInstance().isHideUnrelatedData()) {
            this.hideUnrelatedButton.getModel().setArmed(true);
            this.hideUnrelatedButton.getModel().setPressed(true);

            this.hideUnrelatedButton.setBackground(Color.RED);
            this.hideUnrelatedButton.setBorderPainted(false);
        } else {
            this.hideUnrelatedButton.getModel().setArmed(false);
            this.hideUnrelatedButton.getModel().setPressed(false);

            // 在需要的时候修改按钮的外观
            this.hideUnrelatedButton.setBackground(null);
            this.hideUnrelatedButton.setBorderPainted(true);
        }
    }

    public void refreshHideAttributeButton() {
        // 隐藏之后，更新按钮颜色
        if (UiFightService.getInstance().isHideAttributeUnit()) {
            this.hideAttributeButton.getModel().setArmed(true);
            this.hideAttributeButton.getModel().setPressed(true);

            this.hideAttributeButton.setBackground(Color.RED);
            this.hideAttributeButton.setBorderPainted(false);
        } else {
            this.hideAttributeButton.getModel().setArmed(false);
            this.hideAttributeButton.getModel().setPressed(false);

            // 在需要的时候修改按钮的外观
            this.hideAttributeButton.setBackground(null);
            this.hideAttributeButton.setBorderPainted(true);
        }
    }

    public void reset() {
        this.textField.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);
        this.skillField.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);
        this.attrField.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);
        this.attributeField.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);
        this.buffField.setText(FightViewConst.TEXT_FIELD_DEFAULT_TEXT);

        // 重置不隐藏
        UiFightService.getInstance().setHideUnrelatedData(false);
        UiFightService.getInstance().setHideAttributeUnit(false);
    }
}
