package com.skilltool.function.check.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.check.view.CheckMainPanel;
import com.skilltool.function.check.view.CheckViewConst;
import com.skilltool.function.check.view.listen.ObtainButtonListener;

import javax.swing.*;

/**
 * “检查功能”的工具栏窗口
 *
 * @author liuxuanjie
 * @date 2023/7/14 10:06
 */
public class CheckToolBarPanel extends AbstractCustomizePanel<CheckMainPanel> {
    /**
     * 地址文本域
     */
    private final JTextField addressField;

    /**
     * 获取“配置检查结果”的按钮
     */
    private final JButton obtainButton;

    public CheckToolBarPanel(CheckMainPanel parentPanel) {
        super(parentPanel);

        this.addressField = new JTextField(CheckViewConst.ADDRESS_FIELD_LENGTH);
        this.addressField.setText(CheckViewConst.DEFAULT_ADDRESS);
        this.add(this.addressField);

        this.obtainButton = new JButton(CheckViewConst.OBTAIN_BUTTON);
        this.obtainButton.addActionListener(new ObtainButtonListener());
        this.add(this.obtainButton);
    }

    /**
     * 获取输入的地址
     */
    public String getInputAddress() {
        return this.addressField.getText();
    }
}
