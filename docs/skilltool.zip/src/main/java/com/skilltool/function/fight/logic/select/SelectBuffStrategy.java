package com.skilltool.function.fight.logic.select;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.data.UiBuffUpdateUnit;
import com.skilltool.data.UiDataEnum;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 检索buff的策略
 *
 * @author liuxuanjie
 * @date 2023/6/27 16:47
 */
public class SelectBuffStrategy extends AbstractSelectStrategy {

    @Override
    public List<AbstractRecordUnit> selectBy(String value, WarriorFightData data) {
        if (StringUtil.isEmpty(value) || Objects.isNull(data)) {
            return null;
        }

        int number = 0;
        try {
            number = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }

        List<AbstractRecordUnit> buffUpdateUnitList = data.listRecordUnitBy(UiDataEnum.RecordEnum.BUFF);
        if (Objects.isNull(buffUpdateUnitList) || buffUpdateUnitList.isEmpty()) {
            return null;
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (AbstractRecordUnit abstractRecordUnit : buffUpdateUnitList) {
            UiBuffUpdateUnit uiBuffUpdateUnit = (UiBuffUpdateUnit) abstractRecordUnit;
            if (uiBuffUpdateUnit.getBuffTemplateId() == number) {
                resultList.add(abstractRecordUnit);
            }
        }

        return resultList;
    }
}
