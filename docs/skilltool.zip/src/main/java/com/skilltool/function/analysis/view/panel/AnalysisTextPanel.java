package com.skilltool.function.analysis.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.analysis.logic.UiAnalysisService;
import com.skilltool.function.analysis.view.AnalysisMainPanel;

import javax.swing.*;
import java.awt.*;

/**
 * "验证文本展示"panel
 *
 * @author liuxuanjie
 * @date 2023/7/11 9:30
 */
public class AnalysisTextPanel extends AbstractCustomizePanel<AnalysisMainPanel> {
    /**
     * 战斗详情信息文本域
     */
    private JTextArea textArea;

    /**
     * 增加滚动条
     */
    private JScrollPane scrollPane;

    public AnalysisTextPanel(AnalysisMainPanel parentPanel) {
        super(parentPanel);

        this.setLayout(new GridBagLayout());
        this.textArea = new JTextArea();
        this.textArea.setEditable(false);
        this.textArea.setBackground(new Color(255, 192, 203));
        // 将文本域设置为等宽字体
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        textArea.setFont(font);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;

        this.scrollPane = new JScrollPane(textArea);
        this.add(this.scrollPane, gbc);
    }

    public void refreshText() {
        this.textArea.setText(UiAnalysisService.getInstance().generateAnalysisResult());
    }
}
