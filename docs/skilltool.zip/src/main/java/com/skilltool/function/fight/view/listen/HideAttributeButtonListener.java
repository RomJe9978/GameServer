package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author liuxuanjie
 * @date 2023/7/6 20:15
 */
public class HideAttributeButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        boolean isHideState = UiFightService.getInstance().isHideAttributeUnit();
        UiFightService.getInstance().setHideAttributeUnit(!isHideState);

        // 刷新界面
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
