package com.skilltool.function.help.logic;

/**
 * @author liuxuanjie
 * @date 2023/7/20 18:03
 */
public class UiHelpService {
    private final static UiHelpService INSTANCE = new UiHelpService();

    private UiHelpService() {
    }

    public static UiHelpService getInstance() {
        return INSTANCE;
    }

    /**
     * 构造“使用说明”的详细解析
     */
    public String generateOperationInstruction() {
        return "";
    }
}
