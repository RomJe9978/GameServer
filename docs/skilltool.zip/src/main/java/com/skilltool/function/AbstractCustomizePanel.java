package com.skilltool.function;

import lombok.Getter;

import javax.swing.*;

/**
 * 自定义panel
 *
 * @author liuxuanjie
 * @date 2023/6/25 10:57
 */
public abstract class AbstractCustomizePanel<T extends JPanel> extends JPanel {

    @Getter
    private final T parentPanel;

    public AbstractCustomizePanel(T parentPanel) {
        super();
        this.parentPanel = parentPanel;
    }
}
