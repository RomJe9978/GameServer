package com.skilltool.function;

/**
 * 全局使用常量
 *
 * @author liuxuanjie
 * @date 2023/7/10 15:49
 */
public class GlobalConst {
    //============================== 整个工具主窗口相关 ======================================

    public final static String MAIN_VIEW_TITLE = "技能小帮手";

    public final static int MAIN_FRAME_WIDTH = 1400;
    public final static int MAIN_FRAME_HEIGHT = 600;

    public final static int MAIN_FRAME_LOCATION_X = 100;
    public final static int MAIN_FRAME_LOCATION_Y = 100;

    public final static String CHECK_CONFIG_PANEL = "配置检查";
    public final static String ANALYSIS_PANEL_NAME = "效果解析";
    public final static String FIGHT_PANEL_NAME = "战斗调试";
    public final static String TOOL_GM_NAME = "工具GM";
    public final static String FUNCTION_HELP = "帮助";

    public final static String HTTP_PREFIX = "http://";

    //============================== "配置静态检查"相关 ======================================

    /**
     * "获取配置检测的url"
     */
    public final static String HTTP_API_URL_CHECK = "/gm_battle_obtain_table_error";

    public final static String CHECK_RESPONSE_KEY = "check";

    //============================== “配置验证主页”相关 ======================================

    /**
     * "解析Attr的url"
     */
    public final static String HTTP_API_URL_ANALYSIS = "/gm_battle_analysis_config";

    public final static String SKILL_PARAM = "skillId";

    //============================== “战斗调试主页”相关 ======================================

    /**
     * 获取服务器数据的url
     */
    public final static String HTTP_API_URL_PULL = "/gm_pull_last_battle_data";
    public final static String PULL_START_ROUND = "start";
    public final static String PULL_END_ROUND = "end";

    /**
     * 分批次请求的间隔数
     */
    public final static int BATCH_INTERVAL = 5;

    /**
     * 最大回合数
     */
    public final static int MAX_ROUND_COUNT = 30;

    /**
     * 每个阵营的位置数
     */
    public final static int ATTACKER_POS_NUM = 6;
    public final static int DEFENDER_POS_NUM = 6;

    /**
     * 光环的唯一位置标识
     */
    public final static int ATTACK_HALO_LOCATION_MARK = 1 << 13;
    public final static int DEFEND_HALO_LOCATION_MARK = 1 << 14;

    /**
     * “空格”的字符串
     */
    public final static String STRING_BLANK_SPACE = " ";

    /**
     * “分号”分隔符
     */
    public final static String SPLIT_STRING_SEMICOLON = ";";
}
