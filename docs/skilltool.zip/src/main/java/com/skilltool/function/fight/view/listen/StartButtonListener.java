package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * "开始"按钮的监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 12:24
 */
public class StartButtonListener implements ActionListener {
    /**
     * 关联服务器地址输入框
     */
    private JTextField addressField;

    private JTextField pullCountField;

    public StartButtonListener(JTextField addressField, JTextField pullCountField) {
        this.addressField = addressField;
        this.pullCountField = pullCountField;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 清空所有数据
        UiFightService.getInstance().clear();

        // 重置面板
        FightMainPanel.getInstance().reset();

        int count = Integer.parseInt(this.pullCountField.getText());
        UiFightService.getInstance().setPullCount(count);

        // 初始化服务器数据
        boolean decodeRes = UiFightService.getInstance().decodeAddress(this.addressField.getText());
        if (decodeRes) {
            boolean result = UiFightService.getInstance().pullServerData(0, UiFightService.getInstance().getPullCount(), true);
            if (result) {
                // 默认第一回合开始
                UiFightService.getInstance().setStartRoundMark();
            }
        } else {
            JOptionPane.showMessageDialog(null, "服务器地址格式不正确！", "错误", JOptionPane.ERROR_MESSAGE);
        }

        // 刷新战斗面板（无论是否成功都要刷新）
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
