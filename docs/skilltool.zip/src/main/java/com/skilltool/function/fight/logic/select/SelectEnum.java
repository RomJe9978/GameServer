package com.skilltool.function.fight.logic.select;

import lombok.Getter;

/**
 * 检索类型枚举
 *
 * @author liuxuanjie
 * @date 2023/6/25 18:27
 */
@Getter
public enum SelectEnum {
    /**
     * 检索类型枚举
     */
    SKILL("SKILL_ID:", new SelectSkillStrategy()),
    ATTR("ATTR_ID:", new SelectAttrStrategy()),
    ATTRIBUTE("属性_ID:", new SelectAttributeStrategy()),
    BUFF("BUFF_ID:", new SelectBuffStrategy()),

    MARK("MARK_ID:", new SelectBuffStrategy()),
    GLOBAL("全局文本检索：", new SelectGlobalTextStrategy());

    /**
     * 检索前缀
     * 例：当检索类型为属性时，检索前缀为“属性_ID:”
     * 避免全局检索的时候，ID重复，但是类型不同的情况
     */
    private String selectPrefix;

    /**
     * 检索策略
     */
    private AbstractSelectStrategy selectStrategy;

    SelectEnum(String selectPrefix, AbstractSelectStrategy abstractSelectStrategy) {
        this.selectPrefix = selectPrefix;
        this.selectStrategy = abstractSelectStrategy;
    }
}
