package com.skilltool.function.fight.view.panel;

import com.skilltool.function.AbstractCustomizePanel;
import com.skilltool.function.fight.view.FightViewConst;
import com.skilltool.function.fight.view.SnapshotMainPanel;
import com.skilltool.function.fight.view.listen.SnapshotRetrievalButtonListener;
import lombok.Getter;

import javax.swing.*;

/**
 * 快照的检索面板
 *
 * @author liuxuanjie
 * @date 2023/7/4 16:24
 */
public class SnapshotRetrievalPanel extends AbstractCustomizePanel<SnapshotMainPanel> {

    private final JLabel sequenceLabel;

    @Getter
    private final JTextField sequenceField;
    private final JButton retrievalButton;

    public SnapshotRetrievalPanel(SnapshotMainPanel parentPanel) {
        super(parentPanel);

        this.sequenceLabel = new JLabel(FightViewConst.SNAPSHOT_RETRIEVAL_LABEL);
        this.sequenceField = new JTextField(10);
        this.add(sequenceLabel);
        this.add(sequenceField);

        this.retrievalButton = new JButton(FightViewConst.SNAPSHOT_RETRIEVAL_BUTTON);
        this.retrievalButton.addActionListener(new SnapshotRetrievalButtonListener(this));
        this.add(retrievalButton);
    }

    public int getLocationMark() {
        return this.getParentPanel().getLocationMark();
    }
}
