package com.skilltool.function.fight.view;

import com.skilltool.function.GlobalConst;

import javax.swing.plaf.ColorUIResource;
import java.awt.*;

/**
 * 战斗界面常量
 *
 * @author liuxuanjie
 * @date 2023/6/25 10:40
 */
public class FightViewConst {
    //============================== 战斗选择器相关 ======================================

    public final static int SELECTOR_TEXT_LENGTH = 10;

    public final static String SELECT_SEARCH_BUTTON = "检索";
    public final static String SELECT_HIDE_BUTTON = "隐藏无关";
    public final static String SELECT_HIDE_ATTRIBUTE_BUTTON = "隐藏属性";

    //============================== 战斗信息相关 ======================================

    /**
     * 战斗信息栏的左中右三个部分的百分比（分母是1.0）
     */
    public final static float FIGHT_PANEL_LEFT_PERCENT = 0.1f;
    public final static float FIGHT_PANEL_CENTER_PERCENT = 0.8f;
    public final static float FIGHT_PANEL_RIGHT_PERCENT = 0.1f;

    public final static String ATTACK_NAME = "(攻)";
    public final static String DEFEND_NAME = "(防)";
    public final static String ATTACK_HALO_LABEL = "攻击方光环";
    public final static String DEFEND_HALO_LABEL = "防御方光环";

    /**
     * 检索出的高亮位置的颜色
     */
    public final static Color BUTTON_DEFAULT_BACK_GROUND = new ColorUIResource(238, 238, 238);
    public final static Color SELECT_LIGHT_COLOR = Color.RED;

    public final static String DEFAULT_DETAILS_WARN = "=========当前不需要展示任何信息=============";

    /**
     * 转换数据的时候，如果数据为<code>null</code>，显示的字符串
     */
    public static final String EMPTY_DATA_STRING = "空";

    /**
     * 文本域默认空字符串
     */
    public static final String TEXT_FIELD_DEFAULT_TEXT = "";

    /**
     * 快照窗口的最小宽高
     */
    public final static int SNAP_WINDOW_MIN_WIDTH = 100;
    public final static int SNAP_WINDOW_MIN_HEIGHT = 100;

    /**
     * 展示序号填充的长度
     */
    public final static int SEQUENCE_PADDING_LENGTH = 5;

    /**
     * 展示嵌套层级填充的长度
     */
    public final static int NEST_PADDING_LENGTH = 10;

    //============================== 战斗 tool bar 相关 ====================================

    public final static String TOOL_BAR_DEFAULT_ADDRESS = "127.0.0.1:9090";
    public final static int TOOL_BAR_ADDRESS_TEXT_LENGTH = 11;
    public final static String TOOL_BAR_DEFAULT_PULL_COUNT = String.valueOf(GlobalConst.BATCH_INTERVAL);
    public final static int TOOL_BAR_PULL_COUNT_LENGTH = 2;
    public final static String TOOL_BAR_START = "开始";
    public final static String TOOL_BAR_SHOW_ATTR_TIMING_BUTTON = "显示时机";

    public final static String TOOL_BAR_LAST_ROUND = "上一回合";
    public final static String TOOL_BAR_NEXT_ROUND = "下一回合";

    public final static String TOOL_BAR_ROUND_LABEL = "回合数：";
    public final static int TOOL_BAR_JUMP_TEXT_LENGTH = 2;
    public final static String TOOL_BAR_JUMP_STEP = "跳转";

    //============================== 快照窗口相关 ======================================

    public final static String SNAPSHOT_VIEW_TITLE = "快照";
    public final static String SNAPSHOT_CLOSE_NAME = "关闭快照";

    public final static int SNAPSHOT_VIEW_WIDTH = 600;
    public final static int SNAPSHOT_VIEW_HEIGHT = 600;

    public final static String SNAPSHOT_RETRIEVAL_LABEL = "快照序号：";
    public final static String SNAPSHOT_RETRIEVAL_BUTTON = "搜索快照";
}
