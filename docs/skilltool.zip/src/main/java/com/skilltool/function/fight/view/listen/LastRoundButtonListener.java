package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ”上一回合“按钮监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 11:36
 */
public class LastRoundButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        // 按钮被点击时候执行的代码
        System.out.println("上一回合按钮被点击了！");

        UiFightService.getInstance().setLastRoundMark();

        // 更新详情信息面板
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
