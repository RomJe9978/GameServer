package com.skilltool.function.fight.view;

import com.skilltool.function.fight.view.panel.BattlePanel;
import com.skilltool.function.fight.view.panel.BattleSelectorPanel;
import com.skilltool.function.fight.view.panel.BattleToolBarPanel;
import lombok.Getter;

import javax.swing.*;
import java.awt.*;

/**
 * “战斗调试”功能的主界面
 *
 * @author liuxuanjie
 * @date 2023/6/25 10:15
 */
@Getter
public class FightMainPanel extends JPanel {
    private final static FightMainPanel INSTANCE = new FightMainPanel();

    private final BattleSelectorPanel battleSelectorPanel;
    private final BattlePanel battlePanel;
    private final BattleToolBarPanel battleToolBarPanel;

    private FightMainPanel() {
        super();

        this.setBackground(Color.BLUE);
        this.setLayout(new BorderLayout());

        // 添加选择栏
        this.battleSelectorPanel = new BattleSelectorPanel(this);
        this.add(this.battleSelectorPanel, BorderLayout.NORTH);

        // 添加战斗信息栏
        this.battlePanel = new BattlePanel(this);
        this.add(this.battlePanel, BorderLayout.CENTER);

        // 添加工具栏
        this.battleToolBarPanel = new BattleToolBarPanel(this);
        this.add(this.battleToolBarPanel, BorderLayout.SOUTH);
    }

    public static FightMainPanel getInstance() {
        return INSTANCE;
    }

    /**
     * 刷新页面
     */
    public void refreshBattlePanel() {
        SwingUtilities.invokeLater(() -> {
            this.battleSelectorPanel.refreshHideUnrelatedButton();
            this.battleSelectorPanel.refreshHideAttributeButton();
            this.battlePanel.refreshLocationButton();
            this.battlePanel.refreshDetailsPanel();
            this.battleToolBarPanel.refreshRoundText();
        });
    }

    /**
     * 重置页面的所有默认内容
     */
    public void reset() {
        this.battleSelectorPanel.reset();
        this.battlePanel.reset();
    }
}
