package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author liuxuanjie
 * @date 2023/7/3 17:05
 */
public class HideButtonListener implements ActionListener {
    private JButton jButton;

    public HideButtonListener(JButton jButton) {
        this.jButton = jButton;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 每次反转状态
        boolean isHideState = UiFightService.getInstance().isHideUnrelatedData();
        UiFightService.getInstance().setHideUnrelatedData(!isHideState);

        // 刷新界面
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
