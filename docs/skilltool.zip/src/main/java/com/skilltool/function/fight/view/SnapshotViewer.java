package com.skilltool.function.fight.view;

import lombok.Getter;

import javax.swing.*;

/**
 * 后台调试工具的快照查看窗口
 * <p>与{@link FightMainPanel}不同，该窗口不是单例模式，因为
 * 该窗口是与位置绑定的，每个位置都有一个快照查看窗口，各自独立
 *
 * @author liuxuanjie
 * @date 2023/7/4 16:35
 */
public class SnapshotViewer {
    private JFrame snapshotFrame;

    @Getter
    private SnapshotMainPanel snapshotMainPanel;

    /**
     * 该快照查看窗口属于哪个位置
     */
    @Getter
    private final int locationMark;

    public SnapshotViewer(int locationMark) {
        super();
        this.locationMark = locationMark;

        this.snapshotFrame = new JFrame(FightViewConst.SNAPSHOT_VIEW_TITLE);
        this.snapshotFrame.setSize(FightViewConst.SNAPSHOT_VIEW_WIDTH, FightViewConst.SNAPSHOT_VIEW_HEIGHT);
        this.snapshotFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.snapshotMainPanel = new SnapshotMainPanel(this);
        this.snapshotFrame.add(this.snapshotMainPanel);
    }

    public void setTitle(String title) {
        this.snapshotFrame.setTitle(title);
    }

    /**
     * 设置位置
     */
    public void setLocation(int x, int y) {
        this.snapshotFrame.setLocation(x, y);
    }

    public void open() {
        this.snapshotFrame.setVisible(true);
    }

    /**
     * 关闭请调用该接口，不要直接点击“页面x号“
     */
    public void close() {
        this.snapshotFrame.setVisible(false);
    }

    public void reset() {
        this.snapshotMainPanel.reset();
    }
}
