package com.skilltool.function.fight.logic.select;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.data.UiDataEnum;
import com.skilltool.data.UiSkillApplyUnit;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author liuxuanjie
 * @date 2023/7/5 14:19
 */
public class SelectSkillStrategy extends AbstractSelectStrategy {

    @Override
    public List<AbstractRecordUnit> selectBy(String value, WarriorFightData data) {
        if (StringUtil.isEmpty(value) || Objects.isNull(data)) {
            return null;
        }

        int number = 0;
        try {
            number = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }

        List<AbstractRecordUnit> recordUnitList = data.listRecordUnitBy(UiDataEnum.RecordEnum.SKILL);
        if (Objects.isNull(recordUnitList) || recordUnitList.isEmpty()) {
            return null;
        }

        List<AbstractRecordUnit> resultList = new ArrayList<>();
        for (AbstractRecordUnit recordUnit : recordUnitList) {
            if (Objects.isNull(recordUnit)) {
                continue;
            }

            UiSkillApplyUnit skillApplyUnit = (UiSkillApplyUnit) recordUnit;
            if (skillApplyUnit.getSkillId() == number) {
                resultList.add(skillApplyUnit);
            }
        }
        return resultList;
    }
}
