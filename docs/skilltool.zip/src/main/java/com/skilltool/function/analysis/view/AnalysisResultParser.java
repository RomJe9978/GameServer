package com.skilltool.function.analysis.view;

import com.skilltool.data.UiAnalysisAttrResult;
import com.skilltool.data.UiAnalysisSkillResult;
import com.skilltool.data.UiDataEnum;
import com.skilltool.data.UiSingleAnalysisData;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.StringUtil;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 分析结果解析器
 *
 * @author liuxuanjie
 * @date 2023/7/11 14:34
 */
public class AnalysisResultParser {

    /**
     * @param indent 需要缩进多少个“单位”
     */
    public static String parseString(UiAnalysisSkillResult result, int indent) {
        if (Objects.isNull(result)) {
            return null;
        }

        Map<UiDataEnum.AnalysisTypeEnum, UiSingleAnalysisData> analysisDataMap = result.getTypeAnalysisMap();
        if (Objects.isNull(analysisDataMap) || analysisDataMap.isEmpty()) {
            return null;
        }

        String fillString = StringUtil.blankSpaceStr(indent);
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<UiDataEnum.AnalysisTypeEnum, UiSingleAnalysisData> entry : analysisDataMap.entrySet()) {
            sb.append("\n");
            sb.append(fillString).append(entry.getKey().getMarkStr()).append(": ").append("\n");
            UiSingleAnalysisData singleData = entry.getValue();
            if (Objects.isNull(singleData)) {
                continue;
            }

            sb.append(fillString).append("ID: ").append(singleData.getId()).append("\n");
            if (entry.getKey() == UiDataEnum.AnalysisTypeEnum.SKILL) {
                sb.append(fillString).append("技能目标： ").append(result.getSkillTargetStr()).append("\n");
            }
            sb.append(parseAttrDescribeMap(singleData.getAttrList(), singleData.getAttrDescribeMap(), indent)).append("\n");
        }
        return sb.toString();
    }

    /**
     * 按照list中的顺序，依次拼接描述
     */
    public static String parseAttrDescribeMap(List<Integer> attrList, Map<Integer, UiAnalysisAttrResult> describeMap, int indent) {
        if (EmptyUtil.isEmpty(attrList) || EmptyUtil.isEmpty(describeMap)) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        for (Integer attrId : attrList) {
            UiAnalysisAttrResult attrResult = describeMap.get(attrId);
            if (Objects.isNull(attrResult)) {
                sb.append(StringUtil.blankSpaceStr(indent)).append(attrId).append(":  ").append("空\n");
            } else {
                String parseStr = parseString(attrResult, indent);
                parseStr = parseStr.replace("owner", AnalysisViewConst.DESCRIBE_OWNER);
                parseStr = parseStr.replace("xxx", AnalysisViewConst.DESCRIBE_TARGET);
//                parseStr = parseStr.replace("TTT", "赵云");
                sb.append(parseStr).append("\n");
            }
        }
        return sb.toString();
    }

    private static String parseString(UiAnalysisAttrResult attrResult, int indent) {
        if (Objects.isNull(attrResult)) {
            return "";
        }

        int attrTemplateId = attrResult.getAttrTemplateId();
        return StringUtil.blankSpaceStr(indent) + attrTemplateId +
                ": " + parseTiming(attrResult.getTimingList()) +
                ", " + (Objects.nonNull(attrResult.getJudgmentStr()) ? attrResult.getJudgmentStr() : "") +
                ", " + parseEffect(attrResult) +
                ", " + parseDuration(attrResult);
    }

    /**
     * 解析触发时机
     */
    private static String parseTiming(List<String> timingList) {
        if (EmptyUtil.isEmpty(timingList)) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("{owner}");
        for (int i = 0, iSize = timingList.size(); i < iSize; i++) {
            sb.append(timingList.get(i));
            if (i != iSize - 1) {
                sb.append(" 和 ");
            }
        }
        //    sb.append(", 假设选中目标是{TTT}");
        return sb.toString();
    }

    private static String parseEffect(UiAnalysisAttrResult result) {
        String effectStr = result.getEffectStr();
        if (StringUtil.isEmpty(effectStr)) {
            return "";
        }

        String targetStr = result.getEffectTargetList();
        if (Objects.nonNull(targetStr)) {
            effectStr = effectStr.replace("{xxx}", targetStr);
        }
        return effectStr;
    }

    private static String parseDuration(UiAnalysisAttrResult result) {
        String durationStr = result.getDurationStr();
        if (StringUtil.isEmpty(durationStr)) {
            return "";
        }
        return " 持续到：" + durationStr;
    }
}
