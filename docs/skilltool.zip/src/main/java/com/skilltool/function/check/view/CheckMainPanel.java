package com.skilltool.function.check.view;

import com.skilltool.function.check.view.panel.CheckTextPanel;
import com.skilltool.function.check.view.panel.CheckToolBarPanel;
import lombok.Getter;

import javax.swing.*;
import java.awt.*;

/**
 * @author liuxuanjie
 * @date 2023/7/14 10:02
 */
public class CheckMainPanel extends JPanel {
    /**
     * “工具栏”
     */
    @Getter
    private final CheckToolBarPanel toolBarPanel;

    /**
     * “文本展示”
     */
    private final CheckTextPanel textPanel;

    private final static CheckMainPanel INSTANCE = new CheckMainPanel();

    private CheckMainPanel() {
        super();
        this.setLayout(new BorderLayout());

        this.toolBarPanel = new CheckToolBarPanel(this);
        this.add(this.toolBarPanel, BorderLayout.NORTH);

        this.textPanel = new CheckTextPanel(this);
        this.add(this.textPanel, BorderLayout.CENTER);
    }

    public static CheckMainPanel getInstance() {
        return INSTANCE;
    }

    public void refreshAll() {
        SwingUtilities.invokeLater(this.textPanel::refreshText);
    }
}
