package com.skilltool.function.fight.data;

import com.skilltool.data.*;
import com.skilltool.function.GlobalConst;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.utils.EmptyUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * 数据转换工具类
 *
 * @author liuxuanjie
 * @date 2023/6/27 14:46
 */
public class DataTranslator {

    public static void convert(DataContainer dataContainer, UiBattleData uiBattleData) {
        if (Objects.isNull(dataContainer) || Objects.isNull(uiBattleData)) {
            return;
        }

        UiFightService.getInstance().setServerMaxRound(uiBattleData.getMaxRound());

        Map<Integer, UiRoundData> roundDataMap = uiBattleData.getRoundDataMap();
        if (Objects.isNull(roundDataMap) || roundDataMap.isEmpty()) {
            return;
        }
        dataContainer.setFightNotes(uiBattleData.getNotes());

        int maxRound = 0;
        for (Map.Entry<Integer, UiRoundData> entry : roundDataMap.entrySet()) {
            maxRound = Math.max(maxRound, entry.getKey());
        }

        int startRound = UiFightService.getInstance().getNextRequestRound();
        int endRound = Math.min(startRound + UiFightService.getInstance().getPullCount(), uiBattleData.getMaxRound());
        for (int i = startRound; i <= endRound; i++) {
            UiRoundData uiRoundData = roundDataMap.get(i);
            if (Objects.nonNull(uiRoundData)) {
                RoundData roundData = parseFrom(uiRoundData);
                dataContainer.addRoundData(roundData);
            } else {
                dataContainer.addRoundData(RoundData.createInstance(i));
            }
        }
    }

    /**
     * 解析“回合”数据
     */
    public static RoundData parseFrom(UiRoundData uiRoundData) {
        int roundMark = uiRoundData.getRoundMark();
        RoundData roundData = new RoundData(roundMark);

        // 优先增加“第一个warrior”
        Map<Integer, UiWarriorData> firstWarriorDataMap = uiRoundData.getFirstWarriorMap();
        if (EmptyUtil.nonEmpty(firstWarriorDataMap)) {
            for (Map.Entry<Integer, UiWarriorData> entry : firstWarriorDataMap.entrySet()) {
                WarriorFightData warriorFightData = parseFrom(entry.getValue());
                roundData.offerWarriorData(warriorFightData);
            }
        }
        // 其次增加“替换warrior”
        Map<Integer, UiWarriorData> replaceWarriorMap = uiRoundData.getReplaceWarriorMap();
        if (EmptyUtil.nonEmpty(replaceWarriorMap)) {
            for (Map.Entry<Integer, UiWarriorData> entry : replaceWarriorMap.entrySet()) {
                WarriorFightData warriorFightData = parseFrom(entry.getValue());
                roundData.offerWarriorData(warriorFightData);
            }
        }
        return roundData;
    }


    public static WarriorFightData parseFrom(UiWarriorData uiWarriorData) {
        WarriorFightData warriorFightData = null;
        if (uiWarriorData.isAttackHalo()) {
            warriorFightData = new WarriorFightData(uiWarriorData.getWarriorMark(), GlobalConst.ATTACK_HALO_LOCATION_MARK);
        } else if (uiWarriorData.isDefendHalo()) {
            warriorFightData = new WarriorFightData(uiWarriorData.getWarriorMark(), GlobalConst.DEFEND_HALO_LOCATION_MARK);
        } else {
            warriorFightData = new WarriorFightData(uiWarriorData.getWarriorMark(), uiWarriorData.getLocation());
        }
        warriorFightData.setName(uiWarriorData.getName());

        // 所有记录
        Map<UiDataEnum.RecordEnum, Map<Integer, AbstractRecordUnit>> recordMap = new HashMap<>();
        warriorFightData.setRecordMap(recordMap);

        Map<Integer, UiBattleEventUnit> eventUnitMap = uiWarriorData.getBattleEventUnitMap();
        if (EmptyUtil.nonEmpty(eventUnitMap)) {
            recordMap.put(UiDataEnum.RecordEnum.BATTLE_EVENT, new HashMap<>(eventUnitMap));
        }

        Map<Integer, UiSkillApplyUnit> skillRecordMap = uiWarriorData.getSkillUnitMap();
        if (EmptyUtil.nonEmpty(skillRecordMap)) {
            recordMap.put(UiDataEnum.RecordEnum.SKILL, new HashMap<>(skillRecordMap));
        }

        Map<Integer, UiAttrEffectUnit> attrRecordMap = uiWarriorData.getAttrEffectUnitMap();
        if (EmptyUtil.nonEmpty(attrRecordMap)) {
            recordMap.put(UiDataEnum.RecordEnum.ATTR, new HashMap<>(attrRecordMap));
        }

        Map<Integer, UiBuffUpdateUnit> buffRecordMap = uiWarriorData.getBuffUpdateUnitMap();
        if (EmptyUtil.nonEmpty(buffRecordMap)) {
            recordMap.put(UiDataEnum.RecordEnum.BUFF, new HashMap<>(buffRecordMap));
        }

        Map<Integer, UiMarkUpdateUnit> markRecordMap = uiWarriorData.getMarkUpdateUnitMap();
        if (EmptyUtil.nonEmpty(markRecordMap)) {
            recordMap.put(UiDataEnum.RecordEnum.MARK, new HashMap<>(markRecordMap));
        }

        Map<Integer, UiAttributeUpdateUtil> attributeUpdateUtilMap = uiWarriorData.getAttributeUpdateUtilMap();
        if (EmptyUtil.nonEmpty(attributeUpdateUtilMap)) {
            recordMap.put(UiDataEnum.RecordEnum.ATTRIBUTE, new HashMap<>(attributeUpdateUtilMap));
        }

        Map<Integer, UiCalculateAttributeUnit> calculateAttributeUnitMap = uiWarriorData.getCalculateAttributeUnitMap();
        if (EmptyUtil.nonEmpty(calculateAttributeUnitMap)) {
            recordMap.put(UiDataEnum.RecordEnum.CALCULATE_ATTRIBUTE, new HashMap<>(calculateAttributeUnitMap));
        }

        Map<Integer, UiDamageCalculateUnit> damageCalculateUnitMap = uiWarriorData.getDamageCalculateUnitMap();
        if (EmptyUtil.nonEmpty(damageCalculateUnitMap)) {
            recordMap.put(UiDataEnum.RecordEnum.ONCE_DAMAGE_CALCULATE, new HashMap<>(damageCalculateUnitMap));
        }

        Map<Integer, UiDamageUnit> damageUnitMap = uiWarriorData.getDamageUnitMap();
        if (EmptyUtil.nonEmpty(damageUnitMap)) {
            recordMap.put(UiDataEnum.RecordEnum.DAMAGE, new HashMap<>(damageUnitMap));
        }

        Map<Integer, UiHealUnit> healUnitMap = uiWarriorData.getHealUnitMap();
        if (EmptyUtil.nonEmpty(healUnitMap)) {
            recordMap.put(UiDataEnum.RecordEnum.HEAL, new HashMap<>(healUnitMap));
        }

        // 快照
        warriorFightData.setUiWarriorSnapshotDataMap(uiWarriorData.getSnapshotDataMap());
        return warriorFightData;
    }
}
