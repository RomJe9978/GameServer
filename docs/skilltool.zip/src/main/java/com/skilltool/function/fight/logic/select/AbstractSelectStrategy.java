package com.skilltool.function.fight.logic.select;

import com.skilltool.data.AbstractRecordUnit;
import com.skilltool.function.fight.data.WarriorFightData;

import java.util.List;

/**
 * 检索策略
 *
 * @author liuxuanjie
 * @date 2023/6/27 16:38
 */
public abstract class AbstractSelectStrategy {

    /**
     * 是否被包含在检索结果中
     *
     * @param value 检索的值(如果是数值等其他类型，实现类自己处理转换)
     * @param data  检索的数据源
     * @return 搜索出来包含<code>value</code>的所有的记录
     */
    public abstract List<AbstractRecordUnit> selectBy(String value, WarriorFightData data);
}
