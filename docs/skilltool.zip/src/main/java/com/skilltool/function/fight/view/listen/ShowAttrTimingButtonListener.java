package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author RomJe
 */
public class ShowAttrTimingButtonListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        boolean isShowAttrTiming = UiFightService.getInstance().isShowAttrTiming();
        UiFightService.getInstance().setShowAttrTiming(!isShowAttrTiming);

        // 刷新界面
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
