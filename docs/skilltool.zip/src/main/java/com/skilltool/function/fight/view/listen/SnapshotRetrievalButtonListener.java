package com.skilltool.function.fight.view.listen;

import com.skilltool.function.GlobalConst;
import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.SnapshotMainPanel;
import com.skilltool.function.fight.view.panel.SnapshotRetrievalPanel;
import com.skilltool.utils.StringUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

/**
 * 快照检索按钮监听器
 *
 * @author liuxuanjie
 * @date 2023/7/4 17:53
 */
public class SnapshotRetrievalButtonListener implements ActionListener {
    /**
     * 关联的panel
     */
    private final SnapshotRetrievalPanel snapshotRetrievalPanel;

    public SnapshotRetrievalButtonListener(SnapshotRetrievalPanel snapshotRetrievalPanel) {
        super();
        this.snapshotRetrievalPanel = snapshotRetrievalPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("快照检索按钮被点击了！");
        // 关联的位置
        int locationMark = this.snapshotRetrievalPanel.getLocationMark();
        UiFightService.getInstance().removeInputRetrievalSnapshot(locationMark);

        // 获取用户输入的内容
        JTextField textField = this.snapshotRetrievalPanel.getSequenceField();
        String text = textField.getText();
        int[] inputArr = StringUtil.splitInt(text, GlobalConst.SPLIT_STRING_SEMICOLON);
        if (Objects.nonNull(inputArr)) {
            UiFightService.getInstance().recordInputRetrievalSnapshotList(locationMark, inputArr);
        }

        // 刷新即可
        SnapshotMainPanel snapshotMainPanel = this.snapshotRetrievalPanel.getParentPanel();
        snapshotMainPanel.refreshSnapshotPanel();
    }
}
