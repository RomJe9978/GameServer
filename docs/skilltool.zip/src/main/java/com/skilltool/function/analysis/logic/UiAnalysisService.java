package com.skilltool.function.analysis.logic;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.skilltool.data.UiAnalysisSkillResult;
import com.skilltool.data.UiDataEnum;
import com.skilltool.function.GlobalConst;
import com.skilltool.function.analysis.view.AnalysisResultParser;
import com.skilltool.utils.HttpUtil;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * “配置分析”的逻辑服务
 *
 * @author liuxuanjie
 * @date 2023/7/11 9:48
 */
public class UiAnalysisService {
    /**
     * 输入的地址
     */
    @Setter
    private String address;

    /**
     * 当前输入框中所有类型的所有输入
     */
    private Map<UiDataEnum.AnalysisTypeEnum, Integer> analysisTypeInputMap = new HashMap<>();

    /**
     * 每次请求服务器的“分析结果”
     */
    private UiAnalysisSkillResult analysisResult;

    private final static UiAnalysisService INSTANCE = new UiAnalysisService();

    private UiAnalysisService() {
    }

    public static UiAnalysisService getInstance() {
        return INSTANCE;
    }

    public void clear() {
        this.address = null;
        this.analysisResult = null;
        this.analysisTypeInputMap.clear();
    }

    public boolean gmAnalysisSkill() {
        if (this.analysisTypeInputMap.isEmpty()) {
            return false;
        }

        String serverUrl = GlobalConst.HTTP_PREFIX + this.address + GlobalConst.HTTP_API_URL_ANALYSIS;
        HashMap<String, String> paramMap = new HashMap<>();
        for (Map.Entry<UiDataEnum.AnalysisTypeEnum, Integer> entry : this.analysisTypeInputMap.entrySet()) {
            int inputId = entry.getValue();
            if (inputId <= 0) {
                continue;
            }
            paramMap.put(entry.getKey().getMarkStr(), Integer.toString(entry.getValue()));
        }

        String respondData = HttpUtil.sendGetData(serverUrl, paramMap);
        if (Objects.isNull(respondData)) {
            return false;
        }

        JSONObject pullData = JSON.parseObject(respondData);
        String jsonData = pullData.getString("analysis");
        this.analysisResult = JSON.parseObject(jsonData, UiAnalysisSkillResult.class);
        return false;
    }

    public String generateAnalysisResult() {
        if (Objects.isNull(this.analysisResult)) {
            return null;
        }
        return AnalysisResultParser.parseString(this.analysisResult, 20);
    }

    public void recordTypeInput(UiDataEnum.AnalysisTypeEnum analysisTypeEnum, int id) {
        if (Objects.isNull(analysisTypeEnum) || id <= 0) {
            return;
        }
        this.analysisTypeInputMap.put(analysisTypeEnum, id);
    }

    public boolean nonInputEmpty() {
        return !this.analysisTypeInputMap.isEmpty();
    }
}
