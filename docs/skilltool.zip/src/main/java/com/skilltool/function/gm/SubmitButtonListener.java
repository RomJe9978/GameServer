package com.skilltool.function.gm;

import com.skilltool.function.GlobalConst;
import com.skilltool.utils.HttpUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

/**
 * "开始"按钮的监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 12:24
 */
public class SubmitButtonListener implements ActionListener {

    public SubmitButtonListener() {
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String address = GmMainPanel.getInstance().getSubmitField().getText();

        GmSwitchEnum[] gmSwitchEnums = GmSwitchEnum.values();
        for (int i = 0, iSize = gmSwitchEnums.length; i < iSize; i++) {
            JTextField[] fields = GmMainPanel.getInstance().getInfoFields();
            int value = Integer.parseInt(fields[i].getText());

            String serverUrl = GlobalConst.HTTP_PREFIX + address + gmSwitchEnums[i].getUrl();
            HashMap<String, String> paramMap = new HashMap<>();
            paramMap.put("isOpen", String.valueOf(value));

            HttpUtil.sendGetData(serverUrl, paramMap);
        }
    }
}
