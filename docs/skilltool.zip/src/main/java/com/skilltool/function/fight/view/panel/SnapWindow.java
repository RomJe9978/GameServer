package com.skilltool.function.fight.view.panel;

import com.skilltool.function.fight.view.FightViewConst;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * 快照窗口（支持窗口拖动和调整大小）
 *
 * @author liuxuanjie
 */
public class SnapWindow extends JWindow {
    private Point initialClick;
    private boolean resizing = false;

    private final JPanel panel;
    private final JLabel promptLabel;
    //    private final JTextArea textArea;
    private final JButton closeButton;

//    private final SnapshotMainPanel snapshotMainPanel;

    public SnapWindow() {
        super();

        this.panel = new JPanel(new BorderLayout());
        this.panel.setBackground(Color.WHITE);
        Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
        panel.setBorder(border);

        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
                resizing = isDragEdge(e.getXOnScreen(), e.getYOnScreen());
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (resizing) {
                    setCursor(Cursor.getDefaultCursor());
                    resizing = false;
                }
            }
        });

        panel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (resizing) {
                    int width = e.getXOnScreen() - getLocationOnScreen().x;
                    int height = e.getYOnScreen() - getLocationOnScreen().y;
                    if (width > FightViewConst.SNAP_WINDOW_MIN_WIDTH && height > FightViewConst.SNAP_WINDOW_MIN_HEIGHT) {
                        setSize(new Dimension(width, height));
                    }
                } else {
                    int newX = getLocation().x + e.getX() - initialClick.x;
                    int newY = getLocation().y + e.getY() - initialClick.y;
                    setLocation(newX, newY);
                }
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                if (isDragEdge(e.getXOnScreen(), e.getYOnScreen())) {
                    setCursor(Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));
                } else if (isLocationEdge(e.getXOnScreen(), e.getYOnScreen())) {
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                } else {
                    setCursor(Cursor.getDefaultCursor());
                }
            }
        });

        this.promptLabel = new JLabel("快照详情");
        panel.add(this.promptLabel, BorderLayout.NORTH);

//        this.textArea = new JTextArea();
//        JScrollPane jScrollPane = new JScrollPane(this.textArea);
//        panel.add(jScrollPane, BorderLayout.CENTER);
//        this.snapshotMainPanel = new SnapshotMainPanel(panel);
//        panel.add(this.snapshotMainPanel, BorderLayout.CENTER);

        this.closeButton = new JButton("Close");
        this.closeButton.addActionListener(e -> dispose());
        panel.add(this.closeButton, BorderLayout.SOUTH);

        this.getContentPane().add(panel);
        pack();
    }

    private boolean isDragEdge(int x, int y) {
        Rectangle bounds = getBounds();
        int edgeSize = 20;
        boolean onBottomEdge = (y >= bounds.y + bounds.height - edgeSize && y <= bounds.y + bounds.height);
        boolean onLeftEdge = (x >= bounds.x && x <= bounds.x + edgeSize);
        boolean onRightEdge = (x >= bounds.x + bounds.width - edgeSize && x <= bounds.x + bounds.width);
        return onBottomEdge || onLeftEdge || onRightEdge;
    }

    private boolean isLocationEdge(int x, int y) {
        Rectangle bounds = getBounds();
        int edgeSize = 20;
        return (y >= bounds.y && y <= bounds.y + edgeSize);
    }

    public void refreshSnapshot(String text) {
//        this.snapshotMainPanel.refreshSnap(text);
    }
}
