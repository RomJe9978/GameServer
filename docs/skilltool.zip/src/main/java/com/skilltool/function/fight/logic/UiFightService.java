package com.skilltool.function.fight.logic;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.skilltool.data.*;
import com.skilltool.function.GlobalConst;
import com.skilltool.function.fight.data.DataContainer;
import com.skilltool.function.fight.data.DataTranslator;
import com.skilltool.function.fight.data.RoundData;
import com.skilltool.function.fight.data.WarriorFightData;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.function.fight.view.FightTextParser;
import com.skilltool.utils.CollectionUtil;
import com.skilltool.utils.EmptyUtil;
import com.skilltool.utils.HttpUtil;
import com.skilltool.utils.StringUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.*;
import java.util.stream.Collectors;

/**
 * "战斗调试"服务逻辑
 *
 * @author liuxuanjie
 * @date 2023/6/25 17:57
 */
public class UiFightService {
    private final static UiFightService INSTANCE = new UiFightService();

    /**
     * 服务器地址
     */
    private String ip;
    private int port;

    /**
     * 数据容器
     */
    private final DataContainer dataContainer = new DataContainer();

    /**
     * 当前是第几回合
     */
    @Getter
    private int curRound;

    /**
     * 服务器战斗最大回合数
     */
    @Getter
    @Setter
    private int serverMaxRound;

    /**
     * 分批，下次请求的回合数
     */
    @Getter
    @Setter
    private int nextRequestRound;

    /**
     * 用户输入的检索信息
     * key:检索类型，value：对应类型的检索值
     */
    @Getter
    private final Map<SelectEnum, String> inputSelectEnumMap = new HashMap<>();

    /**
     * 所有回合检索“用户输入的检索信息”的搜索结果
     * key：回合数，value:{key:位置标识，value：对应位置被检索出的所有记录}
     */
    private final Map<Integer, Map<Integer, List<AbstractRecordUnit>>> retrievalInputResultMap = new HashMap<>();

    /**
     * 所有输入“检索值”在当前展示文本中被检索出来的位置index
     * key：检索枚举，value：两个位置一组（start1，end1，start2，end2...）
     */
    @Getter
    private final Map<SelectEnum, List<Integer>> retrievalInputTextMap = new HashMap<>();

    /**
     * 用户锁定的位置信息：locationMark（去重）
     * 战斗面板会显示锁定的位置的信息,依赖此数据
     */
    @Getter
    private final List<Integer> lockLocationList = new ArrayList<>();

    /**
     * 检索“锁定选中的位置”所对应的“warriorMark”在当前展示文本的位置index
     * key：locationMark，value：两个位置一组（start1，end1，start2，end2...）
     */
    @Getter
    private final Map<Integer, List<Integer>> selectLockLocationWarriorMarkMap = new HashMap<>();

    /**
     * 详情面板对应的位置栈，用于“开始”和“结束”的对应
     */
    private final Stack<Integer> sequenceStack = new Stack<>();

    /**
     * 是否隐藏和检索无关的数据
     */
    @Setter
    @Getter
    private boolean isHideUnrelatedData = false;

    /**
     * 是否隐藏“属性记录单位”（这种无意义的太多了）
     */
    @Getter
    @Setter
    private boolean isHideAttributeUnit = false;

    /**
     * 是否展示“Attr触发时机”
     */
    @Getter
    @Setter
    private boolean isShowAttrTiming = false;

    /**
     * 位置检索的快照列表
     * key：位置标识，value：{@link UiWarriorSnapshotData#getSnapMark()}列表
     * <p>该列表是“显示过滤”，如果<code>nonEmpty</code>，处于列表内的会被显示
     * <p>如果该列表<code>isEmpty</code>，则表示不进行过滤，显示全部数据
     */
    private Map<Integer, Set<Integer>> locationFilterSnapshotMap = new HashMap<>();

    /**
     * 战斗文本显示的行数
     */
    @Getter
    @Setter
    private int fightAreaLineSize;

    /**
     * 自定义设置的拉取回合数
     */
    @Getter
    @Setter
    private int pullCount = GlobalConst.BATCH_INTERVAL;

    private UiFightService() {
    }

    public static UiFightService getInstance() {
        return INSTANCE;
    }

    public void clear() {
        this.ip = null;
        this.port = 0;
        this.dataContainer.clear();
        this.curRound = 0;
        this.nextRequestRound = 0;
        this.serverMaxRound = 0;
        this.inputSelectEnumMap.clear();
        this.retrievalInputResultMap.clear();
        this.retrievalInputTextMap.clear();
        this.lockLocationList.clear();
        this.selectLockLocationWarriorMarkMap.clear();
        this.sequenceStack.clear();
        this.isHideUnrelatedData = false;
        this.locationFilterSnapshotMap.clear();
        this.fightAreaLineSize = 0;
        this.isHideAttributeUnit = false;
        this.isShowAttrTiming = false;
        this.pullCount = GlobalConst.BATCH_INTERVAL;
    }

    /**
     * 初始化服务器数据.先拉取，然后构建
     */
    public boolean pullServerData(int start, int end, boolean requireClear) {
        // 先清空之前的数据
        if (requireClear) {
            this.dataContainer.clear();
        }

        // 服务器获取数据
        UiBattleData uiBattleData = pullServerData(this.ip + ":" + this.port, start, end);
        if (Objects.isNull(uiBattleData)) {
            return false;
        }

        DataTranslator.convert(this.dataContainer, uiBattleData);
        this.nextRequestRound = Math.min(end, this.serverMaxRound) + 1;
        return true;
    }

    public boolean decodeAddress(String address) {
        if (Objects.isNull(address) || address.isEmpty()) {
            return false;
        }

        try {
            String[] addressArray = address.split(":");
            this.ip = addressArray[0];
            this.port = Integer.parseInt(addressArray[1]);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean requirePull() {
        if (this.nextRequestRound > this.serverMaxRound) {
            return false;
        }
        return this.curRound == this.nextRequestRound - 1;
    }

    /**
     * 拉取服务器记录的战斗数据
     */
    public static UiBattleData pullServerData(String address, int start, int end) {
        String serverUrl = GlobalConst.HTTP_PREFIX + address + GlobalConst.HTTP_API_URL_PULL;
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(GlobalConst.PULL_START_ROUND, Integer.toString(start));
        paramMap.put(GlobalConst.PULL_END_ROUND, Integer.toString(end));

        String respondData = HttpUtil.sendGetData(serverUrl, paramMap);
        if (Objects.isNull(respondData)) {
            return null;
        }

        JSONObject pullData = JSON.parseObject(respondData);
        String battleDataStr = pullData.getString("battleData");
        return JSON.parseObject(battleDataStr, UiBattleData.class);
    }

    public void setStartRoundMark() {
        this.setCurRound(0);
    }

    public void setNextRoundMark() {
        this.setCurRound(this.curRound + 1);
    }

    public void setLastRoundMark() {
        this.setCurRound(this.curRound - 1);
    }

    /**
     * 设置当前回合数的最终统一接口
     */
    public void setCurRound(int value) {
        if (value < 0 || value > GlobalConst.MAX_ROUND_COUNT) {
            return;
        }

        if (value > this.dataContainer.getMaxRound()) {
            return;
        }

        this.curRound = value;
    }

    public RoundData getCurrentRoundData() {
        return this.dataContainer.getRoundData(this.curRound);
    }

    public void setSelectValue(SelectEnum key, String value) {
        this.inputSelectEnumMap.put(key, value);
    }

    public void clearSelectKey() {
        this.inputSelectEnumMap.clear();
    }

    public void removeSelectKey(SelectEnum key) {
        this.inputSelectEnumMap.remove(key);
    }

    /**
     * 记录用户锁定的位置信息，注意去重
     */
    public void recordLockLocation(int locationMark) {
        if (this.lockLocationList.contains(locationMark)) {
            return;
        }
        this.lockLocationList.add(locationMark);
    }

    public void removeLockLocation(int locationMark) {
        int index = this.lockLocationList.indexOf(locationMark);
        if (index >= 0 && index < this.lockLocationList.size()) {
            this.lockLocationList.remove(index);
        }
    }

    /**
     * 根据“输入”的数据，开始实际检索“关联的位置”
     */
    public void doRetrievalInput() {
        // 只要检索，先清空之前的检索数据
        this.retrievalInputResultMap.clear();

        // 此时没有检索内容，直接返回
        if (this.inputSelectEnumMap.isEmpty()) {
            return;
        }

        List<RoundData> roundDataList = this.dataContainer.getRoundDataList();
        if (Objects.isNull(roundDataList) || roundDataList.isEmpty()) {
            return;
        }

        for (RoundData roundData : roundDataList) {
            List<WarriorFightData> allDataList = roundData.listAllData();
            if (Objects.isNull(allDataList) || allDataList.isEmpty()) {
                continue;
            }

            for (WarriorFightData warriorFightData : allDataList) {
                if (Objects.isNull(warriorFightData)) {
                    continue;
                }

                List<AbstractRecordUnit> resultList = warriorFightData.select();
                if (EmptyUtil.nonEmpty(resultList)) {
                    this.recordRoundSelect(roundData.getRoundMark(), warriorFightData, resultList);
                }
            }
        }
    }

    /**
     * 在text中检索用户输入的“被检索信息”
     */
    public void doSelectInput(String text) {
        // 上来先清空之前的检索记录
        this.retrievalInputTextMap.clear();

        if (Objects.isNull(text) || text.isEmpty()) {
            return;
        }

        if (this.inputSelectEnumMap.isEmpty()) {
            return;
        }

        for (Map.Entry<SelectEnum, String> entry : this.inputSelectEnumMap.entrySet()) {
            String subStr = entry.getValue();
            subStr = (entry.getKey() == SelectEnum.GLOBAL ? "" : entry.getKey().getSelectPrefix()) + subStr;
            List<Integer> resultList = StringUtil.searchSubString(text, subStr);
            CollectionUtil.appendValueUnique(this.retrievalInputTextMap, entry.getKey(), resultList);
        }
    }

    /**
     * 在text中检索“选中的位置信息”对应的“warriorMark”
     */
    public void doSearchLockLocationWarriorMark(String text) {
        // 上来先清空之前的检索记录
        this.selectLockLocationWarriorMarkMap.clear();
        if (EmptyUtil.isEmpty(this.lockLocationList) || StringUtil.isEmpty(text)) {
            return;
        }

        for (Integer locationMark : this.lockLocationList) {
            if (Objects.isNull(locationMark) || locationMark < 0) {
                continue;
            }

            List<WarriorFightData> warriorFightDataList = this.dataContainer.listWarriorDataBy(this.curRound, locationMark);
            if (EmptyUtil.isEmpty(warriorFightDataList)) {
                continue;
            }

            for (WarriorFightData warriorFightData : warriorFightDataList) {
                if (Objects.isNull(warriorFightData)) {
                    continue;
                }
                int warriorMark = warriorFightData.getWarriorMark();
                String subString = FightTextParser.parseWarriorName(warriorMark);
                List<Integer> searchList = StringUtil.searchSubString(text, subString);
                CollectionUtil.appendValueUnique(this.selectLockLocationWarriorMarkMap, locationMark, searchList);
            }
        }
    }

    /**
     * @param resultList 已经检索出来的结果
     */
    private void recordRoundSelect(int roundMark, WarriorFightData warriorFightData, List<AbstractRecordUnit> resultList) {
        if (EmptyUtil.isEmpty(resultList)) {
            return;
        }

        Map<Integer, List<AbstractRecordUnit>> locationRecordMap = this.retrievalInputResultMap.get(roundMark);
        if (Objects.isNull(locationRecordMap)) {
            locationRecordMap = new HashMap<>(16);
            this.retrievalInputResultMap.put(roundMark, locationRecordMap);
        }

        int locationMark = warriorFightData.getLocationMark();
        List<AbstractRecordUnit> recordUnitList = locationRecordMap.get(locationMark);
        if (Objects.isNull(recordUnitList)) {
            recordUnitList = new ArrayList<>();
            locationRecordMap.put(locationMark, recordUnitList);
        }

        // 注意去重
        CollectionUtil.addUnique(recordUnitList, resultList);
    }

    /**
     * 构造所有详情面板的数据
     */
    public String generateDetailInfo() {
        this.sequenceStack.clear();

        // 重新展示锁定位置的详细信息,此处需要排序
        StringBuilder sb = new StringBuilder();
        List<Integer> lockLocationList = UiFightService.getInstance().getLockLocationList();
        if (Objects.isNull(lockLocationList) || lockLocationList.isEmpty()) {
            return null;
        } else {
            List<AbstractRecordUnit> sortList = this.listAttentionOrderRecord();
            if (EmptyUtil.nonEmpty(sortList)) {
                for (AbstractRecordUnit recordUnit : sortList) {
                    sb.append(FightTextParser.parseRecordUnit(recordUnit, updateSequenceNest(recordUnit), this.fightAreaLineSize)).append("\n");
                }
            }
        }
        return sb.toString();
    }

    /**
     * 根据一些条件，列出当前回合“关注的”记录（有序）
     * <p>首先是“锁定的位置”，先筛选所有位置的记录
     * <p>其次是“隐藏无关”，需要筛选，注意是根据{@link AbstractRecordUnit#getNestBeginSequence()}
     * 进行筛选的,因为需要保持一个“嵌套记录”的完整上下文的嵌套结构
     */
    public List<AbstractRecordUnit> listAttentionOrderRecord() {
        List<AbstractRecordUnit> sortList = new ArrayList<>();
        Set<Integer> hadAddSet = new HashSet<>();
        for (Integer locationMark : lockLocationList) {
            // 如果需要“隐藏无关”，需要再次筛选
            if (this.isHideUnrelatedData) {
                List<AbstractRecordUnit> selectResultList = this.listLocationSelectRecord(locationMark, this.curRound);
                if (EmptyUtil.nonEmpty(selectResultList)) {
                    for (AbstractRecordUnit recordUnit : selectResultList) {
                        if (!hadAddSet.contains(recordUnit.getSequence())) {
                            this.filterAdd(recordUnit, sortList);
                            hadAddSet.add(recordUnit.getSequence());
                        }
                        // 如果没有“最外层的序号”，说明当前记录自身就是最外层的记录，不需要再次筛选
                        int nestBeginSequence = recordUnit.getNestBeginSequence();
                        if (nestBeginSequence <= 0) {
                            continue;
                        }

                        AbstractRecordUnit abstractRecordUnit = this.getCurRoundRecordBySequence(nestBeginSequence);
                        AbstractNestRecordUnit nestRecordUnit = (AbstractNestRecordUnit) abstractRecordUnit;
                        int nestEndSequence = nestRecordUnit.getSideSequence();
                        for (int i = nestBeginSequence; i <= nestEndSequence; i++) {
                            if (hadAddSet.contains(i)) {
                                continue;
                            }

                            AbstractRecordUnit unit = this.getCurRoundRecordBySequence(i);
                            if (Objects.isNull(unit)) {
                                continue;
                            }

                            // 嵌套内部只保留"嵌套结构"的记录（注意，自身已经被加进去了）
                            if (nestRecordUnit.getRecordEnum().isNest()) {
                                this.filterAdd(unit, sortList);
                                hadAddSet.add(i);
                            }
                        }
                    }
                }
            } else {
                // 不隐藏，全部展示
                this.listRecordUnit(locationMark, this.curRound).forEach(value -> this.filterAdd(value, sortList));
            }
        }

        // 排序
        if (EmptyUtil.nonEmpty(sortList)) {
            sortList.sort(Comparator.comparingInt(AbstractRecordUnit::getSequence));
        }
        return sortList;
    }

    /**
     * 过滤添加
     */
    private void filterAdd(AbstractRecordUnit unit, List<AbstractRecordUnit> resultList) {
        if (isHideAttributeUnit) {
            if (unit.getRecordEnum() == UiDataEnum.RecordEnum.ATTRIBUTE) {
                return;
            }
        }

        if (!isShowAttrTiming) {
            if (unit.getRecordEnum() == UiDataEnum.RecordEnum.BATTLE_EVENT) {
                return;
            }
        }

        resultList.add(unit);
    }

    /**
     * 更新最新的序号堆栈（嵌套结构）
     *
     * @return recordUnit的“父级嵌套”数量
     */
    private int updateSequenceNest(AbstractRecordUnit recordUnit) {
        if (Objects.isNull(recordUnit)) {
            return 0;
        }

        int size = this.sequenceStack.size();
        boolean isNest = recordUnit.getRecordEnum().isNest();
        if (isNest) {
            AbstractNestRecordUnit nestRecordUnit = (AbstractNestRecordUnit) recordUnit;
            if (nestRecordUnit.isStartRecord()) {
                // 开始的记录,入栈
                this.sequenceStack.push(nestRecordUnit.getSequence());
            } else {
                if (this.sequenceStack.isEmpty()) {
                    return 0;
                }
                this.sequenceStack.pop();
                size = this.sequenceStack.size();
            }
        }
        return size;
    }

    /**
     * 构造指定位置的快照数据
     */
    public String generateSnapshotInfo(int locationMark) {
        List<WarriorFightData> warriorFightDataList = this.dataContainer.listWarriorDataBy(this.curRound, locationMark);
        if (EmptyUtil.isEmpty(warriorFightDataList)) {
            return null;
        }

        // 指定检索快照列表
        Set<Integer> retrievalSet = this.listInputRetrievalSnapshot(locationMark);
        boolean isFilter = EmptyUtil.nonEmpty(retrievalSet);

        // todo：后续做出排序
        // 记录已经选择的数量，如果需要过滤，那么选择的数量达到过滤数量时，就不需要再选择了
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (WarriorFightData warriorFightData : warriorFightDataList) {
            if (Objects.isNull(warriorFightData)) {
                continue;
            }

            Map<Integer, UiWarriorSnapshotData> snapMap = warriorFightData.getUiWarriorSnapshotDataMap();
            if (EmptyUtil.nonEmpty(snapMap)) {
                sb.append("名称：").append(FightTextParser.parseWarriorName(warriorFightData.getWarriorMark())).append("\n");
                for (Map.Entry<Integer, UiWarriorSnapshotData> entry : snapMap.entrySet()) {
                    UiWarriorSnapshotData snapshotData = entry.getValue();
                    if (Objects.isNull(snapshotData)) {
                        continue;
                    }
                    // 需要过滤，且不再列表内
                    if (isFilter && !retrievalSet.contains(snapshotData.getSnapMark())) {
                        continue;
                    }
                    sb.append(FightTextParser.parseSnapshotData(entry.getValue())).append("\n");
                    if (isFilter && ++count >= retrievalSet.size()) {
                        break;
                    }
                }
            }
        }
        return sb.toString();
    }

    /**
     * 当前回合满足“检索条件”的位置列表
     */
    public Set<Integer> listCurRoundRetrievalLocation() {
        Map<Integer, List<AbstractRecordUnit>> recordList = this.retrievalInputResultMap.get(this.curRound);
        if (EmptyUtil.isEmpty(recordList)) {
            return null;
        }
        return recordList.keySet();
    }

    /**
     * 列出所有记录,依据{@code locationMark，roundMark)
     */
    public List<AbstractRecordUnit> listRecordUnit(int locationMark, int roundMark) {
        List<AbstractRecordUnit> resultList = new ArrayList<>();
        RoundData roundData = this.dataContainer.getRoundData(roundMark);
        if (Objects.isNull(roundData)) {
            return resultList;
        }

        List<WarriorFightData> warriorDataList = roundData.listWarriorDataBy(locationMark);
        if (EmptyUtil.isEmpty(warriorDataList)) {
            return resultList;
        }

        for (WarriorFightData warriorFightData : warriorDataList) {
            if (Objects.isNull(warriorFightData)) {
                continue;
            }
            resultList.addAll(warriorFightData.listAllRecordUnit());
        }
        return resultList;
    }

    /**
     * 列出“指定位置，指定回合”下的所有“检索”出的数据
     */
    public List<AbstractRecordUnit> listLocationSelectRecord(int locationMark, int roundMark) {
        Map<Integer, List<AbstractRecordUnit>> locationRecordMap = this.retrievalInputResultMap.get(roundMark);
        if (EmptyUtil.isEmpty(locationRecordMap)) {
            return null;
        }
        return locationRecordMap.get(locationMark);
    }

    /**
     * 获得当前回合指定序号的记录
     */
    public AbstractRecordUnit getCurRoundRecordBySequence(int sequenceId) {
        RoundData roundData = this.getCurrentRoundData();
        if (Objects.isNull(roundData)) {
            return null;
        }

        List<WarriorFightData> warriorFightDataList = roundData.listAllData();
        if (EmptyUtil.isEmpty(warriorFightDataList)) {
            return null;
        }

        for (WarriorFightData warriorFightData : warriorFightDataList) {
            if (Objects.isNull(warriorFightData)) {
                continue;
            }

            AbstractRecordUnit abstractRecordUnit = warriorFightData.getRecordBySequence(sequenceId);
            if (Objects.nonNull(abstractRecordUnit)) {
                return abstractRecordUnit;
            }
        }
        return null;
    }

    /**
     * 获得指定回合指定位置的战士数据
     */
    public List<WarriorFightData> listWarriorData(int roundMark, int locationMark) {
        return this.dataContainer.listWarriorDataBy(roundMark, locationMark);
    }

    /**
     * 获取当前回合指定位置的战士名称列表
     */
    public List<String> listCurRoundWarriorName(int locationMark) {
        List<WarriorFightData> warriorDataList = listWarriorData(this.curRound, locationMark);
        if (EmptyUtil.isEmpty(warriorDataList)) {
            return null;
        }
        return warriorDataList.stream().map(WarriorFightData::getName).collect(Collectors.toList());
    }

    /**
     * 获取当前回合指定位置的战士标识列表
     */
    public List<Integer> listCurRoundWarriorMarkBy(int locationMark) {
        List<WarriorFightData> warriorDataList = listWarriorData(this.curRound, locationMark);
        if (EmptyUtil.isEmpty(warriorDataList)) {
            return null;
        }
        return warriorDataList.stream().map(WarriorFightData::getWarriorMark).collect(Collectors.toList());
    }

    /**
     * 获取当前回合“第一个”战士标识
     */
    public int getCurRoundLocationFirstWarriorMark(int locationMark) {
        List<WarriorFightData> warriorDataList = listWarriorData(this.curRound, locationMark);
        if (EmptyUtil.isEmpty(warriorDataList)) {
            return -1;
        }
        WarriorFightData warriorFightData = warriorDataList.get(0);
        return Objects.isNull(warriorFightData) ? -1 : warriorFightData.getWarriorMark();
    }

    /**
     * 清空指定位置“输入的检索快照列表”
     */
    public void removeInputRetrievalSnapshot(int locationMark) {
        this.locationFilterSnapshotMap.remove(locationMark);
    }

    /**
     * 记录“输入的检索快照列表”
     */
    public void recordInputRetrievalSnapshotList(int locationMark, int[] inputSnapshotArr) {
        if (Objects.isNull(inputSnapshotArr) || inputSnapshotArr.length == 0) {
            return;
        }

        Set<Integer> retrievalSet = this.locationFilterSnapshotMap.get(locationMark);
        if (Objects.isNull(retrievalSet)) {
            retrievalSet = new HashSet<>();
            this.locationFilterSnapshotMap.put(locationMark, retrievalSet);
        }
        Arrays.stream(inputSnapshotArr).forEach(retrievalSet::add);
    }

    /**
     * 获取“输入的检索快照列表”
     */
    public Set<Integer> listInputRetrievalSnapshot(int locationMark) {
        return this.locationFilterSnapshotMap.get(locationMark);
    }

    /**
     * 获取“指定战士标识”在“所有回合”下的所有位置信息
     */
    public Map<Integer, Integer> getRoundLocationByWarriorMark(int warriorMark) {
        return this.dataContainer.getWarriorMarkMap().get(warriorMark);
    }

    /**
     * 记录“指定战士标识”在“指定回合”下的“指定位置”
     */
    public void recordWarriorLocation(int warriorMark, int roundMark, int locationMark) {
        this.dataContainer.recordWarriorLocation(warriorMark, roundMark, locationMark);
    }

    public String getFightNotes() {
        return this.dataContainer.getFightNotes();
    }

    public boolean isMaxRound() {
        return this.curRound == this.serverMaxRound;
    }
}
