package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.view.FightMainPanel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

/**
 * “跳转”按钮的监听器
 *
 * @author liuxuanjie
 * @date 2023/6/26 17:14
 */
public class JumpRoundButtonListener implements ActionListener {
    /**
     * 关联的跳转回合数文本框
     */
    private JTextField jumpRoundText;

    public JumpRoundButtonListener(JTextField jumpRoundText) {
        this.jumpRoundText = jumpRoundText;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 按钮被点击时候执行的代码
        System.out.println("跳转按钮被点击了！");

        // 获取跳转回合数
        String jumpRoundStr = this.jumpRoundText.getText();
        if (Objects.nonNull(jumpRoundStr) && !jumpRoundStr.isEmpty()) {
            int jumpRound = Integer.parseInt(jumpRoundStr);
            UiFightService.getInstance().setCurRound(jumpRound);
        }

        // 跳转回合
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
