package com.skilltool.function.fight.view.listen;

import com.skilltool.function.fight.logic.UiFightService;
import com.skilltool.function.fight.logic.select.SelectEnum;
import com.skilltool.function.fight.view.FightMainPanel;
import com.skilltool.function.fight.view.panel.BattleSelectorPanel;
import com.skilltool.utils.StringUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * "检索"按钮监听器
 *
 * @author liuxuanjie
 * @date 2023/6/25 11:46
 */
public class BattleSelectButtonListener implements ActionListener {
    /**
     * 监听的panel
     */
    private BattleSelectorPanel battleSelectorPanel;

    public BattleSelectButtonListener(BattleSelectorPanel battleSelectorPanel) {
        super();
        this.battleSelectorPanel = battleSelectorPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("检索按钮被点击了！");
        // 先全部清空
        UiFightService.getInstance().clearSelectKey();

        // 先记录下来用户输入的内容
        try {
            String textData = this.battleSelectorPanel.getTextField().getText();
            if (StringUtil.nonEmpty(textData)) {
                UiFightService.getInstance().setSelectValue(SelectEnum.GLOBAL, textData);
            }

            String skillData = this.battleSelectorPanel.getSkillField().getText();
            if (StringUtil.nonEmpty(skillData)) {
                int skillValue = Integer.parseInt(skillData);
                UiFightService.getInstance().setSelectValue(SelectEnum.SKILL, skillData);
            }

            String attrData = this.battleSelectorPanel.getAttrField().getText();
            if (StringUtil.nonEmpty(attrData)) {
                int attrValue = Integer.parseInt(attrData);
                UiFightService.getInstance().setSelectValue(SelectEnum.ATTR, attrData);
            }

            String attributeData = this.battleSelectorPanel.getAttributeField().getText();
            if (StringUtil.nonEmpty(attributeData)) {
                int attributeValue = Integer.parseInt(attributeData);
                UiFightService.getInstance().setSelectValue(SelectEnum.ATTRIBUTE, attributeData);
            }

            String buffData = this.battleSelectorPanel.getBuffField().getText();
            if (StringUtil.nonEmpty(buffData)) {
                int buffValue = Integer.parseInt(buffData);
                UiFightService.getInstance().setSelectValue(SelectEnum.BUFF, buffData);
            }
        } catch (NumberFormatException ex) {
            // 显示错误提示框
            JOptionPane.showMessageDialog(null, "请输入有效的数字！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 检索数据
        UiFightService.getInstance().doRetrievalInput();

        // 检索完之后，刷新ui
        FightMainPanel.getInstance().refreshBattlePanel();
    }
}
