package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * Tower detail information request
 *
 * @author mengyan
 */
public class TowerDetail extends RobotAction {
    public TowerDetail(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("TowerDetail enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("TowerDetail...");
        BattleLevel.BattleLevelDetailRequest.Builder builder = BattleLevel.BattleLevelDetailRequest.newBuilder();
        builder.setLevel(1);
        builder.setType(Battle.BattleType.TOWER_NORMAL_VALUE);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.BATTLE_LEVEL_DETAIL_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("TowerDetail exit...");
    }
}
