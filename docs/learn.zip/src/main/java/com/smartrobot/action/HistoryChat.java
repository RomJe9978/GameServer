package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class HistoryChat extends RobotAction {
    public HistoryChat(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("HistoryChat enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("HistoryChat doExecute...");
        return super.doExecute(input, output);
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("HistoryChat doExit...");
        Chat.ChatHistoryRequest.Builder builder = Chat.ChatHistoryRequest.newBuilder();
        builder.setChatType(Chat.ChatType.WORLD_VALUE);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.CHAT_HISTORY_REQUEST_VALUE, builder));
    }
}
