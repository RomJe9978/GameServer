package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class TeamDungeonInfo extends RobotAction {
    public TeamDungeonInfo(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        TeamDungeon.TeamDungeonInfoRequest.Builder request = TeamDungeon.TeamDungeonInfoRequest.newBuilder();
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.TEAM_DUNGEON_INFO_REQUEST_VALUE, request));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
