package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * Changes the background of chat.
 *
 * @author mengyan
 */
public class ChatBackground extends RobotAction {
    public ChatBackground(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("Private Chat enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Change chat background...");
        Chat.ChatChangeBgRequest.Builder request = Chat.ChatChangeBgRequest.newBuilder();

        Chat.ChatBgInfo.Builder chatBgInfo = Chat.ChatBgInfo.newBuilder();
        chatBgInfo.setChatType(1);
        chatBgInfo.setBackgroundId(1);
        request.setChatBg(chatBgInfo);

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.CHAT_CHANGE_BG_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Login exit...");
    }

}
