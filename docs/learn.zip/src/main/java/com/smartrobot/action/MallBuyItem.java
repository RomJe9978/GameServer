package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;
import org.apache.commons.lang3.RandomUtils;

import java.util.List;
import java.util.Map;

public class MallBuyItem extends RobotAction {
    public MallBuyItem(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("MallBuyItem enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("MallBuyItem doExecute...");

        Mall.MallBuyItemRequest.Builder builder = Mall.MallBuyItemRequest.newBuilder();

        Mall.MallShopInfo shopInfo = this.randomSelectShop();
        builder.setMallType(shopInfo.getMallType());
        builder.setMallTemplateId(this.randomSelectItem(shopInfo));
        builder.setAmount(1);

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MALL_BUY_ITEM_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("MallBuyItem doExit...");
    }

    private Mall.MallShopInfo randomSelectShop() {
        Map<Integer, Object> shops = this.getRobot().getMallShops();
        int size = shops.keySet().size();
        int selected = RandomUtils.nextInt(0, size - 1);
        Object object = shops.keySet().toArray()[selected];
        return (Mall.MallShopInfo) object;
    }

    private int randomSelectItem(Mall.MallShopInfo shopInfo) {
        List<Mall.MallItemInfo> items = shopInfo.getMallItemsList();
        int size = items.size();
        int selected = RandomUtils.nextInt(0, size - 1);
        return items.get(selected).getTemplateId();
    }
}
