package com.smartrobot.action;


import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class Draw extends RobotAction {
    public Draw(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
        System.out.println("Draw.doEnter ...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Draw.doExecute ...");
        LuckyDraw.LuckyDrawRequest.Builder request = LuckyDraw.LuckyDrawRequest.newBuilder();
        request.setMulti(true);
        int subPoolId = RandUtil.choice(this.getRobot().poolInfoMap.keySet().toArray(new Integer[0]));
        request.setSubPoolId(subPoolId);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.GUILD_JOIN_APPLY_REQUEST_VALUE, request));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
        System.out.println("JoinGuild.doExit ...");
    }
}

