package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class ChallengeMission extends RobotAction {
    public ChallengeMission(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {

        Log.getNetworkLogger().info("ChallengeMission.doExecute, missions: {}", this.getRobot().getMissions());

        if (this.getRobot().getMissions().size() > 0) {
            long missionId = (Long) this.getRobot().getMissions().keySet().toArray()[0];
            Mission.MissionChallengeStageRequest.Builder request = Mission.MissionChallengeStageRequest.newBuilder();
            request.setMissionId(missionId);
//            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MISSION_CHALLENGE_STAGE_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
