package com.smartrobot.action;


import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * @author mengyan
 */
public class Idle extends RobotAction {
    private Integer times;
    private Integer maxTimes;

    public Idle(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
        this.times = 0;
        this.maxTimes = 100;

    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("idle enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        if (this.times >= this.maxTimes) {
            this.times = 0;
            this.maxTimes = (int) (50 + Math.random() * 100);
            System.out.println("idle finished.");
            return ControllerRunningStatus.Finished;

        } else {
            System.out.println("idling...");
            this.times++;
            return ControllerRunningStatus.Running;
        }
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("idle exit...");
    }
}
