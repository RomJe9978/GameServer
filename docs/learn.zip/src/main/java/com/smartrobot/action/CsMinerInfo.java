package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class CsMinerInfo extends RobotAction {
    public CsMinerInfo(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("CsMiner info enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("CsMiner info execute...");
        Miner.MinerInfoRequest.Builder request = Miner.MinerInfoRequest.newBuilder();
        Miner.MinerInfo minerInfo = (Miner.MinerInfo) RandUtil.choice(this.getRobot().getMinerNodeList().toArray(new Object[0]));
        request.setMinerId(minerInfo.getMinerId());
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MINER_NODE_LIST_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("CsMiner node list exit...");
    }

}
