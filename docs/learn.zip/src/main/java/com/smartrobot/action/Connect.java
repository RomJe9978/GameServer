package com.smartrobot.action;

import com.smartrobot.Robot;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class Connect extends RobotAction {
    private int MAX_WAITING_TIMES = 10;

    private int waitingConnect = 0;

    public Connect(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        if (this.getRobot().getState() == Robot.State.NONE) {
            this.waitingConnect = 0;
            System.out.println("Connect enter...");
        }
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        if (this.getRobot().getState() == Robot.State.NONE) {
            System.out.println("Connecting...");
            this.getRobot().setState(Robot.State.CONNECTING);
            boolean success = this.getRobot().connect();
            if (!success) {
                this.getRobot().setState(Robot.State.NONE);
            }
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Connect exit...");
    }
}
