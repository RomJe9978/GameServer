package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class HeroAddStarExp extends RobotAction {
    public HeroAddStarExp(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        Log.getJengineLogger().info("HeroAddStarExp doEnter ...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        Log.getJengineLogger().info("HeroAddStarExp doExecute ...");

        if (this.getRobot().getHeroes().size() > 0) {
            long heroId = (Long) this.getRobot().getHeroes().keySet().toArray()[0];
            Hero.HeroIncreaseStarExpRequest.Builder request = Hero.HeroIncreaseStarExpRequest.newBuilder();
            request.setHeroId(heroId);
            request.setIndex(RandUtil.randInt(1, 3));
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.HERO_INCREASE_STAR_EXP_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        Log.getJengineLogger().info("HeroAddStarExp doExit ...");
    }
}
