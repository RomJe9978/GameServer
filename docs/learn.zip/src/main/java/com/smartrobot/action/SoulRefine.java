package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.ArrayList;

public class SoulRefine extends RobotAction {
    public SoulRefine(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("SoulRefine.doEnter...");
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("SoulRefine.doExecute...");
        if (this.getRobot().getEquippedSouls().size() > 0) {
            Soul.SoulRefineRequest.Builder request = Soul.SoulRefineRequest.newBuilder();
            request.setSoulId((Long) this.getRobot().getEquippedSouls().keySet().toArray()[0]);
            request.setLockedUniqueAttribute(false);
            request.addAllLockedIndexes(new ArrayList<>());
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.SOUL_REFINE_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
