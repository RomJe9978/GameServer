package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class WorldBossChallenge extends RobotAction {
    public WorldBossChallenge(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("WorldBossChallenge enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("WorldBoss Challenging...");
        WorldBoss.WorldBossChallengeRequest.Builder request = WorldBoss.WorldBossChallengeRequest.newBuilder();
        request.setIsMock(true);
        if (this.getRobot().getHeroes().size() > 0) {
            request.addAllHeros(this.getRobot().getHeroes().keySet());
        }

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.WORLD_BOSS_CHALLENGE_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("WorldBossChallenge exit...");
    }

}
