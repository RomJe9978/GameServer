package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * Rank request
 *
 * @author mengyan
 */
public class RankRequest extends RobotAction {
    public RankRequest(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("Rank enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Rank...");
        Rank.RankInfoRequest.Builder builder = Rank.RankInfoRequest.newBuilder();
        builder.setRankType(Rank.RankType.GVGOccupyCityScore_VALUE);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.RANK_INFO_REQUEST_VALUE, builder));


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("TowerBattle exit...");
    }
}
