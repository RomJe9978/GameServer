package com.smartrobot.action;

import com.golden.protocol.*;
import com.golden.protocol.Soul.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class SoulPutOn extends RobotAction {
    public SoulPutOn(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        Log.getJengineLogger().info("SoulPutOn.doExecute, heroes: {}, unequippedSouls: {}",
                this.getRobot().getHeroes(), this.getRobot().getUnequippedSouls());

        if (this.getRobot().getHeroes().size() > 0 && this.getRobot().getUnequippedSouls().size() > 0) {
            SoulPutonRequest.Builder request = SoulPutonRequest.newBuilder();
            request.setHeroId((Long) this.getRobot().getHeroes().keySet().toArray()[0]);
            request.setSoulId((Long) this.getRobot().getUnequippedSouls().keySet().toArray()[0]);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.SOUL_PUTON_REQUEST_VALUE, request));
        }

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }

    @Override
    protected ControllerRunningStatus doTick(Object input, Object output) {
        return super.doTick(input, output);
    }
}
