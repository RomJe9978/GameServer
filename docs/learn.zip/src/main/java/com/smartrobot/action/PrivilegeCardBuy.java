package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class PrivilegeCardBuy extends RobotAction {
    public PrivilegeCardBuy(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("PrivilegeCardBuy enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("PrivilegeCardBuy...");
        MonthlyCard.PrivilegeCardBuyRequest.Builder builder = MonthlyCard.PrivilegeCardBuyRequest.newBuilder();
        builder.setTemplateId(1);

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.PRIVILEGE_CARD_BUY_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("PrivilegeCardBuy exit...");
    }

}
