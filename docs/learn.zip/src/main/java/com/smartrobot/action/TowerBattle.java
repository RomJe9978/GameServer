package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.Map;

/**
 * Tower noraml battle request
 *
 * @author mengyan
 */
public class TowerBattle extends RobotAction {
    public TowerBattle(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("TowerBattle enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("TowerBattle...");
        Tower.TowerLevelBattleRequest.Builder builder = Tower.TowerLevelBattleRequest.newBuilder();
        builder.setType(Battle.BattleType.TOWER_NORMAL_VALUE);

        Map<Long, Object> heroIds = this.getRobot().getHeroes();
        if (heroIds != null) {
            builder.addAllHeros(heroIds.keySet());
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.TOWER_LEVEL_BATTLE_REQUEST_VALUE, builder));
        }


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("TowerBattle exit...");
    }
}
