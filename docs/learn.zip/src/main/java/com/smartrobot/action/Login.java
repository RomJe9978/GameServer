package com.smartrobot.action;


import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.Robot;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * @author mengyan
 */
public class Login extends RobotAction {
    public Login(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        if (this.getRobot().getState() == Robot.State.CONNECTED) {
            System.out.println("Login enter...");
        }
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        if (this.getRobot().getState() != Robot.State.LOGINING) {
            System.out.println("Logining...");
            this.getRobot().setState(Robot.State.LOGINING);
            com.golden.protocol.Login.LoginRequest.Builder builder = com.golden.protocol.Login.LoginRequest.newBuilder();
            builder.setClientId(this.getRobot().getClientId());
            builder.setDeviceId(RandUtil.randInt(100000) + "");
            builder.setPlatform("Android");
            builder.setServerId(1);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.LOGIN_REQUEST_VALUE, builder));
            return ControllerRunningStatus.Finished;
        }

        return ControllerRunningStatus.Running;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Login exit...");
    }


}
