package com.smartrobot.action;

import com.golden.protocol.Friend;
import com.golden.protocol.Msg;
import com.golden.protocol.Player;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.ArrayList;
import java.util.List;

public class ApplyFriend extends RobotAction {
    public ApplyFriend(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        List<Long> applyIds = new ArrayList<>();
        for (Object object : this.getRobot().getRecommendedFriendList()) {
            Player.PlayerSimpleInfo info = (Player.PlayerSimpleInfo) object;
            applyIds.add(info.getPlayerId());
        }
        Friend.FriendApplyToBeFriendRequest.Builder request = Friend.FriendApplyToBeFriendRequest.newBuilder();
        request.addAllFriendId(applyIds);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.FRIEND_APPLY_TO_BE_FRIEND_REQUEST_VALUE, request));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
