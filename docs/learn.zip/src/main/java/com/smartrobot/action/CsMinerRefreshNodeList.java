package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.List;

public class CsMinerRefreshNodeList extends RobotAction {
    public CsMinerRefreshNodeList(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("CsMiner refresh node list enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        Miner.MinerRefreshNodeListRequest.Builder request = Miner.MinerRefreshNodeListRequest.newBuilder();
        List<Object> selectObjects = RandUtil.sample(this.getRobot().getMinerNodeList(), 10);
        for (Object object : selectObjects) {
            Miner.MinerInfo info = (Miner.MinerInfo) object;
            request.addMinerIds(info.getMinerId());
        }
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MINER_REFRESH_NODE_LIST_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("CsMiner node list exit...");
    }

}
