package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class CsMinerTimeInfo extends RobotAction {
    public CsMinerTimeInfo(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("CsMiner TimeInfo enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("World Chating...");
        Miner.MinerTimeInfoRequest.Builder request = Miner.MinerTimeInfoRequest.newBuilder();

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MINER_TIME_INFO_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("CsMiner TimeInfo exit...");
    }

}
