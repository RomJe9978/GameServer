package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class HeroRefine extends RobotAction {
    public HeroRefine(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        if (this.getRobot().getHeroes().size() > 0) {
            long heroId = (Long) this.getRobot().getHeroes().keySet().toArray()[0];
            Hero.HeroRefineRequest.Builder request = Hero.HeroRefineRequest.newBuilder();
            request.setHeroId(heroId);
            request.setIndex(RandUtil.randInt(1, 4));
            request.setTimes(10);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.HERO_REFINE_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
