package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class ItemUse extends RobotAction {
    public ItemUse(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("ItemUse enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("ItemUse doExecute...");

        Item.PropsUseRequest.Builder builder = Item.PropsUseRequest.newBuilder();
        builder.setPropsId(38643353889276928L);
        builder.setCount(1);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.PROPS_USE_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("ItemUse doExit...");
    }
}
