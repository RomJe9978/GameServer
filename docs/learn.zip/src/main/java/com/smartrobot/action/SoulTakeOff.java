package com.smartrobot.action;

import com.golden.protocol.*;
import com.golden.protocol.Soul.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class SoulTakeOff extends RobotAction {
    public SoulTakeOff(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        if (this.getRobot().getHeroes().size() > 0 && this.getRobot().getEquippedSouls().size() > 0) {
            SoulTakeoffRequest.Builder request = SoulTakeoffRequest.newBuilder();
            request.setHeroId((Long) this.getRobot().getHeroes().keySet().toArray()[0]);
            request.addAllSoulIds(this.getRobot().getEquippedSouls().keySet());
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.SOUL_TAKEOFF_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }

    @Override
    protected ControllerRunningStatus doTick(Object input, Object output) {
        return super.doTick(input, output);
    }
}
