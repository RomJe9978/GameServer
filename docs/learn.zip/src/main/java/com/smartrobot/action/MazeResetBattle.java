package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * Tower noraml battle request
 *
 * @author mengyan
 */
public class MazeResetBattle extends RobotAction {
    public MazeResetBattle(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("MazeResetBattle enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("MazeResetBattle...");
        Maze.MazeResetBattleRequest.Builder builder = Maze.MazeResetBattleRequest.newBuilder();
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MAZE_RESET_BATTLE_REQUEST_VALUE, builder));


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("MazeResetBattle exit...");
    }
}
