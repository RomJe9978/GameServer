package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class WorldBossRecord extends RobotAction {
    public WorldBossRecord(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("WorldBossRecord enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("WorldBoss record...");
        WorldBoss.WorldBossRecordRequest.Builder request = WorldBoss.WorldBossRecordRequest.newBuilder();
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.WORLD_BOSS_RECORD_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("WorldBossRecord exit...");
    }

}
