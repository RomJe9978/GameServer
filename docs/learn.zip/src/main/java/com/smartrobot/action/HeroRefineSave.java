package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class HeroRefineSave extends RobotAction {
    public HeroRefineSave(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        Log.getJengineLogger().info("HeroRefineSave.doEnter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        Log.getJengineLogger().info("HeroRefineSave.doExecute...");

        if (this.getRobot().getHeroes().size() > 0) {
            long heroId = (Long) this.getRobot().getHeroes().keySet().toArray()[0];
            Hero.HeroRefineSaveRequest.Builder request = Hero.HeroRefineSaveRequest.newBuilder();
            request.setHeroId(heroId);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.HERO_REFINE_SAVE_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        Log.getJengineLogger().info("HeroRefineSave.doExit...");
    }
}
