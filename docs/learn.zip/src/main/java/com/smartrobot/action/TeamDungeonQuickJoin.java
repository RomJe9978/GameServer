package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class TeamDungeonQuickJoin extends RobotAction {
    public TeamDungeonQuickJoin(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("TeamDungeonQuickJoin.doEnter...");
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        TeamDungeon.TeamDungeonQuickJoinRequest.Builder request = TeamDungeon.TeamDungeonQuickJoinRequest.newBuilder();
        request.setId(this.getRobot().getDungeonId());
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.TEAM_DUNGEON_QUICK_JOIN_REQUEST_VALUE, request));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
