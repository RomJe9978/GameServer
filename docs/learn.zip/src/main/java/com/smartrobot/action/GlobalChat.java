package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class GlobalChat extends RobotAction {
    public GlobalChat(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("Global Chat enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Global Chating...");
        Chat.ChatRequest.Builder builder = Chat.ChatRequest.newBuilder();
        builder.setChatType(Chat.ChatType.GLOBAL_VALUE);
        builder.setChatContent("a global せいえきdd chat message from robot");
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.CHAT_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Login exit...");
    }

}
