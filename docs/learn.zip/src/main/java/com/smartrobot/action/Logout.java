package com.smartrobot.action;

import com.smartrobot.Robot;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class Logout extends RobotAction {


	public Logout(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
	}

	@Override
	protected void doEnter(Object input) {
		if (this.getRobot().getState() == Robot.State.RUNNING) {
			System.out.println("Logout enter...");
			this.getRobot().disconnect();
			this.getRobot().setState(Robot.State.NONE);
		}
	}
	
	@Override
	protected ControllerRunningStatus doExecute(Object input, Object output) {
		return ControllerRunningStatus.Finished;
	}
	
	@Override
	protected void doExit(Object inpout, ControllerRunningStatus status) {
		System.out.println("Logout exit...");
	}
	
	
}
