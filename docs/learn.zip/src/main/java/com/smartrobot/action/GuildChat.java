package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class GuildChat extends RobotAction {
    public GuildChat(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("Guild Chat enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Guild Chating...");
        Chat.ChatRequest.Builder builder = Chat.ChatRequest.newBuilder();
        builder.setChatType(Chat.ChatType.GUILD_VALUE);
        builder.setTargetId(this.getRobot().getGuildId());
        builder.setChatContent("This is a guild chat message from robot");

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.CHAT_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Guild chat exit...");
    }

}
