package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.Set;

public class PrivateChat extends RobotAction {
    public PrivateChat(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("Private Chat enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("Private Chating...");
        Set<Long> privateChatterId = this.getRobot().getPrivateChatter();

        for (Long id : privateChatterId) {
            Chat.ChatRequest.Builder builder = Chat.ChatRequest.newBuilder();
            builder.setChatType(Chat.ChatType.PRIVATE_VALUE);
            builder.setTargetId(id);
            builder.setChatContent("This is a private chat message from robot");

            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.CHAT_REQUEST_VALUE, builder));
        }

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("Login exit...");
    }

}
