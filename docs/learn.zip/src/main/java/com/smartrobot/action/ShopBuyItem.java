package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;
import org.apache.commons.lang3.RandomUtils;

import java.util.List;
import java.util.Map;

public class ShopBuyItem extends RobotAction {
    public ShopBuyItem(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("ShopBuyItem enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("ShopBuyItem doExecute...");

        Shop.ShopBuyItemRequest.Builder builder = Shop.ShopBuyItemRequest.newBuilder();

        Shop.ShopInfo shopInfo = this.randomSelectShop();
        builder.setShopType(shopInfo.getShopType());
        builder.setShopItemId(this.randomSelectItem(shopInfo));
        builder.setCount(1);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.SHOP_BUY_ITEM_REQUEST_VALUE, builder));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("ShopBuyItem doExit...");
    }

    private Shop.ShopInfo randomSelectShop() {
        Map<Integer, Object> shops = this.getRobot().getShops();
        int size = shops.keySet().size();
        int selected = RandomUtils.nextInt(0, size - 1);
        Object object = shops.keySet().toArray()[selected];
        return (Shop.ShopInfo) object;
    }

    private long randomSelectItem(Shop.ShopInfo shopInfo) {
        List<Shop.ShopItemInfo> items = shopInfo.getItemsList();
        int size = items.size();
        int selected = RandomUtils.nextInt(0, size - 1);
        return items.get(selected).getShopItemId();
    }
}
