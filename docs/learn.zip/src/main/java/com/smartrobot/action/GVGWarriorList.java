package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * Tower noraml battle request
 *
 * @author mengyan
 */
public class GVGWarriorList extends RobotAction {
    public GVGWarriorList(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("MazeBattle enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("MazeBattle...");
        GVG.GVGWarriorInfoRequest.Builder builder = GVG.GVGWarriorInfoRequest.newBuilder();

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.GV_G_WARRIOR_INFO_REQUEST_VALUE, builder));


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("MazeBattle exit...");
    }
}
