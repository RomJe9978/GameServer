package com.smartrobot.action;

import com.golden.protocol.Attribute.*;
import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.ArrayList;
import java.util.List;

public class CsMinerNodeChallenge extends RobotAction {
    public CsMinerNodeChallenge(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("CsMiner challenge enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("CsMiner challenge execute...");
        Object object = this.getRobot().getLastQueryMinerInfo();
        if (object != null) {
            Miner.MinerInfo lastQueryMinerInfo = (Miner.MinerInfo) this.getRobot().getLastQueryMinerInfo();
            if (lastQueryMinerInfo != null
                    && lastQueryMinerInfo.getOccupierInfo() != null
                    && lastQueryMinerInfo.getOccupierInfo().getBasic().getPlayerId() != this.getRobot().getOId().getId()) {
                Miner.MinerChallengeRequest.Builder request = Miner.MinerChallengeRequest.newBuilder();
                request.setMinerId(lastQueryMinerInfo.getMinerId());
                request.addAllHeroes(getHeroIds(lastQueryMinerInfo));
                request.setOccupiedTimestamp(lastQueryMinerInfo.getOccupiedTimestamp());
                request.setOccupierPlayerId(lastQueryMinerInfo.getOccupierInfo().getBasic().getPlayerId());
                this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MINER_CHALLENGE_REQUEST_VALUE, request));
            }
        }
        return ControllerRunningStatus.Finished;
    }

    private List<Long> getHeroIds(Miner.MinerInfo minerInfo) {
        List<Long> heroIds = new ArrayList<>();
        AttributeInfo attributeInfo = minerInfo.getHeroRequiredCond();
        for (Object object : this.getRobot().getHeroInfoList()) {
            Hero.HeroInfo heroInfo = (Hero.HeroInfo) object;
            if (heroInfo.getStageInfo().getStage() >= attributeInfo.getType()) {
                heroIds.add(heroInfo.getHeroId());
            }
        }
        return heroIds;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("CsMiner node list exit...");
    }

}
