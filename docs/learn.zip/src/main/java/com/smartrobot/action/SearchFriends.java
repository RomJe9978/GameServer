package com.smartrobot.action;

import com.golden.protocol.Friend;
import com.golden.protocol.Msg;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * @author leiyunfei
 * @time 2020-07-13 15:27
 */
public class SearchFriends extends RobotAction {

	public SearchFriends(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
	}

	@Override
	protected void doEnter(Object input) {
		super.doEnter(input);
	}

	@Override
	protected ControllerRunningStatus doExecute(Object input, Object output) {
		Friend.FriendSearchFriendsRequest.Builder builder = Friend.FriendSearchFriendsRequest.newBuilder();
		Log.getJengineLogger().info("send FriendSearchFriendsRequest");
		this.getRobot().send(TcpPacket.valueOf(Msg.opcode.FRIEND_SEARCH_FRIENDS_REQUEST_VALUE, builder));
		return ControllerRunningStatus.Finished;
	}

	@Override
	protected void doExit(Object inpout, ControllerRunningStatus status) {
		super.doExit(inpout, status);
	}
}
