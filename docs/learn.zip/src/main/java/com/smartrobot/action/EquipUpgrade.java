package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class EquipUpgrade extends RobotAction {
    public EquipUpgrade(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("EquipUpgrade enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("EquipUpgrade doExecute...");

        if (this.getRobot().getUnwornEquips().size() > 0) {
            Equip.EquipUpgradeRequest.Builder builder = Equip.EquipUpgradeRequest.newBuilder();
            builder.setEquipId((Long) this.getRobot().getUnwornEquips().keySet().toArray()[0]);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.EQUIP_UPGRADE_REQUEST_VALUE, builder));
        }

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("EquipUpgrade doExit...");
    }
}
