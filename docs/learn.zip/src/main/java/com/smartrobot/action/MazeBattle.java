package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.Map;

/**
 * Tower noraml battle request
 *
 * @author mengyan
 */
public class MazeBattle extends RobotAction {
    public MazeBattle(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("MazeBattle enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("MazeBattle...");
        Maze.MazeChallengeRequest.Builder builder = Maze.MazeChallengeRequest.newBuilder();
        builder.setPointPos(1);

        Map<Long, Object> heroIds = this.getRobot().getHeroes();
        if (heroIds != null) {
            builder.addAllHeroIds(heroIds.keySet());
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MAZE_CHALLENGE_REQUEST_VALUE, builder));
        }


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("MazeBattle exit...");
    }
}
