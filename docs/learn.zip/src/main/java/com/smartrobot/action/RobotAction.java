package com.smartrobot.action;

import com.smartrobot.Robot;
import com.smartrobot.ai.action.ActionNode;
import com.smartrobot.ai.base.BtsNode;


public class RobotAction extends ActionNode {
	protected Robot robot;
	
	public RobotAction(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
	}
	
	protected Robot getRobot() {
		return (Robot)this.getAgent();
	}

}
