package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.RandUtil;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class CreateGuild extends RobotAction {
    public CreateGuild(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
        System.out.println("CreateGuild.doEnter ...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("CreateGuild.doExecute ...");
        Guild.GuildCreateRequest.Builder request = Guild.GuildCreateRequest.newBuilder();
        request.setName("No." + RandUtil.randInt());
        request.setLogo(1);
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.GUILD_CREATE_REQUEST_VALUE, request));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
        System.out.println("CreateGuild.doExit ...");
    }
}
