package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

import java.util.Map;

public class StoryEmailReply extends RobotAction {
    public StoryEmailReply(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("StoryEmailReply enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("StoryEmailReply...");
        StoryEmail.StoryEmailReplyRequest.Builder builder = StoryEmail.StoryEmailReplyRequest.newBuilder();
        builder.setChooseIndex(0);


        Map<Long, Object> ids = this.getRobot().getStoryEmails();
        if (ids.size() > 0) {
            Long id = (Long) ids.keySet().toArray()[0];
            builder.setStoryEmailId(id);
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.STORY_EMAIL_REPLY_REQUEST_VALUE, builder));
        }


        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("StoryEmailReply exit...");
    }
}
