package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class SoulPutOnAll extends RobotAction {
    public SoulPutOnAll(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("SoulPutOnAll.doEnter ...");
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("SoulPutOnAll.doExecute ...");
        if (this.getRobot().getHeroes().size() > 0 && this.getRobot().getUnequippedSouls().size() > 0) {
            Soul.SoulPutonAllRequest.Builder request = Soul.SoulPutonAllRequest.newBuilder();
            request.setHeroId((Long) this.getRobot().getHeroes().keySet().toArray()[0]);
            request.addAllSoulIds(this.getRobot().getUnequippedSouls().keySet());
            this.getRobot().send(TcpPacket.valueOf(Msg.opcode.SOUL_PUTON_ALL_REQUEST_VALUE, request));
        }
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
