package com.smartrobot.action;

import com.golden.protocol.Friend;
import com.golden.protocol.Msg;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

/**
 * @author leiyunfei
 * @time 2020-07-11 14:10
 */
public class ListFriendAction extends RobotAction {
    public ListFriendAction(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        super.doEnter(input);
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        Friend.FriendListRequest.Builder builder = Friend.FriendListRequest.newBuilder();
        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.FRIEND_LIST_REQUEST_VALUE, builder));
        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        super.doExit(inpout, status);
    }
}
