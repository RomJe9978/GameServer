package com.smartrobot.action;

import com.golden.protocol.*;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class CsMinerNodeList extends RobotAction {
    public CsMinerNodeList(BtsNode parent, Boolean useWeight) {
        super(parent, useWeight);
    }

    @Override
    protected void doEnter(Object input) {
        System.out.println("CsMiner node list enter...");
    }

    @Override
    protected ControllerRunningStatus doExecute(Object input, Object output) {
        System.out.println("CsMiner node listing...");
        Miner.MinerNodeListRequest.Builder request = Miner.MinerNodeListRequest.newBuilder();

        this.getRobot().send(TcpPacket.valueOf(Msg.opcode.MINER_NODE_LIST_REQUEST_VALUE, request));

        return ControllerRunningStatus.Finished;
    }

    @Override
    protected void doExit(Object inpout, ControllerRunningStatus status) {
        System.out.println("CsMiner node list exit...");
    }

}
