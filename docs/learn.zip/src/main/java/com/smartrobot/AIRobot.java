package com.smartrobot;

import com.smartrobot.action.*;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.conditions.*;
import com.smartrobot.ai.factory.BtsNodeFactory;
import com.smartrobot.cfg.RobotConfig;
import io.netty.channel.EventLoopGroup;

/**
 * The AI implementation of smart robot
 *
 * @author mengyan
 */
public class AIRobot extends Robot {
    private BtsNode root;
    private RobotConfig robotConfig = null;

    /**
     * Share EventLoopGroup
     *
     * @param group
     * @param clientId
     * @param host
     * @param port
     * @param autoReconncet
     */
    public AIRobot(EventLoopGroup group, String clientId, String host, int port, boolean autoReconncet) {
        super(group, clientId, host, port, autoReconncet);
    }

    public void create(RobotConfig robotConfig) {
        this.robotConfig = robotConfig;
        BtsNode root = BtsNodeFactory.createSelectorNode(null);
        BtsNodeFactory.createActionNode(Connect.class, root).setAgent(this).addExternalCondtions(new Or(new IsNoneState(this), new IsConnecting(this)));

        BtsNode loginOrLogic = BtsNodeFactory.createSelectorNode(root);
        BtsNodeFactory.createActionNode(Login.class, loginOrLogic).setAgent(this).addExternalCondtions(new IsConnected(this));

        BtsNode sequence = BtsNodeFactory.createSequenceNode(loginOrLogic);
        /*
        BtsNodeFactory.createActionNode(RankRequest.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(GlobalChat.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(WorldBossRecord.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(GVGWarriorList.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(MazeBattle.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(MazeResetBattle.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SearchFriends.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(GuildList.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNode randomSelector = BtsNodeFactory.createRandomSelectorNode(sequence);

        BtsNodeFactory.createActionNode(Idle.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(HistoryChat.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(PrivateChat.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(GuildChat.class, randomSelector).setAgent(this).addExternalCondtions(new IsJoinGuild(this));
        BtsNodeFactory.createActionNode(ChatBackground.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SearchGuild.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(CreateGuild.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(JoinGuild.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(PlayerUpdateSign.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(PlayerRename.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(TowerDetail.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(WorldBossChallenge.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(StoryEmailReply.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(ChallengeMission.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SoulPutOn.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SoulPutOnAll.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SoulTakeOff.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SoulRefine.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(ItemUse.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(TowerBattle.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(EquipEnhance.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(EquipRune.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(EquipUpgrade.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(ListFriendAction.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(SearchFriends.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(ApplyFriend.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(HeroAddStarExp.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(HeroUpgradeStar.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(HeroUpgradeStar.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(HeroRefine.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(HeroRefineSave.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNode sequenceNode1 = BtsNodeFactory.createSequenceNode(randomSelector);
        BtsNodeFactory.createActionNode(MissionIdleQuery.class, sequenceNode1).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(MissionIdlePickUp.class, sequenceNode1).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNode sequenceNode2 = BtsNodeFactory.createSequenceNode(randomSelector);
        BtsNodeFactory.createActionNode(TreasureList.class, sequenceNode2).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(TreasureUpgrade.class, sequenceNode2).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNodeFactory.createActionNode(TaskList.class, randomSelector).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        BtsNode sequenceInRandom = BtsNodeFactory.createSequenceNode(randomSelector);
        BtsNodeFactory.createActionNode(ShopBuyItem.class, sequenceInRandom).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        */

        BtsNode sequenceNode = BtsNodeFactory.createRandomSelectorNode(sequence);
        BtsNodeFactory.createActionNode(CsMinerTimeInfo.class, sequenceNode).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(CsMinerNodeList.class, sequenceNode).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(CsMinerInfo.class, sequenceNode).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(CsMinerRefreshNodeList.class, sequenceNode).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        BtsNodeFactory.createActionNode(CsMinerNodeChallenge.class, sequenceNode).setAgent(this).addExternalCondtions(new IsLoggedin(this));

        if (this.robotConfig.getWatchDogMode() == 1) {
            BtsNodeFactory.createActionNode(Logout.class, sequence).setAgent(this).addExternalCondtions(new IsLoggedin(this));
        }

        this.root = root;
    }

    public void tick() {
        if (this.robotConfig != null) {
            if (this.root.checkCondition(this.robotConfig)) {
                this.root.tick(this.robotConfig, null);
            }
        }
    }

}
