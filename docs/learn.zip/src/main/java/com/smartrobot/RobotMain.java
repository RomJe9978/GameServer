package com.smartrobot;

import com.golden.protocol.*;
import com.jengine.Jengine;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.io.tcp.TcpPacketDispatcher;
import com.jengine.thread.DefaultThreadPool;
import com.smartrobot.cfg.RobotConfig;
import com.smartrobot.cfg.SmartRobotConfig;
import com.smartrobot.handler.*;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import org.apache.commons.configuration2.YAMLConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class RobotMain {
    private List<String> clientIds = new ArrayList<>();
    private RobotConfig robotConfig = null;
    private ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(10);

    public RobotMain() {
        try {
            this.init();
            this.loadClientIds();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        RobotMain robotMain = new RobotMain();
        robotMain.start();
    }

    public void addPeriodTask(Runnable command, long period) {
        this.executor.scheduleAtFixedRate(command, 1 * 1000, period, TimeUnit.MILLISECONDS);
    }

    public void start() {
        if (this.robotConfig.getWatchDogMode() == 1) {
            for (String serverIp : this.robotConfig.getWatchServerList()) {
                this.startRobots(serverIp);
            }
        } else {
            this.startRobots(this.robotConfig.getServerIp());
        }
    }

    private void startRobots(String serverIp) {
        String[] hostIp = serverIp.split(":");
        String host = hostIp[0];
        String ip = hostIp[1];

        SmartRobotConfig newRobotConfig = new SmartRobotConfig();
        newRobotConfig.setServerIp(host);
        newRobotConfig.setPort(robotConfig.getPort());
        newRobotConfig.setWatchDogMode(robotConfig.getWatchDogMode());

        EventLoopGroup group = new NioEventLoopGroup();

        for (int i = robotConfig.getFrom(); i < robotConfig.getTo(); i++) {
            final AIRobot robot = new AIRobot(group, this.clientIds.get(i), host, Integer.parseInt(ip), false);
            robot.create(newRobotConfig);

            this.addPeriodTask(() -> {
                try {
                    if (robot.getState() == Robot.State.RUNNING) {
                        System.out.println("tick");
                        Misc.HeartbeatRequest.Builder request = Misc.HeartbeatRequest.newBuilder();
                        robot.send(TcpPacket.valueOf(Msg.opcode.HEARTBEAT_REQUEST_VALUE, request));
                    }
                } catch (Exception e) {

                }
            }, 1 * 1000);


            this.addPeriodTask(() -> {
                try {
                    robot.tick();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, 10 * 1000);
        }
    }

    private boolean init() throws FileNotFoundException, ConfigurationException {
        // load configuration.
        YAMLConfiguration config = new YAMLConfiguration();
        config.read(new FileInputStream("config.yaml"));

        this.robotConfig = new RobotConfig();
        this.robotConfig.setServerIp(config.getString("server.host"));
        this.robotConfig.setClientIdFile(config.getString("client.idFile"));
        this.robotConfig.setFrom(config.getInt("client.from"));
        this.robotConfig.setTo(config.getInt("client.to"));
        this.robotConfig.setWatchDogMode(config.getInt("client.watchDogMode"));
        this.robotConfig.setWatchServerList(config.getString("client.watchServerList"));
        this.robotConfig.setSentryDSN(config.getString("alert.sentryDSN"));


        Jengine.setLogicExecutor(new DefaultThreadPool("SingleConnection-logic", 2));
        Jengine.setCommonExecutor(new DefaultThreadPool("SingleConnection-common", 2));
        Jengine.getLogicExecutor().start();
        Jengine.getCommonExecutor().start();

        this.registerPacketHandler();
        return true;
    }

    private void registerPacketHandler() {
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.LOGIN_RESPONSE_VALUE, new LoginHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.CHAT_RESPONSE_VALUE, new ChatHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.FRIEND_LIST_RESPONSE_VALUE, new ListFriendHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MARQUEE_RESPONSE_VALUE, new MarqueeHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.EQUIP_SYNC_WORN_RESPONSE_VALUE, new EquipSyncWornHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.EQUIP_SYNC_UNWORN_RESPONSE_VALUE, new EquipSyncUnwornHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.FRIEND_NOTIFY_APPLICATION_RESPONSE_VALUE, new ReceiveApplicationHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.FRIEND_SEARCH_FRIENDS_RESPONSE_VALUE, new SearchFriendsHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.CHAT_BG_INFO_RESPONSE_VALUE, new ChatBgInfoHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.HEARTBEAT_RESPONSE_VALUE, new HeartBeatHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.HERO_SYNC_RESPONSE_VALUE, new HeroSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MISSION_SYNC_RESPONSE_VALUE, new MissionSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MISSION_CHALLENGE_STAGE_RESPONSE_VALUE, new MissionChallengeHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.SOUL_SYNC_EQUIPPED_RESPONSE_VALUE, new SoulSyncEquippedHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.SOUL_SYNC_UNEQUIPPED_RESPONSE_VALUE, new SoulSyncUnEquippedHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.STORY_EMAIL_SYNC_RESPONSE_VALUE, new StoryEmailSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.SHOP_INFO_SYNC_RESPONSE_VALUE, new ShopSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MALL_SHOP_INFO_SYNC_RESPONSE_VALUE, new MallSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.CHARACTER_INFO_SYNC_RESPONSE_VALUE, new CharacterInfoSyncHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MINER_INFO_RESPONSE_VALUE, new CsMinerNodeInfoHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MINER_NODE_LIST_RESPONSE_VALUE, new CsMinerNodeListHandler());
        TcpPacketDispatcher.getInstance().registerSimpleHandler(Msg.opcode.MINER_REFRESH_NODE_LIST_RESPONSE_VALUE, new CsMinerRefreshNodesHandler());
    }

    private void loadClientIds() {
        Reader reader;
        try {
            reader = new InputStreamReader(
                    new FileInputStream(robotConfig.getClientIdFile()));

            BufferedReader in = new BufferedReader(reader);
            String clientId;
            while ((clientId = in.readLine()) != null) {
                this.clientIds.add(clientId);
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
