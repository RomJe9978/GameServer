package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class CsMinerNodeInfoHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("CsMiner node info response received");
        Robot robot = (Robot) session.getGameObject();
        Miner.MinerInfoResponse response = packet.parsePacket(Miner.MinerInfoResponse.getDefaultInstance());
        robot.setLastQueryMinerInfo(response.getInfo());
    }
}
