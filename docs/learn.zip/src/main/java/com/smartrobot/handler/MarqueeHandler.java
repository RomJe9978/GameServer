package com.smartrobot.handler;

import com.golden.protocol.Marquee;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;

import java.util.List;

/**
 * @author mengyan
 */
public class MarqueeHandler implements SimpleHandler {
	@Override
	public void onPacket(ClientSession session, TcpPacket packet) {
		Log.getJengineLogger().info("marquee response handler received");
		Marquee.MarqueeResponse response = packet.parsePacket(Marquee.MarqueeResponse.getDefaultInstance());
		List<Marquee.MarqueeInfo> marqueeInfos = response.getMarqueeInfos().getInfosList();
		for (Marquee.MarqueeInfo marqueeInfo : marqueeInfos) {
			Log.getJengineLogger().info("receive marquee msg: {}", marqueeInfo.getMarqueeContent());
		}
	}
}
