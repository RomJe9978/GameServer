package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

/**
 * @author leiyunfei
 * @time 2020-07-11 14:12
 */
public class ListFriendHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info(" FriendListResponse handler");
        Robot robot = (Robot) session.getGameObject();
        Friend.FriendListResponse response = packet.parsePacket(Friend.FriendListResponse.getDefaultInstance());
        Log.getJengineLogger().info("playerId: " + robot.getOId() +
                ", friendList: " + response.getFriendListList().toString() +
                ", applyList: " + response.getApplyListList().toString() +
                ", blackList: " + response.getBlackListList().toString());
    }
}
