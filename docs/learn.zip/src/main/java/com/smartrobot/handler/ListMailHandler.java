package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class ListMailHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("Receive package, packet: {}", packet.toString());
        Robot robot = (Robot) session.getGameObject();
        Mail.MailListResponse response = packet.parsePacket(Mail.MailListResponse.getDefaultInstance());
        Log.getJengineLogger().info("mail list: {}", response.getMailListList());
    }
}
