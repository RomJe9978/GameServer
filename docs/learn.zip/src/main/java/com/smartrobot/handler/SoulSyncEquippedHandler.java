package com.smartrobot.handler;

import com.golden.protocol.Soul.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

public class SoulSyncEquippedHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("SoulSyncEquippedHandler response handler");
        Robot robot = (Robot) session.getGameObject();
        SoulSyncEquippedResponse response = packet.parsePacket(SoulSyncEquippedResponse.getDefaultInstance());
        List<SoulInfo> soulInfos = response.getSoulsList();
        for (SoulInfo info : soulInfos) {
            robot.addEquippedSoul(info.getSoulId(), info);
        }
    }
}
