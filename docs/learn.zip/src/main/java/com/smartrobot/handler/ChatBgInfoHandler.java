package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;

import java.util.List;

/**
 * Receives chat background information.
 *
 * @author mengyan
 */
public class ChatBgInfoHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("chat background information handler received");
        Chat.ChatBgInfoResponse response = packet.parsePacket(Chat.ChatBgInfoResponse.getDefaultInstance());
        List<Chat.ChatBgInfo> chatBgInfos = response.getChatBgInfoList();
        for (Chat.ChatBgInfo bgInfo : chatBgInfos) {
            Log.getJengineLogger().info("chat background receive, kind:{},  at:{},  msg: {}", bgInfo.getChatType(), bgInfo.getBackgroundId());
        }
    }
}
