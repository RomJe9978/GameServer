package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;

public class HeartBeatHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Misc.HeartbeatResponse response = packet.parsePacket(Misc.HeartbeatResponse.getDefaultInstance());
        int serverTime = response.getServerTime();

        Log.getJengineLogger().info("server time: {}", serverTime);
    }
}
