package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class MissionSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        Mission.MissionSyncResponse response = packet.parsePacket(Mission.MissionSyncResponse.getDefaultInstance());
        for (Mission.MissionInfo info : response.getMissionInfosList()) {
            robot.addMission(info.getId(), info);
        }

        Log.getNetworkLogger().info("MissionSyncHandler.onPacket, missions: {}", response.getMissionInfosList());
    }
}
