package com.smartrobot.handler;

import com.golden.protocol.Character;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class CharacterInfoSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        Character.CharacterInfoSyncResponse response = packet.parsePacket(Character.CharacterInfoSyncResponse.getDefaultInstance());
        robot.setGuildId(response.getCharacterInfo().getSimpleInfo().getGuildId());

        Log.getNetworkLogger().info("CharacterInfoSyncResponse.onPacket, missions: {}", response.getCharacterInfo());
    }
}
