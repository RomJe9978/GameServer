package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

/**
 * @author mengyan
 */
public class ChatHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("chat response handler received");
        Chat.ChatResponse response = packet.parsePacket(Chat.ChatResponse.getDefaultInstance());
        List<Chat.ChatInfo> chatInfos = response.getChatInfos().getInfosList();
        for (Chat.ChatInfo chatInfo : chatInfos) {
            Log.getJengineLogger().info("chat receive, kind:{},  at:{},  msg: {}", chatInfo.getChatType(), chatInfo.getChatAt(), chatInfo.getChatContent());

            if (chatInfo.getChatType() == Chat.ChatType.PRIVATE_VALUE) {
                Chat.ChatRequest.Builder request = Chat.ChatRequest.newBuilder();
                request.setChatContent(chatInfo.getChatContent());
                request.setChatType(chatInfo.getChatType());
                request.setTargetId(chatInfo.getFromPlayerInfo().getPlayerId());
                session.send(TcpPacket.valueOf(Msg.opcode.CHAT_REQUEST_VALUE, request));

                Robot robot = (Robot) session.getGameObject();
                robot.addPrivateChatter(chatInfo.getFromPlayerInfo().getPlayerId());
            }
        }
    }
}
