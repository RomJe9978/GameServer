package com.smartrobot.handler;

import com.golden.protocol.Equip;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

/**
 * @author mengyan
 */
public class EquipSyncUnwornHandler implements SimpleHandler {
	@Override
	public void onPacket(ClientSession session, TcpPacket packet) {
		Equip.EquipSyncUnwornResponse response = packet.parsePacket(Equip.EquipSyncUnwornResponse.getDefaultInstance());
		Log.getJengineLogger().info("EquipSyncUnwornHandler response handler");
		Robot robot = (Robot) session.getGameObject();
		List<Equip.EquipInfo> equips = response.getEquipsList();
		for (Equip.EquipInfo equip : equips) {
			robot.addUnwornEquip(equip.getEquipId(), equip);
		}

		Log.getJengineLogger().info("unworn equip size: {}", robot.getUnwornEquips().size());
	}
}
