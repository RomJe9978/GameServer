package com.smartrobot.handler;

import com.golden.protocol.Friend;
import com.golden.protocol.Msg;
import com.golden.protocol.Player;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;

public class ReceiveApplicationHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Friend.FriendNotifyApplicationResponse response = packet.parsePacket(Friend.FriendNotifyApplicationResponse.getDefaultInstance());
        Player.PlayerSimpleInfo playerSimpleInfo = response.getFriendInfo();
        Log.getJengineLogger().info("Receive application, packet: {}, friendInfo: {}", packet, playerSimpleInfo);
        Friend.FriendAgreeAllApplicationsRequest.Builder request = Friend.FriendAgreeAllApplicationsRequest.newBuilder();
        session.send(TcpPacket.valueOf(Msg.opcode.FRIEND_AGREE_ALL_APPLICATIONS_REQUEST_VALUE, request));
    }
}
