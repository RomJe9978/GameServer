package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class ShopSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        Shop.ShopInfoSyncResponse response = packet.parsePacket(Shop.ShopInfoSyncResponse.getDefaultInstance());
        for (Shop.ShopInfo info : response.getShopInfosList()) {
            robot.addShop(info.getShopType(), info);
        }

        Log.getNetworkLogger().info("ShopInfoSyncResponse.onPacket, missions: {}", response.getShopInfosList());
    }
}
