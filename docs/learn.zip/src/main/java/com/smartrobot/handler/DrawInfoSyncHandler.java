package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

public class DrawInfoSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {

        Log.getJengineLogger().info("DrawInfoSyncHandler receive response ...");

        Robot robot = (Robot) session.getGameObject();

        LuckyDraw.LuckyDrawSyncInfoResponse response = packet.parsePacket(LuckyDraw.LuckyDrawSyncInfoResponse.getDefaultInstance());
        List<LuckyDraw.PoolDrawInfo> infos = response.getInfosList();
        for (LuckyDraw.PoolDrawInfo one : infos) {
            for (LuckyDraw.DrawInfo info : one.getInfosList()) {
                robot.poolInfoMap.put(info.getSubPoolId(), info);
            }
        }
    }
}
