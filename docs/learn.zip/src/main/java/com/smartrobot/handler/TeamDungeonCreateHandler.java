package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.Robot;

public class TeamDungeonCreateHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        TeamDungeon.TeamDungeonCreateTeamResponse response = packet.parsePacket(TeamDungeon.TeamDungeonCreateTeamResponse.getDefaultInstance());
        robot.setDungeonId(response.getId());
        robot.setTeamInfo(response.getTeam());
    }
}
