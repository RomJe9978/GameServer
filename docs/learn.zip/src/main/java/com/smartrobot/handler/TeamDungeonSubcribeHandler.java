package com.smartrobot.handler;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.Robot;

public class TeamDungeonSubcribeHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
    }
}
