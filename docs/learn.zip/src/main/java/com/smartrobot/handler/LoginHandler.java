package com.smartrobot.handler;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

/**
 *
 * @author mengyan
 */
public class LoginHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("login response handler");
        Robot robot = (Robot)session.getGameObject();
        robot.setState(Robot.State.RUNNING);
    }
}
