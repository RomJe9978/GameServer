package com.smartrobot.handler;

import com.golden.protocol.Soul.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

public class SoulSyncUnEquippedHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("SoulSyncUnEquippedHandler response handler");
        SoulSyncUnequippedResponse response = packet.parsePacket(SoulSyncUnequippedResponse.getDefaultInstance());
        Robot robot = (Robot) session.getGameObject();
        List<SoulInfo> soulInfos = response.getSoulsList();
        for (SoulInfo info : soulInfos) {
            robot.addUnEquippedSoul(info.getSoulId(), info);
        }
        Log.getJengineLogger().info("SoulSyncUnEquippedHandler, unequipped souls: {}", response.getSoulsList());
    }
}
