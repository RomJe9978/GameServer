package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;

public class CsMinerRefreshNodesHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info("CsMiner refresh nodes response received");
        Miner.MinerRefreshNodeListResponse response = packet.parsePacket(Miner.MinerRefreshNodeListResponse.getDefaultInstance());
        for (Miner.MinerInfo info : response.getMinerInfosList()) {
            Log.getNetworkLogger().info("Refresh miner info: {}", info);
        }
    }
}
