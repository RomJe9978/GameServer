package com.smartrobot.handler;

import com.golden.protocol.Friend.*;
import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

/**
 * @author leiyunfei
 * @time 2020-07-13 15:30
 */
public class SearchFriendsHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Log.getJengineLogger().info(" SearchFriends handler");
        Robot robot = (Robot) session.getGameObject();
        robot.clearRecommendedFriendList();
        FriendSearchFriendsResponse response = packet.parsePacket(FriendSearchFriendsResponse.getDefaultInstance());
        for (Player.PlayerSimpleInfo info : response.getListList()) {
            robot.addRecommendedFriend(info);
        }
        Log.getJengineLogger().info("player {} receive recommend friends {} ", robot.getOId(), response.getListList().toString());
    }
}
