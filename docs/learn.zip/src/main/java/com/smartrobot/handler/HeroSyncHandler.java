package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

import java.util.List;

public class HeroSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {

        Log.getJengineLogger().info("HeroSyncHandler receive response ...");

        Robot robot = (Robot) session.getGameObject();

        Hero.HeroSyncResponse response = packet.parsePacket(Hero.HeroSyncResponse.getDefaultInstance());
        List<Hero.HeroInfo> heroes = response.getHeroesList();
        for (Hero.HeroInfo hero : heroes) {
            robot.addHero(hero.getHeroId(), hero);
        }
    }
}
