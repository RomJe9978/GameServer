package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.Robot;

public class TeamDungeonInfoHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        TeamDungeon.TeamDungeonInfoResponse response = packet.parsePacket(TeamDungeon.TeamDungeonInfoResponse.getDefaultInstance());
        for (TeamDungeon.DungeonInfo info : response.getDungeonsList()) {
            robot.addDungeon(info.getId(), info);
        }
    }
}
