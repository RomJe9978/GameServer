package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.smartrobot.Robot;

public class TeamDungeonTeamInfoHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        TeamDungeon.TeamSyncInfoResponse response = packet.parsePacket(TeamDungeon.TeamSyncInfoResponse.getDefaultInstance());
        TeamDungeon.TeamInfo teamInfo = response.getTeam();
        robot.setTeamInfo(teamInfo);
        robot.setDungeonId(teamInfo.getId());
    }
}
