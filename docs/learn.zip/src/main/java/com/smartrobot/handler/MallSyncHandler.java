package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class MallSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        Mall.MallShopInfoSyncResponse response = packet.parsePacket(Mall.MallShopInfoSyncResponse.getDefaultInstance());
        for (Mall.MallShopInfo info : response.getMallInfosList()) {
            robot.addMallShop(info.getMallType(), info);
        }

        Log.getNetworkLogger().info("MallShopInfoSyncResponse.onPacket, missions: {}", response.getMallInfosList());
    }
}
