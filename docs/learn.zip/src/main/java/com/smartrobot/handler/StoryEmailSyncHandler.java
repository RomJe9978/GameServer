package com.smartrobot.handler;

import com.golden.protocol.*;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.SimpleHandler;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.smartrobot.Robot;

public class StoryEmailSyncHandler implements SimpleHandler {
    @Override
    public void onPacket(ClientSession session, TcpPacket packet) {
        Robot robot = (Robot) session.getGameObject();
        StoryEmail.StoryEmailSyncResponse response = packet.parsePacket(StoryEmail.StoryEmailSyncResponse.getDefaultInstance());
        for (StoryEmail.StoryEmailInfo info : response.getEmailInfosList()) {
            robot.addStoryEmail(info.getId(), info);
        }

        Log.getNetworkLogger().info("StoryEmailSyncHandler.onPacket, missions: {}", response.getEmailInfosList());
    }
}
