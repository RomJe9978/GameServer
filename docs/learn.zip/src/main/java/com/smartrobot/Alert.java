package com.smartrobot;

import com.smartrobot.cfg.RobotConfig;
import io.sentry.Sentry;
import io.sentry.event.BreadcrumbBuilder;

public class Alert {

    public static void init(RobotConfig robotConfig) {
        Sentry.init(robotConfig.getSentryDSN());

        Sentry.getContext().recordBreadcrumb(
                new BreadcrumbBuilder().setMessage("User made an action").build()
        );

        // Add extra data to future events in this context.
        Sentry.getContext().addTag("platform", "game-release");
    }

    public static void Report(Exception e) {
        Sentry.capture(e);
    }
}
