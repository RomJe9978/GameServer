package com.smartrobot.cfg;

public class SmartRobotConfig extends  RobotConfig {
    private  String serverIp;
    private  int port;
    private  int watchDogMode;

    @Override
    public String getServerIp() {
        return serverIp;
    }

    @Override
    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    @Override
    public int getPort() {
        return port;
    }

    @Override
    public void setPort(int port) {
        this.port = port;
    }

    @Override
    public int getWatchDogMode() {
        return watchDogMode;
    }

    @Override
    public void setWatchDogMode(int watchDogMode) {
        this.watchDogMode = watchDogMode;
    }
}
