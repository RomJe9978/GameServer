package com.smartrobot.cfg;

import java.util.ArrayList;
import java.util.List;

public class RobotConfig {
    protected String clientIdFile;

    protected String serverIp;

    protected int port;

    protected int from;

    protected int to;

    protected String sentryDSN;

    protected String watchServerList;

    protected List<String> watchServers = new ArrayList<>();

    protected int watchDogMode;

    public RobotConfig() {
        clientIdFile = "";
        serverIp = "";
        port = 0;
        from = 0;
        to = 0;
        watchDogMode = 0;
        sentryDSN = "";
        watchServerList = null;
    }

    public String getClientIdFile() {
        return clientIdFile;
    }

    public String getServerIp() {
        return serverIp;
    }

    public int getPort() {
        return port;
    }

    public int getFrom() {
        return from;
    }

    public int getTo() {
        return to;
    }

    public String getSentryDSN() {
        return sentryDSN;
    }

    public int getWatchDogMode() {
        return watchDogMode;
    }

    public List<String> getWatchServerList() {
        if (this.watchServerList != null && !"".equals(this.watchServerList)) {
            String[] servers = this.watchServerList.split(",");
            for (String server : servers) {
                this.watchServers.add(server);
            }
        }
        return watchServers;
    }

    public void setClientIdFile(String clientIdFile) {
        this.clientIdFile = clientIdFile;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public void setTo(int to) {
        this.to = to;
    }

    public void setSentryDSN(String sentryDSN) {
        this.sentryDSN = sentryDSN;
    }

    public void setWatchServerList(String watchServerList) {
        this.watchServerList = watchServerList;
    }

    public void setWatchServers(List<String> watchServers) {
        this.watchServers = watchServers;
    }

    public void setWatchDogMode(int watchDogMode) {
        this.watchDogMode = watchDogMode;
    }
}
