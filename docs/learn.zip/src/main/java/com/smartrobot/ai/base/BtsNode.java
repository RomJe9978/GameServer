package com.smartrobot.ai.base;

import java.util.ArrayList;
import java.util.List;

/**
 * The base-class of Behavior trees .
 * 
 *
 */
public class BtsNode {
	// parent node.
	protected BtsNode parent;
	
	
	// @TODO
	protected Boolean useWeight;
	protected int totalWeight;
	
	// child nodes.
	protected List<BtsNode> children = new ArrayList<BtsNode>();
	
	// external conditions.
	private List<Condition> externalConditions = new ArrayList<Condition>();
	
	
	public BtsNode(BtsNode parent, Boolean useWeight) {
		this.parent = parent;
	}
	
	public void addChild(BtsNode child) {
		this.children.add(child);
	}
	
	public void addExternalCondtions(Condition condtion) {
		this.externalConditions.add(condtion);
	}
	
	public Boolean checkCondition(Object input) {
		if (this.externalConditions.size() == 0) {
			return this.doCheckCondition(input);
			
		} else {
			for(Condition cond : this.externalConditions) {
				if(!cond.check(input)) {
					return false;
				}
			}
		}
		
		return true;
	}
	
	public void transition(Object input) {
		this.doTransition(input);
	}
	
	public ControllerRunningStatus tick(Object input, Object output) {
		return this.doTick(input, output);
	}
	
	public int getChildrenNum() {
		return this.children.size();
	}
	
	protected Boolean isValidIndex(int index) {
		return index >=0 && index <this.getChildrenNum();
	}
	
	// ------------------------- to be overrided ---------------------------------	
	protected Boolean doCheckCondition(Object input) {
		return true;
	}
	
	protected void doTransition(Object input) {
		
	}
	
	protected ControllerRunningStatus doTick(Object input, Object output) {
		return ControllerRunningStatus.Finished;
	}
}
