package com.smartrobot.ai.base;

public class Constants {
	// invalid index for children index.	
	public static int InvalidIndex = -1;
	
	public static int InfiniteFlag = -1;
}
