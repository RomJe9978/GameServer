package com.smartrobot.ai.conditions;


import com.smartrobot.Robot;
import com.smartrobot.ai.base.Condition;

public class IsConnected implements Condition {
    private Robot robot;

    public IsConnected(Robot robot) {
        this.robot = robot;
    }

    @Override
    public boolean check(Object input) {
        if (this.robot.getState() == Robot.State.CONNECTED) {
            return true;
        }
        return false;
    }

}
