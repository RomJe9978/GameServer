package com.smartrobot.ai.control;


import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;
import com.smartrobot.ai.base.ParallelFinishType;

import java.util.ArrayList;
import java.util.List;

public class ParallelNode extends BtsNode {
	private ParallelFinishType finishType;
	private List<ControllerRunningStatus> childrenRunningStatus = new ArrayList<ControllerRunningStatus>();
	
	public ParallelNode(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
		this.finishType = ParallelFinishType.Or;
	}
	
	public void SetFinishType(ParallelFinishType finishType) {
		this.finishType = finishType;
	}
	
	@Override
	protected Boolean doCheckCondition(Object input) {
		if(this.childrenRunningStatus.size() < this.getChildrenNum()) {
			for (int i = this.childrenRunningStatus.size(); i< this.getChildrenNum(); i++) {
				this.childrenRunningStatus.add(i, ControllerRunningStatus.Running);
			}
		}
		
		for (int i = 0; i < this.getChildrenNum(); ++i) {
			BtsNode bnode = this.children.get(i);
			if (this.childrenRunningStatus.get(i) == ControllerRunningStatus.Running) {
				if(bnode == null || !bnode.checkCondition(input)) {
					return false;
				}
			}
		}
		return true;
	}
		
	@Override
	protected void doTransition(Object input) {
		for (int i = 0; i < this.getChildrenNum(); ++i){
			this.childrenRunningStatus.set(i, ControllerRunningStatus.Running);
			BtsNode bnode = this.children.get(i);
			bnode.transition(input);
		}
	}
	
	@Override
	protected ControllerRunningStatus doTick(Object input, Object output) {
		int finishIndex = 0;
		
		for ( int i = 0; i < this.getChildrenNum(); ++i) {
			if (this.finishType == ParallelFinishType.Or) {
				if(this.handleTickFinishTypeOr(i, input, output)) {
					return ControllerRunningStatus.Finished;
				}
			} else {
				finishIndex = this.handleTickFinishTypeAnd(finishIndex, i, input, output);
			} 
			
			if (finishIndex == this.getChildrenNum()) {
				for (int n = 0; n < this.getChildrenNum(); ++n) {
					this.childrenRunningStatus.set(i, ControllerRunningStatus.Running);
				}
				
				return ControllerRunningStatus.Finished;
			}
		}
		
		return ControllerRunningStatus.Running;
	}
	
	private boolean handleTickFinishTypeOr(int i, Object input, Object output) {
		BtsNode bnode = this.children.get(i);
		if (this.childrenRunningStatus.get(i) == ControllerRunningStatus.Running) {
			this.childrenRunningStatus.set(i,bnode.tick(input,output));
			return false;
			
		} else{
			for (int j = 0;j < this.getChildrenNum(); ++j ) {
				this.childrenRunningStatus.set(i, ControllerRunningStatus.Running);
			}
			return true;
		}
	}
	
	private int handleTickFinishTypeAnd(int finishIndex, int i, Object input, Object output) {
		BtsNode bnode = this.children.get(i);
		if (this.childrenRunningStatus.get(i) == ControllerRunningStatus.Running){
			this.childrenRunningStatus.set(i, bnode.tick(input,output));
		} else{
			++finishIndex;
		}
		
		return finishIndex;
	}

}
