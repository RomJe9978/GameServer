package com.smartrobot.ai.conditions;

import com.smartrobot.Robot;
import com.smartrobot.ai.base.Condition;

public class IsNoneState implements Condition {
    private Robot robot;

    public IsNoneState(Robot robot) {
        this.robot = robot;
    }

    @Override
    public boolean check(Object input) {
        if (this.robot.getState() == Robot.State.NONE) {
            return true;
        }
        return false;
    }
}
