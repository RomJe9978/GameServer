package com.smartrobot.ai.conditions;

import com.smartrobot.ai.base.Condition;

public class Or implements Condition {
	private Condition[] conditons;
	
	public Or(Condition...conditions) {
		this.conditons = conditions;
	}
	public boolean check(Object input) {
		for (Condition c : this.conditons) {
			if (c.check(input)) {
				return true;
			}
		}
		return false;
	}

}
