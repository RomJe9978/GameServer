package com.smartrobot.ai.base;

public enum ControllerRunningStatus {
	Running,
	
	Finished,
	
	Failed,
}
