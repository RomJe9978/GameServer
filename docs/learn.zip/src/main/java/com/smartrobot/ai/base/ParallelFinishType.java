package com.smartrobot.ai.base;

public enum ParallelFinishType {
	// finished when all node in parallel node finished.
	And,
	
	// finished when one node in parallel node finished.	
	Or,
}
