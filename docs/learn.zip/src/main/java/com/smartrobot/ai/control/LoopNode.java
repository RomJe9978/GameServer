package com.smartrobot.ai.control;

import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.Constants;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class LoopNode extends BtsNode {
	private int maxLoopCount;
	private int currentLoopCount;

	public LoopNode(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
		this.maxLoopCount = Constants.InfiniteFlag;
	}
	
	public LoopNode setMaxLoopCount(int maxLoopCount) {
		this.maxLoopCount= maxLoopCount;
		return this;
	}

	@Override
	protected Boolean doCheckCondition(Object input) {
		boolean hasLoopCount = (this.maxLoopCount== Constants.InfiniteFlag) || (this.currentLoopCount < this.maxLoopCount);
		if (!hasLoopCount) {
			return false;
		}

		return true;
	}
	
	@Override
	protected void doTransition(Object input) {
	}
	
	@Override
	protected ControllerRunningStatus doTick(Object input, Object output) {
		ControllerRunningStatus status = ControllerRunningStatus.Running;
		for(BtsNode cnode : this.children) {
			if (cnode.checkCondition(input)) {
				if(cnode.tick(input, output) == ControllerRunningStatus.Finished) {
					status = ControllerRunningStatus.Finished;
				}
			}
		}
		
		if (this.maxLoopCount != Constants.InfiniteFlag){
			++this.currentLoopCount;
			if (this.currentLoopCount < this.maxLoopCount){
				status = ControllerRunningStatus.Running;
			}else {
				status = ControllerRunningStatus.Finished;
			}
		} 


		if (status == ControllerRunningStatus.Finished) {
			this.currentLoopCount = 0;
		}
		return status;
	}
}
