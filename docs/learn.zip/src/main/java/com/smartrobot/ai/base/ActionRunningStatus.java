package com.smartrobot.ai.base;

public enum ActionRunningStatus {
	Ready,
	
	Running,
	
	Finished,
}
