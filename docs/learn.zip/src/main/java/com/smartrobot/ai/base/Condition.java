package com.smartrobot.ai.base;

public interface Condition {
	boolean check(Object input);
}
