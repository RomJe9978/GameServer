package com.smartrobot.ai.conditions;


import com.smartrobot.Robot;
import com.smartrobot.ai.base.Condition;

public class IsConnecting implements Condition {
    private Robot robot;

    public IsConnecting(Robot robot) {
        this.robot = robot;
    }

    @Override
    public boolean check(Object input) {
        if (this.robot.getState() == Robot.State.CONNECTING) {
            return true;
        }
        return false;
    }

}
