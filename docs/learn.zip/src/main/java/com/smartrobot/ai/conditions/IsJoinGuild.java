package com.smartrobot.ai.conditions;


import com.smartrobot.Robot;
import com.smartrobot.ai.base.Condition;

public class IsJoinGuild implements Condition {
    private Robot robot;

    public IsJoinGuild(Robot robot) {
        this.robot = robot;
    }

    public boolean check(Object input) {
        if (this.robot.getGuildId() > 0) {
            return true;
        }
        return false;
    }

}
