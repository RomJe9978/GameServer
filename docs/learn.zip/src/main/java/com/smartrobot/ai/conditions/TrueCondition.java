package com.smartrobot.ai.conditions;

import com.smartrobot.ai.base.Condition;

public class TrueCondition implements Condition {

	public boolean check(Object input) {
		return true;
	}

}
