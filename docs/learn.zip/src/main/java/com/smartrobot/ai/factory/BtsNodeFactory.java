package com.smartrobot.ai.factory;


import com.smartrobot.ai.action.ActionNode;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.control.*;

public class BtsNodeFactory {
	public static SelectorNode createSelectorNode(BtsNode parent) {
		SelectorNode bnode = new SelectorNode(parent, false);
		if (parent != null) {
			parent.addChild(bnode);
		}
		return bnode;
	}
	
	public static RandomSelectorNode createRandomSelectorNode(BtsNode parent) {
		RandomSelectorNode bnode = new RandomSelectorNode(parent, false);
		if (parent != null) {
			parent.addChild(bnode);
		}
		return bnode;
	}
	
	public static SequenceNode createSequenceNode(BtsNode parent) {
		SequenceNode bnode = new SequenceNode(parent, false);
		if (parent != null) {
			parent.addChild(bnode);
		}
		return bnode;
	}
	
	public static LoopNode createLoopNode(BtsNode parent) {
		LoopNode bnode = new LoopNode(parent, false);
		if (parent != null) {
			parent.addChild(bnode);
		}
		return bnode;
	}
	
	public static ParallelNode createParallelNode(BtsNode parent) {
		ParallelNode bnode = new ParallelNode(parent, false);
		if (parent != null) {
			parent.addChild(bnode);
		}
		return bnode;
	}
	
	public static ActionNode createActionNode(Class<?> action, BtsNode parent) {
		try {
			ActionNode bnode =  (ActionNode) action.getDeclaredConstructor(BtsNode.class, Boolean.class).newInstance(parent, false);
			if (parent != null) {
				parent.addChild(bnode);
			}
			return bnode;
		}  catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
