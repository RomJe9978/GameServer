package com.smartrobot.ai.conditions;


import com.smartrobot.ai.base.Condition;

public class Not implements Condition {
	private Condition c;
	
	public Not(Condition c) {
		this.c = c;
	}
	public boolean check(Object input) {
		return !this.c.check(input);
	}

}
