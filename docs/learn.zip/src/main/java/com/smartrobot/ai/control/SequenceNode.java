package com.smartrobot.ai.control;

import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.Constants;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class SequenceNode extends BtsNode {
	private int currentNodeIndex;

	
	public SequenceNode(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
		this.currentNodeIndex = Constants.InvalidIndex;
	}

	@Override
	protected Boolean doCheckCondition(Object input) {
		int index = 0;
		if (this.currentNodeIndex == Constants.InvalidIndex){
			index = 0;
		} else{
			index = currentNodeIndex;
		}
		
		if (this.isValidIndex(index)){
			BtsNode bnode = this.children.get(index);
			if(bnode.checkCondition(input)) {
				return true;
			}
		}
		
		return false;
	}
		
	@Override
	protected void doTransition(Object input) {
		if (this.isValidIndex(currentNodeIndex)){
			BtsNode bnode = this.children.get(currentNodeIndex);
			bnode.transition(input);
		}
		
		this.currentNodeIndex = Constants.InvalidIndex;
	}
	
	@Override
	protected ControllerRunningStatus doTick(Object input, Object output) {
		ControllerRunningStatus status = ControllerRunningStatus.Finished;
		
		if (this.children.size() ==0) {
			return status;
		}

		if (!this.isValidIndex(this.currentNodeIndex)){
			this.currentNodeIndex = 0;
		}
		
		BtsNode bnode = this.children.get(currentNodeIndex);
		status = bnode.tick(input,output);
		if (status == ControllerRunningStatus.Finished){
			++this.currentNodeIndex;
			if(this.currentNodeIndex == this.getChildrenNum()) {
				this.currentNodeIndex = Constants.InvalidIndex;
			} else {
				status = ControllerRunningStatus.Running;
			}
		}

		return status;
	}
}
