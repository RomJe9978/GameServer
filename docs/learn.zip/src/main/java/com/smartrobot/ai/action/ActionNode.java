package com.smartrobot.ai.action;

import com.smartrobot.ai.base.ActionRunningStatus;
import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class ActionNode extends BtsNode {
	protected Object agent;
	
	protected ActionRunningStatus runningStatus;
	protected boolean needExit;

	public ActionNode(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
		this.runningStatus = ActionRunningStatus.Ready;
	}
	
	protected void doEnter(Object input) {}
	protected ControllerRunningStatus doExecute(Object input, Object output) {
		return ControllerRunningStatus.Finished;
	}
	protected void doExit(Object inpout, ControllerRunningStatus status) {}
	
	@Override
	protected ControllerRunningStatus doTick(Object input, Object output) {
		ControllerRunningStatus ctlrunningStatus = ControllerRunningStatus.Finished;
		if (this.runningStatus == ActionRunningStatus.Ready){
			this.doEnter(input);
			needExit = true;
			this.runningStatus = ActionRunningStatus.Running;
		}
		
		if (this.runningStatus == ActionRunningStatus.Running){
			ctlrunningStatus = this.doExecute(input, output);
			if (ctlrunningStatus != ControllerRunningStatus.Running){
				this.runningStatus = ActionRunningStatus.Finished;
			}
		}
		
		if (this.runningStatus == ActionRunningStatus.Finished){
			if (needExit) {
				this.doExit(input,ctlrunningStatus);
			}
				
			this.runningStatus = ActionRunningStatus.Ready;
		}
		return ctlrunningStatus;
	}
	
	public ActionNode setAgent(Object agent) {
		this.agent = agent;
		return this;
	}
	
	public Object getAgent() {
		return this.agent;
	}
}
