package com.smartrobot.ai.conditions;


import com.smartrobot.Robot;
import com.smartrobot.ai.base.Condition;

public class IsLoggedin implements Condition {
	private Robot robot;
	public IsLoggedin(Robot robot) {
		this.robot = robot;
	}
	public boolean check(Object input) {
		if (this.robot.getState() ==  Robot.State.RUNNING) {
			return true;
		}
		return false;
	}

}
