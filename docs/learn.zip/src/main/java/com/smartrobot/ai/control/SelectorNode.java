package com.smartrobot.ai.control;

import com.smartrobot.ai.base.BtsNode;
import com.smartrobot.ai.base.Constants;
import com.smartrobot.ai.base.ControllerRunningStatus;

public class SelectorNode extends BtsNode {
	private int currentSelectedIndex;
	private int	lastSelectedIndex;

	public SelectorNode(BtsNode parent, Boolean useWeight) {
		super(parent, useWeight);
		
		this.currentSelectedIndex = Constants.InvalidIndex;
		this.lastSelectedIndex = Constants.InvalidIndex;
	}

	@Override
	protected Boolean doCheckCondition(Object input) {
		this.currentSelectedIndex = Constants.InvalidIndex;
		for (int i=0; i<this.getChildrenNum(); i++) {
			if(this.children.get(i).checkCondition(input)) {
				this.currentSelectedIndex = i;
				return true;
			}
		}
		return false;
	}
	
	@Override
	protected void doTransition(Object input) {
		if (this.isValidIndex(this.lastSelectedIndex)){
			BtsNode node = this.children.get(this.lastSelectedIndex);
			if (node != null) {
				node.transition(input);
			}
		}
		this.lastSelectedIndex = Constants.InvalidIndex;
	}
	
	@Override
	protected ControllerRunningStatus doTick(Object input, Object output) {
		ControllerRunningStatus status = ControllerRunningStatus.Finished;
		if(this.isValidIndex(this.currentSelectedIndex)) {
			if (this.lastSelectedIndex != this.currentSelectedIndex){
				if (this.isValidIndex(this.lastSelectedIndex)){
					BtsNode node = this.children.get(this.lastSelectedIndex);
					if (node != null) {
						node.transition(input);
					}
				}
				this.lastSelectedIndex = this.currentSelectedIndex;
			}
		}
		
		if (this.isValidIndex(this.lastSelectedIndex)) {
			BtsNode node = this.children.get(this.lastSelectedIndex);
			status = node.tick(input,output);
			if (status == ControllerRunningStatus.Finished){
				this.lastSelectedIndex = Constants.InvalidIndex;
			}
		}
		return status;
	}
}
