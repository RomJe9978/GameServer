package com.smartrobot;


import com.jengine.io.ClientSession;
import com.jengine.io.tcp.connector.SingleConnector;
import com.jengine.object.GameObject;
import com.jengine.object.ObjectId;
import io.netty.channel.EventLoopGroup;
import org.apache.commons.collections.map.HashedMap;

import java.util.*;
import java.util.concurrent.ConcurrentSkipListSet;

/**
 * A basic robot implementation which can hold a connection with server.
 *
 * @author mengyan
 */
public class Robot extends SingleConnector implements GameObject {
    private String clientId;
    private ObjectId objectId;
    private State state;
    private Map<Long, Object> wornEquips = new HashedMap();
    private Map<Long, Object> unwornEquips = new HashedMap();

    private List<Object> recommendedFriendList = new ArrayList<>();
    private Set<Long> privateChatter;


    private Map<Long, Object> heroes = new HashMap<>();

    private Map<Long, Object> storyEmails = new HashMap<>();

    private Map<Long, Object> missions = new HashMap<>();
    private Map<Integer, Object> shopItems = new HashMap<>();
    private Map<Integer, Object> mallShopItems = new HashMap<>();

    private Map<Long, Object> equippedSouls = new HashMap<>();
    private Map<Long, Object> unequippedSouls = new HashMap<>();
    private long guildId;

    private Map<Long, Object> dungeonMap = new HashMap<>();
    private long dungeonId;
    private Object teamInfo;

    public Map<Integer, Object> poolInfoMap = new HashMap<>();

    private List<Object> minerNodeList = new ArrayList<>();
    private List<Object> heroInfoList = new ArrayList<>();
    private Object lastQueryMinerInfo;

    public enum State {
        NONE, CONNECTING, CONNECTED, LOGINING, RUNNING;
    }

    public Robot(EventLoopGroup group, String clientId, String host, int port, boolean autoReconncet) {
        super(group, host, port, autoReconncet);
        this.privateChatter = new ConcurrentSkipListSet<>();
        this.clientId = clientId;
        this.objectId = new ObjectId(this.getType(), 1);
        this.state = State.NONE;
    }

    public String getClientId() {
        return this.clientId;
    }

    public void setState(State state) {
        this.state = state;
    }

    public State getState() {
        return this.state;
    }

    public void setObjectId(ObjectId objectId) {
        this.objectId = objectId;
    }

    public Map<Long, Object> getWornEquips() {
        return wornEquips;
    }

    public void addWornEquip(long id, Object object) {
        this.wornEquips.put(id, object);
    }

    public Map<Long, Object> getUnwornEquips() {
        return unwornEquips;
    }

    public void addUnwornEquip(long id, Object object) {
        this.unwornEquips.put(id, object);
    }

    public List<Object> getRecommendedFriendList() {
        return recommendedFriendList;
    }

    public void setRecommendedFriendList(List<Object> recommendedFriendList) {
        this.recommendedFriendList = recommendedFriendList;
    }

    public void addRecommendedFriend(Object object) {
        recommendedFriendList.add(object);
    }

    public void clearRecommendedFriendList() {
        recommendedFriendList.clear();
    }

    public void addHero(long id, Object object) {
        this.heroes.put(id, object);
    }

    public Object getHero(long id) {
        return this.heroes.get(id);
    }

    public Map<Long, Object> getHeroes() {
        return this.heroes;
    }

    public void addStoryEmail(long id, Object object) {
        this.storyEmails.put(id, object);
    }

    public Map<Long, Object> getStoryEmails() {
        return this.storyEmails;
    }

    public void addMission(long id, Object object) {
        this.missions.put(id, object);
    }

    public void addShop(int id, Object object) {
        this.shopItems.put(id, object);
    }

    public void addMallShop(int id, Object object) {
        this.mallShopItems.put(id, object);
    }

    public Object getMission(long id) {
        return this.missions.get(id);
    }

    public Map<Long, Object> getMissions() {
        return this.missions;
    }

    public Map<Integer, Object> getShops() {
        return shopItems;
    }

    public Map<Integer, Object> getMallShops() {
        return mallShopItems;
    }

    public long getGuildId() {
        return guildId;
    }

    public void setGuildId(long guildId) {
        this.guildId = guildId;
    }

    public void addEquippedSoul(long id, Object object) {
        this.equippedSouls.put(id, object);
    }

    public Map<Long, Object> getEquippedSouls() {
        return this.equippedSouls;
    }

    public void addUnEquippedSoul(long id, Object object) {
        this.unequippedSouls.put(id, object);
    }

    public Map<Long, Object> getUnequippedSouls() {
        return this.unequippedSouls;
    }

    @Override
    public void onConnected(ClientSession session) {
        System.out.println("session connected.");
        super.onConnected(session);
        session.bindGameObject(this);

        this.setState(Robot.State.CONNECTED);
    }

    @Override
    public void onDisconnected() {
        super.onDisconnected();
        System.out.println("session closed.");
        super.onDisconnected();
        this.state = State.NONE;
    }

    @Override
    public int getType() {
        return 1;
    }

    @Override
    public ObjectId getOId() {
        return this.objectId;
    }

    @Override
    public void setOId(ObjectId oid) {

    }

    @Override
    public boolean lock() {
        return false;
    }

    @Override
    public boolean unlock() {
        return false;
    }

    @Override
    public void setLastTouchTime(long curMillis) {

    }

    @Override
    public long getLastTouchTimeInMillis() {
        return 0;
    }

    public void addPrivateChatter(long chatterId) {
        this.privateChatter.add(chatterId);
    }

    public Set<Long> getPrivateChatter() {
        return this.privateChatter;
    }

    public long getDungeonId() {
        return dungeonId;
    }

    public void setDungeonId(long dungeonId) {
        this.dungeonId = dungeonId;
    }

    public Object getTeamInfo() {
        return teamInfo;
    }

    public void setTeamInfo(Object teamInfo) {
        this.teamInfo = teamInfo;
    }

    public Map<Long, Object> getDungeonMap() {
        return dungeonMap;
    }

    public void setDungeonMap(Map<Long, Object> dungeonMap) {
        this.dungeonMap = dungeonMap;
    }

    public void addDungeon(long id, Object dungeon) {
        this.dungeonMap.put(id, dungeon);
    }

    public List<Object> getMinerNodeList() {
        return minerNodeList;
    }

    public void addMinerNode(Object object) {
        this.minerNodeList.add(object);
    }

    public List<Object> getHeroInfoList() {
        return heroInfoList;
    }

    public void addMinerHero(Object object) {
        this.heroInfoList.add(object);
    }

    public Object getLastQueryMinerInfo() {
        return lastQueryMinerInfo;
    }

    public void setLastQueryMinerInfo(Object lastQueryMinerInfo) {
        this.lastQueryMinerInfo = lastQueryMinerInfo;
    }
}
