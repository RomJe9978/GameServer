package com.jengine.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Manager of the various types of modules
 *
 * @author mengyan
 */
public class ModuleManager {
	private static final ModuleManager instance = new ModuleManager();

	public static ModuleManager getInstance() {
		return instance;
	}

	private Map<Integer, List<Module>> typeModules = new HashMap<>();

	/**
	 * Registers a new module of type.
	 *
	 * @param type
	 * @param module
	 */
	public void registerModule(int type, Module module) {
		if (!this.typeModules.containsKey(type)) {
			this.typeModules.put(type, new ArrayList<Module>());
		}

		this.typeModules.get(type).add(module);
	}

	/**
	 * Returns all modules of type.
	 *
	 * @param type
	 * @return
	 */
	public List<Module> getModules(int type) {
		return this.typeModules.get(type);
	}

	public Map<Integer, List<Module>> getModules() {
		return this.typeModules;
	}
}
