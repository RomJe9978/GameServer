package com.jengine.module;

import com.jengine.updater.Ticker;

/**
 * Module represents different logical modules of a certain type of game object
 *
 * @author mengyan
 */
public interface Module extends Ticker {
	/**
	 * Return the type of this module.
	 *
	 * @return
	 */
	int getType();
}
