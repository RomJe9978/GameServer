package com.jengine.generator;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.cache.RedisClientService;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

/**
 * 全服唯一ID生成器，借助于Redis， 通过Redis原子命令INCRBY产生唯一自增ID
 */
public class RedisIdGenerator implements Generator {
    private final int serverId;
    private String redisKey;
    private static final RedisClientService redisClientService = Jengine.getAppContext().get(RedisClientService.class);


    public RedisIdGenerator(int serverId, String redisKey, long initIdentifier) {
        this.serverId = serverId;
        this.redisKey = redisKey;

        this.resetInitIdentifier(initIdentifier);
    }

    public int getServerId() {
        return this.serverId;
    }

    public void setRedisKey(String redisKey) {
        this.redisKey = redisKey;
    }

    public String getRedisKey() {
        return this.redisKey;
    }

    private void resetInitIdentifier(long initIdentifier) {
        if (redisClientService.isClusterMode()) {
            redisClientService.getCluster().setnx(getRedisKey(), String.valueOf(initIdentifier));
        } else {
            try (Jedis client = redisClientService.getClient()) {
                if (client != null) {
                    client.setnx(getRedisKey(), String.valueOf(initIdentifier));
                }
            }
        }
    }

    private long doINCRRedisCluster() throws JengineException {
        for (int i = 0; i < 3; i++) {
            JedisCluster cluster = redisClientService.getCluster();
            if (cluster != null) {
                return cluster.incr(this.getRedisKey());
            }
        }
        throw new JengineException("Acquire JedisCluster object failed");
    }

    private long doINCRRedisStandalone() throws JengineException {
        for (int i = 0; i < 3; i++) {
            try (Jedis jedis = redisClientService.getClient()) {
                if (jedis != null) {
                    return jedis.incr(this.getRedisKey());
                }
            }
        }
        throw new JengineException("Acquire Jedis object failed");
    }

    @Override
    public long nextId() throws JengineException {
        if (redisClientService.isClusterMode()) {
            return doINCRRedisCluster();
        } else {
            return doINCRRedisStandalone();
        }
    }
}
