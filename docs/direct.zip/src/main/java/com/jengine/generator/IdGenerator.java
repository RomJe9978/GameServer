package com.jengine.generator;


import com.jengine.JengineException;

/**
 * @author leiyunfei
 */
public class IdGenerator<T extends Generator> {
	protected T generator;

	void setGenerator(T generator) {
		this.generator = generator;
	}

	public IdGenerator(T generator) {
		this.generator = generator;
	}

	public long nextId() throws JengineException {
		return generator.nextId();
	}

	/**
	 * @param num generate id nums for testing
	 * @throws JengineException
	 */
	public void gen(int num) throws JengineException {
		for (int i = 0; i < num; i++) {
			System.out.println("new Id: " + this.nextId());
		}
	}
}
