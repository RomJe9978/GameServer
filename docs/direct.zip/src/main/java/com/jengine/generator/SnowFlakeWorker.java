package com.jengine.generator;

import com.jengine.JengineException;

/**
 * Twitter SnowFlake Id generator algorithm
 * SnowFlake的标准结构，每部分用 | 分割
 * <p>
 * 0|0000000 00000000 00000000 00000000 00000000 00|00000|0 0000|0000 00000000
 * <p>
 * 1 > 1bit标识0，表示生成的id是正数
 * 2 > 41bits的时间戳（毫秒级），这个时间戳并不存储当前时间的时间戳，而是存储当前时间戳和ID生成器开始产生Id的时间戳之间
 * 的差值，一般由程序来指定，41为时间戳可以使用69年（2 ** 41 / (356 * 24 * 60 * 60 * 1000) = 69.73
 * 3 > 5bits的机器ID和5bits的centerID，共10位，总共可以部署1024个机器节点
 * 4 > 12bits的流水序列号，12bits的计数顺序号可以支持每个节点每毫秒产生4096个ID序号
 * <p>
 * 我们游戏服务器并不需要支持分布式部署，我们的目标是每个区服产生的ID唯一，方便未来合服，而且区服的数量要超过1024个，
 * 所以5bits的机器ID+5bits的centerID预留是不够的，我们对Twitter_SnowFlake算法进行改造。
 * <p>
 * 改造后的SnowFlake结构，每部分用 | 分割
 * 0|0000000 00000000 00000000 00000000 00000000 00|000000 000000|00 00000000
 * 1 > 1bit标识0，表示生成的id是正数
 * 2 > 41bits的时间戳（毫秒级），这个时间戳并不存储当前时间的时间戳，而是存储当前时间戳和ID生成器开始产生Id的时间戳之间
 * 的差值，一般由程序来指定，41为时间戳可以使用69年（2 ** 41 / (356 * 24 * 60 * 60 * 1000) = 69.73
 * 3 > 12bits的区服号，最多支持4096个逻辑区服，对于我们的游戏来说，预留区服足够大了
 * 4 > 10bits的流水顺序号，支持每毫秒产生1024个ID序号，对于我们的业务足够了。
 *
 * @author leiyunfei
 */
public class SnowFlakeWorker implements Generator {

    private static final long TWEPOCH = 1591113600000L;  // 开始时间戳，2020-06-03 00:00 金鳞工作室正式成立
    private static final long SERVER_ID_BITS = 12L;  // 游戏逻辑区服ID所占比特位数，最多支持4096个区服
    private static final long SEQUENCE_BITS = 10L;  // 每毫秒每
    private static final long MAX_SERVER_ID = ~(-1L << SERVER_ID_BITS);

    private static final long SERVER_ID_SHIFT = SEQUENCE_BITS; // 区服ID向左移10位
    private static final long TIMESTAMP_SHIFT = SEQUENCE_BITS + SERVER_ID_BITS;  // 时间戳向左移22位（10+12）
    private static final long SEQUENCE_MAST = ~(-1L << SEQUENCE_BITS); // 流水顺序号掩码，这里是1023

    private final long serverId;  // 服务器区服ID
    private long sequenceId = 0L;  // 每毫秒内流水顺序号
    private long lastTimestampMillis = -1L;  // 上次生成ID的时间戳
    private static final long MAX_TIME_BACKWARD_MILLIS = 50; // 最大支持时间回拨的时间范围 ms

    /**
     * @return 当前服务器区服ID
     */
    public long getServerId() {
        return serverId;
    }

    /**
     * @return 当前毫秒内分配顺序号
     */
    public long getSequenceId() {
        return sequenceId;
    }

    /**
     * @return 上次生成ID的时间戳
     */
    public long lastTimestampMillis() {
        return lastTimestampMillis;
    }

    public SnowFlakeWorker(long serverId) {
        if (serverId > SnowFlakeWorker.MAX_SERVER_ID || serverId <= 0) {
            throw new IllegalArgumentException(
                    String.format("serverId can't be greater than %d or less than 0", MAX_SERVER_ID));
        }
        this.serverId = serverId;
    }

    public static long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }

    /**
     * @return 返回下一个ID（线程安全方法）
     */
    @Override
    public synchronized long nextId() throws JengineException {
        long nowTimeMillis = SnowFlakeWorker.getCurrentTimeMillis();
        if (nowTimeMillis < lastTimestampMillis) {
            // 如果时钟回拨在可接受范围内, 等待即可
            if (lastTimestampMillis - nowTimeMillis < MAX_TIME_BACKWARD_MILLIS) {
                try {
                    Thread.sleep(lastTimestampMillis - nowTimeMillis);
                } catch (InterruptedException e) {
                    throw new JengineException(
                            String.format("SnowFlakeWorker error, currentTimeMillis: %d, lastTimestamp: %d", nowTimeMillis, lastTimestampMillis));
                }
            } else {
                throw new JengineException(
                        String.format("SnowFlakeWorker error, currentTimeMillis: %d, lastTimestamp: %d", nowTimeMillis, lastTimestampMillis));
            }
        }

        if (nowTimeMillis == lastTimestampMillis) {
            // 同一毫秒内生成
            sequenceId = (sequenceId + 1) & SEQUENCE_MAST;
            if (sequenceId == 0) {
                // 阻塞到下一毫秒
                nowTimeMillis = untilNextMillis(lastTimestampMillis);
            }
        } else {
            sequenceId = 0L;
        }

        // 记录上次生成ID的时间戳
        lastTimestampMillis = nowTimeMillis;

        return ((nowTimeMillis - TWEPOCH) << TIMESTAMP_SHIFT) | (serverId << SERVER_ID_SHIFT) | sequenceId;
    }

    private long untilNextMillis(long timestampMillis) {
        long nowTimeMillis = SnowFlakeWorker.getCurrentTimeMillis();
        while (nowTimeMillis <= lastTimestampMillis) {
            nowTimeMillis = SnowFlakeWorker.getCurrentTimeMillis();
        }
        return nowTimeMillis;
    }
}