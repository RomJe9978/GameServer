package com.jengine.generator;

import com.jengine.JengineException;

/**
 * @author leiyunfei
 */
public interface Generator {
	/**
	 * @return Return 64bits global unique Id
	 */
	long nextId() throws JengineException;
}
