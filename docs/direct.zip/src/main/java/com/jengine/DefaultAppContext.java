package com.jengine;

import com.jengine.event.EventHandler;
import com.jengine.event.EventManager;
import com.jengine.io.ProtocolHandler;
import com.jengine.io.tcp.TcpPacketDispatcher;
import com.jengine.logger.Log;
import com.jengine.module.Module;
import com.jengine.module.ModuleManager;
import com.jengine.service.Service;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Default implementation of {@AppContext}
 *
 * @author mengyan
 */
public class DefaultAppContext implements AppContext {
    Logger log = Log.getJengineLogger();
    private Map<Class<?>, Object> classObjectMap;

    public DefaultAppContext() {
        this.classObjectMap = new ConcurrentHashMap<>();
    }

    @Override
    public <T> T get(Class<T> clazz) {
        return (T) classObjectMap.get(clazz);
    }

    @Override
    public <X, Y extends X> void create(Class<Y> extendClass, Class<X> superClass) throws Exception {
        Object obj = this.registerListenerClass(extendClass);
        if (obj != null) {
            if (extendClass.getClass() != superClass && !superClass.isAssignableFrom(extendClass)) {
                throw new IllegalArgumentException();
            }

            this.classObjectMap.put(superClass, obj);

            // process services
            if (obj instanceof Service) {
                Log.getJengineLogger().info("AppContext init service {} begin ...", ((Service) obj).getId());
                boolean ok = ((Service) obj).init();
                Log.getJengineLogger().info("AppContext init service {} finished", ((Service) obj).getId());

                Log.getJengineLogger().info("AppContext startup service {} begin ...", ((Service) obj).getId());
                ok &= ((Service) obj).startup();
                if (!ok) {
                    throw new JengineException("Init service " + obj + " failed");
                }
                Log.getJengineLogger().info("AppContext startup service {} ok", ((Service) obj).getId());

                // register shutdown handler.
                Jengine.getShutdownManager().addService((Service) obj);
            }

            // register modules
            if (obj instanceof Module) {
                Module module = (Module) obj;
                ModuleManager.getInstance().registerModule(module.getType(), module);
            }
        } else {
            log.error("AppContext create object failed for registered listener is null.");
        }

    }

    private Object registerListenerClass(Class clazz) {
        if (!this.classObjectMap.containsKey(clazz)) {
            try {
                Object o = clazz.newInstance();
                Method[] methods = clazz.getMethods();
                for (Method method : methods) {
                    // find methods with event annoutation
                    this.registerEventListenerClass(method, o);

                    // find methods with msg annoutation
                    this.registerPacketHandlerClass(method, o);
                }

                return o;

            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }

        return null;
    }

    private void registerEventListenerClass(Method method, Object o) {
        if (method.isAnnotationPresent(EventHandler.class)) {
            method.setAccessible(true);
            EventHandler eventAnnotation = method.getAnnotation(EventHandler.class);
            if (eventAnnotation.code() != null) {
                for (int code : eventAnnotation.code()) {
                    EventManager.getInstance().registerListener(code, method, o);
                }
            }
        }
    }

    private void registerPacketHandlerClass(Method method, Object o) {
        if (method.isAnnotationPresent(ProtocolHandler.class)) {
            method.setAccessible(true);
            ProtocolHandler protocolAnnotation = method.getAnnotation(ProtocolHandler.class);
            if (protocolAnnotation.code() != null) {
                for (int opcode : protocolAnnotation.code()) {
                    TcpPacketDispatcher.getInstance().registerHandler(opcode, method, o);
                }
            }
        }
    }
}
