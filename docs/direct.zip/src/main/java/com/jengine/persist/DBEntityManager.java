package com.jengine.persist;

import com.jengine.service.Service;

import java.util.List;

/**
 * Database entity manager
 *
 * @author mengyan
 */
public interface DBEntityManager extends Service {
	/**
	 * Immediately stored into the database
	 */
	void sync();

	/**
	 * Creates new entity in database.
	 *
	 * @param entity
	 * @return
	 */
	boolean create(AbstractEntity entity);

	/**
	 * Creates multiple entities in database.
	 *
	 * @param entities
	 * @return
	 */
	boolean createList(List<? extends AbstractEntity> entities);

	/**
	 * Deletes entity from database.
	 *
	 * @param entity
	 * @return
	 */
	boolean delete(AbstractEntity entity);

	/**
	 * Deletes multiple entities from database.
	 *
	 * @param entities
	 * @return
	 */
	boolean deleteList(List<? extends AbstractEntity> entities);

	/**
	 * Updates entity to database.
	 *
	 * @param entity
	 * @return
	 */
	boolean update(AbstractEntity entity);

	/**
	 * Updates by sql string.
	 *
	 * @param sqlString
	 * @return
	 */
	int update(String sqlString);

	/**
	 * Updates entity to database asynchronously.
	 *
	 * @param entity
	 * @return
	 */
	boolean updateAsync(AbstractEntity entity);

	/**
	 * Updates multiple entities to database.
	 *
	 * @param entities
	 * @return
	 */
	boolean updateList(List<? extends AbstractEntity> entities);

	/**
	 * Fetches entity from database.
	 *
	 * @param sqlString
	 * @param values
	 * @param <T>
	 * @return
	 */
	<T> T fetch(String sqlString, Object... values);

	/**
	 * Queries a list of entities from database.
	 *
	 * @param sqlString
	 * @param values
	 * @param <T>
	 * @return
	 */
	<T> List<T> query(String sqlString, Object... values);

	/**
	 * Queries a list of entities from database by sql.
	 *
	 * @param sqlString
	 * @param <T>
	 * @return
	 */
	<T> List<T> sqlQuery(String sqlString);

	/**
	 * Update database by sql.
	 *
	 * @param sqlString
	 * @return
	 */
	int sqlUpdate(String sqlString);

	/**
	 * Queries a list of entities from database in limit count.
	 *
	 * @param sqlString
	 * @param start
	 * @param count
	 * @param values
	 * @param <T>
	 * @return
	 */
	<T> List<T> limitQuery(String sqlString, int start, int count, Object... values);

	/**
	 * Returns the count of entity which match the conditions.
	 *
	 * @param sqlString
	 * @param values
	 * @return
	 */
	long count(String sqlString, Object... values);

}
