package com.jengine.persist;

import com.jengine.Jengine;
import com.jengine.util.TimeUtil;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The super class of all database entity.
 */
@MappedSuperclass
public abstract class AbstractEntity implements Serializable {
    @Column(name = "create_at")
    protected Date createAt;

    @Column(name = "update_at")
    protected Date updateAt;

    @Column(name = "create_ts")
    protected int createTs;

    @Column(name = "update_ts")
    protected int updateTs;

    @Column(name = "invalid")
    protected boolean invalid;

    public Date getCreateAt() {
        return this.createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
        this.createTs = (int) (createAt.getTime() / 1000);
    }

    public Date getUpdateAt() {
        return this.updateAt;
    }

    public void setUpdateAt(Date updateAt) {
        this.updateAt = updateAt;
        this.updateTs = (int) (updateAt.getTime() / 1000);
    }

    public boolean isInvalid() {
        return this.invalid;
    }

    public void setInvalid(boolean invalid) {
        this.invalid = invalid;
    }

    public int getCreateTs() {
        return createTs;
    }

    public void setCreateTs(int createTs) {
        this.createTs = createTs;
    }

    public int getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(int updateTs) {
        this.updateTs = updateTs;
    }

    @Transient
    private AtomicLong needLandAt = new AtomicLong(0);

    public boolean isDirty() {
        return needLandAt.get() != 0;
    }

    public boolean trySetNeedLandAt(long ts) {
        return this.needLandAt.compareAndSet(0, ts);
    }

    public void resetLandTime() {
        this.needLandAt.set(0L);
    }

    public long getLandAt() {
        return this.needLandAt.get();
    }

    public boolean notifyCreate() {
        if (this.getCreateAt() == null) {
            this.setCreateAt(TimeUtil.getCalendar().getTime());
        }
        this.setUpdateAt(TimeUtil.getCalendar().getTime());

        return Jengine.getAppContext().get(DBEntityManager.class).create(this);
    }

    public void delete() {
        this.delete(true);
    }

    public void delete(boolean async) {
        this.setInvalid(true);
        if (async) {
            this.notifyUpdate(true);
        } else {
            Jengine.getAppContext().get(DBEntityManager.class).delete(this);
        }
    }

    public void notifyUpdate() {
        this.notifyUpdate(true);
    }

    public void notifyUpdate(boolean async) {
        if (this.getCreateAt() == null) {
            this.setCreateAt(TimeUtil.getCalendar().getTime());
        }

        this.setUpdateAt(TimeUtil.getCalendar().getTime());

        if (async) {
            Jengine.getAppContext().get(DBEntityManager.class).updateAsync(this);
        } else {
            Jengine.getAppContext().get(DBEntityManager.class).update(this);
        }
    }
}
