package com.jengine.persist;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import com.jengine.task.AbstractTask;
import com.jengine.thread.DefaultThreadPool;
import com.jengine.thread.ThreadPool;
import com.jengine.util.ClassScanner;
import com.jengine.util.CostTimeMonitor;
import com.jengine.util.RandUtil;
import com.jengine.util.TimeUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.slf4j.Logger;

import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * The default implementation of DBEntityManager
 *
 * @author mengyan
 */
public class DefaultDBEntityManager implements DBEntityManager, Runnable {
    protected static Logger log = Log.getDatabaseLogger();

    protected long optTimeout = Jengine.getConfiguration().getInt("database.opTimeout");

    protected volatile boolean running;
    protected boolean landImmediately;
    protected Configuration configuration;
    protected Thread asyncThread;
    protected ThreadPool asyncThreadPool;
    protected LinkedList<AbstractEntity> asyncList;
    protected SessionFactory sessionFactory;

    public DefaultDBEntityManager() {
        asyncList = new LinkedList<>();
    }

    protected void startAsyncThread() {
        if (asyncThread == null) {
            asyncThread = new Thread(this);
            asyncThread.setName("DBManager");
            asyncThread.start();

            int asyncThreadNum = Jengine.getConfiguration().getInt("database.asyncThreadNum");
            if (asyncThreadNum > 1) {
                asyncThreadPool = new DefaultThreadPool("DbManager", asyncThreadNum);
                asyncThreadPool.start();
            }
        }
    }

    @Override
    public void sync() {
        this.landImmediately = true;
    }

    private Session getSession() {
        if (sessionFactory != null) {
            return sessionFactory.getCurrentSession();
        }
        return null;
    }

    @Override
    public boolean create(AbstractEntity entity) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                session.save(entity);
                trans.commit();
                return true;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("create");
            monitor.printWarning();
        }
        return false;
    }

    @Override
    public boolean createList(List<? extends AbstractEntity> entities) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                for (int i = 0; i < entities.size(); i++) {
                    session.save(entities.get(i));
                }
                trans.commit();
                return true;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("createList");
            monitor.printWarning();
        }
        return false;
    }

    @Override
    public boolean delete(AbstractEntity entity) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                session.delete(entity);
                trans.commit();
                return true;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("delete");
            monitor.printWarning();
        }
        return false;
    }

    @Override
    public boolean deleteList(List<? extends AbstractEntity> entities) {
        if (entities == null || entities.size() <= 0) {
            return false;
        }

        String className = "";
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
        Session session = getSession();
        Transaction trans = session.beginTransaction();
        try {
            for (AbstractEntity entity : entities) {
                if (entity == null) {
                    continue;
                }
                className = entity.getClass().getSimpleName();
                session.delete(entity);
            }

            trans.commit();
            return true;
        } catch (Exception e) {
            trans.rollback();
            JengineException.catchEx(e);
        } finally {
            monitor.knock("deleteList");
            monitor.printWarning();
        }
        return false;
    }

    @Override
    public boolean update(AbstractEntity entity) {
        if (entity != null) {
            CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
            try {
                Session session = getSession();
                Transaction trans = session.beginTransaction();
                try {
                    if (entity.isInvalid()) {
                        session.delete(entity);
                    } else {
                        session.saveOrUpdate(entity);
                    }
                    trans.commit();
                    return true;
                } catch (Exception e) {
                    trans.rollback();
                    JengineException.catchEx(e);
                }
            } catch (Exception e) {
                JengineException.catchEx(e);
            } finally {
                monitor.knock("update");
                monitor.printWarning();
            }
        }
        return false;
    }

    @Override
    public int update(String sqlString) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createQuery(sqlString);
                int result = query.executeUpdate();
                trans.commit();
                return result;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("update");
            monitor.printWarning();
        }
        return 0;
    }

    @Override
    public boolean updateAsync(AbstractEntity entity) {
        if (asyncThread == null) {
            return update(entity);
        }

        long landTime = TimeUtil.getTimeInMillis() + Jengine.getConfiguration().getInt("database.asyncPeriod") * 1000;
        try {
            int offset = Jengine.getConfiguration().getInt("database.asyncPeriod") * 1000 / 5;
            landTime += (RandUtil.randInt(offset * 2) - offset);
        } catch (Exception e) {
        }

        if (entity.trySetNeedLandAt(landTime)) {
            synchronized (asyncList) {
                asyncList.remove(entity);
                int index = 0;
                try {
                    Iterator<AbstractEntity> iterator = asyncList.iterator();
                    while (iterator.hasNext()) {
                        AbstractEntity nodeEntity = iterator.next();
                        long landAt = nodeEntity.getLandAt();
                        if (landTime >= landAt) {
                            if (landAt <= 0) {
                                log.error("updateAsync stateError: entity {} " + nodeEntity.getClass().getSimpleName());
                            }
                            break;
                        }
                        index++;
                    }
                } catch (Exception e) {
                    index = 0;
                    JengineException.catchEx(e);
                }

                asyncList.add(index, entity);
            }
        } else if (TimeUtil.getTimeInMillis() - entity.getLandAt() >= Jengine.getConfiguration().getInt("database.asyncPeriod") * 1000 * 2) {
            log.error("updateAsync timeout: timeout:{}, entity: {}, landAt: {}", TimeUtil.getTimeInMillis() - entity.getLandAt(), entity.getClass().getSimpleName(), entity.getLandAt());
            update(entity);
        }
        return true;
    }

    @Override
    public boolean updateList(List<? extends AbstractEntity> entities) {
        if (entities == null || entities.size() <= 0) {
            return false;
        }

        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
        Session session = getSession();
        Transaction trans = session.beginTransaction();
        try {
            for (AbstractEntity entity : entities) {
                if (entity == null) {
                    continue;
                }
                session.update(entity);
            }
            trans.commit();
            return true;
        } catch (Exception e) {
            trans.rollback();
            JengineException.catchEx(e);
        } finally {
            monitor.knock("updateList");
            monitor.printWarning();
        }
        return false;
    }

    @Override
    public <T> T fetch(String sqlString, Object... values) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createQuery(sqlString);
                if (values != null) {
                    for (int i = 0; i < values.length; i++) {
                        query.setParameter(i, values[i]);
                    }
                }
                Object entity = query.uniqueResult();
                trans.commit();
                return (T) entity;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("fetch");
            monitor.printWarning();
        }
        return null;
    }

    @Override
    public <T> List<T> query(String sqlString, Object... values) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createQuery(sqlString);
                if (values != null) {
                    for (int i = 0; i < values.length; i++) {
                        query.setParameter(i, values[i]);
                    }
                }
                List<T> list = (List<T>) query.list();
                trans.commit();
                return list;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("query");
            monitor.printWarning();
        }
        return null;
    }

    @Override
    public <T> List<T> sqlQuery(String sqlString) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);
        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createSQLQuery(sqlString);
                List<T> list = (List<T>) query.list();
                trans.commit();
                return list;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("sqlQuery");
            monitor.printWarning();
        }
        return null;
    }

    @Override
    public int sqlUpdate(String sqlString) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        int effectCount = 0;
        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = session.createSQLQuery(sqlString);
                effectCount = query.executeUpdate();
                trans.commit();
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("sqlUpdate");
            monitor.printWarning();
        }
        return effectCount;
    }

    @Override
    public <T> List<T> limitQuery(String sqlString, int start, int count, Object... values) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createQuery(sqlString);
                if (values != null) {
                    for (int i = 0; i < values.length; i++) {
                        query.setParameter(i, values[i]);
                    }
                }
                query.setFirstResult(start);
                query.setMaxResults(count);
                List<T> list = (List<T>) query.list();
                trans.commit();
                return list;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("limitQuery");
            monitor.printWarning();
        }
        return null;
    }

    @Override
    public long count(String sqlString, Object... values) {
        CostTimeMonitor monitor = new CostTimeMonitor("DBEntityManager", log, optTimeout);

        try {
            Session session = getSession();
            Transaction trans = session.beginTransaction();
            try {
                Query query = getSession().createQuery(sqlString);
                if (values != null) {
                    for (int i = 0; i < values.length; i++) {
                        query.setParameter(i, values[i]);
                    }
                }
                long count = (Long) query.uniqueResult();
                trans.commit();
                return count;
            } catch (Exception e) {
                trans.rollback();
                JengineException.catchEx(e);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        } finally {
            monitor.knock("count");
            monitor.printWarning();
        }
        return 0;
    }

    @Override
    public String getId() {
        return "DBEntityManager";
    }

    @Override
    public boolean init() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            if (this.configuration == null) {
                String configPath = System.getProperty("user.dir") + File.separator + "hibernate.cfg.xml";
                this.configuration = new Configuration();
                this.configuration.configure(new File(configPath));
            }

            String url = Jengine.getConfiguration().getString("database.connection.url");
            this.configuration.setProperty("hibernate.connection.url", url);
            this.configuration.setProperty("hibernate.connection.username", Jengine.getConfiguration().getString("database.connection.username"));
            this.configuration.setProperty("hibernate.connection.password", Jengine.getConfiguration().getString("database.connection.password"));

            String[] entityPackages = Jengine.getConfiguration().getString("database.entityPackages").split(",");
            if (entityPackages != null) {
                for (String entityPackage : entityPackages) {
                    log.info("init entity package: " + entityPackage);
                    Set<Class> entities = ClassScanner.scanClassInPackage(entityPackage, false);
                    for (Class entity : entities) {
                        this.configuration.addAnnotatedClass(entity);
                    }
                }
            }

            this.sessionFactory = this.configuration.buildSessionFactory();

            log.info("Init database url: {}, entity packages: {} success.", url, entityPackages);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }
        return true;
    }

    @Override
    public boolean startup() {
        this.running = true;
        this.startAsyncThread();
        return true;
    }

    @Override
    public boolean shutdown() {
        this.running = false;
        if (this.asyncThread != null) {
            try {
                this.asyncThread.join();
                this.asyncThread = null;
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }

        if (this.asyncThreadPool != null) {
            try {
                this.asyncThreadPool.close(true);
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }

        return true;
    }

    @Override
    public void run() {
        while (this.running) {
            try {
                if (!executeAsyncList()) {
                    Thread.sleep(Jengine.getConfiguration().getInt("database.checkAsyncSavePeriod"));
                }
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }

        log.info("DBEntityManager exit, save data start...");
        this.sync();
        this.executeAsyncList();
        log.info("DBEntityManager exit, save data finish.");
    }

    private void landDBImmediately() {
        this.landImmediately = false;
        synchronized (this.asyncList) {
            for (AbstractEntity entity : asyncList) {
                doAsyncUpdate(entity);
                if (entity != null) {
                    entity.resetLandTime();
                }
            }

            log.info("[DBEntityManager] landImmediately, entity count: {}", asyncList.size());
            asyncList.clear();
        }
    }

    private boolean executeAsyncList() {
        if (this.landImmediately) {
            this.landDBImmediately();
            return true;
        } else {
            long curTime = TimeUtil.getTimeInMillis();
            AbstractEntity lastEntity = asyncList.peekLast();
            if (lastEntity != null && curTime >= lastEntity.getLandAt()) {
                AbstractEntity entity;
                synchronized (asyncList) {
                    entity = asyncList.pollLast();
                }

                if (entity != null) {
                    entity.resetLandTime();
                    doAsyncUpdate(entity);
                    return true;
                }
            }
        }
        return false;
    }

    private void doAsyncUpdate(final AbstractEntity entity) {
        if (this.asyncThreadPool == null) {
            update(entity);
        } else {
            this.asyncThreadPool.addTask(new AbstractTask(true) {
                @Override
                public void run() {
                    update(entity);
                }

                @Override
                public int getType() {
                    return 0;
                }
            });
        }
    }
}
