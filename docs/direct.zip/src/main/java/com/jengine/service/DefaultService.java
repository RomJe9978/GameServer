package com.jengine.service;

public class DefaultService implements Service {
    @Override
    public String getId() {
        return "DefaultService";
    }

    @Override
    public boolean init() {
        return true;
    }

    @Override
    public boolean startup() throws Exception {
        return true;
    }

    @Override
    public boolean shutdown() throws Exception {
        return true;
    }
}
