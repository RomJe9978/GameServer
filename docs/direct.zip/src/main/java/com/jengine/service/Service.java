package com.jengine.service;

/**
 * Lifecycle management interface
 *
 * @author mengyan
 */
public interface Service {
    String getId();

    boolean init();

    boolean startup() throws Exception;

    boolean shutdown() throws Exception;
}
