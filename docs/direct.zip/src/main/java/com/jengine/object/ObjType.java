package com.jengine.object;

public class ObjType {
    /**
     * PLAYER represents a user role in the server.
     */
    public static final int PLAYER = 1;

    /**
     * CLIENT represents a device unique id.
     */
    public static final int CLIENT = 2;

    /**
     * MANAGER represents a manager object in the server.
     */
    public static final int MANAGER = 3;

    /**
     * CLUSTER represents a cluster manager in the server.
     */
    public static final int CLUSTER = 4;

    /**
     * LOGIC-ITEM
     */
    public static final int LOGIC = 5;

    /**
     * RPC
     */
    public static final int RPC = 6;
}
