package com.jengine.object;

import java.util.Objects;

/**
 * A {@ObjectId} represents the ID of a game object.
 *
 * @author mengyan
 */
public class ObjectId implements Comparable<ObjectId>, Cloneable {
    /**
     * Invalid object id defines.
     */
    static public final long INVALID_OBJECT_ID = 0L;
    /**
     * The type of game object.
     */
    private int type;

    /**
     * The actual id of game object.
     */
    private long id;

    private ObjectId() {
        this.type = 0;
        this.id = 0;
    }

    private ObjectId(int type) {
        this.id = 0;
        this.type = type;
    }

    private ObjectId(long id) {
        this.type = 0;
        this.id = id;
    }

    public ObjectId(int type, long id) {
        this.type = type;
        this.id = id;
    }

    public static ObjectId valueOf(int type) {
        return new ObjectId(type);
    }

    public static ObjectId valueOfId(long id) {
        return new ObjectId(id);
    }

    public static ObjectId valueOf(int type, long id) {
        return new ObjectId(type, id);
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ObjectId objectId = (ObjectId) o;
        return type == objectId.type &&
                id == objectId.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, id);
    }


    @Override
    protected ObjectId clone() throws CloneNotSupportedException {
        return new ObjectId(this.type, this.id);
    }

    @Override
    public int compareTo(ObjectId o) {
        if (this.type < o.type) {
            return -1;
        } else if (this.type > o.type) {
            return 1;
        }

        if (this.id < o.id) {
            return -1;
        } else if (id > o.id) {
            return 1;
        }

        return 0;
    }

    @Override
    public String toString() {
        return "ObjectId{" +
                "type=" + type +
                ", id=" + id +
                '}';
    }
}
