package com.jengine.object;

import com.jengine.thread.Lockable;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * The default implementation of {@GameObject}.
 *
 * @author mengyan
 */
public class SimpleGameObject implements GameObject, Lockable {
    /**
     * The holder of Object ID.
     */
    protected ObjectId oid;

    private Lock locker;

    private long lastTouchMillis;

    public SimpleGameObject() {
        this.locker = new ReentrantLock();
    }

    public SimpleGameObject(ObjectId objectId) {
        this();
        this.oid = objectId;
    }

    @Override
    public int getType() {
        if (this.oid != null) {
            return this.oid.getType();
        }
        return 0;
    }

    @Override
    public ObjectId getOId() {
        return this.oid;
    }

    @Override
    public synchronized void setOId(ObjectId oid) {
        this.oid = oid;
    }

    @Override
    public boolean lock() {
        if (this.locker != null) {
            return this.locker.tryLock();
        }
        return false;
    }

    @Override
    public boolean unlock() {
        if (this.locker != null) {
            this.locker.unlock();
            return true;
        }
        return false;
    }

    @Override
    public synchronized void setLastTouchTime(long curMillis) {
        this.lastTouchMillis = curMillis;
    }

    @Override
    public synchronized long getLastTouchTimeInMillis() {
        return this.lastTouchMillis;
    }
}
