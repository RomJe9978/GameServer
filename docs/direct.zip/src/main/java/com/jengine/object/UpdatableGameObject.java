package com.jengine.object;

import com.jengine.Jengine;
import com.jengine.updater.BaseUpdatable;
import com.jengine.updater.Updatable;

/**
 * UpdatableGameObject represents a simple Game Object which has update method.
 * The update method will be called in the thread id calculated by hash.
 *
 * @author mengyan
 */
public class UpdatableGameObject extends SimpleGameObject implements Updatable {
    protected BaseUpdatable updatable;

    public UpdatableGameObject() {
        this.updatable = new BaseUpdatable();
        Jengine.getUpdater().addSyncUpdatable(this);
    }

    public UpdatableGameObject(long intervalInMillis) {
        this.updatable = new BaseUpdatable(intervalInMillis);
        Jengine.getUpdater().addSyncUpdatable(this);
    }

    @Override
    public long getUpdateInterval() {
        return this.updatable.getUpdateInterval();
    }

    @Override
    public long getLastUpdateAt() {
        return this.updatable.getLastUpdateAt();
    }

    @Override
    public boolean update() {
        return this.updatable.update();
    }
}