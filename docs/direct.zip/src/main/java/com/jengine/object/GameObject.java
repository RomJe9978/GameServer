package com.jengine.object;

/**
 * A {@GameObject} represents an entity in game.
 */
public interface GameObject {
	/**
	 * Returns the type of game object.
	 *
	 * @return
	 */
	int getType();

	/**
	 * Returns the holder of Object ID in this Object.
	 *
	 * @return
	 */
	ObjectId getOId();

	/**
	 * Sets the holder of Object ID in this Object.
	 *
	 * @param oid
	 */
	void setOId(ObjectId oid);

	/**
	 * Locks this object to ensure thread-safe.
	 *
	 * @return
	 */
	boolean lock();

	/**
	 * Unlocks the object.
	 *
	 * @return
	 */
	boolean unlock();

	/**
	 * Updates the last time in milliseconds of touching this object.
	 *
	 * @param curMillis
	 */
	void setLastTouchTime(long curMillis);

	/**
	 * Returns the last touching time in milliseconds.
	 *
	 * @return
	 */
	long getLastTouchTimeInMillis();
}
