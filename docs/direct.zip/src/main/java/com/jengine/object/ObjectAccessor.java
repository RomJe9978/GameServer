package com.jengine.object;

import com.jengine.Jengine;
import com.jengine.JengineConfiguration;
import com.jengine.logger.Log;
import com.jengine.updater.BaseUpdatable;
import com.jengine.util.TimeUtil;
import org.slf4j.Logger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Accessor of cached objects.
 * There may be different accesors for different purposes.
 *
 * @author mengyan
 */
public class ObjectAccessor extends BaseUpdatable {
    private static final Logger log = Log.getJengineLogger();

    /**
     * The default size Of object map.
     */
    private static final int DEFAULT_SIZE = JengineConfiguration.getDefaultSizeOfObjectAccessor();

    /**
     * The object's expired interval.
     * If objectTimeoutMillis <= 0, represents that the objects won'nt be expired.
     */
    private long objectTimeoutMillis;

    private long lastCheckTimeMillis;
    private long lastTickTimeMillis;

    /**
     * Type of game object.
     */
    private int type;

    /**
     * All cached object in the accessor.
     */
    private Map<ObjectId, GameObject> objects;

    public ObjectAccessor(int type) {
        this.objects = new ConcurrentHashMap<>(DEFAULT_SIZE);
        this.type = type;

        this.lastCheckTimeMillis = TimeUtil.getTimeInMillis();
        this.lastTickTimeMillis = TimeUtil.getTimeInMillis();
    }

    public long getObjectTimeoutMillis() {
        return this.objectTimeoutMillis;
    }

    public void setObjectTimeoutMillis(long objectTimeoutMillis) {
        this.objectTimeoutMillis = objectTimeoutMillis;
    }

    public synchronized GameObject addObject(GameObject gameObject) {
        if (gameObject == null) {
            log.error("[ObjectAccessor] addObject GameObject is null!", gameObject.getOId());
            return null;
        }

        if (this.objects.containsKey(gameObject.getOId())) {
            log.warn("[ObjectAccessor] addObject GameObject ID {} is already exist!", gameObject.getOId());
        }

        gameObject.setLastTouchTime(TimeUtil.getTimeInMillis());
        this.objects.put(gameObject.getOId(), gameObject);
        return gameObject;
    }

    public GameObject removeObject(ObjectId oid) {
        return this.objects.remove(oid);
    }

    public GameObject queryObject(ObjectId oid) {
        return this.objects.get(oid);
    }

    public Set<ObjectId> getAllObjectIds() {
        return this.objects.keySet();
    }

    public boolean lockObject(ObjectId oid) {
        if (this.objects.containsKey(oid)) {
            return this.objects.get(oid).lock();
        }

        return false;
    }

    public boolean unlockObject(ObjectId oid) {
        if (this.objects.containsKey(oid)) {
            return this.objects.get(oid).unlock();
        }

        return false;
    }

    public List<GameObject> removeExpiredObject(long currentMillis, boolean changedTime) {
        List<GameObject> removedObj = new ArrayList<>();

        if (this.objectTimeoutMillis > 0) {
            Iterator<Map.Entry<ObjectId, GameObject>> iterator = this.objects.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<ObjectId, GameObject> kv = iterator.next();
                if (changedTime) {
                    kv.getValue().setLastTouchTime(currentMillis);
                    continue;
                }

                if ((currentMillis >= kv.getValue().getLastTouchTimeInMillis() + this.objectTimeoutMillis)) {
                    removedObj.add(kv.getValue());
                    iterator.remove();
                }
            }
        }

        return removedObj;
    }

    @Override
    public boolean update() {
        super.update();

        // Check if the object expired,
        // This need a longer timeout check interval,
        // if it times out, remove it from the cache
        if (TimeUtil.getTimeInMillis() - this.lastCheckTimeMillis > Jengine.getConfiguration().getInt("object.cacheExpiredCheckCycle")) {
            boolean isChangeTime = this.isChangedTime();
            this.lastCheckTimeMillis = TimeUtil.getTimeInMillis();
            List<GameObject> removedObjects = this.removeExpiredObject(TimeUtil.getTimeInMillis(), isChangeTime);
            log.info("ObjectAccessor remove timeout object, type:{}, remove count: {}, current total count:{}",
                    this.type, removedObjects.size(), this.objects.size());
        }

        // Call ticker on modules
        // Use default update interval.
        /*
        if (TimeUtil.getTimeInMillis() - this.lastTickTimeMillis > Jengine.getConfiguration().getInt("module.tickCycle")) {
            List<Module> modules = ModuleManager.getInstance().getModules(this.type);
            if (modules != null && modules.size() > 0) {
                for (Map.Entry<ObjectId, GameObject> kv : this.objects.entrySet()) {
                    TaskExecutor.getInstance().postTickTask(TickTask.valueOf(kv.getKey(), true));
                }
            }
        }
         */

        return true;
    }

    /**
     * When the two update intervals are greater than the object timeout period,
     * the system time is considered modified
     *
     * @return
     */
    private boolean isChangedTime() {
        return TimeUtil.getTimeInMillis() - this.lastCheckTimeMillis > Jengine.getConfiguration().getInt("object.cacheExpiredCheckCycle") * 10;
    }
}
