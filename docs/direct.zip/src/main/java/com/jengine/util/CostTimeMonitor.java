package com.jengine.util;


import org.slf4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * A util for monitoring the cost of time.
 *
 * @author mengyan
 */
public class CostTimeMonitor implements Serializable {
	private static final int NO_OPCODE = -1;
	private static final long NANO_TIME_TO_MILLIS = 1000000L;

	private List<String> causeList = new ArrayList<>();
	private List<Long> timeList = new ArrayList<>();
	private String module;
	private long warnThreshold;
	private Logger log;

	public CostTimeMonitor() {
		this.module = "default";
	}

	public CostTimeMonitor(String module) {
		this.module = module;
	}

	public CostTimeMonitor(String module, Logger log, long warnThreshold) {
		this.module = module;
		this.warnThreshold = warnThreshold;
		this.log = log;
	}

	public void knock(String cause) {
		this.causeList.add(cause);
		this.timeList.add(System.nanoTime());
	}

	public void printWarning() {
		long totalTime = this.totalTime();

		if (totalTime > this.warnThreshold) {
			this.log.warn("{} timeout, info: {}", this.module, this.dumpMessage());
		}
	}

	private long totalTime() {
		return (((Long) this.timeList.get(this.timeList.size() - 1)).longValue() - ((Long) this.timeList.get(0)).longValue()) / NANO_TIME_TO_MILLIS;
	}

	public String dumpMessage() {
		return this.dumpMessage(NO_OPCODE);
	}

	public String dumpMessage(int opcode) {
		this.timeList.add(System.nanoTime());

		long totalTime = this.totalTime();
		StringBuilder sb = new StringBuilder();
		sb.append("\r\n========================================\r\n");
		sb.append("CostTimeMonitor: [").append(this.module).append("]");
		sb.append("\r\n---------------------------------------\r\n");
		sb.append("STEP\tCAUSE\t\t\t\tTIME");

		for (int i = 1; i < this.timeList.size(); i++) {
			sb.append("\r\n").append(i - 1);
			sb.append(".\t    ").append(this.causeList.get(i - 1));
			long t = (((Long) this.timeList.get(i)).longValue() - ((Long) this.timeList.get(i - 1)).longValue()) / NANO_TIME_TO_MILLIS;
			sb.append("\t\t\t\t").append(t).append("ms");

		}
		sb.append("\r\n---------------------------------------\r\n");

		if (opcode == NO_OPCODE) {
			sb.append("module : ").append(this.module).append(", total time : ").append(totalTime).append("ms");
		} else {
			sb.append("opcode : ").append(opcode).append(", total time : ").append(totalTime).append("ms");
		}

		sb.append("\r\n========================================\r\n");
		return sb.toString();
	}
}
