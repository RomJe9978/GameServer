package com.jengine.util;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.constant.TimeConst;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class TimeUtil {
    private static final Logger log = LoggerFactory.getLogger(TimeUtil.class);

    public static final int SECS_IN_DAY = 24 * 60 * 60;
    public static final String PATTERN_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String PATTERN_YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String PATTERN_YYYY_MM_DD_HH = "yyyy-MM-dd HH";
    public static final String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String PATTERN_YYYYMMDD = "yyyyMMdd";

    public static final String PATTERN_SEPARATOR = ":";

    /**
     * 给定小时数，转换成秒数
     *
     * @param hour 非正数，为无效参数
     * @return 调用处自行考虑long值结果的必要性
     */
    public static long secondOfHours(int hour) {
        if (hour <= 0) {
            return 0;
        }
        return (long) hour * TimeConst.SECONDS_OF_HOUR;
    }

    public static final List<Integer> parseHMS(String formatter) {
        List<Integer> hms = new ArrayList<>();
        if (StringUtil.isEmpty(formatter)) {
            hms.add(0);
            hms.add(0);
            hms.add(0);
            return hms;
        }
        String[] result = formatter.split(PATTERN_SEPARATOR);
        for (String r : result) {
            hms.add(Integer.parseInt(r));
        }

        return hms;
    }

    public static final int parseSecsFromHMS(String formatter) {
        List<Integer> hms = parseHMS(formatter);
        if (hms.size() >= 3) {
            return hms.get(0) * 3600 + hms.get(1) * 60 + hms.get(2);
        } else {
            return 0;
        }
    }

    /**
     * Date time formatter yyyy-MM-dd HH:mm:ss
     */
    public static final DateTimeFormatter YYYYMMDDHHMMSS = DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD_HH_MM_SS)
            .withLocale(Locale.getDefault());

    /**
     * Date time formatter yyyy-MM-dd HH:mm
     */
    public static final DateTimeFormatter YYYYMMDDHHMM = DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD_HH_MM);

    /**
     * Date time formatter yyyy-MM-dd HH
     */
    public static final DateTimeFormatter YYYY_MM_DD_HH = DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD_HH);

    /**
     * Date time formatter yyyy-MM-dd
     */
    public static final DateTimeFormatter YYYY_MM_DD = DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD);

    /**
     * Date time formatter yyyyMMdd
     */
    public static final DateTimeFormatter YYYYMMDD = DateTimeFormatter.ofPattern(PATTERN_YYYYMMDD);

    private static long offsetInMillis = 0L;

    public static synchronized long getOffsetInMillis() {
        return offsetInMillis;
    }

    public static synchronized void setOffsetInMillis(long offsetMillis) {
        offsetInMillis = offsetMillis;
    }

    /**
     * Update time to the target date.
     *
     * @param date
     */
    public static void setTo(Date date) {
        Calendar calendar = Calendar.getInstance();
        setOffsetInMillis(date.getTime() - calendar.getTimeInMillis());
    }

    public static Date secondTimestampToDate(long tsInSecond) {
        return milliTimestampToDate(tsInSecond * 1000);
    }

    public static Date milliTimestampToDate(long msInSecond) {
        Date date = new Date(msInSecond);
        return date;
    }

    /**
     * Return the offset-calendar
     *
     * @return
     */
    public static Calendar getCalendar() {
        Calendar calendar = Calendar.getInstance();
        if (getOffsetInMillis() != 0) {
            calendar.setTimeInMillis(calendar.getTimeInMillis() + getOffsetInMillis());
        }

        return calendar;
    }

    /**
     * Return the offset-time in milliseconds.
     *
     * @return
     */
    public static long getTimeInMillis() {
        return getCalendar().getTimeInMillis();
    }

    /**
     * Return the offset-time in seconds.
     *
     * @return
     */
    public static int getTimeInSeconds() {
        return (int) (getTimeInMillis() / 1000);
    }

    /**
     * Return the date at AM 0 of target date.
     *
     * @param date
     * @return
     */
    public static Date getDateAt0AM(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public static Date getDateAt(Date date, int hour, int minute, int second) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, second);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public static Date getCurDateAt(int hour, int minute, int second) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(getDate());
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, second);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public static Date getDate() {
        Calendar curTime = getCalendar();
        return curTime.getTime();
    }

    public static Date getNextDate() {
        Calendar curTime = getCalendar();
        curTime.add(Calendar.DAY_OF_MONTH, 1);
        return curTime.getTime();
    }

    public static Date getNextDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date nextDay = cal.getTime();
        return nextDay;
    }

    /**
     * Judges that whether represents the same day of two timestamp.
     *
     * @param date1 the milliseconds since January 1, 1970, 00:00:00 GMT.
     * @param date2 the milliseconds since January 1, 1970, 00:00:00 GMT.
     * @return
     */
    public static boolean isSameDay(long date1, long date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(new Date(date1));

        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(new Date(date2));

        return calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR) &&
                calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH)
                && calendar1.get(Calendar.DAY_OF_MONTH) == calendar2.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * Judges that whether the same day of target date with today.
     *
     * @param date
     * @return
     */
    public static boolean isToday(Date date) {
        return isSameDay(getCalendar().getTimeInMillis(), date.getTime());
    }

    private static String formatTime(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }

    private static String formatTime(Date date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    /**
     * Return a time string in "yyyy-MM-dd HH:mm:ss" pattern of now.
     *
     * @return
     */
    public static String getTimeString() {
        Date now = getCalendar().getTime();
        return formatTime(now);
    }

    public static String getTimeString(String pattern) {
        Date now = getCalendar().getTime();
        return formatDate(now, pattern);
    }

    /**
     * Return a time string in "yyyy-MM-dd HH:mm:ss" pattern of target date.
     *
     * @return
     */
    public static String getTimeString(Date date) {
        return formatTime(date);
    }

    public static String getTimeString(Date date, String pattern) {
        return formatTime(date, pattern);
    }

    private static String formatDate(Date date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    private static String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    /**
     * Return a time string in "yyyy-MM-dd" pattern of now.
     *
     * @return
     */
    public static String getDateString() {
        Date now = getCalendar().getTime();
        return formatDate(now);
    }

    public static String getDateString(String pattern) {
        Date now = getCalendar().getTime();
        return formatDate(now, pattern);
    }

    /**
     * Return a time string in "yyyy-MM-dd" pattern of target date.
     *
     * @return
     */
    public static String getDateString(Date date) {
        return formatDate(date);
    }

    public static String getDateString(Date date, String pattern) {
        return formatDate(date, pattern);
    }

    /**
     * ls
     * Return a Date from a formated Date string in pattern.
     *
     * @param dateStr the target date string.
     * @param pattern the pattern of date string, such as "yyyy-MM-dd" or "yyyy-MM-dd HH:mm:ss".
     * @return
     */
    public static Date getDateFromString(String dateStr, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            JengineException.catchEx(e);
        }
        return sdf.getCalendar().getTime();
    }

    public static int getDateSecondFromString(String dateStr, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            JengineException.catchEx(e);
        }
        return (int) (sdf.getCalendar().getTimeInMillis() / 1000);
    }

    /**
     * Calculates the milliseconds between two dates.
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long millisBetween(Date date1, Date date2) {
        if (date1 == null || date2 == null) {
            return 0;
        }

        long diff = date1.getTime() - date2.getTime();
        return diff;
    }

    /**
     * Calculates the secons between two dates.
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long secondsBetween(Date date1, Date date2) {
        long diffMillis = millisBetween(date1, date2);
        return TimeUnit.MILLISECONDS.toSeconds(diffMillis);
    }

    /**
     * Calculates the minutes between two dates.
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long minutesBetween(Date date1, Date date2) {
        long diffMillis = millisBetween(date1, date2);
        return TimeUnit.MILLISECONDS.toMinutes(diffMillis);
    }

    /**
     * Calculates the hours between two dates.
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long hoursBetween(Date date1, Date date2) {
        long diffMillis = millisBetween(date1, date2);
        return TimeUnit.MILLISECONDS.toHours(diffMillis);
    }

    public static boolean isBetween(Date test, Date start, Date end) {
        return millisBetween(test, start) >= 0 && millisBetween(test, end) < 0;
    }

    /**
     * Calculates the days between two dates.
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long daysBetween(Date date1, Date date2) {
        long diffMillis = millisBetween(date1, date2);
        return TimeUnit.MILLISECONDS.toDays(diffMillis);
    }

    /**
     * Calculates the days between two date time in millis.
     */
    public static long daysBetween(long time1, long time2) {
        return Duration.ofMillis(time1).toDays() - Duration.ofMillis(time2).toDays();
    }

    public static int daysBetween(int time1, int time2) {
        return (int) (Duration.ofSeconds(time1).toDays() - Duration.ofSeconds(time2).toDays());
    }

    /**
     * 返回指定时间与当前时间的天数差
     *
     * @param time 以毫秒为单位的时间戳
     * @return 正数，指定的时间要比当前时间晚，未来时间；负数，指定的时间要比当前时间早，已经过去了的时间
     */
    public static long daysOffsetNow(long time) {
        return Duration.ofMillis(time).toDays() - Duration.ofMillis(getTimeInMillis()).toDays();
    }

    /**
     * @return 获取系统当前第几周 1-7
     */
    public static int getDayOfWeek() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault()).getDayOfWeek().getValue();
    }

    /**
     * @return 获取系统当前第几月 1-12
     */
    public static int getMonth() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault()).getMonthValue();
    }

    public static Date getFirstDayOfLastMonth(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.MONTH, -1);
        cd.set(Calendar.DAY_OF_MONTH, 1);
        return cd.getTime();
    }

    public static Date getFirstDayOfThisMonth() {
        return getFirstDayOfThisMonth(getDate());
    }

    public static Date getFirstDayOfThisMonth(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.set(Calendar.DAY_OF_MONTH, 1);
        return cd.getTime();
    }

    public static Date getFirstDayOfNextMonth(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.MONTH, 1);
        cd.set(Calendar.DAY_OF_MONTH, 1);
        return cd.getTime();
    }

    public static Date getNextMonth(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.MONTH, 1);
        return cd.getTime();
    }

    public static Date getLastWeekMonday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(getThisWeekMonday(date));
        cal.add(Calendar.DATE, -7);
        return cal.getTime();
    }

    public static Date getThisWeekMonday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (1 == dayWeek) {
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        int day = cal.get(Calendar.DAY_OF_WEEK);
        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - day);
        return cal.getTime();
    }

    public static Date getDateAfter(int after) {
        Calendar calendar = getCalendar();
        calendar.setTime(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, after);
        return calendar.getTime();
    }

    /**
     * 获取几天后的日期
     *
     * @param date  参考日期
     * @param after 几天后
     * @return Date
     */
    public static Date getDateAfter(Date date, int after) {
        Calendar calendar = getCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, after);
        return calendar.getTime();
    }

    public static Date getNextMonday(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);

        int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK);
        int nextMondayOffset = dayOfWeek == 1 ? 1 : 9 - dayOfWeek;
        cd.add(Calendar.DAY_OF_MONTH, nextMondayOffset);
        return cd.getTime();
    }

    /**
     * @param pattern 日期格式
     * @return 当月第一天的日期字符串
     */
    public static String getMonthFirstDayFormat(String pattern) {
        LocalDateTime ldt = LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault());
        ldt = LocalDateTime.of(ldt.minusDays(ldt.getDayOfMonth() - 1).toLocalDate(), LocalTime.MIN);
        return ldt.format(DateTimeFormatter.ofPattern(pattern));
    }

    public static Date getMonthFirstDayDateFormat(String pattern) {
        String stringDate = getMonthFirstDayFormat(pattern);
        return getDateFromString(stringDate, pattern);
    }

    /**
     * @return 返回当月第一天日期格式的整数形式，例如20200101
     */
    public static int getMonthFirstDayInt() {
        return Integer.parseInt(getMonthFirstDayFormat(TimeUtil.PATTERN_YYYYMMDD));
    }

    public static int getMonthFirstDayInt(long timeMillis) {
        return Integer.parseInt(formatTime(milliTimestampToDate(timeMillis), TimeUtil.PATTERN_YYYYMMDD));
    }

    /**
     * @param pattern 日期格式
     * @return 当周第一天的日期字符串
     */
    public static String getWeekFirstDayFormat(String pattern) {
        LocalDateTime ldt = LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault());
        ldt = LocalDateTime.of(ldt.minusDays(ldt.getDayOfWeek().getValue() - 1).toLocalDate(), LocalTime.MIN);
        return ldt.format(DateTimeFormatter.ofPattern(pattern));
    }

    public static Date getWeekFirstDayDateFormat(String pattern) {
        String stringDate = getWeekFirstDayFormat(pattern);
        return getDateFromString(stringDate, pattern);
    }

    public static int getWeekFirstDayInt() {
        return Integer.parseInt(getWeekFirstDayFormat(TimeUtil.PATTERN_YYYYMMDD));
    }

    /**
     * @return 返回今日日期格式的整数形式，例如20200101
     */
    public static int getCurrentDayInt() {
        LocalDateTime ldt = LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault());
        return Integer.parseInt(ldt.format(YYYYMMDD));
    }

    public static int getTimestampFromDayInt(int dayInt) {
        Date date = getDateFromString(String.valueOf(dayInt), PATTERN_YYYYMMDD);
        return (int) (date.getTime() / 1000);
    }

    /**
     * @return 返回日期的整数形式，例如20200101
     */
    public static int getDateInt(Date date) {
        return date != null ? Integer.parseInt(formatTime(date, PATTERN_YYYYMMDD)) : 0;
    }

    public static int getDateTs(Date date) {
        return date != null ? (int) (date.getTime() / 1000) : 0;
    }

    public static int getDayOfThisMonth() {
        return getCalendar().get(Calendar.DAY_OF_MONTH);
    }

    public static int getDayOfThisMonth(Date date) {
        Calendar calendar = getCalendar();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * @return 返回今日流逝时间秒数（距离今日00:00:00的秒数差）
     */
    public static int getDayElapsedSeconds() {
        LocalDateTime now = LocalDateTime.ofInstant(Instant.ofEpochMilli(getTimeInMillis()), ZoneId.systemDefault());
        return now.getHour() * 60 * 60 + now.getMinute() * 60 + now.getSecond();
    }

    public static int getDayElapsedSeconds(int timestamp) {
        Date date = secondTimestampToDate(timestamp);
        Calendar calendar = getCalendar();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY) * 3600 + calendar.get(Calendar.MINUTE) * 60 + calendar.get(Calendar.SECOND);
    }

    /**
     * @return 返回今日剩余时间秒数
     */
    public static int getDayLeftSeconds() {
        return 86400 - getDayElapsedSeconds();
    }

    /**
     * @return 返回今日00:00:00时刻的时间戳
     */
    public static int getCurrentDayZeroTimestamps() {
        return getTimeInSeconds() - getDayElapsedSeconds();
    }

    public static int fromDateTime(Date date) {
        return (int) (date.getTime() / 1000);
    }

    /**
     * @return 获取当前时区相对于UTC时区偏移
     */
    public static int getTimeZoneOffset() {
        if (Jengine.getConfiguration().containsKey("server.timeZone")) {
            return Jengine.getConfiguration().getInt("server.timeZone");
        }
        return TimeUtil.getCalendar().getTimeZone().getOffset(TimeUtil.getTimeInMillis()) / 3600000;
    }

    private static LocalDate toLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    /**
     * @return 计算两个日期相隔的自然天数
     */
    public static long naturalDaysDiff(Date d1, Date d2) {
        LocalDate ldt1 = toLocalDate(d1);
        LocalDate ldt2 = toLocalDate(d2);
        return ChronoUnit.DAYS.between(ldt1, ldt2);
    }

    public static Date getDateFromInt(int dateInt) {
        return getDateFromString(String.valueOf(dateInt), PATTERN_YYYYMMDD);
    }

    public static int getTimestamp(String timeString) {
        Date date = getDateFromString(timeString, PATTERN_YYYY_MM_DD_HH_MM_SS);
        return fromDateTime(date);
    }

    public static boolean inTime(String starTime, String endTime, int timestamps) {
        if (StringUtil.isEmpty(starTime) && StringUtil.isEmpty(endTime)) {
            return true;
        }
        if (StringUtil.isNotEmpty(starTime) && StringUtil.isEmpty(endTime)) {
            return getDateSecondFromString(starTime, PATTERN_YYYY_MM_DD_HH_MM_SS) < timestamps;
        }
        if (StringUtil.isNotEmpty(endTime) && StringUtil.isEmpty(starTime)) {
            return getDateSecondFromString(endTime, PATTERN_YYYY_MM_DD_HH_MM_SS) > timestamps;
        }

        return timestamps >= getDateSecondFromString(starTime, PATTERN_YYYY_MM_DD_HH_MM_SS) &&
                timestamps < getDateSecondFromString(endTime, PATTERN_YYYY_MM_DD_HH_MM_SS);
    }

    public static boolean inTime(int starTime, int endTime, int timestamps) {
        if (starTime == 0 && endTime == 0) {
            return true;
        }

        if (starTime > 0 && endTime == 0) {
            return starTime < timestamps;
        }

        if (endTime > 0 && starTime == 0) {
            return endTime > timestamps;
        }

        return timestamps >= starTime && timestamps < endTime;
    }

    public static int zeroMinute(int timestamps) {
        return timestamps - timestamps % 60;
    }

    public static Date dateOfZeroMinute(int timestamps) {
        return TimeUtil.secondTimestampToDate(zeroMinute(timestamps));
    }

    public static Date getCurrentMonthBeginAt(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.set(Calendar.DAY_OF_MONTH, 1);
        return getDateAt(cd.getTime(), 0, 0, 0);
    }

    public static Date getCurrentMonthEndAt(Date date) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.set(Calendar.DAY_OF_MONTH, cd.getActualMaximum(Calendar.DAY_OF_MONTH));
        return getDateAt(cd.getTime(), 23, 59, 59);
    }

    public static boolean isValid(String time) {
        if (StringUtil.isNotEmpty(time)) {
            SimpleDateFormat sdf = new SimpleDateFormat(TimeUtil.PATTERN_YYYY_MM_DD_HH_MM_SS);
            try {
                sdf.parse(time);
            } catch (ParseException e) {
                JengineException.catchEx(e);
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println(getThisWeekMonday(new Date()));
        System.out.println(getDateAfter(-3));
        System.out.println(formatTime(getDate(), PATTERN_YYYY_MM_DD));
        System.out.println(getDate());
        System.out.println(getDayOfThisMonth());
        System.out.println(getDayOfThisMonth(getDateAfter(-3)));
        LocalDate before = LocalDate.parse("2020-12-17 20:30:00", DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD_HH_MM_SS));
        LocalDate after = LocalDate.parse("2020-12-18 23:00:00", DateTimeFormatter.ofPattern(PATTERN_YYYY_MM_DD_HH_MM_SS));
        System.out.println(ChronoUnit.DAYS.between(before, after));
        System.out.println(naturalDaysDiff(getDateFromString("2020-12-17 20:30:00", PATTERN_YYYY_MM_DD_HH_MM_SS), getDateFromString("2020-12-17 00:00:00", PATTERN_YYYY_MM_DD_HH_MM_SS)));
        System.out.println(getDateFromString("20210101", PATTERN_YYYYMMDD));
        System.out.println(inTime("2021-03-22 00:00:00", "2021-04-01 23:59:59", getTimeInSeconds()));
        System.out.println(inTime("2021-03-22 00:00:00", null, getTimeInSeconds()));
        System.out.println(inTime(null, "2021-04-01 23:59:59", getTimeInSeconds()));
        System.out.println(inTime(null, null, getTimeInSeconds()));
        System.out.println(inTime("2021-03-24 00:00:00", "2021-04-01 23:59:59", getTimeInSeconds()));

        String dateStr = "2021-06-30 23:59:59";
        System.out.println(formatTime(getCurrentMonthBeginAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));
        System.out.println(formatTime(getCurrentMonthEndAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));

        dateStr = "2021-06-10 00:00:00";
        System.out.println(formatTime(getCurrentMonthBeginAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));
        System.out.println(formatTime(getCurrentMonthEndAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));

        dateStr = "2021-07-30 23:59:59";
        System.out.println(formatTime(getCurrentMonthBeginAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));
        System.out.println(formatTime(getCurrentMonthEndAt(getDateFromString(dateStr, PATTERN_YYYY_MM_DD_HH_MM_SS))));
    }
}
