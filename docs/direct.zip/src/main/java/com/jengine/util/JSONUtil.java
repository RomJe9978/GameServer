package com.jengine.util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * A simple json util for load json object.
 *
 * @author mengyan
 */
public class JSONUtil {
    private static final Gson gsonInstance = new Gson();

    /**
     * Loads a json object from json file.
     *
     * @param resourceName
     * @return
     * @throws FileNotFoundException
     */
    public static JsonObject loadObjectFromFile(String resourceName) throws FileNotFoundException {
        JsonObject jsonObject;

        JsonElement jsonElement = JsonParser.parseReader(new FileReader(resourceName));
        jsonObject = jsonElement.getAsJsonObject();

        return jsonObject;
    }

    public static Gson getGsonInstance() {
        return gsonInstance;
    }
}
