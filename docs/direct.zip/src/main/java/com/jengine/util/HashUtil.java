package com.jengine.util;

/**
 * A hash algorithm util.
 *
 * @author mengyan
 */
public class HashUtil {
    /**
     * ELF Hash algorithm
     *
     * @param data
     * @return
     */
    public static int elfHash(byte[] data) {
        int hash = 0;
        int x;

        for (int i = 0; i < data.length; i++) {
            hash = (hash << 4) + data[i];
            if ((x = (int) (hash & 0xF0000000L)) != 0) {
                hash ^= (x >> 24);
                hash &= ~x;
            }
        }

        return hash & 0x7FFFFFFF;
    }

    /**
     * ELF Hash algorithm
     *
     * @param data
     * @return
     */
    public static long elfHashLong(byte[] data) {
        long hash = 0;
        long x;

        for (int i = 0; i < data.length; i++) {
            hash = (hash << 4) + data[i];
            if ((x = (hash & 0xF0000000L)) != 0) {
                hash ^= (x >> 24);
                hash &= ~x;
            }
        }

        return hash & 0x7FFFFFFF;
    }

    /**
     * AP Hash algorithm.
     *
     * @param data
     * @return
     */
    public static int apHash(byte[] data) {
        int hash = 0;

        for (int i = 0; i < data.length; i++) {
            hash ^= ((i & 1) == 0) ? ((hash << 7) ^ (data[i] & 0xff) ^ (hash >> 3)) : (~((hash << 11) ^ (data[i] & 0xff) ^ (hash >> 5)));
        }

        return hash;
    }

    /**
     * Optmized FNV Hash algorithm.
     *
     * @param data
     * @return
     */
    public static int fnvHash(byte[] data) {
        final int p = 16777619;
        int hash = (int) 2166136261L;
        for (byte b : data) {
            hash = (hash ^ b) * p;
        }
        hash += hash << 13;
        hash ^= hash >> 7;
        hash += hash << 3;
        hash ^= hash >> 17;
        hash += hash << 5;
        return Math.abs(hash);
    }

    /**
     * Int value Hash algorithm.
     *
     * @param key
     * @return
     */
    public static int intHash(int key) {
        key += ~(key << 15);
        key ^= (key >>> 10);
        key += (key << 3);
        key ^= (key >>> 6);
        key += ~(key << 11);
        key ^= (key >>> 16);
        return key;
    }

    /**
     * RS Hash algorithm
     *
     * @param data
     * @return
     */
    public static int rsHash(byte[] data) {
        int b = 378551;
        int a = 63689;
        int hash = 0;

        for (int i = 0; i < data.length; i++) {
            hash = hash * a + data[i];
            a = a * b;
        }

        return hash & 0x7FFFFFFF;
    }

    /**
     * JS Hash algorithm
     *
     * @param data
     * @return
     */
    public static int jsHash(byte[] data) {
        int hash = 1315423911;

        for (int i = 0; i < data.length; i++) {
            hash ^= ((hash << 5) + data[i] + (hash >> 2));
        }

        return hash & 0x7FFFFFFF;
    }

    /**
     * PJW Hash algorithm.
     *
     * @param data
     * @return
     */
    public static int pjwHash(byte[] data) {
        int bitsInUnsignedInt = 32;
        int threeQuarters = (bitsInUnsignedInt * 3) / 4;
        int oneEighth = bitsInUnsignedInt / 8;
        int highBits = 0xFFFFFFFF << (bitsInUnsignedInt - oneEighth);
        int hash = 0;
        int test;

        for (int i = 0; i < data.length; i++) {
            hash = (hash << oneEighth) + data[i];
            if ((test = hash & highBits) != 0) {
                hash = ((hash ^ (test >> threeQuarters)) & (~highBits));
            }
        }

        return hash & 0x7FFFFFFF;
    }
}
