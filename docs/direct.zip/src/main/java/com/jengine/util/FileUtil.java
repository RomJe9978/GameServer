package com.jengine.util;

import java.io.*;

public class FileUtil {
	private static final int MAX_BYTES = 8192;

	/**
	 * @param fileToRead
	 * @return
	 * @throws IOException
	 */
	public static byte[] readFileToBytes(File fileToRead) {
		try {
			return toByteArray(new FileInputStream(fileToRead));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static FileInputStream fileInputStream(File file) {
		try {
			return new FileInputStream(file);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	public static FileInputStream fileInputStream(String file) {
		try {
			return new FileInputStream(file);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Read the stream into byte array
	 *
	 * @param inputStream
	 * @return
	 * @throws java.io.IOException
	 */
	public static byte[] toByteArray(InputStream inputStream) {
		try {
			return readDataNice(inputStream);
		} finally {
			close(inputStream);
		}
	}

	private static byte[] readDataNice(InputStream inputStream) {
		ByteArrayOutputStream outputStream;
		byte[] buffer;

		try {
			int read;
			buffer = new byte[MAX_BYTES];
			outputStream = new ByteArrayOutputStream();
			while ((read = inputStream.read(buffer, 0, MAX_BYTES)) > -1) {
				outputStream.write(buffer, 0, read);
			}
			return outputStream.toByteArray();

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Close streams (in or out)
	 *
	 * @param stream
	 */
	public static void close(Closeable stream) {
		if (stream != null) {
			try {
				if (stream instanceof Flushable) {
					((Flushable) stream).flush();
				}
				stream.close();
			} catch (IOException e) {
				// ignore it.
			}
		}
	}
}