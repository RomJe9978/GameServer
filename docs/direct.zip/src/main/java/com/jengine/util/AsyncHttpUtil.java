package com.jengine.util;

import com.google.gson.JsonObject;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;

import java.io.IOException;

/**
 * http utility
 *
 * @author mengyan
 */
public class AsyncHttpUtil {
    // 超时时间 单位:ms
    private static final int TimeoutMillSecond = 5 * 1000;
    // 单路径最大连接数
    private static final int MAX_CONN_PER_ROUTE = 50;
    // 最大总连接数
    private static final int MAX_CONN_TOTAL = 300;

    /**
     * 初始化异步Http client
     */
    private static RequestConfig requestConfig = RequestConfig.custom()
            .setSocketTimeout(TimeoutMillSecond)
            .setConnectTimeout(TimeoutMillSecond).build();
    private static CloseableHttpAsyncClient httpclient = HttpAsyncClients.custom()
            .setDefaultRequestConfig(requestConfig)
            .setMaxConnPerRoute(MAX_CONN_PER_ROUTE)
            .setMaxConnTotal(MAX_CONN_TOTAL)
            .build();

    // 初始化异步IO线程
    static {
        httpclient.start();
    }

    /**
     * 异步请求，没有返回值，非阻塞
     *
     * @param url
     * @param request
     */
    public static void postJsonWithNoResponse(String url, JsonObject request) {
        try {
            doPost(url, request);
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

    private static void doPost(String url, JsonObject request) throws IOException {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-type", "application/json; charset=utf-8");

        String jsonString = request.toString();
        Log.getNetworkLogger().info("Http request: {}", jsonString);
        HttpEntity requestEntity = new StringEntity(jsonString, "utf-8");
        httpPost.setEntity(requestEntity);

        httpclient.execute(httpPost, null);
    }

}
