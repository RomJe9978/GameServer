package com.jengine.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;

import java.io.IOException;
import java.io.InputStreamReader;

/**
 * http utility
 *
 * @author mengyan
 */
public class HttpUtil {
    static HttpClient httpclient = new HttpClient();
    static int TimeoutMillSecond = 5 * 1000;

    public static synchronized void postJsonWithNoResponse(String url, JsonObject request) {
        try {
            doPost(url, request);
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

    public static synchronized JsonObject doPostJson(String url, JsonObject request) {
        try {
            PostMethod method = doPost(url, request);

            JsonObject response = JsonParser.parseReader(new InputStreamReader(method.getResponseBodyAsStream())).getAsJsonObject();
            return response;

        } catch (Exception e) {
            JengineException.catchEx(e);
        }
        return null;
    }

    private static PostMethod doPost(String url, JsonObject request) throws IOException {
        PostMethod method = new PostMethod(url);
        String jsonString = request.toString();
        Log.getNetworkLogger().info("Http request: {}", jsonString);
        StringRequestEntity requestEntity = new StringRequestEntity(
                jsonString,
                "application/json",
                "UTF-8");
        method.setRequestEntity(requestEntity);

        HttpConnectionManager connectionManager = httpclient.getHttpConnectionManager();
        HttpConnectionManagerParams params = connectionManager.getParams();
        params.setConnectionTimeout(TimeoutMillSecond);
        params.setSoTimeout(TimeoutMillSecond);
        httpclient.executeMethod(method);
        return method;
    }

}
