package com.jengine.util;

import java.lang.management.ManagementFactory;

/**
 * Process related util.
 *
 * @author mengyan
 */
public class ProcessUtil {

	/**
	 * Returns the pid representing the running Java virtual machine.
	 * There are no guarantees about this value for
	 * `The returned name string can be any arbitrary string and
	 * a Java virtual machine implementation can choose
	 * to embed platform-specific useful information in the
	 * returned name string.  Each running virtual machine could have
	 * a different name.`
	 * <p>
	 * But on linux & windows it returns a value like pid@hostname, in most cases.
	 *
	 * @return the pid representing the running Java virtual machine.
	 */
	public static String getProcessPID() {
		String nameOfRunningVM = ManagementFactory.getRuntimeMXBean().getName();
		String pid = nameOfRunningVM.substring(0, nameOfRunningVM.indexOf('@'));

		return pid;
	}
}
