package com.jengine.util;

import com.jengine.JengineException;

import java.io.File;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * ClassScanner is a util for scaning the classes below the special package and return a class set.
 *
 * @author mengyan
 */
public class ClassScanner {
    private static final String CLASS_SUFFIX = ".class";

    private static final String PROTOCOL_FILE = "file";
    private static final String PROTOCOL_JAR = "jar";

    public static Set<Class> scanClassInPackage(String packageName, boolean recursive) {
        Set<Class> classSet = new HashSet<>();
        String packageDirName = packageName.replace('.', File.separatorChar);
        Enumeration<URL> dirs;

        try {
            dirs = Thread.currentThread().getContextClassLoader().getResources(packageDirName);

            while (dirs.hasMoreElements()) {
                URL url = dirs.nextElement();
                String protocol = url.getProtocol();

                if (PROTOCOL_FILE.equals(protocol)) {
                    String filePath = URLDecoder.decode(url.getFile(), "UTF-8");
                    File dir = new File(filePath);
                    List<File> fileList = fetchFilesInDir(dir, recursive);
                    for (File f : fileList) {
                        String fileName = f.getAbsolutePath();
                        if (fileName.endsWith(CLASS_SUFFIX)) {
                            String noSuffixFileName = fileName.substring(8 + fileName.lastIndexOf("classes"), fileName.indexOf(CLASS_SUFFIX));
                            String filePackage = noSuffixFileName.replaceAll(ClassScanner.getSeparatorStr(), ".");
                            Class clazz = Class.forName(filePackage);
                            classSet.add(getClearClass(clazz));
                        }
                    }

                } else if (PROTOCOL_JAR.equals(protocol)) {
                    JarFile jar;
                    JarURLConnection urlConnection = (JarURLConnection) url.openConnection();
                    jar = urlConnection.getJarFile();
                    Enumeration<JarEntry> entries = jar.entries();

                    while (entries.hasMoreElements()) {
                        JarEntry entry = entries.nextElement();
                        String name = entry.getName();
                        if (name.charAt(0) == '/') {
                            name = name.substring(1);
                        }

                        if (name.startsWith(packageDirName)) {
                            String newPackageName = null;
                            int idx = name.lastIndexOf('/');
                            if (idx != -1) {
                                newPackageName = name.substring(0, idx).replace(File.separatorChar, '.');
                            }

                            if (name.endsWith(CLASS_SUFFIX) && !entry.isDirectory()) {
                                if (!recursive && !packageName.equals(newPackageName)) {
                                    continue;
                                }

                                String className = name.substring(packageName.length() + 1, name.length() - 6);
                                Class clazz = Class.forName(packageName + '.' + className);
                                classSet.add(getClearClass(clazz));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
        return classSet;
    }

    private static List<File> fetchFilesInDir(File dir, boolean recursive) {
        List<File> files = new ArrayList<>();
        if (dir.isDirectory()) {
            for (File file : Objects.requireNonNull(dir.listFiles())) {
                if (recursive) {
                    files.addAll(fetchFilesInDir(file, recursive));
                } else {
                    // ignore folders if no recursive.
                    if (!file.isDirectory()) {
                        files.add(file);
                    }
                }

            }
        } else {
            files.add(dir);
        }

        return files;
    }

    private static String getSeparatorStr() {
        if (File.separatorChar == '\\') {
            return "\\\\";
        }
        return String.valueOf(File.separatorChar);
    }

    private static Class getClearClass(Class clazz) {
        Class<?> enclosingClass = clazz.getEnclosingClass();
        if (enclosingClass != null) {
            return enclosingClass;
        } else {
            return clazz;
        }
    }

    public static void main(String[] args) {
        System.out.println(ClassScanner.scanClassInPackage("com.jengine.updater", true));
    }
}
