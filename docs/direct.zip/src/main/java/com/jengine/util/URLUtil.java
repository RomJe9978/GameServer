package com.jengine.util;

/**
 * A URL helper.
 *
 * @author mengyan
 */
public class URLUtil {
    public static String concat(String separator, String firstString, String... params) {
        String[] left = {firstString};
        return StringUtil.join(concat(left, params), separator);
    }

    private static String[] concat(String[] left, String[] right) {
        String[] result = new String[left.length + right.length];
        System.arraycopy(left, 0, result, 0, left.length);
        System.arraycopy(right, 0, result, left.length, right.length);
        return result;
    }
}
