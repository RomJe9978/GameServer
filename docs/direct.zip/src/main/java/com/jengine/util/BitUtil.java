package com.jengine.util;

/**
 * 位运算工具类
 *
 * @author RomJe
 */
public class BitUtil {
    /**
     * 获得Long类型编码中，指定位的“bit”数值
     *
     * @param position 最高位为63,最低位为0
     * @return Returns 0 when position is invalid.
     */
    public static byte bitAtLong(long value, int position) {
        if (position < 0 || position > 63) {
            return 0;
        }
        return (byte) ((value >> position) & 1);
    }

    /**
     * 获得Int类型编码中，指定位的“bit”数值
     *
     * @param value    int类型编码
     * @param position 最高位为31,最低位为0
     * @return Returns 0 when position is invalid.
     */
    public static byte bitAtInt(int value, int position) {
        if (position < 0 || position > 31) {
            return 0;
        }
        return (byte) ((value >> position) & 1);
    }
}
