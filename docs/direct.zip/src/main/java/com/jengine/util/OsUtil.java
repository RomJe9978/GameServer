package com.jengine.util;

public class OsUtil {
	public static String getSystemName() {
		return System.getProperty("os.name");
	}

	public static String getLowercaseSystemName() {
		return System.getProperty("os.name").toLowerCase();
	}

	public static String getUppercaseSystemName() {
		return System.getProperty("os.name").toUpperCase();
	}

	public static String getUserDir() {
		return System.getProperty("user.dir");
	}
}
