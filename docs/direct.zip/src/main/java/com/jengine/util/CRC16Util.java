package com.jengine.util;

/**
 * CRC algorithm util
 *
 * @author mengyan
 */
public class CRC16Util {
	private static final int BITS_IN_BYTE = 8;

	/**
	 * Crc 16 algorithm.
	 *
	 * @param buffer
	 * @return
	 */
	public static int crc16(final byte[] buffer) {
		int crc = 0xFFFF;

		for (int j = 0; j < buffer.length; j++) {
			crc = ((crc >>> 8) | (crc << 8)) & 0xffff;
			//byte to int, trunc sign
			crc ^= (buffer[j] & 0xff);
			crc ^= ((crc & 0xff) >> 4);
			crc ^= (crc << 12) & 0xffff;
			crc ^= ((crc & 0xFF) << 5) & 0xffff;
		}
		crc &= 0xffff;
		return crc;
	}

	/**
	 * MODBUS RTU CRC algorithm.
	 */
	public static int ModRTU_CRC(byte[] buf, int len) {
		int crc = 0xFFFF;
		for (int pos = 0; pos < len; pos++) {
			crc ^= buf[pos];

			for (int i = BITS_IN_BYTE; i != 0; i--) {
				if ((crc & 0x0001) != 0) {
					crc >>= 1;
					crc ^= 0xA001;
				} else {
					crc >>= 1;
				}
			}
		}
		return crc;
	}
}
