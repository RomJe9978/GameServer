package com.jengine.util;

import com.google.protobuf.GeneratedMessageV3;
import com.jengine.Jengine;
import com.jengine.io.ClientSession;
import com.jengine.io.Packet;
import com.jengine.io.helper.MsgIdRegisterService;
import com.jengine.io.tcp.TcpPacket;

/**
 * Make send packet easier.
 *
 * @author mengyan
 */
public class PacketHelper {
    public static void sendPacket(ClientSession session, GeneratedMessageV3.Builder<?> builder) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        try {
            session.send(TcpPacket.valueOf(opcode, builder));
        } catch (Exception e) {
            // ignore
        }
    }

    public static void sendExPacket(ClientSession session, GeneratedMessageV3.Builder<?> builder) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        try {
            session.send(TcpPacket.valueOf(opcode, 0, builder));
        } catch (Exception e) {
            // ignore
        }
    }

    public static boolean sendSyncPacket(ClientSession session, GeneratedMessageV3.Builder<?> builder) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        try {
            return session.sendSync(TcpPacket.valueOf(opcode, builder));
        } catch (Exception e) {
            // ignore
        }
        return false;
    }

    public static Packet createPacket(GeneratedMessageV3.Builder<?> builder) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        return TcpPacket.valueOf(opcode, builder);
    }

    public static Packet createExPacket(GeneratedMessageV3.Builder<?> builder, long oid) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        return TcpPacket.valueOf(opcode, oid, builder);
    }

    public static Packet createExPacket(GeneratedMessageV3.Builder<?> builder, long oid, int rpcLogicId) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        return TcpPacket.valueOf(rpcLogicId, oid, opcode, builder.build().toByteArray());
    }

    public static Packet createExPacket(GeneratedMessageV3.Builder<?> builder, long oid, int rpcLogicId, int routeType, long routeId) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        return TcpPacket.valueOf(rpcLogicId, oid, opcode, builder.build().toByteArray(), routeType, routeId);
    }

    public static Packet createExPacket(GeneratedMessageV3.Builder<?> builder, long oid, int rpcLogicId, int routeType, long routeId, int encodedRpcSource) {
        int opcode = Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder);
        return TcpPacket.valueOf(rpcLogicId, oid, opcode, builder.build().toByteArray(), routeType, routeId, encodedRpcSource);
    }
}
