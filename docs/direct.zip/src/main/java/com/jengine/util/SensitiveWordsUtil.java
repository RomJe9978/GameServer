package com.jengine.util;

import java.util.*;

/**
 * A util to check sensitive words.
 *
 * @author mengyan
 */
public class SensitiveWordsUtil {
    /**
     * Minimum-match rules, will return the first one when find one.
     */
    public static final int MATCH_TYPE_MIN = 0;

    /**
     * Maximum-match rules, will return the last one until find all sensitive words.
     */
    public static final int MATCH_TYPE_MAX = 1;

    private static final String END_FLAG_WORD = "endFlag";
    private static final String END_TRUE = "1";

    private Map sensitiveWordsMap;

    public synchronized void init(Set<String> sensitiveWords) {
        if (sensitiveWords != null) {
            this.sensitiveWordsMap = new HashMap(sensitiveWords.size());
            this.initSensitiveWords(sensitiveWords);
        }
    }

    public boolean contains(String checker) {
        return this.contains(checker, MATCH_TYPE_MAX);
    }

    public boolean contains(String checker, int matchType) {
        boolean isContains = false;

        for (int i = 0; i < checker.length(); i++) {
            int matchFlag = checkSensitiveWord(checker, i, matchType);
            if (matchFlag > 0) {
                isContains = true;
            }
        }
        return isContains;
    }

    public Set<String> getSensitiveWords(String checker, int matchType) {
        Set<String> sensitiveWordList = new HashSet<>();

        for (int i = 0; i < checker.length(); i++) {
            int length = checkSensitiveWord(checker, i, matchType);
            if (length > 0) {
                sensitiveWordList.add(checker.substring(i, i + length));
                i = i + length - 1;
            }
        }

        return sensitiveWordList;
    }

    public Set<String> getSensitiveWords(String checker) {
        return this.getSensitiveWords(checker, MATCH_TYPE_MAX);
    }

    public String replaceSensitiveWords(String checker, char replacer) {
        return this.replaceSensitiveWords(checker, replacer, MATCH_TYPE_MIN);
    }

    public String replaceSensitiveWords(String checker, char replacer, int matchType) {
        String result = checker;
        Set<String> set = getSensitiveWords(checker, matchType);
        Iterator<String> iterator = set.iterator();
        String word;
        String replaceString;

        while (iterator.hasNext()) {
            word = iterator.next();
            replaceString = getReplaceChars(replacer, word.length());
            result = result.replaceAll(word, replaceString);
        }

        return result;
    }

    public String replaceSensitiveWords(String checker, String replaceStr) {
        return replaceSensitiveWords(checker, replaceStr, MATCH_TYPE_MAX);
    }

    public String replaceSensitiveWords(String checker, String replaceStr, int matchType) {
        String resultTxt = checker;
        Set<String> set = getSensitiveWords(checker, matchType);
        Iterator<String> iterator = set.iterator();
        String word;
        while (iterator.hasNext()) {
            word = iterator.next();
            resultTxt = resultTxt.replaceAll(word, replaceStr);
        }

        return resultTxt;
    }

    private void initSensitiveWords(Set<String> sensitiveWords) {
        String sensitiveWord;
        Map pointer;
        Map newMap;

        Iterator<String> iterator = sensitiveWords.iterator();
        while (iterator.hasNext()) {
            sensitiveWord = iterator.next();
            pointer = this.sensitiveWordsMap;

            int length = sensitiveWord.length();
            for (int i = 0; i < length; i++) {
                char keyChar = sensitiveWord.charAt(i);
                Object wordMap = pointer.get(keyChar);
                if (wordMap != null) {
                    pointer = (Map) wordMap;
                } else {
                    newMap = new HashMap<>();
                    pointer.put(keyChar, newMap);
                    pointer = newMap;
                }

                if (i == length - 1) {
                    pointer.put(END_FLAG_WORD, END_TRUE);
                }
            }
        }
    }

    private int checkSensitiveWord(String checker, int beginIndex, int matchType) {
        boolean isContains = false;
        int matchCharNum = 0;
        char charWord;
        Map pointer = this.sensitiveWordsMap;

        for (int i = beginIndex; i < checker.length(); i++) {
            charWord = checker.charAt(i);
            pointer = (Map) pointer.get(charWord);
            if (pointer != null) {
                matchCharNum++;
                if (END_TRUE.equals(pointer.get(END_FLAG_WORD))) {
                    isContains = true;
                    if (MATCH_TYPE_MIN == matchType) {
                        break;
                    }
                }
            } else {
                break;
            }
        }

        if (matchCharNum < 2 || !isContains) {
            matchCharNum = 0;
        }
        return matchCharNum;
    }

    private static String getReplaceChars(char replaceChar, int length) {
        String resultReplace = String.valueOf(replaceChar);
        for (int i = 1; i < length; i++) {
            resultReplace += replaceChar;
        }

        return resultReplace;
    }
}
