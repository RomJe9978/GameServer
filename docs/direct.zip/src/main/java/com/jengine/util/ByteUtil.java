package com.jengine.util;

import java.nio.ByteBuffer;

/**
 * ByteUtil
 *
 * @author mengyan
 */
public class ByteUtil {
    private static ByteBuffer longBuffer = ByteBuffer.allocate(Long.BYTES);

    public static byte[] longToBytes(long x) {
        longBuffer.putLong(0, x);
        return longBuffer.array();
    }

    public static long bytesToLong(byte[] bytes) {
        longBuffer.put(bytes, 0, bytes.length);
        longBuffer.flip();
        return longBuffer.getLong();
    }
}
