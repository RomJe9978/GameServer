package com.jengine.util;

import java.util.Objects;

/**
 * 二元组
 *
 * @author leiyunfei
 * @time 2020-06-29 16:12
 */
public class KeyValuePair<K, V> {
    private K key;
    private V value;

    public KeyValuePair() {
    }

    public KeyValuePair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public V getValue() {
        return value;
    }

    public void setValue(V value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        KeyValuePair<?, ?> that = (KeyValuePair<?, ?>) o;
        return Objects.equals(key, that.key) &&
                Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, value);
    }

    @Override
    public String toString() {
        return "KeyValuePair(" + key.toString() + ", " + value.toString() + ")";
    }

	public static <K, V> KeyValuePair<K, V> makePair(K key, V value) {
        return new KeyValuePair<>(key, value);
    }
}
