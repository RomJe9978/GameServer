package com.jengine.util;

import java.util.*;

public class RandUtil {
    private static final int A = 48271;
    private static final int M = 2147483647;
    private static final int Q = M / A;
    private static final int R = M % A;
    private static int State = -1;

    private static final Random random = new Random(System.currentTimeMillis());

    public static int randInt() {
        if (State < 0) {
            State = random.nextInt();
        }

        int tmpState = A * (State % Q) - R * (State / Q);
        if (tmpState >= 0) {
            State = tmpState;
        } else {
            State = tmpState + M;
        }
        return State;
    }

    public static int randInt(int max) { // 包含边界max
        return randInt() % (max + 1);
    }

    /**
     * 指定右边界，随机整数{@code 0 <= result < max}
     *
     * @param max 不包含该值，只有正数为有效参数
     * @return Returns 0 if invalid param.
     */
    public static int randIntWithout(int max) {
        return max > 0 ? randInt() % max : 0;
    }

    public static int randInt(int low, int high) {
        return randInt(Math.abs(high - low)) + Math.min(low, high);
    }

    public static float randFloat() {
        return (float) randInt() / (float) M;
    }

    public static float randFloat(float max) {
        return randFloat() * max;
    }

    public static float randFloat(float low, float high) {
        return randFloat(Math.abs(high - low)) + Math.min(low, high);
    }

    public static int[] randomN(int min, int max, int count) {
        if (max - min + 1 < count) {
            return null;
        }

        int[] result = new int[count];

        List<Integer> list = new LinkedList<>();
        for (int i = min; i <= max; i++) {
            list.add(i);
        }

        for (int i = 0; i < count; i++) {
            int r = random(0, list.size() - 1);
            result[i] = list.get(r);
            list.remove(r);
        }
        return result;
    }

    public static int random(int min, int max) {
        return (int) (min + Math.random() * (max - min + 1));
    }

    /**
     * @param percent 概率万分比
     * @return true 概率发生； false 概率没发生
     */
    public static boolean hit(int percent) {
        percent = Math.min(percent, 10000);
        return randIntWithout(10000) < percent;
    }

    /**
     * 从枚举中随机一个值
     *
     * @param enumClass 枚举类型
     * @return 随机出的一个枚举值
     */
    public static <T extends Enum<T>> T random(Class<T> enumClass) {
        T[] elements = enumClass.getEnumConstants();
        return elements[random(0, elements.length - 1)];
    }

    /**
     * 从list中随机一个元素
     *
     * @return {@code list}没有元素时会返回{@code null}
     */
    public static <T> T randomList(List<T> list) {
        if (Objects.isNull(list) || list.isEmpty()) {
            return null;
        }
        int index = randInt(0, list.size() - 1);
        return list.get(index);
    }

    /**
     * 从数组中随机一个元素
     *
     * @param array 待选数组
     * @param <T>   待选元素类型
     * @return 随机选择一个
     */
    public static <T> T choice(T[] array) {
        int index = array.length;
        return array[randInt(0, index - 1)];
    }

    /**
     * Select random items without repetitions list element
     *
     * @param src         data src
     * @param chooseCount count of selected elements
     * @return list element whose size is `chooseCount`
     */
    public static <T> List<T> sample(List<T> src, int chooseCount) {
        // chooseCount should not be greater than src.size()
        chooseCount = Math.min(chooseCount, src.size());

        List<T> copy = new ArrayList<>(src);

        // create a temporary list for storing
        List<T> newList = new ArrayList<>();
        for (int i = 0; i < chooseCount; i++) {
            // take a  random index between 0 to size of given List
            int randomIndex = randInt(copy.size() - 1);

            // add element in temporary list
            newList.add(copy.get(randomIndex));
            copy.remove(randomIndex);
        }

        return newList;
    }

    public static void main(String[] args) {
        int count = 0;
        for (int i = 0; i < 10000; i++) {
            if (hit(2000)) {
                count++;
            }
        }
        System.out.println(count);
    }
}
