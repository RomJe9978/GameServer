package com.jengine;

import com.jengine.logger.Log;
import org.slf4j.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * A {@JengineException} which is thrown when Jengine boot failed.
 *
 * @author mengyan
 */
public class JengineException extends Exception {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Log.getExceptionLogger();

	/**
	 * Creates a new exception.
	 */
	public JengineException(String message) {
		super(message);
	}

	/**
	 * Creates a new exception.
	 */
	public JengineException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Creates a new exception.
	 */
	public JengineException(Throwable cause) {
		super(cause);
	}

	/**
	 * Catch a exception and track it.
	 *
	 * @param e
	 */
	public static void catchEx(Exception e) {
		log.error(getMsg(e));

		if (Jengine.getExceptionTracker() != null) {
			Jengine.getExceptionTracker().track(e);
		}
	}

	public static String getMsg(Exception e) {
		if (e != null) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			return "[Exception]\r\n" + sw.toString() + "\r\n";
		}
		return "exception empty information";
	}
}
