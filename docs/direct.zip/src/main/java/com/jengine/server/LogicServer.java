package com.jengine.server;

/**
 * Base interface for all logic server
 *
 * @author mengyan
 */
public interface LogicServer {
	void init() throws Exception;
}
