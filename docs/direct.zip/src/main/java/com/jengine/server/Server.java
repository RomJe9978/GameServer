package com.jengine.server;

import com.jengine.DefaultAppContext;
import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.cache.RedisClientService;
import com.jengine.cache.RedisKeys;
import com.jengine.configuration.PriorityConfiguration;
import com.jengine.generator.Generator;
import com.jengine.generator.IdGenerator;
import com.jengine.generator.SnowFlakeWorker;
import com.jengine.io.helper.MsgIdRegisterService;
import com.jengine.io.rpc.RPCTimeSelector;
import com.jengine.io.tcp.TcpServerService;
import com.jengine.logger.Log;
import com.jengine.persist.DBEntityManager;
import com.jengine.persist.DefaultDBEntityManager;
import com.jengine.script.ScriptService;
import com.jengine.service.Service;
import com.jengine.shutdown.ShutdownManager;
import com.jengine.task.IPacketDispatcher;
import com.jengine.task.TaskExecutor;
import com.jengine.thread.DefaultThreadPool;
import com.jengine.thread.ThreadMonitor;
import com.jengine.updater.SimpleUpdater;
import com.jengine.util.StringUtil;
import com.jengine.util.TimeUtil;
import org.apache.commons.configuration2.YAMLConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.slf4j.Logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * The basic server implementation.
 *
 * @author mengyan
 */
public class Server implements Service {
    private static final Logger log = Log.getJengineLogger();
    protected volatile boolean isRunning;
    protected long lastRunTime;
    private LogicServer logicServer;

    @Override
    public String getId() {
        return Jengine.getConfiguration().getString("server.id");
    }

    @Override
    public boolean init() {
        try {
            // init configuration firstly.
            log.info("---------------------------------- Initializing configuration ... ----------------------------------");
            this.initConfig();

            // init AppContext
            log.info("---------------------------------- Initializing App Context ... ----------------------------------");
            Jengine.setAppContext(new DefaultAppContext());

            // init thread pool
            log.info("---------------------------------- Initializing Thread Pool ... ----------------------------------");
            this.initThreadPool();

            // init updater.
            log.info("---------------------------------- Initializing Updater ... ----------------------------------");
            Jengine.setUpdater(new SimpleUpdater());
            Jengine.getUpdater().addSyncUpdatable(new RPCTimeSelector());

            log.info("---------------------------------- Initializing ShutdownManager ... ----------------------------------");
            Jengine.setShutdownManager(new ShutdownManager());
            Jengine.getShutdownManager().init();

            if (Jengine.getConfiguration().getBoolean("cache.useCache")) {
                log.info("---------------------------------- Initializing Redis Cache Service... ----------------------------------");
                Jengine.getAppContext().create(RedisClientService.class, RedisClientService.class);
                RedisKeys.KEY_PREFIX = Jengine.getConfiguration().getString("cache.keyPrefix");
            }

            Jengine.getShutdownManager().addService(this);

            log.info("---------------------------------- Initializing Msg Id Register Service ... ----------------------------------");
            Jengine.getAppContext().create(MsgIdRegisterService.class, MsgIdRegisterService.class);

            // init id generator
            if (Jengine.getConfiguration().getBoolean("switch.idgenerator")) {
                log.info("---------------------------------- Initializing ID Generator ... ----------------------------------");
                long serverId = Jengine.getConfiguration().getInt("server.id");
                IdGenerator<Generator> generator = new IdGenerator<>(new SnowFlakeWorker(serverId));
                Jengine.setIdGenerator(generator);
            }

            // init DBEntityManager by DefaultDBEntityManager and start
            if (Jengine.getConfiguration().getBoolean("switch.database")) {
                log.info("---------------------------------- Initializing Database Manager... ----------------------------------");
                Jengine.getAppContext().create(DefaultDBEntityManager.class, DBEntityManager.class);
            }

            // init script manager
            if (Jengine.getConfiguration().getBoolean("switch.script")) {
                log.info("---------------------------------- Initializing Script Service ... ----------------------------------");
                Jengine.getAppContext().create(ScriptService.class, ScriptService.class);
            }

            // init task executor
            String packetDispatcherName = Jengine.getConfiguration().getString("gate.dispatcher.class");
            if (StringUtil.isEmpty(packetDispatcherName)) {
                Jengine.setPacketDispatcher(TaskExecutor.getInstance());
            } else {
                Jengine.setPacketDispatcher((IPacketDispatcher) Class.forName(packetDispatcherName).newInstance());
            }

            // init logic server
            log.info("---------------------------------- Initializing Logic Server ... ----------------------------------");
            String logicServerName = Jengine.getConfiguration().getString("logicServer.class");
            this.logicServer = (LogicServer) Class.forName(logicServerName).newInstance();
            this.logicServer.init();

        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }

        return true;
    }

    private void initConfig() throws FileNotFoundException, ConfigurationException {
        YAMLConfiguration configBase = new YAMLConfiguration();
        configBase.read(new FileInputStream("config-base.yaml"));

        YAMLConfiguration config = new YAMLConfiguration();
        config.read(new FileInputStream("config.yaml"));

        PriorityConfiguration priorityConfiguration = new PriorityConfiguration(config, configBase);
        Jengine.setConfiguration(priorityConfiguration);
    }

    private void initThreadPool() {
        Jengine.setThreadMonitor(new ThreadMonitor("Thread-Monitor"));
        Jengine.getThreadMonitor().start();

        Jengine.setLogicExecutor(new DefaultThreadPool("logic",
                Jengine.getConfiguration().getInt("threadPool.logicExecutorSize")));
        Jengine.getLogicExecutor().start();

        Jengine.setCommonExecutor(new DefaultThreadPool("common",
                Jengine.getConfiguration().getInt("threadPool.commonExecutorSize")));
        Jengine.getCommonExecutor().start();
    }

    @Override
    public boolean startup() {
        // start TcpServerService
        try {
            Jengine.getAppContext().create(TcpServerService.class, TcpServerService.class);

            String callBeforeCloseTcp = Jengine.getConfiguration().getString("beforeTcpCloseService.class");
            if (StringUtil.isNotEmpty(callBeforeCloseTcp)) {
                Service beforeTcpClose = (Service) Class.forName(callBeforeCloseTcp).newInstance();
                Jengine.getAppContext().get(TcpServerService.class).setBeforeCloseTcpService(beforeTcpClose);
            }

        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }

        if (!this.isRunning) {
            this.isRunning = true;
            log.info("[--------------------------------- {} SERVER START OK! ---------------------------------]",
                    StringUtil.toUpperCase(Jengine.getConfiguration().getString("server.name")));
            log.info("------------------------- Server information as follow: -------------------------");
            log.info("\t\tserver id: {}", Jengine.getConfiguration().getInt("server.id"));
            log.info("\t\tserver name: {}", Jengine.getConfiguration().getString("server.name"));
            log.info("\t\ttcp server port: {}", Jengine.getConfiguration().getString("server.port"));
            log.info("\t\ttcp server max connection: {}", Jengine.getConfiguration().getInt("network.connection.maxSize"));

            if (Jengine.getConfiguration().getBoolean("switch.script")) {
                log.info("\t\tscript server port: {}", Jengine.getConfiguration().getString("script.port"));
            }

            log.info("----------------------------------------------------------------------------------");
            // main loop
            while (this.isRunning) {
                lastRunTime = TimeUtil.getTimeInMillis();

                try {
                    Jengine.getUpdater().update();
                    Thread.sleep(Jengine.getConfiguration().getInt("updater.period"));
                } catch (NoSuchMethodError e) {
                    Log.getJengineLogger().error("Server update error: " + e.toString());
                } catch (Exception e) {
                    JengineException.catchEx(e);
                }
            }
            return true;
        }

        return false;
    }

    @Override
    public boolean shutdown() {
        log.info("close executor start...");

        Jengine.getLogicExecutor().close(true);
        Jengine.getCommonExecutor().close(true);
        this.isRunning = false;

        log.info("close executor finish.");
        return true;
    }
}
