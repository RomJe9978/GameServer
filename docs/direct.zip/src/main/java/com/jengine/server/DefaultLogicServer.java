package com.jengine.server;

/**
 * Default implementation of logic server.
 *
 * @author mengyan
 */
public class DefaultLogicServer implements LogicServer {
	@Override
	public void init() {

	}
}
