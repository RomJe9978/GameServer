package com.jengine;

import com.jengine.configuration.PriorityConfiguration;
import com.jengine.generator.IdGenerator;
import com.jengine.logger.Log;
import com.jengine.object.GameObject;
import com.jengine.object.ObjectAccessor;
import com.jengine.object.ObjectId;
import com.jengine.shutdown.ShutdownManager;
import com.jengine.task.IPacketDispatcher;
import com.jengine.thread.ThreadMonitor;
import com.jengine.thread.ThreadPool;
import com.jengine.tracker.ExceptionTracker;
import com.jengine.updater.Updater;
import org.slf4j.Logger;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Jengine provides the environments for engine.
 *
 * @author mengyan
 */
public class Jengine {
    private static final Logger log = Log.getJengineLogger();

    /**
     * A tracker of exception which will report exception information to the receivers.
     */
    private static ExceptionTracker exceptionTracker;

    /**
     * A monitor of threads.
     */
    private static ThreadMonitor threadMonitor;

    /**
     * The object accessor manager.
     */
    private static Map<Integer, ObjectAccessor> objectAccessorManager = new ConcurrentHashMap<>();

    /**
     * The AppContext holder.
     */
    private static AppContext appContext;

    /**
     * The thread pool which will run task in special thread which bind with objectId.
     */
    private static ThreadPool logicExecutor;

    /**
     * The thread pool which will run task in random mode(round-robin selector).
     */
    private static ThreadPool commonExecutor;

    /**
     * Configuration holder.
     */
    private static PriorityConfiguration configuration;

    private static Updater updater;

    private static ShutdownManager shutdownManager;

    /**
     * Global id generator
     */
    private static IdGenerator idGenerator;

    private static IPacketDispatcher packetDispatcher;

    public static void setPacketDispatcher(IPacketDispatcher packetDispatcher) {
        Jengine.packetDispatcher = packetDispatcher;
    }

    public static IPacketDispatcher getPacketDispatcher() {
        return packetDispatcher;
    }

    public static void setExceptionTracker(ExceptionTracker tracker) {
        exceptionTracker = tracker;
    }

    public static ExceptionTracker getExceptionTracker() {
        return exceptionTracker;
    }

    public static ThreadMonitor getThreadMonitor() {
        return threadMonitor;
    }

    public static void setThreadMonitor(ThreadMonitor threadMonitor) {
        Jengine.threadMonitor = threadMonitor;
    }

    public static void addGameObjectToAccessor(GameObject gameObject) {
        if (gameObject != null) {
            Jengine.getObjectAccessor(gameObject.getOId().getType()).addObject(gameObject);
        }
    }

    /**
     * NOTE: must initial all ObjectAccessor firstly for thread safe.
     */
    public static ObjectAccessor createObjectAccessor(int type) {
        if (Jengine.objectAccessorManager.get(type) == null) {
            ObjectAccessor accessor = new ObjectAccessor(type);
            Jengine.objectAccessorManager.put(type, accessor);

            // NOTE: The updater must be initialized before the ObjectAccessor
            Jengine.getUpdater().addSyncUpdatable(accessor);

            return accessor;
        }

        return Jengine.objectAccessorManager.get(type);
    }

    /**
     * Query game object by object id.
     *
     * @param objectId
     * @return
     */
    public static GameObject queryObjectFromAccessor(ObjectId objectId) {
        if (objectId != null) {
            if (getObjectAccessor(objectId.getType()) == null) {
                return null;
            }

            return getObjectAccessor(objectId.getType()).queryObject(objectId);
        } else {
            return null;
        }
    }

    public static ObjectAccessor getObjectAccessor(Integer type) {
        return objectAccessorManager.get(type);
    }

    public static AppContext getAppContext() {
        return appContext;
    }

    public static void setAppContext(AppContext appContext) {
        Jengine.appContext = appContext;
    }

    public static ThreadPool getLogicExecutor() {
        return logicExecutor;
    }

    public static void setLogicExecutor(ThreadPool logicExecutor) {
        Jengine.logicExecutor = logicExecutor;
    }

    public static ThreadPool getCommonExecutor() {
        return commonExecutor;
    }

    public static void setCommonExecutor(ThreadPool commonExecutor) {
        Jengine.commonExecutor = commonExecutor;
    }

    public static PriorityConfiguration getConfiguration() {
        return configuration;
    }

    public static void setConfiguration(PriorityConfiguration configuration) {
        Jengine.configuration = configuration;
    }

    public static Updater getUpdater() {
        return updater;
    }

    public static void setUpdater(Updater updater) {
        Jengine.updater = updater;
    }

    public static ShutdownManager getShutdownManager() {
        return shutdownManager;
    }

    public static void setShutdownManager(ShutdownManager shutdownManager) {
        Jengine.shutdownManager = shutdownManager;
    }

    public static void setIdGenerator(IdGenerator idGenerator) {
        Jengine.idGenerator = idGenerator;
    }

    public static IdGenerator getIdGenerator() {
        return idGenerator;
    }
}
