package com.jengine.task;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.rpc.RPCContext;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.io.tcp.TcpPacketDispatcher;
import com.jengine.object.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MsgTask extends AbstractTask {
    private static final Logger log = LoggerFactory.getLogger(MsgTask.class);
    private TcpPacket packet;
    private ClientSession session;

    /**
     * 是否是RPC机制的回复消息
     */
    private boolean isRpcResponse = false;

    public MsgTask(ObjectId oid) {
        super(oid);
    }

    public MsgTask(ClientSession session, TcpPacket packet) {
        this.session = session;
        this.packet = packet;
    }

    public MsgTask(ClientSession session, TcpPacket packet, boolean isRpcResponse) {
        this.session = session;
        this.packet = packet;
        this.isRpcResponse = isRpcResponse;
    }

    public MsgTask(boolean ensureRun) {
        super(ensureRun);
    }

    public MsgTask(ObjectId oid, boolean ensureRun) {
        super(oid, ensureRun);
    }

    public MsgTask(ObjectId oid, ClientSession session, TcpPacket packet) {
        super(oid);
        this.packet = packet;
        this.session = session;
    }

    public MsgTask(ObjectId oid, ClientSession session, TcpPacket packet, boolean isRpcPacket) {
        super(oid);
        this.packet = packet;
        this.session = session;
        this.isRpcResponse = isRpcPacket;
    }

    public static MsgTask valueOf(ObjectId oid, ClientSession session, TcpPacket packet, boolean isRpcResponse) {
        return new MsgTask(oid, session, packet, isRpcResponse);
    }

    public static MsgTask valueOf(ObjectId oid, ClientSession session, TcpPacket packet) {
        return new MsgTask(oid, session, packet);
    }

    public static MsgTask valueOf(ObjectId oid) {
        return new MsgTask(oid);
    }

    public static MsgTask valueOf(ClientSession session, TcpPacket packet, boolean isRpcResponse) {
        return new MsgTask(session, packet, isRpcResponse);
    }

    public static MsgTask valueOf(ClientSession session, TcpPacket packet) {
        return new MsgTask(session, packet);
    }

    public static MsgTask valueOf(boolean ensureRun) {
        return new MsgTask(ensureRun);
    }

    public static MsgTask valueOf(ObjectId oid, boolean ensureRun) {
        return new MsgTask(oid, ensureRun);
    }


    @Override
    public void run() {
        try {
            if (this.session != null && this.packet != null) {
                // 先处理RPC回复包，互斥
                if (this.isRpcResponse) {
                    RPCContext.getInstance().onRpcResponse(this.session, this.packet);
                    return;
                }

                boolean dispatchOK = TcpPacketDispatcher.getInstance().handle(this.session, this.packet);
                if (!dispatchOK) {
                    log.error("[MsgTask] dispatch protocol failed, opcode: {}", packet.getOpcode());
                }
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

    @Override
    public int getType() {
        return TaskType.MSG.code();
    }
}
