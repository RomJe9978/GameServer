package com.jengine.task;

import com.jengine.object.UpdatableGameObject;

/**
 * A periodic task for UpdatableGameObject.
 *
 * @author mengyan
 */
public class UpdateTask extends AbstractTask {
	private UpdatableGameObject updatableGameObject;

	public UpdateTask(UpdatableGameObject updatableGameObject) {
		super(updatableGameObject.getOId());
		this.updatableGameObject = updatableGameObject;
	}

	public UpdateTask(boolean ensureRun) {
		super(ensureRun);
	}

	public UpdateTask(UpdatableGameObject updatableGameObject, boolean ensureRun) {
		super(updatableGameObject.getOId(), ensureRun);
		this.updatableGameObject = updatableGameObject;
	}

	public static UpdateTask valueOf(UpdatableGameObject updatableGameObject) {
		return new UpdateTask(updatableGameObject);
	}

	public static UpdateTask valueOf(boolean ensureRun) {
		return new UpdateTask(ensureRun);
	}

	public static UpdateTask valueOf(UpdatableGameObject updatableGameObject, boolean ensureRun) {
		return new UpdateTask(updatableGameObject, ensureRun);
	}

	@Override
	public void run() {
		this.updatableGameObject.update();
	}

	@Override
	public int getType() {
		return TaskType.TICK.code();
	}
}
