package com.jengine.task;

import com.jengine.JengineException;
import com.jengine.event.Event;
import com.jengine.event.EventObject;
import com.jengine.object.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventTask extends AbstractTask {
	private static final Logger log = LoggerFactory.getLogger(EventTask.class);
	private Event event;
	private EventObject eventObject;

	public EventTask(ObjectId objectId, Event event, EventObject eventObject) {
		super(objectId);
		this.event = event;
		this.eventObject = eventObject;
	}

	public EventTask(Event event, EventObject eventObject) {
		this.event = event;
		this.eventObject = eventObject;
	}

	public EventTask(boolean ensureRun) {
		super(ensureRun);
	}

	public EventTask(ObjectId oid, boolean ensureRun) {
		super(oid, ensureRun);
	}

	public static EventTask valueOf(ObjectId objectId, Event event, EventObject eventObject) {
		return new EventTask(objectId, event, eventObject);
	}

	public static EventTask valueOf(Event event, EventObject eventObject) {
		return new EventTask(event, eventObject);
	}

	public static EventTask valueOf(boolean ensureRun) {
		return new EventTask(ensureRun);
	}

	public static EventTask valueOf(ObjectId oid, boolean ensureRun) {
		return new EventTask(oid, ensureRun);
	}

	@Override
	public void run() {
		try {
			if (this.event != null && this.eventObject != null) {
				this.eventObject.invoke(this.event);
			}
		} catch (Exception e) {
			JengineException.catchEx(e);
		}
	}

	@Override
	public int getType() {
		return TaskType.EVENT.code();
	}

}
