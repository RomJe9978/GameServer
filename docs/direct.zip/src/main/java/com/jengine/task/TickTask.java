package com.jengine.task;

import com.jengine.Jengine;
import com.jengine.module.Module;
import com.jengine.module.ModuleManager;
import com.jengine.object.GameObject;
import com.jengine.object.ObjectId;
import com.jengine.updater.Ticker;

import java.util.List;

/**
 * A periodic task for modules.
 *
 * @author mengyan
 */
public class TickTask extends AbstractTask {
	public TickTask(ObjectId oid) {
		super(oid);
	}

	public TickTask(boolean ensureRun) {
		super(ensureRun);
	}

	public TickTask(ObjectId oid, boolean ensureRun) {
		super(oid, ensureRun);
	}

	public static TickTask valueOf(ObjectId oid) {
		return new TickTask(oid);
	}

	public static TickTask valueOf(boolean ensureRun) {
		return new TickTask(ensureRun);
	}

	public static TickTask valueOf(ObjectId oid, boolean ensureRun) {
		return new TickTask(oid, ensureRun);
	}

	@Override
	public void run() {
		/**
		 * For the task of the tick type, each time it will traverse
		 * all modules of all objects to which the task belongs and call.
		 */
		if (this.dispatchId != null && Jengine.getObjectAccessor(dispatchId.getType()) != null) {
			List<Module> tickers = ModuleManager.getInstance().getModules(this.dispatchId.getType());
			if (tickers == null) {
				return;
			}

			GameObject gameObject = Jengine.getObjectAccessor(dispatchId.getType()).queryObject(this.dispatchId);
			for (Ticker ticker : tickers) {
				ticker.onTick(gameObject);
			}
		}
	}

	@Override
	public int getType() {
		return TaskType.TICK.code();
	}
}
