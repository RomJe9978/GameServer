package com.jengine.task;

public enum TaskType {
	/**
	 * A task type of unknown.
	 */
	UNKNOWN(0x0),

	/**
	 * A task type of network protocol message.
	 */
	MSG(0x1),

	/**
	 * A task type of event.
	 */
	EVENT(0x2),

	/**
	 * A task type of tick.
	 * Only for modules.
	 */
	TICK(0x3),

	/**
	 * A task type of update.
	 * for all UpdatableGameObject.
	 */
	UPDATE(0x4),
	;

	private final int code;
	private static final TaskType[] INT_TO_ENUM_MAP;

	static {
		TaskType[] types = TaskType.values();
		TaskType[] map = new TaskType[types.length];
		for (TaskType type : types) {
			map[type.code()] = type;
		}
		INT_TO_ENUM_MAP = map;
	}

	TaskType(int code) {
		this.code = code;
	}

	/**
	 * Gets the code for this type.
	 */
	public int code() {
		return code;
	}

	/**
	 * Creates a new type by code.
	 *
	 * @param code
	 * @return
	 */
	public static TaskType valueOf(int code) {
		return code >= INT_TO_ENUM_MAP.length || code < 0 ? null : INT_TO_ENUM_MAP[code];
	}

}
