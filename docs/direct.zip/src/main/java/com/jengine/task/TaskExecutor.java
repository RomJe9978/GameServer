package com.jengine.task;

import com.jengine.Jengine;
import com.jengine.event.Event;
import com.jengine.event.EventManager;
import com.jengine.event.EventObject;
import com.jengine.io.ClientSession;
import com.jengine.io.Packet;
import com.jengine.io.rpc.RPCContext;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.jengine.object.GameObject;
import com.jengine.object.ObjectId;
import com.jengine.util.TimeUtil;

import java.util.List;

public class TaskExecutor implements IPacketDispatcher {
    private static final TaskExecutor instance = new TaskExecutor();
    /**
     * 主要用于跨服玩法的优化，便于跨服玩法充分利用服务器资源
     * 跨服玩法的session绑定服务器ID，导致消息派发逻辑同游服会派发到相同线程
     * 将服务器ID绑定的消息都改成异步派发，充分利用服务器CPU资源
     */
    private static final long MIN_DISPATCH_OID = 10000;

    public static TaskExecutor getInstance() {
        return instance;
    }

    /**
     * Fires a new event to target object and run listener in the thread bind with objectId.
     *
     * @param event
     * @param objectId
     */
    public void fireEvent(Event event, ObjectId objectId) {
        List<EventObject> listeners = EventManager.getInstance().getListeners(event.getType());
        for (EventObject listener : listeners) {
            this.dispatchSingleEvent(objectId, event, listener);
        }
    }

    public void fireEvent(Event event) {
        if (event != null) {
            List<EventObject> listeners = EventManager.getInstance().getListeners(event.getType());
            if (listeners == null) {
                Log.getJengineLogger().warn("Not listen event, eventType: {}", event.getType());
                return;
            }

            for (EventObject listener : listeners) {
                if (listener.getObject() instanceof GameObject) {
                    GameObject gameObject = (GameObject) listener.getObject();
                    this.dispatchSingleEvent(gameObject.getOId(), event, listener);
                } else {
                    if (event.getTargetId() != null) {
                        this.dispatchSingleEvent(event.getTargetId(), event, listener);
                    } else {
                        this.dispatchSingleEvent(event, listener);
                    }
                }
            }
        }
    }

    /**
     * Dispatches network packet in the thread bind with session.
     * if not bind yet, select a thread by round-robin.
     *
     * @param session
     * @param packet
     */
    public void dispatchPacket(ClientSession session, Packet packet) {
        if (packet instanceof TcpPacket) {
            TcpPacket tcpPacket = (TcpPacket) packet;
            boolean isRpcResponse = RPCContext.isRpcResponse(tcpPacket);

            if (session != null && tcpPacket.getObjectId() != null) {
                ObjectId objectId = tcpPacket.getObjectId();
                MsgTask msgTask = MsgTask.valueOf(objectId, session, tcpPacket, isRpcResponse);
                Jengine.getLogicExecutor().addTask(msgTask, objectId.getId());
            } else if (session != null && session.getGameObject() != null) {
                /**
                 *  update touch time every network communication
                 */
                session.getGameObject().setLastTouchTime(TimeUtil.getTimeInMillis());

                ObjectId objectId = session.getGameObject().getOId();
                if (objectId.getId() > MIN_DISPATCH_OID) {
                    MsgTask msgTask = MsgTask.valueOf(objectId, session, tcpPacket, isRpcResponse);
                    Jengine.getLogicExecutor().addTask(msgTask, objectId.getId());
                } else {
                    MsgTask msgTask = MsgTask.valueOf(session, tcpPacket, isRpcResponse);
                    Jengine.getLogicExecutor().addTask(msgTask);
                }
            } else {
                MsgTask msgTask = MsgTask.valueOf(session, tcpPacket, isRpcResponse);
                Jengine.getLogicExecutor().addTask(msgTask);
            }
        }
    }

    /**
     * Post a task in random thread.
     *
     * @param task
     */
    public void postAsyncTask(Task task) {
        if (task != null && Jengine.getCommonExecutor() != null) {
            Jengine.getCommonExecutor().addTask(task);
        }
    }

    public void postTask(Task task) {
        if (task != null && Jengine.getLogicExecutor() != null) {
            Jengine.getLogicExecutor().addTask(task);
        }
    }

    public void postCommonTask(AbstractTask task) {
        if (task != null && Jengine.getCommonExecutor() != null) {
            Jengine.getCommonExecutor().addTask(task, task.getDispatchId().getId());
        }
    }

    /**
     * 逻辑线程的异步通信，基于{@code task.getDispatchId().getId()}分发
     */
    public void postLogicTask(AbstractTask task) {
        if (task != null && Jengine.getLogicExecutor() != null) {
            Jengine.getLogicExecutor().addTask(task, task.getDispatchId().getId());
        }
    }

    public void postTickTask(TickTask task) {
        Jengine.getLogicExecutor().addTask(task, task.getDispatchId().getId());
    }

    public void postUpdateTask(UpdateTask task) {
        Jengine.getLogicExecutor().addTask(task, task.getDispatchId().getId());
    }

    private void dispatchSingleEvent(ObjectId dispatchId, Event event, EventObject eventObject) {
        if (dispatchId != null && event != null) {
            EventTask eventTask = EventTask.valueOf(dispatchId, event, eventObject);
            Jengine.getLogicExecutor().addTask(eventTask, dispatchId.getId());
        } else {
            Log.getJengineLogger().error("dispatchId is null");
        }
    }

    private void dispatchSingleEvent(Event event, EventObject eventObject) {
        if (event != null) {
            EventTask eventTask = EventTask.valueOf(event, eventObject);
            Jengine.getLogicExecutor().addTask(eventTask);
        }
    }
}
