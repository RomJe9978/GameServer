package com.jengine.task;

import com.jengine.object.ObjectId;

public abstract class AbstractTask implements Task {
	/**
	 * The object id kept by task
	 */
	protected ObjectId dispatchId;

	/**
	 * If ensureRun = true,
	 * the task must be run before exit(for thread or process).
	 */
	private boolean ensureRun;

	public AbstractTask() {
	}

	public AbstractTask(ObjectId dispatchId) {
		this.dispatchId = dispatchId;
	}

	public AbstractTask(boolean ensureRun) {
		this.ensureRun = ensureRun;
	}

	public AbstractTask(ObjectId dispatchId, boolean ensureRun) {
		this.dispatchId = dispatchId;
		this.ensureRun = ensureRun;
	}

	/**
	 * The actual job of this task.
	 */
	@Override
	public abstract void run();

	/**
	 * Return the type code of task.
	 */
	@Override
	public abstract int getType();

	/**
	 * Whether the task must be run before exit.
	 */
	@Override
	public boolean ensureRun() {
		return ensureRun;
	}

	/**
	 * Returns the object Id bind with task.
	 *
	 * @return
	 */
	public ObjectId getDispatchId() {
		return dispatchId;
	}

}
