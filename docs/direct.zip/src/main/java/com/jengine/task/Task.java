package com.jengine.task;

public interface Task {
	default int getType() {
		return 0;
	}

	default boolean ensureRun() {
		return true;
	}

	void run();
}
