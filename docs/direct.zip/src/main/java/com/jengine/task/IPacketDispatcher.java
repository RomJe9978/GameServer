package com.jengine.task;

import com.jengine.io.ClientSession;
import com.jengine.io.Packet;

/**
 * “网络消息包”派发接口
 * <p>为了兼容旧的机制，只把“消息派发”抽离出来
 *
 * @author RomJe
 */
public interface IPacketDispatcher {

    void dispatchPacket(ClientSession session, Packet packet);
}
