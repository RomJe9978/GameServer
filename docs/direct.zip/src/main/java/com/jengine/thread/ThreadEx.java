package com.jengine.thread;

import com.jengine.JengineException;
import com.jengine.logger.Log;
import com.jengine.task.Task;
import com.jengine.util.TimeUtil;

import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A {@ThreadEx} is a extension of Thread.
 */
public class ThreadEx extends Thread {
    private ThreadMonitor threadMonitor;
    private Deque<Task> tasks;

    private static final int SLEEP_DURATION = 5;

    /**
     * Flag of thread state
     * running: a thread in running state
     * waitingExit: a thread waiting for exit
     */
    private volatile boolean running;
    private volatile boolean waitingExit;

    private AtomicLong totalTaskCount;

    private AtomicLong totalProcessTaskCount;

    private volatile long lastRunAtMs;

    public ThreadEx(ThreadMonitor monitor) {
        this.running = false;
        this.waitingExit = false;
        this.totalTaskCount = new AtomicLong(0);
        this.totalProcessTaskCount = new AtomicLong(0);

        tasks = new ConcurrentLinkedDeque<>();

        if (monitor != null) {
            this.threadMonitor = monitor;
            monitor.register(this);
        }
    }

    public ThreadEx(String name, ThreadMonitor monitor) {
        super(name);
        this.running = false;
        this.waitingExit = false;
        this.totalTaskCount = new AtomicLong(0);
        this.totalProcessTaskCount = new AtomicLong(0);

        tasks = new ConcurrentLinkedDeque<>();

        if (monitor == null) {
            this.threadMonitor = monitor;
            this.threadMonitor.register(this);
        }
    }

    public ThreadEx(String name, Runnable runnable, ThreadMonitor monitor) {
        super(runnable, name);
        this.threadMonitor = monitor;
        this.threadMonitor.register(this);
    }

    public int getBlockingTaskCount() {
        return this.tasks.size();
    }

    public long getTotalTaskCount() {
        return this.totalTaskCount.get();
    }

    public long getTotalProcessTaskCount() {
        return totalProcessTaskCount.get();
    }

    public boolean addTask(Task task) {
        if (this.running && !waitingExit) {
            this.tasks.add(task);
            this.totalTaskCount.incrementAndGet();
            return true;
        }

        return false;
    }

    public boolean addTaskToHead(Task task) {
        if (this.running && !waitingExit) {
            this.tasks.push(task);
            this.totalTaskCount.incrementAndGet();
            return true;
        }

        return false;
    }

    public boolean close(boolean waitUntilFinish) {
        if (this.running && !this.waitingExit) {
            this.waitingExit = waitUntilFinish;
            if (!waitUntilFinish) {
                this.running = false;
            }

            try {
                join();
            } catch (Exception e) {
                JengineException.catchEx(e);
                return false;
            }

            this.running = false;
            this.waitingExit = false;
        }

        return true;
    }

    public long getLastRunAtMs() {
        return lastRunAtMs;
    }

    @Override
    public synchronized void start() {
        this.running = true;
        super.start();
    }

    @Override
    public void run() {
        while (this.running) {
            try {
                Task task = null;
                if (!this.tasks.isEmpty()) {
                    task = tasks.pop();
                }

                if (waitingExit) {
                    if (task != null && task.ensureRun()) {
                        this.lastRunAtMs = TimeUtil.getTimeInMillis();
                        task.run();
                        this.totalProcessTaskCount.incrementAndGet();
                    } else {
                        break;
                    }
                } else {
                    if (task != null) {
                        long start = TimeUtil.getTimeInMillis();
                        this.lastRunAtMs = start;
                        task.run();
                        this.totalProcessTaskCount.incrementAndGet();
                        long end = TimeUtil.getTimeInMillis();
                        if (end - start > 1000) {
                            Log.getJengineLogger().warn("task {}  cost too much time: {}", task, end - start);
                        }

                        if (end - start > 2000) {
                            JengineException.catchEx(new Exception("task " + task + " cost too much time: " + (end - start)));
                        }
                    } else {
                        Thread.sleep(SLEEP_DURATION);
                    }
                }

            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }
    }

}
