package com.jengine.thread;

public interface Lockable {
	boolean lock();

	boolean unlock();
}
