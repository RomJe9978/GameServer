package com.jengine.thread;

import com.jengine.JengineConfiguration;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import com.jengine.util.TimeUtil;
import org.slf4j.Logger;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ThreadMonitor extends Thread {
    private static final Logger log = Log.getJengineLogger();
    private static final long MONITOR_LOG_INTERVAL = JengineConfiguration.getThreadMonitorLogIntervalInMs();
    private static final long MONITOR_CHECK_INTERVAL = JengineConfiguration.getThreadMonitorCheckIntervalInMs();
    private static final int MAX_BLOCKING_SIZE = JengineConfiguration.getThreadMonitorMaxBlockingSize();

    private Map<ThreadEx, Long> thread2Time = new ConcurrentHashMap<>();
    private String name;
    private volatile long lastLogTime;

    public ThreadMonitor(String name) {
        this.name = name;
    }

    /**
     * Registers a thread to monitor.
     *
     * @param thread
     */
    public void register(ThreadEx thread) {
        this.thread2Time.put(thread, TimeUtil.getTimeInMillis());
        log.debug("ThreadMonitor: register({})", thread.getName());
    }

    public void unRegister(ThreadEx thread) {
        if (this.thread2Time.containsKey(thread.getName())) {
            this.thread2Time.remove(thread.getName());
            log.debug("ThreadMonitor: unRegister({})", thread.getName());
        } else {
            log.debug("ThreadMonitor: unRegister ({}) failed[thread not registered", thread.getName());
        }
    }

    @Override
    public void run() {
        while (true) {
            long pre = TimeUtil.getTimeInMillis();

            this.checkThreadMetrics();
            if (pre - this.lastLogTime >= MONITOR_LOG_INTERVAL) {
                this.logThreadDetails(pre);
            }

            long now = TimeUtil.getTimeInMillis();
            if (now - pre < MONITOR_CHECK_INTERVAL) {
                try {
                    Thread.sleep(MONITOR_LOG_INTERVAL - (now - pre));
                } catch (InterruptedException e) {
                    JengineException.catchEx(e);
                }
            }
        }
    }

    private void checkThreadMetrics() {
        for (ThreadEx threadEx : this.thread2Time.keySet()) {
            if (threadEx.getBlockingTaskCount() > MAX_BLOCKING_SIZE) {
                String blockingMsg = String.format("ThreadName[%s], totalCount[%d], totalProcessCount[%d],  blockingCount[%d], lastRunTime[%d]",
                        threadEx.getName(), threadEx.getTotalTaskCount(), threadEx.getTotalProcessTaskCount(), threadEx.getBlockingTaskCount(), threadEx.getLastRunAtMs());
                JengineException.catchEx(new Exception("Thread blocked too much msg, " + blockingMsg));
                log.warn(blockingMsg);
            }
        }
    }

    private void logThreadDetails(long pre) {
        this.lastLogTime = pre;
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("====== Threads Details: total size[{}]========\n", this.thread2Time.size()));
        for (ThreadEx threadEx : this.thread2Time.keySet()) {
            sb.append(String.format("\tName: %s, \t\t\tCount: %d, \t\tblockingCount: %d, \t\tlastRunTime: %d\n",
                    threadEx.getName(), threadEx.getTotalTaskCount(), threadEx.getBlockingTaskCount(), threadEx.getLastRunAtMs()));
        }

        log.debug(sb.toString());
    }
}
