package com.jengine.thread;

import com.jengine.Jengine;
import com.jengine.task.Task;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;


/**
 * The default implementation of {@ThreadPool}.
 *
 * @author mengyan
 */
public class DefaultThreadPool implements ThreadPool {
    /**
     * Generally, for thread-safe, each task's owner binds with a task by owner's ObjectId.
     * But if there's no bound thread with the task, will use round-robin algorithm to choose a thread to schedule it.
     * This is the flag of this kind task.
     */
    private static final int ASYNC_INDEX_FLAG = -1;

    /**
     * Flag of thread state
     * running: thread pool in running state
     * waitingExit: thread pool waiting for exit
     */
    private volatile boolean running;
    private volatile boolean waitingExit;

    private List<ThreadEx> threads;
    private AtomicLong curIndex;

    /**
     * The name of the ThreadPool for nice printed.
     */
    private String name;

    public DefaultThreadPool(String name, int size) {
        this.name = name;
        this.running = false;
        this.waitingExit = false;
        this.curIndex = new AtomicLong(0);
        this.threads = new CopyOnWriteArrayList<>();

        this.init(size);
    }

    private boolean init(int size) {
        if (size <= 0) {
            return false;
        }

        for (int i = 0; i < size; i++) {
            ThreadEx thread = new ThreadEx(Jengine.getThreadMonitor());
            thread.setName(name + "-" + thread.getId());

            this.threads.add(thread);
        }

        return true;
    }

    /**
     * Schedules the task with special thread.
     *
     * @param task
     * @param index
     * @return
     */
    @Override
    public boolean addTask(Task task, long index) {
        if (this.running && !this.waitingExit) {
            if (index == ASYNC_INDEX_FLAG) {
                index = (int) (curIndex.incrementAndGet() % this.threads.size());
            } else {
                index = index % this.threads.size();
            }

            if (index >= 0 && index < this.threads.size()) {
                return this.threads.get((int) index).addTask(task);
            }
        }
        return false;
    }

    /**
     * Schedules the task use round-robin to choose the next thread.
     *
     * @param task
     * @return
     */
    @Override
    public boolean addTask(Task task) {
        return this.addTask(task, ASYNC_INDEX_FLAG);
    }

    @Override
    public boolean start() {
        if (!this.running) {
            this.running = true;
            for (ThreadEx threadEx : this.threads) {
                threadEx.start();
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean close(boolean waitUntilFinish) {
        if (this.running && !this.waitingExit) {
            this.waitingExit = waitUntilFinish;
            if (!this.waitingExit) {
                this.running = false;
            }

            for (ThreadEx threadEx : threads) {
                threadEx.close(waitUntilFinish);
            }

            this.running = false;
            this.waitingExit = false;
        }

        return false;
    }
}
