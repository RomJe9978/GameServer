package com.jengine.thread;

import com.jengine.task.Task;

public interface ThreadPool {
    boolean addTask(Task task);

    boolean addTask(Task task, long index);

    boolean start();

    boolean close(boolean waitUntilFinish);

}
