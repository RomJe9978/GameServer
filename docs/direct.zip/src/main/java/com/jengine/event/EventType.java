package com.jengine.event;

/**
 * Predefined system event types.
 *
 * @author mengyan
 */
public class EventType {
	/**
	 * Network session event code definitions
	 */
	public static final int SESSION_OPEN = 1;
	public static final int SESSION_CLOSE = 2;

}
