package com.jengine.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Event manager for registering event listeners and processing events.
 *
 * @author mengyan
 */
public class EventManager {
	private static final Logger log = LoggerFactory.getLogger(EventManager.class);
	private static EventManager instance = new EventManager();

	public static EventManager getInstance() {
		return instance;
	}

	/**
	 * Not support multiple listeners for one event.
	 */
	private Map<Integer, List<EventObject>> listeners;

	private EventManager() {
		this.listeners = new HashMap<>();
	}

	public void registerListener(int code, Method listener, Object object) {
		log.info("[EventManager] registerListener(code: {}, listener:{})", code, listener.getClass().getSimpleName());

		if (!this.isListenedEvent(code)) {
			this.listeners.put(code, new ArrayList<>());
		}

		this.listeners.get(code).add(EventObject.valueOf(listener, object));
	}

	boolean isListenedEvent(int code) {
		return this.listeners.containsKey(code);
	}

	public List<EventObject> getListeners(int type) {
		if (this.isListenedEvent(type)) {
			return this.listeners.get(type);
		}

		return null;
	}

	public boolean onEvent(Event event) {
		List<EventObject> listeners = this.listeners.get(event.getType());

		for (EventObject listener : listeners) {
			if (listener != null) {
				listener.safeInvoke(event);
			} else {
				log.error("[EventManager] event code: {} not registered.", event.getType());
			}
		}

		return false;
	}
}
