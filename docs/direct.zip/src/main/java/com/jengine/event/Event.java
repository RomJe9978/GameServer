package com.jengine.event;

import com.jengine.Jengine;
import com.jengine.object.GameObject;
import com.jengine.object.ObjectId;
import com.jengine.util.TimeUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Event represents a user event or a system event.
 *
 * @author mengyan
 */
public class Event {
    private int type;

    private GameObject source;
    private GameObject target;

    private List<Object> params;

    private long createdAtMillis;

    public Event(int type) {
        this.params = new ArrayList<>();
        this.type = type;
        this.createdAtMillis = TimeUtil.getTimeInMillis();
    }

    public static Event valueOf(int type) {
        return new Event(type);
    }

    public static Event valueOf(int type, ObjectId target) {
        return Event.valueOf(type).setTarget(target);
    }

    public static Event valueOf(int type, ObjectId target, ObjectId source) {
        return Event.valueOf(type, target).setSource(source);
    }

    public GameObject getTarget() {
        return this.target;
    }

    public ObjectId getTargetId() {
        if (target == null) {
            return null;
        }

        return target.getOId();
    }

    public Event setTarget(ObjectId targetId) {
        this.target = Jengine.getObjectAccessor(targetId.getType()).queryObject(targetId);
        return this;
    }

    public GameObject getSource() {
        return this.source;
    }

    public ObjectId getSourceId() {
        return this.source.getOId();
    }

    public Event setSource(ObjectId sourceId) {
        this.source = Jengine.getObjectAccessor(sourceId.getType()).queryObject(sourceId);
        return this;
    }

    public List<Object> getParams() {
        return params;
    }

    public Event addParams(Object... params) {
        this.params.addAll(Arrays.asList(params));
        return this;
    }

    public long getCreatedAtMillis() {
        return createdAtMillis;
    }

    public int getType() {
        return type;
    }
}
