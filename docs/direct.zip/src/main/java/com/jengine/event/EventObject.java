package com.jengine.event;

import com.jengine.JengineException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * An event object holds the implementation of this event listener which will pass the Event as parameter for calling.
 *
 * @author mengyan
 */
public class EventObject {
	private Method method;
	private Object object;

	public EventObject(Method method, Object object) {
		this.method = method;
		this.object = object;
	}

	public static EventObject valueOf(Method method, Object object) {
		return new EventObject(method, object);
	}

	public Object getObject() {
		return object;
	}

	public void safeInvoke(Event event) {
		try {
			this.invoke(event);
		} catch (Exception e) {
			JengineException.catchEx(e);
		}
	}

	public void invoke(Event event) throws InvocationTargetException, IllegalAccessException {
		this.method.invoke(this.object, event);
	}
}