package com.jengine.cluster;

import com.jengine.cluster.resolver.ConfigBasedResolver;
import com.jengine.cluster.storage.MemoryBasedStorage;
import com.jengine.io.Connector;
import com.jengine.io.Packet;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.io.tcp.connector.SingleConnector;
import com.jengine.logger.Log;
import com.jengine.object.ObjType;
import com.jengine.object.ObjectId;
import org.slf4j.Logger;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Manages multiple servers and provide operation API.
 *
 * @author mengyan
 */
public class Cluster {
    private static final Logger log = Log.getJengineLogger();

    private ConcurrentMap<String, String> channelBalancers;

    private ConcurrentMap<Connector, String> connectors;
    private ConcurrentMap<String, Balancer> balancers;

    private Storage stickinessStorage;
    private Resolver resolver;

    public Cluster(Resolver resolver) {
        this.channelBalancers = new ConcurrentHashMap<>();
        this.connectors = new ConcurrentHashMap<>();
        this.balancers = new ConcurrentHashMap<>();

        this.resolver = resolver;
    }

    /**
     * If channel's balancer is StickinessLoadBalancer,
     * A storage for it must be set which will maintenance the id and connector mapping.
     *
     * @param storage
     */
    public void setStorage(Storage storage) {
        this.stickinessStorage = storage;
    }

    public Storage getStorage() {
        return stickinessStorage;
    }

    public void registerServiceBalancer(String channel, String balancerName) {
        this.channelBalancers.put(channel, balancerName);
    }

    public synchronized void addService(String channel, Connector connector, boolean removeInactiveConnector) {
        if (!this.balancers.containsKey(channel)) {
            if (!this.channelBalancers.containsKey(channel)) {
                this.channelBalancers.put(channel, Balancer.DEFAULT);
            }

            Balancer balancer = BalancerFactory.create(
                    this.channelBalancers.get(channel), channel, this.resolver, this.stickinessStorage, removeInactiveConnector);
            if (balancer == null) {
                log.error("Cluster addService failed for balancer is null.");
                return;
            }

            this.balancers.put(channel, balancer);
        }

        this.connectors.put(connector, channel);
        this.resolver.registerConnector(channel, connector);
    }

    public void removeService(Connector connector) {
        String channel = this.connectors.get(connector);
        this.resolver.unregisterConnector(channel, connector);
    }

    /**
     * Get a connector for the given channel and objectId by loadbalancer
     *
     * @param channel
     * @param objectId
     * @return
     */
    public Connector getConnector(String channel, ObjectId objectId) {
        if (this.balancers.containsKey(channel)) {
            Connector connector = this.balancers.get(channel).pick(objectId);
            if (connector != null && connector.isActive()) {
                return connector;
            } else {
                log.error("Cluster sendPacket failed for no active connector found.");
            }
        } else {
            log.error("Cluster sendPacket failed for no balancer found for channel name {}.", channel);
        }

        return null;
    }

    public boolean isRegisteredService(String channel) {
        return this.channelBalancers.containsKey(channel);
    }

    public void sendPacket(String channel, Packet packet) {
        this.sendPacket(channel, null, packet);
    }

    public void sendPacket(String channel, long oid, Packet packet) {
        this.sendPacket(channel, new ObjectId(ObjType.PLAYER, oid), packet);
    }

    public void sendPacket(String channel, ObjectId objectId, Packet packet) {
        if (this.balancers.containsKey(channel)) {
            Connector connector = this.balancers.get(channel).pick(objectId);
            if (connector != null && connector.isActive()) {
                connector.send(packet);
            } else {
                log.error("Cluster sendPacket failed for no active connector found.");
            }
        } else {
            log.error("Cluster sendPacket failed for no balancer found for channel name {}.", channel);
        }
    }

    public void broadcast(String channel, Packet packet) {
        if (this.balancers.containsKey(channel)) {
            List<Connector> connectors = this.balancers.get(channel).allConnectors();
            if (connectors != null) {
                for (Connector connector : connectors) {
                    if (connector != null && connector.isActive()) {
                        connector.send(packet);
                    }
                }
            }
        } else {
            log.error("Cluster sendPacket failed for no balancer found for channel name {}.", channel);
        }
    }

    public static void main(String[] args) {
        String channel = "game";

        Cluster cluster = new Cluster(new ConfigBasedResolver());
        cluster.registerServiceBalancer(channel, Balancer.STICKINESS);

        Storage<Connector> storage = new MemoryBasedStorage();
        SingleConnector connector = new SingleConnector("127.0.0.1", 8899, true);
        storage.set(channel, "1111", connector);

        cluster.setStorage(storage);
        cluster.addService(channel, connector, true);
        cluster.sendPacket(channel, ObjectId.valueOf(1, 1111L), TcpPacket.valueOf(1));
    }
}
