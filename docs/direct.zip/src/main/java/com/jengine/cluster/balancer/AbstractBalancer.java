package com.jengine.cluster.balancer;

import com.jengine.cluster.Balancer;
import com.jengine.cluster.Resolver;
import com.jengine.io.Connector;

import java.util.List;

/**
 * AbstractBalancer
 *
 * @author mengyan
 */
public abstract class AbstractBalancer implements Balancer {
    private String channelName;
    protected Resolver resolver;
    protected boolean removeInactiveConnector;

    public AbstractBalancer(String channelName, Resolver resolver, boolean removeInactiveConnector) {
        this.channelName = channelName;
        this.resolver = resolver;
        this.removeInactiveConnector = removeInactiveConnector;
    }

    @Override
    public String channelName() {
        return this.channelName;
    }

    @Override
    public List<Connector> allConnectors() {
        return this.resolver.resolveConnector(this.channelName());
    }
}
