package com.jengine.cluster;

import java.util.concurrent.ConcurrentMap;

/**
 * Storage maintenances the relation of key & connector.
 *
 * @author mengyan
 */
public interface Storage<T> {
    /**
     * returns the connector with service name and key.
     *
     * @param channel
     * @param key
     * @return
     */
    T get(String channel, String key);

    /**
     * updates the releation of key and connector.
     *
     * @param channel
     * @param key
     * @param connector
     */
    void set(String channel, String key, T connector);

    /**
     * updates the releation of channel id and connector by sharable mapping.
     *
     * @param channel
     * @param mapping
     */
    void setSharableMapping(String channel, ConcurrentMap<String, T> mapping);

    /**
     * removes the key from storage.
     *
     * @param channel
     * @param key
     */
    void remove(String channel, String key);
}
