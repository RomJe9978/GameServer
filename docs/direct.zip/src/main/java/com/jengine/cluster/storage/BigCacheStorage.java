package com.jengine.cluster.storage;

import com.jengine.Jengine;
import com.jengine.cluster.Storage;
import com.jengine.io.Connector;
import com.jengine.util.StringUtil;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * A cache system based implementation of storage.
 *
 * @author mengyan
 */
public class BigCacheStorage implements Storage<Connector> {
    private RedisBasedStorage redisBasedStorage;
    private ConcurrentMap<String, Connector> channelConnectorMapping;

    public BigCacheStorage(Jedis client, JedisCluster cluster) {
        this.redisBasedStorage = new RedisBasedStorage(Jengine.getConfiguration().getString("cache.globalIDKeyPrefix"), client, cluster);
        this.channelConnectorMapping = new ConcurrentHashMap<>();
    }

    @Override
    public Connector get(String channelName, String key) {
        String value = this.redisBasedStorage.get(channelName, key);
        if (StringUtil.isNotEmpty(value)) {
            return this.channelConnectorMapping.get(value);
        }

        return null;
    }

    @Override
    public void set(String channelName, String key, Connector serverConnector) {
        this.channelConnectorMapping.put(key, serverConnector);
    }

    @Override
    public void setSharableMapping(String channel, ConcurrentMap<String, Connector> mapping) {
        this.channelConnectorMapping = mapping;
    }

    @Override
    public void remove(String channelName, String key) {
        if (this.channelConnectorMapping.containsKey(channelName)) {
            this.channelConnectorMapping.remove(key);
        }
    }
}
