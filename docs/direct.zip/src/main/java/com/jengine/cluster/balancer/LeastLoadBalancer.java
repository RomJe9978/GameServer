package com.jengine.cluster.balancer;

import com.jengine.cluster.Resolver;
import com.jengine.io.Connector;
import com.jengine.object.ObjectId;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Selects a connector by loads.
 *
 * @author mengyan
 */
public class LeastLoadBalancer extends AbstractBalancer {
    public static final String NAME = "LeastLoad";
    private static final int MIN_LOAD = 0;
    private ConcurrentMap<Connector, AtomicLong> loads = new ConcurrentHashMap<>();

    public LeastLoadBalancer(String channelName, Resolver resolver, boolean removeInactiveConnector) {
        super(channelName, resolver, removeInactiveConnector);
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public Connector pick(ObjectId context) {
        List<Connector> connectors = this.resolver.resolveConnector(this.channelName());
        if (connectors != null && connectors.size() > 0) {
            return this.selectMinLoad(connectors);
        }

        return null;
    }

    private Connector selectMinLoad(List<Connector> connectors) {
        Connector minLoadConnector = null;
        long minLoad = -1;

        Iterator<Connector> iterator = connectors.iterator();
        while (iterator.hasNext()) {
            Connector connector = iterator.next();

            // remove inactive connector
            if (connector != null && !connector.isActive()) {
                if (this.removeInactiveConnector) {
                    iterator.remove();
                    this.loads.remove(connector);
                }

                continue;
            }

            // select a least active load connector.
            if (!this.loads.containsKey(connector)) {
                this.loads.put(connector, new AtomicLong(MIN_LOAD));
            }

            if (this.loads.get(connector).get() == MIN_LOAD) {
                this.loads.get(connector).incrementAndGet();
                return connector;
            } else {
                long trySelect = this.loads.get(connector).get();
                if (trySelect <= minLoad || minLoad == -1) {
                    minLoad = trySelect;
                    minLoadConnector = connector;
                }
            }
        }

        return minLoadConnector;
    }
}
