package com.jengine.cluster;

import com.jengine.util.StringUtil;

import java.util.Objects;

/**
 * A wrapper for host and port.
 *
 * @author mengyan
 */
public class HostAndPort {
    private static final String COLON_SEPARATOR = ":";

    /**
     * the ip address.
     */
    private String host;
    /**
     * the port.
     */
    private int port;

    public HostAndPort(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public static HostAndPort valueOf(String address) {
        if (StringUtil.isEmpty(address)) {
            return null;
        }

        String[] temp = address.split(COLON_SEPARATOR);
        if (temp.length >= 2) {
            return new HostAndPort(temp[0], Integer.valueOf(temp[1]));
        }

        return null;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof HostAndPort)) {
            return false;
        }

        HostAndPort that = (HostAndPort) o;
        return getPort() == that.getPort() &&
                Objects.equals(getHost(), that.getHost());
    }

    @Override
    public String toString() {
        return "HostAndPort{" +
                "host='" + host + '\'' +
                ", port=" + port +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(getHost(), getPort());
    }
}
