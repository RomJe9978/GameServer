package com.jengine.cluster.balancer;

import com.jengine.cluster.Resolver;
import com.jengine.io.Connector;
import com.jengine.object.ObjectId;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A load balancer based on random selector.
 *
 * @author mengyan
 */
public class RandomLoadBalancer extends AbstractBalancer {
    public static final String NAME = "Random";

    public RandomLoadBalancer(String channelName, Resolver resolver, boolean removeInactiveConnector) {
        super(channelName, resolver, removeInactiveConnector);
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public Connector pick(ObjectId context) {
        List<Connector> connectors = this.resolver.resolveConnector(this.channelName());
        if (connectors != null && connectors.size() > 0) {
            return this.randSelect(connectors);
        }

        return null;
    }

    private Connector randSelect(List<Connector> connectors) {
        int size = connectors.size();
        int select = ThreadLocalRandom.current().nextInt(size);
        Connector connector = connectors.get(select);
        if (connector != null && !connector.isActive() && this.removeInactiveConnector) {
            connectors.remove(connector);
            if (connectors.size() > 0) {
                return randSelect(connectors);
            }
        } else {
            return connector;
        }

        return null;
    }
}
