package com.jengine.cluster.resolver;

import com.jengine.cluster.HostAndPort;
import com.jengine.util.StringUtil;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * A resolver implement based on static configuration.
 *
 * @author mengyan
 */
public class ConfigBasedResolver extends AbstractResolver {
    private static final String SEMICOLON_SEPARATOR = ";";
    private ConcurrentMap<String, List<HostAndPort>> addresses;

    public ConfigBasedResolver() {
        this.addresses = new ConcurrentHashMap<>();
    }

    @Override
    public void register(String channelName, String addresses) {
        if (StringUtil.isEmpty(addresses)) {
            return;
        }

        for (String ipAndPort : addresses.split(SEMICOLON_SEPARATOR)) {
            HostAndPort hostAndPort = HostAndPort.valueOf(ipAndPort);
            if (!this.addresses.containsKey(channelName)) {
                this.addresses.put(channelName, new CopyOnWriteArrayList<>());
            }
            if (!this.addresses.get(channelName).contains(hostAndPort)) {
                this.addresses.get(channelName).add(hostAndPort);
            }
        }
    }

    @Override
    public List<HostAndPort> resolve(String channelName) {
        return this.addresses.getOrDefault(channelName, new CopyOnWriteArrayList<>());
    }
}
