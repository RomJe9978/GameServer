package com.jengine.cluster;

import com.jengine.cluster.balancer.LeastLoadBalancer;
import com.jengine.cluster.balancer.RandomLoadBalancer;
import com.jengine.cluster.balancer.RoundRobinLoadBalancer;
import com.jengine.cluster.balancer.StickinessLoadBalancer;

/**
 * Factory method for create balancer.
 *
 * @author mengyan
 */
public class BalancerFactory {
    public static <T> Balancer create(String balancerName, String channelName, Resolver resolver, Storage storage, boolean removeInactiveConnector) {
        switch (balancerName) {
            case StickinessLoadBalancer.NAME:
                if (storage == null) {
                    return null;
                }
                return new StickinessLoadBalancer<T>(channelName, resolver, storage, removeInactiveConnector);
            case RandomLoadBalancer.NAME:
                return new RandomLoadBalancer(channelName, resolver, removeInactiveConnector);
            case LeastLoadBalancer.NAME:
                return new LeastLoadBalancer(channelName, resolver, removeInactiveConnector);
            default:
                return new RoundRobinLoadBalancer(channelName, resolver, removeInactiveConnector);
        }
    }
}
