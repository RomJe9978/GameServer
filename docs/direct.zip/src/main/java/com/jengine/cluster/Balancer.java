package com.jengine.cluster;

import com.jengine.cluster.balancer.LeastLoadBalancer;
import com.jengine.cluster.balancer.RandomLoadBalancer;
import com.jengine.cluster.balancer.RoundRobinLoadBalancer;
import com.jengine.cluster.balancer.StickinessLoadBalancer;
import com.jengine.io.Connector;
import com.jengine.object.ObjectId;

import java.util.List;

/**
 * The common operations of load balancer.
 *
 * @author mengyan
 */
public interface Balancer {
    /**
     * RoundRobin load balancer
     */
    String ROUND_ROBIN = RoundRobinLoadBalancer.NAME;

    /**
     * Random load balancer.
     */
    String RANDOM = RandomLoadBalancer.NAME;

    /**
     * Stickiness load balancer.
     */
    String STICKINESS = StickinessLoadBalancer.NAME;

    /**
     * Least-load load balancer.
     */
    String LEAST_LOAD = LeastLoadBalancer.NAME;

    /**
     * Defines the default balancer name
     */
    String DEFAULT = ROUND_ROBIN;

    /**
     * Returns the name of loadbalancer.
     *
     * @return
     */
    String name();

    /**
     * Returns the name of channel that the balancer bind to.
     *
     * @return
     */
    String channelName();

    /**
     * Picks a connector to use.
     *
     * @param context
     * @return
     */
    Connector pick(ObjectId context);

    /**
     * Return all the connectors.
     *
     * @return
     */
    List<Connector> allConnectors();

}
