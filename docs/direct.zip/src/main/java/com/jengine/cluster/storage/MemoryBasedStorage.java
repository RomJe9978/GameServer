package com.jengine.cluster.storage;

import com.jengine.cluster.Storage;
import com.jengine.io.Connector;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Storage all information in memory.
 *
 * @author mengyan
 */
public class MemoryBasedStorage implements Storage<Connector> {
    private ConcurrentMap<String, ConcurrentMap<String, Connector>> channelConnectorMapping = new ConcurrentHashMap<>();

    @Override
    public Connector get(String channelName, String key) {
        if (!this.channelConnectorMapping.containsKey(channelName)) {
            return null;
        }

        return this.channelConnectorMapping.get(channelName).get(key);
    }

    @Override
    public void set(String channelName, String key, Connector connector) {
        if (!this.channelConnectorMapping.containsKey(channelName)) {
            this.channelConnectorMapping.put(channelName, new ConcurrentHashMap<>());
        }

        this.channelConnectorMapping.get(channelName).put(key, connector);
    }

    @Override
    public void setSharableMapping(String channelName, ConcurrentMap<String, Connector> mapping) {
        this.channelConnectorMapping.put(channelName, mapping);
    }

    @Override
    public void remove(String channelName, String key) {
        if (this.channelConnectorMapping.containsKey(channelName)) {
            this.channelConnectorMapping.get(channelName).remove(key);
        }
    }
}
