package com.jengine.cluster.balancer;

import com.jengine.cluster.Resolver;
import com.jengine.io.Connector;
import com.jengine.object.ObjectId;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A load balancer base on round-robin algorithm.
 *
 * @author mengyan
 */
public class RoundRobinLoadBalancer extends AbstractBalancer {
    public static final String NAME = "RoundRobin";
    private AtomicLong counter = new AtomicLong(0L);

    public RoundRobinLoadBalancer(String channelName, Resolver resolver, boolean removeInactiveConnector) {
        super(channelName, resolver, removeInactiveConnector);
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public Connector pick(ObjectId context) {
        List<Connector> connectors = this.resolver.resolveConnector(this.channelName());
        if (connectors != null && connectors.size() > 0) {
            return this.selectByRoundRobin(connectors);
        }
        return null;
    }

    private Connector selectByRoundRobin(List<Connector> connectors) {
        int size = connectors.size();
        int index = (int) (incrCounter() % size);
        Connector connector = connectors.get(index);

        if (connector != null && !connector.isActive() && this.removeInactiveConnector) {
            connectors.remove(connector);
            if (connectors.size() > 0) {
                return selectByRoundRobin(connectors);
            }
        } else {
            return connector;
        }

        return null;
    }

    private long incrCounter() {
        if (this.counter.get() >= Integer.MAX_VALUE) {
            this.counter.set(0L);
        }

        return this.counter.incrementAndGet();
    }
}
