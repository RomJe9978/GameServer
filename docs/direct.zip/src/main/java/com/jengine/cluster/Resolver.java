package com.jengine.cluster;

import com.jengine.io.Connector;

import java.util.List;
import java.util.concurrent.ConcurrentMap;

/**
 * Resolver represents a naming service which used for service discovery.
 * By this, you can register a new service at address with name,and also resolve the name
 * and return all services named `name`.
 * A resolver can be implemented by zookeeper, etcd, a self-implemented service or just a
 * static config for test.
 *
 * @author mengyan
 */
public interface Resolver {
    /**
     * regiter new service at address with channel.
     */
    void register(String channel, String address);

    /**
     * resolve the channel and return a address list.
     */
    List<HostAndPort> resolve(String channel);

    /**
     * registers a connector bind with channel name.
     *
     * @param channel
     * @param connector
     */
    void registerConnector(String channel, Connector connector);

    /**
     * unregisters a connector bind with service name.
     *
     * @param channel
     * @param connector
     */
    void unregisterConnector(String channel, Connector connector);

    /**
     * resolves a connector for service name.
     *
     * @param channel
     * @return
     */
    List<Connector> resolveConnector(String channel);

    /**
     * resolves a connector for service name.
     *
     * @return
     */
    ConcurrentMap<String, List<Connector>> resolveConnectors();
}
