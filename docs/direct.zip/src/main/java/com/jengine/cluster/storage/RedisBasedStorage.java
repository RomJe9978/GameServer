package com.jengine.cluster.storage;

import com.jengine.cluster.Storage;
import com.jengine.util.URLUtil;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

import java.util.concurrent.ConcurrentMap;

/**
 * Storage all information in redis.
 *
 * @author mengyan
 */
class RedisBasedStorage implements Storage<String> {
    private String keyPrefix;
    private JedisCluster cluster;
    private Jedis client;

    public RedisBasedStorage(String keyPrefix, Jedis client, JedisCluster cluster) {
        this.keyPrefix = keyPrefix;
        this.cluster = cluster;
        this.client = client;
    }

    @Override
    public String get(String channelName, String key) {
        return this.fetch(this.generateKey(key));
    }

    @Override
    public void set(String channelName, String key, String value) {
        this.update(this.generateKey(key), value);
    }

    @Override
    public void setSharableMapping(String channel, ConcurrentMap<String, String> mapping) {
        // ignore.
    }

    @Override
    public void remove(String channelName, String key) {
        // ignore
    }

    private String fetch(String key) {
        if (this.cluster != null) {
            return this.fetchFromCluster(key);
        } else if (this.client != null) {
            return this.fetchFromStandalone(key);
        }

        return null;
    }

    private void update(String key, String value) {
        if (this.cluster != null) {
            this.updateInCluster(this.generateKey(key), value);
        } else if (this.client != null) {
            this.updateInStandalone(this.generateKey(key), value);
        }
    }

    private String fetchFromCluster(String key) {
        return this.cluster.get(this.generateKey(key));
    }

    private String fetchFromStandalone(String key) {
        return this.client.get(key);
    }

    private void updateInCluster(String key, String value) {
        this.cluster.set(key, value);
    }

    private void updateInStandalone(String key, String value) {
        this.client.set(key, value);
    }

    private String generateKey(String... params) {
        return URLUtil.concat(":", this.keyPrefix, params);
    }

}
