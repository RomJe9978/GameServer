package com.jengine.cluster.balancer;

import com.jengine.cluster.Resolver;
import com.jengine.cluster.Storage;
import com.jengine.io.Connector;
import com.jengine.object.ObjectId;
import com.jengine.util.CollectionUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mengyan
 */
public class StickinessLoadBalancer<T> extends AbstractBalancer {
    public static final String NAME = "Stickiness";
    private Storage<Connector> storage;

    public StickinessLoadBalancer(String channelName, Resolver resolver, Storage<Connector> storage, boolean removeInactiveConnector) {
        super(channelName, resolver, removeInactiveConnector);
        this.storage = storage;
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public Connector pick(ObjectId context) {
        synchronized (this) {
            String id = "0";
            if (context != null) {
                id = String.valueOf(context.getId());
            }

            Connector connector = this.storage.get(this.channelName(), id);
            if (connector == null) {
                return this.randomSelectOne(id);
            } else if (connector != null && !connector.isActive() && this.removeInactiveConnector) {
                this.storage.remove(this.channelName(), id);
                return this.randomSelectOne(id);
            } else {
                return connector;
            }
        }
    }

    private Connector randomSelectOne(String key) {
        synchronized (this) {
            List<Connector> allActiveConnectors = new ArrayList<>();
            for (Connector connector : this.allConnectors()) {
                if (connector.isActive()) {
                    allActiveConnectors.add(connector);
                }
            }

            List<Connector> selectedConnector = CollectionUtil.randomSelect(allActiveConnectors, 1);
            if (selectedConnector != null && selectedConnector.size() > 0) {
                this.storage.set(this.channelName(), key, selectedConnector.get(0));
                return selectedConnector.get(0);
            }

            return null;
        }
    }
}
