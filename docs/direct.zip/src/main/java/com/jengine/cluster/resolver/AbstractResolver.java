package com.jengine.cluster.resolver;

import com.jengine.cluster.Resolver;
import com.jengine.io.Connector;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * AbstractResolver implements the connector manager of resolver.
 *
 * @author mengyan
 */
public abstract class AbstractResolver implements Resolver {
    private ConcurrentMap<String, List<Connector>> connections = new ConcurrentHashMap<>();

    /**
     * registerConnection regiters new service at address with name.
     */
    @Override
    public void registerConnector(String channelName, Connector connector) {
        if (!this.connections.containsKey(channelName)) {
            this.connections.put(channelName, new CopyOnWriteArrayList<>());
        }

        if (!this.connections.get(channelName).contains(connector)) {
            this.connections.get(channelName).add(connector);
        }
    }

    @Override
    public void unregisterConnector(String channelName, Connector connector) {
        if (this.connections.containsKey(channelName)) {
            this.connections.get(channelName).remove(connector);
        }
    }

    /**
     * resolveConnection resolves the name and return a address list.
     */
    @Override
    public List<Connector> resolveConnector(String channelName) {
        return this.connections.getOrDefault(channelName, new CopyOnWriteArrayList<>());
    }

    @Override
    public ConcurrentMap<String, List<Connector>> resolveConnectors() {
        return this.connections;
    }
}
