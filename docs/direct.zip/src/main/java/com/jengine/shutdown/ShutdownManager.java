package com.jengine.shutdown;

import com.jengine.JengineException;
import com.jengine.logger.Log;
import com.jengine.service.Service;
import com.jengine.util.OsUtil;
import sun.misc.Signal;
import sun.misc.SignalHandler;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Processes application exit.
 * Will call all services shutdown method.
 *
 * @author mengyan
 */
public class ShutdownManager {
    private volatile boolean isShutdowning = false;

    /**
     * Must be ordered.
     */
    private Deque<Service> serviceList = new ArrayDeque<>();

    public void addService(Service service) {
        this.serviceList.push(service);
    }

    public void init() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> shutdown()));

        try {
            String signalType = getOsSignalType();

            Signal.handle(new Signal(signalType), new KillSignalHandler(signalType));
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

    public void shutdown() {
        if (isShutdowning) {
            return;
        }

        this.isShutdowning = true;

        Log.getJengineLogger().info("shutdowning server...");

        while (this.serviceList.peek() != null) {
            Service srv = this.serviceList.pop();
            try {
                srv.shutdown();
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }

        Log.getJengineLogger().info("shudown success.");
    }

    private String getOsSignalType() {
        return OsUtil.getLowercaseSystemName().startsWith("win") ? "INT" : "USR2";
    }

    private class KillSignalHandler implements SignalHandler {
        private String name;

        public KillSignalHandler(String name) {
            this.name = name;
        }

        @Override
        public void handle(Signal signal) {
            Log.getJengineLogger().info("processing {} signal.", this.name);
            shutdown();
            System.exit(0);
        }
    }
}
