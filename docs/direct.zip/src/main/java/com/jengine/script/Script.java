package com.jengine.script;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jengine.io.http.HttpExchange;
import com.jengine.io.http.HttpHandler;

/**
 * Interface of all scripts.
 *
 * @author mengyan
 */
public interface Script extends HttpHandler {
    /**
     * Each script must assign the uri path for URL router.
     *
     * @return
     */
    String getUri();

    /**
     * Response success information with no data.
     *
     * @param httpExchange
     */
    static void responseSuccess(HttpExchange httpExchange) {
        JsonObject jsonObject = JsonParser.parseString("{\"msg\": \"success\", \"code\": 0}").getAsJsonObject();
        httpExchange.response(jsonObject);
    }

    static void responseSuccess(HttpExchange httpExchange, JsonObject data) {
        JsonObject response = new JsonObject();
        response.addProperty("msg", "success");
        response.addProperty("code", 0);
        response.add("data", data);
        httpExchange.response(response);
    }

    static void responseFailed(HttpExchange httpExchange, JsonObject data) {
        JsonObject response = new JsonObject();
        response.addProperty("msg", "failed");
        response.addProperty("code", 1);
        response.add("data", data);
        httpExchange.response(response);
    }

    /**
     * Response failed information.
     *
     * @param httpExchange
     * @param reason
     */
    static void responseFailed(HttpExchange httpExchange, String reason) {
        JsonObject response = new JsonObject();
        response.addProperty("msg", "failed");
        response.addProperty("code", 1);
        response.addProperty("reason", reason);
        httpExchange.response(response);
    }

    static void responseFailed(HttpExchange httpExchange, String reason, int code) {
        JsonObject response = new JsonObject();
        response.addProperty("msg", "failed");
        response.addProperty("code", code);
        response.addProperty("reason", reason);
        httpExchange.response(response);
    }
}
