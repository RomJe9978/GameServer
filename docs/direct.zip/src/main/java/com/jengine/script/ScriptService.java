package com.jengine.script;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.io.http.HttpServerService;
import com.jengine.logger.Log;
import com.jengine.service.Service;
import com.jengine.util.OsUtil;
import org.slf4j.Logger;

import javax.tools.*;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Hot reload script and provides http service for script request.
 *
 * @author mengyan
 */
public class ScriptService implements Service {
    Logger logger = Log.getGMLogger();
    private static final ScriptService instance = new ScriptService();

    private static final String SOURCE_FILE_SUFFIX = ".java";
    private static final String WINDOWS_SYSTEM = "windows";
    private static final String WINDOWS_FILE_PROTOCOL_PREFIX = "file:/";
    private static final String UNIX_FILE_PROTOCOL_PREFIX = "file:";

    private HttpServerService httpserver;
    private String classOutputPath;
    private String sourceInputPath;
    private String packageName;

    private List<String> classNames;

    public ScriptService() {
        packageName = Jengine.getConfiguration().getString("script.packageName");

        String basePath = OsUtil.getUserDir();
        String packageDirName = packageName.replace('.', File.separatorChar);

        sourceInputPath = basePath + File.separatorChar + Jengine.getConfiguration().getString("script.inputBaseFolder") + File.separatorChar + packageDirName;
        classOutputPath = basePath + File.separatorChar + Jengine.getConfiguration().getString("script.outputBaseFolder");

        classNames = new ArrayList<>();
        httpserver = new HttpServerService(Jengine.getConfiguration().getString("script.host"), Jengine.getConfiguration().getInt("script.port"));
    }

    @Override
    public String getId() {
        return "ScriptService";
    }

    @Override
    public boolean init() {
        try {
            this.load();
            this.httpserver.registerBeforeCallHandler(httpExchange -> {
                logger.info("gm request path {}, content: {}", httpExchange.uri(), httpExchange.getJSONRequest().toString());
            });

            this.httpserver.registerErrorHandler(httpExchange -> {
                Script.responseFailed(httpExchange, "Server internal error.");
            });

            this.httpserver.registerNotFoundHandler(httpExchange -> {
                Script.responseFailed(httpExchange, "Path not found.");
            });
        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }
        return true;
    }

    @Override
    public boolean startup() throws Exception {
        this.start();
        return true;
    }

    @Override
    public boolean shutdown() throws Exception {
        return true;
    }

    private void start() {
        this.httpserver.start();
    }

    private boolean load() throws IOException, IllegalAccessException, InstantiationException, ClassNotFoundException {
        this.compile();
        this.loadClasses(classOutputPath);
        return true;
    }

    public boolean reload() throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException {
        this.httpserver.clearContext();
        return this.load();
    }

    private boolean compile() throws IOException {
        classNames.clear();

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        try (StandardJavaFileManager fileManager =
                     compiler.getStandardFileManager(null, null, null)) {

            File folder = new File(sourceInputPath);
            File[] listOfFiles = folder.listFiles();
            List<File> sources = Stream.of(listOfFiles)
                    .filter(file -> file.getName().endsWith(SOURCE_FILE_SUFFIX))
                    .collect(Collectors.toList());

            for (File sourceCode : sources) {
                String name = sourceCode.getName();
                classNames.add(name.substring(0, name.length() - 5));
            }

            List<File> classes = Stream.of(Paths.get(classOutputPath))
                    .map(p -> p.toFile())
                    .collect(Collectors.toList());

            Iterable<? extends JavaFileObject> compilationUnits =
                    fileManager.getJavaFileObjectsFromFiles(sources);
            fileManager.setLocation(StandardLocation.CLASS_OUTPUT, classes);

            JavaCompiler.CompilationTask task =
                    compiler.getTask(null, fileManager, null, null, null, compilationUnits);

            boolean passed = task.call();
            return passed;
        }
    }

    private void loadClasses(String classesFolder) throws ClassNotFoundException, MalformedURLException, IllegalAccessException, InstantiationException {
        classesFolder = classesFolder.replaceFirst("^//", "");
        for (String className : classNames) {

            String classUrl;
            String clazz = packageName + "." + className;
            if (OsUtil.getLowercaseSystemName().contains(WINDOWS_SYSTEM)) {
                classUrl = WINDOWS_FILE_PROTOCOL_PREFIX + classesFolder;
            } else {
                classUrl = UNIX_FILE_PROTOCOL_PREFIX + classesFolder;
            }

            Log.getJengineLogger().info("classesFolder:{}", classesFolder);
            Log.getJengineLogger().info("classUrl:{}", classUrl);
            URLClassLoader urlClassLoader = new URLClassLoader(new URL[]{new URL(classUrl + "/")});
            Class<?> classObject = urlClassLoader.loadClass(clazz);

            Object instance = classObject.newInstance();
            if (instance instanceof Script) {
                Script script = (Script) instance;
                this.registerScript(script);
            }
        }
    }

    private void registerScript(Script script) {
        Log.getJengineLogger().info("register script: uri: {}, name: {}", script.getUri(), script.getClass().getSimpleName());
        httpserver.createContext(script.getUri(), script);
    }
}
