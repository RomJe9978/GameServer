package com.jengine.cache;

import com.jengine.JengineException;
import com.jengine.configuration.PriorityConfiguration;
import com.jengine.service.Service;
import org.apache.commons.configuration2.YAMLConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.*;

import java.io.FileInputStream;
import java.util.HashSet;
import java.util.Set;

/**
 * RedisClient is a implementation of cache component.
 *
 * @author mengyan
 */
public class RedisClientService implements Service {
    private static final Logger logger = LoggerFactory.getLogger(RedisClientService.class);
    private static final String REDIS_CLUSTER_HOSTS_SEPARATOR = ",";
    private static final String REDIS_CLUSTER_HOST_PORT_SEPARATOR = ":";

    private static final String REDIS_BASE_CONFIG = "redis-base.yaml";
    private static final String REDIS_CONFIG = "redis.yaml";
    private static final RedisClientService instance = new RedisClientService();

    private JedisPool pool;
    private JedisCluster cluster;

    /**
     * Initialize the redis pool.
     * must be called before use.
     */
    private boolean initialize() {
        logger.info("redis pool initialize....");

        try {
            YAMLConfiguration configBase = new YAMLConfiguration();
            configBase.read(new FileInputStream(REDIS_BASE_CONFIG));

            YAMLConfiguration config = new YAMLConfiguration();
            config.read(new FileInputStream(REDIS_CONFIG));

            PriorityConfiguration priorityConfiguration = new PriorityConfiguration(config, configBase);
            RedisConfig redisConfig = new RedisConfig(priorityConfiguration);

            boolean useCluster = priorityConfiguration.getBoolean("cluster.useCluster");
            if (useCluster) {
                this.initCluster(priorityConfiguration);
            } else {
                this.pool = new JedisPool(redisConfig.getJedisPoolConfig(), redisConfig.getHost(), redisConfig.getPort(), redisConfig.getTimeout(), redisConfig.getPassword());
            }

            return true;
        } catch (Exception e) {
            JengineException.catchEx(e);
            return false;
        }
    }

    private void initCluster(PriorityConfiguration priorityConfiguration) {
        Set<HostAndPort> jedisClusterNodes = new HashSet<>();

        String hosts = priorityConfiguration.getString("cluster.hosts");
        String[] hostsAndPorts = hosts.split(REDIS_CLUSTER_HOSTS_SEPARATOR);
        for (String hostAndPort : hostsAndPorts) {
            String[] temp = hostAndPort.split(REDIS_CLUSTER_HOST_PORT_SEPARATOR);
            if (temp != null && temp.length >= 2) {
                jedisClusterNodes.add(new HostAndPort(temp[0], Integer.parseInt(temp[1])));
            }
        }

        JedisPoolConfig config = createConfig(priorityConfiguration);
        int timeout = priorityConfiguration.getInt("timeout");
        String password = priorityConfiguration.getString("password");
        this.cluster = new JedisCluster(jedisClusterNodes, timeout, timeout, 2, password, config);
    }

    private void destroy() {
        logger.info("redis pool destroy....");
        try {
            if (this.pool != null) {
                this.pool.destroy();
            }

            if (this.cluster != null) {
                this.cluster.close();
            }

        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

    /**
     * a getter method for Jedis client.
     *
     * @return Jedis client.
     */
    public Jedis getClient() {
        Jedis jedis = this.pool.getResource();
        return jedis;
    }

    public JedisCluster getCluster() {
        return this.cluster;
    }

    public boolean isClusterMode() {
        return this.pool == null && this.cluster != null;
    }

    @Override
    public String getId() {
        return "RedisClientService";
    }

    @Override
    public boolean init() {
        return this.initialize();
    }

    @Override
    public boolean startup() throws Exception {
        return true;
    }

    @Override
    public boolean shutdown() throws Exception {
        this.destroy();
        return true;
    }

    private static JedisPoolConfig createConfig(PriorityConfiguration configuration) {
        int maxTotal = configuration.getInt("maxTotal");
        int maxIdle = configuration.getInt("maxIdle");
        int minIdle = configuration.getInt("minIdle");
        int maxWaitMillis = configuration.getInt("maxWaitMillis");
        boolean testOnBorrow = configuration.getBoolean("testOnBorrow");
        boolean testOnReturn = configuration.getBoolean("testOnReturn");
        int timeBetweenEvictionRunsMillis = configuration.getInt("timeBetweenEvictionRunsMillis");
        boolean testWhileIdle = configuration.getBoolean("testWhileIdle");
        int numTestsPerEvictionRun = configuration.getInt("numTestsPerEvictionRun");

        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(maxTotal);
        config.setMaxIdle(maxIdle);
        config.setMinIdle(minIdle);
        config.setMaxWaitMillis(maxWaitMillis);
        config.setTestOnBorrow(testOnBorrow);
        config.setTestOnReturn(testOnReturn);
        config.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        config.setTestWhileIdle(testWhileIdle);
        config.setNumTestsPerEvictionRun(numTestsPerEvictionRun);
        return config;

    }

    private class RedisConfig {
        private JedisPoolConfig jc;

        private String host;
        private int port;
        private String password;
        private int timeout;

        public RedisConfig(PriorityConfiguration configuration) {
            this.jc = RedisClientService.createConfig(configuration);

            this.host = configuration.getString("standalone.host");
            this.port = configuration.getInt("standalone.port");
            this.password = configuration.getString("password");
            this.timeout = configuration.getInt("timeout");
        }

        public JedisPoolConfig getJedisPoolConfig() {
            return jc;
        }

        public String getHost() {
            return host;
        }

        public int getPort() {
            return port;
        }

        public String getPassword() {
            return password;
        }

        public int getTimeout() {
            return timeout;
        }
    }
}
