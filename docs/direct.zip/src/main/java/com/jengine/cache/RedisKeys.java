package com.jengine.cache;

import com.jengine.util.URLUtil;


/**
 * RedisKeys defines the keys and provides management api for keys.
 *
 * @author mengyan
 */
public class RedisKeys {
    public static String KEY_PREFIX = "default";

    /**
     * <p>Joins the elements of the provided array into a single String
     * containing the provided list of elements.</p>
     *
     * <p>No delimiter is added before or after the list.
     * A {@code null} separator is the same as an empty String ("").
     * Null objects or empty strings within the array are represented by
     * empty strings.</p>
     *
     * @param params
     * @return
     */
    public static String generateKey(String... params) {
        return URLUtil.concat(":", KEY_PREFIX, params);
    }

}
