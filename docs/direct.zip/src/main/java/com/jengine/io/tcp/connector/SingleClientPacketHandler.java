package com.jengine.io.tcp.connector;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpClientSession;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.io.tcp.TcpSessionBuilder;
import com.jengine.task.TaskExecutor;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SingleClientPacketHandler represents a single connection packet handler.
 *
 * @author mengyan
 */
@ChannelHandler.Sharable
public class SingleClientPacketHandler extends ChannelInboundHandlerAdapter {
    private static final Logger log = LoggerFactory.getLogger(SingleClientPacketHandler.class);
    private Channel channel;
    private SingleConnector singleConnector;

    public SingleClientPacketHandler(SingleConnector singleConnector) {
        this.singleConnector = singleConnector;
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof TcpPacket) {
            TcpPacket packet = (TcpPacket) msg;
            TaskExecutor.getInstance().dispatchPacket(ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get(), packet);
        }
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        ClientSession clientSession = ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get();
        if (clientSession != null && clientSession.isActive()) {
            log.error("[SingleClientPacketHandler] duplicate connection.");
            ctx.close();
            return;
        }

        log.info("[SingleClientPacketHandler] new session created.");
        clientSession = TcpSessionBuilder.getInstance().build(null, ctx.channel());
        clientSession.setChannel(ctx.channel());
        this.singleConnector.onConnected(clientSession);
    }

    @Override
    public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
        ClientSession clientSession = ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get();
        if (clientSession == null) {
            ctx.fireChannelUnregistered();
            return;
        }

        disconnect(ctx.channel());
        ctx.fireChannelUnregistered();
        this.singleConnector.onDisconnected();
        log.info("Single client connection closed.");
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.debug("channel exceptionCaught", cause);
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    private void disconnect(Channel channel) {
        TcpClientSession session = channel.attr(TcpSessionBuilder.CHANNEL_SESSION).get();
        if (session == null) {
            log.error("tcp session null channelId is:" + channel.id().asLongText());
            return;
        }

        channel.attr(TcpSessionBuilder.CHANNEL_SESSION).set(null);
        session.close(false);
    }
}
