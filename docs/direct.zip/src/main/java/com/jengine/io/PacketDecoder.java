package com.jengine.io;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.CodecException;

/**
 * Abstract defines of packet parser.
 *
 * @author mengyan
 */
public interface PacketDecoder {
	Packet praseMessage(ByteBuf byteBuf) throws CodecException;
}
