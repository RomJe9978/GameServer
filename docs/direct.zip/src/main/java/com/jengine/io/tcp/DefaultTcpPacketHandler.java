package com.jengine.io.tcp;

import com.jengine.Jengine;
import com.jengine.event.Event;
import com.jengine.event.EventType;
import com.jengine.io.ClientSession;
import com.jengine.logger.Log;
import com.jengine.task.TaskExecutor;
import com.jengine.util.TimeUtil;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;

/**
 * Default implementation of tcp packet handler.
 *
 * @author mengyan
 */
public class DefaultTcpPacketHandler extends AbstractTcpPacketHandler {
    private static final Logger log = Log.getNetworkLogger();

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        log.debug("channelRead: {}", msg);
        if (msg instanceof TcpPacket) {
            TcpPacket packet = (TcpPacket) msg;
            if (!packet.isValidCRC()) {
                log.error("invalid crc, given:{}, calculated:{}", packet.getCrc(), packet.calculateCRC());
                return;
            }
            Jengine.getPacketDispatcher().dispatchPacket(ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get(), packet);
        }
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        log.debug("channelReadComplete: {}", ctx);
        super.channelReadComplete(ctx);
    }

    @Override
    public void onSessionOpened(ClientSession clientSession) {
        // @TODO
    }

    @Override
    public void onSessionClosed(ClientSession clientSession) {
        if (clientSession.getGameObject() != null && clientSession.getGameObject().getOId() != null && clientSession.getGameObject().getOId().getType() != 0) {
            TaskExecutor.getInstance().fireEvent(Event.valueOf(EventType.SESSION_CLOSE, clientSession.getGameObject().getOId()).addParams(TimeUtil.getTimeInMillis()));
        }
    }
}
