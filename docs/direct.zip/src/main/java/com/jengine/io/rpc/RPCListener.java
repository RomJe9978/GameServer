package com.jengine.io.rpc;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.object.ObjectId;
import com.jengine.task.AbstractTask;
import com.jengine.task.TaskExecutor;
import com.jengine.util.TimeUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RPC通信机制的总监听器
 * <p>每一个请求会有一个标识，此处监听对此标识的回复
 *
 * @author RomJe
 */
public class RPCListener {
    /**
     * 监听的RPC列表
     * key:业务层请求id(注意不是逻辑id)，value：本次rpc通信的参数
     * <p>由于每一次RPC通讯的“请求id”都唯一，所以这里的同步竞争非常小
     * <p>该集合内的监听全部是单次监听，一旦触发，会直接移除掉
     */
    private final Map<Long, RPCParameter> rpcListenMap;

    public RPCListener() {
        this.rpcListenMap = new ConcurrentHashMap<>();
    }

    /**
     * RPC通讯注册“请求”的监听
     *
     * @param requestId 回复包根据requestId，关联具体的监听参数
     * @param parameter 监听参数，包含所有RPC通讯的信息
     */
    public void listen(long requestId, RPCParameter parameter) {
        RPCParameter oldValue = this.rpcListenMap.put(requestId, parameter);
        if (Objects.nonNull(oldValue)) {
            JengineException.catchEx(new JengineException("Rpc request listener exist,please check!"));
        }
    }

    /**
     * 解除监听，返回监听的数据
     * 内部就是一个移除操作，不要在常规遍历中直接调用
     */
    public RPCParameter cancelListen(long requestId) {
        return this.rpcListenMap.remove(requestId);
    }

    /**
     * 触发监听，该接口内会直接移除监听
     */
    public void trigger(long requestId, ClientSession session, TcpPacket packet) {
        if (Objects.isNull(session) || Objects.isNull(packet)) {
            return;
        }

        // 先移除，再进行回调
        RPCParameter rpcParameter = this.cancelListen(requestId);
        if (Objects.nonNull(rpcParameter)) {
            IRPCCallBack callBack = rpcParameter.getCallBack();
            if (Objects.nonNull(callBack)) {
                callBack.onResponse(requestId, session, packet);
            }
        }
    }

    /**
     * 超时机制
     */
    public void timeOut() {
        if (this.rpcListenMap.isEmpty()) {
            return;
        }

        // 轮训超时
        long curTime = TimeUtil.getTimeInMillis();
        List<RPCParameter> outParamList = new ArrayList<>();
        this.rpcListenMap.forEach((requestId, parameter) -> {
            if (curTime >= parameter.getTimeOutMillis()) {
                outParamList.add(parameter);
            }
        });

        // 取消监听，处理超时回调
        outParamList.forEach(parameter -> {
            this.rpcListenMap.remove(parameter.getRequestId());
            try {
                // 不能在自己线程处理，得分发给发送请求的线程
                TaskExecutor.getInstance().postLogicTask(new AbstractTask(true) {
                    @Override
                    public ObjectId getDispatchId() {
                        return ObjectId.valueOfId(parameter.getObjectId());
                    }

                    @Override
                    public void run() {
                        IRPCCallBack callBack = parameter.getCallBack();
                        if (Objects.nonNull(callBack)) {
                            callBack.onTimeOut(parameter);
                        }
                    }

                    @Override
                    public int getType() {
                        return 0;
                    }
                });
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        });
    }
}
