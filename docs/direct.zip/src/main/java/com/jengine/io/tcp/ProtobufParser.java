package com.jengine.io.tcp;

import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.Parser;
import com.google.protobuf.util.JsonFormat;
import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Parses the protobuf v3 packet.
 *
 * @author mengyan
 */
public class ProtobufParser {
    private static final Logger log = Log.getNetworkLogger();

    private static final String PARSER_IN_PROTOBUF = "PARSER";
    private static ProtobufParser instance = new ProtobufParser();

    public static ProtobufParser getInstance() {
        return instance;
    }

    private Map<String, Parser<?>> cachedParsers;

    private ProtobufParser() {
        this.cachedParsers = new ConcurrentHashMap<>();
    }

    public <T extends GeneratedMessageV3> T parsePacket(TcpPacket packet, T template) {
        if (packet != null && template != null) {
            try {
                T pbProtocol = template;
                Parser<T> parser = (Parser<T>) this.cachedParsers.get(template.getClass().getName());
                if (parser == null) {

                    // set 'private static final' filed to be accessible.
                    Field parserField = template.getClass().getDeclaredField(PARSER_IN_PROTOBUF);
                    parserField.setAccessible(true);

                    parser = (Parser<T>) parserField.get(template);
                    this.cachedParsers.put(template.getClass().getName(), parser);
                }

                if (packet.getSize() > 0) {
                    pbProtocol = parser.parseFrom(packet.getData(), 0, packet.getData().length);
                }

                printProtocolInfo(packet, pbProtocol);
                return pbProtocol;
            } catch (Exception e) {
                JengineException.catchEx(e);
                throw new RuntimeException("[ProtobufParser] parsePacket failed, opcode is: " + packet.getOpcode());
            }
        }

        return null;
    }

    private void printProtocolInfo(TcpPacket packet, GeneratedMessageV3 builder) {
        try {
            if (Jengine.getConfiguration().containsKey("network.printlog") && Jengine.getConfiguration().getBoolean("network.printlog")) {
                long objectId = 0;
                if (packet.getSession() != null && packet.getSession().getGameObject() != null) {
                    objectId = packet.getSession().getGameObject().getOId().getId();
                }

                String pbContent = JsonFormat.printer().print(builder);
                if (builder != null) {
                    log.info("[ProtobufParser] receive packet, playerId: {}, protocol: {}, protocolName: {}, size: {}, crc: {}, protobuf: \n{}",
                            objectId, packet.getOpcode(), builder.getClass().getSimpleName(), packet.getSize(), packet.getCrc(), pbContent);
                } else {
                    log.info("[ProtobufParser] receive packet, playerId: {}, protocol: {}, size: {}, crc: {}",
                            objectId, packet.getOpcode(), packet.getSize(), packet.getCrc());
                }
            }

        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }

}
