package com.jengine.io.http;

import com.jengine.io.Packet;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.FullHttpRequest;

/**
 * A http packet wrapper.
 *
 * @author mengyan
 */
public class HttpPacket extends Packet {


	private FullHttpRequest request;
	private ChannelHandlerContext ctx;

	public HttpPacket(ChannelHandlerContext ctx, FullHttpRequest request) {
		this.ctx = ctx;
		this.request = request;
	}

	public void getUrlParameters() {

	}

	public FullHttpRequest getRequest() {
		return request;
	}

	public ChannelHandlerContext getCtx() {
		return ctx;
	}
}
