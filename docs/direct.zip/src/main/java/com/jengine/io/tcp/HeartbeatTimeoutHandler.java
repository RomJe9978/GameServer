package com.jengine.io.tcp;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;

/**
 * HeartbeatTimeoutHandler designs for checking whether connection is alive by heartbeat to avoid abandoned connection.
 *
 * @author mengyan
 */
public class HeartbeatTimeoutHandler extends SimpleChannelInboundHandler<String> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {

    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        IdleStateEvent event = (IdleStateEvent) evt;

        switch (event.state()) {
            case READER_IDLE:
                ctx.channel().close(); // 手动断开连接
                break;
            default:
                // Ignore it.
        }
    }
}
