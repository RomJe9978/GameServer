package com.jengine.io.rpc;

import com.jengine.io.Connector;

/**
 * RPC底层机制的参数封装
 * <p>具体参数与方法解耦，增强底层方法的可维护性，可扩展性
 * <p>外部采用“链式设值”方式，增强用户使用的灵活性
 *
 * @author RomJe
 */
public class RPCParameter {
    /**
     * 本次通信的“请求id”
     */
    private long requestId;

    /**
     * RPC通信基于的网络实例
     * <p>业务层需要指定
     */
    private Connector connector;

    /**
     * 本次通信设置的超时时间戳：毫秒
     * <p>业务层需要指定，到该绝对时间戳之后算作”超时“
     */
    private long timeOutMillis;

    /**
     * 最终消息配发的object id
     * <p>业务层需要制定
     */
    private long objectId;

    /**
     * 相当于“消息id”
     * <p>业务层需要指定
     */
    private int opcode;

    /**
     * 序列化的数据流
     * <p>业务层需要指定
     */
    private byte[] data;

    /**
     * 本次RPC通信的回调
     * <p>业务层需要指定
     */
    private IRPCCallBack callBack;

    /**
     * 本次RPC通信的路由目标类型
     * <p>业务层根据需要指定 参考{@link com.jengine.io.tcp.TcpPacketHeaderEx}
     */
    private int routerType;

    /**
     * 本次RPC通信的路由目标id
     * <p>业务层根据需要指定 参考{@link com.jengine.io.tcp.TcpPacketHeaderEx}
     */
    private long routerId;

    /**
     * 本次RPC通信的路由源类型，用于rpc回包时消息回传
     */
    private int encodedsourceRouter;

    public RPCParameter() {
    }

    public long getRequestId() {
        return requestId;
    }

    public RPCParameter setRequestId(long requestId) {
        this.requestId = requestId;
        return this;
    }

    public RPCParameter setConnector(Connector connector) {
        this.connector = connector;
        return this;
    }

    public Connector getConnector() {
        return connector;
    }

    public long getTimeOutMillis() {
        return timeOutMillis;
    }

    public RPCParameter setTimeOutMillis(long timeOutMillis) {
        this.timeOutMillis = timeOutMillis;
        return this;
    }

    public long getObjectId() {
        return objectId;
    }

    public RPCParameter setObjectId(long objectId) {
        this.objectId = objectId;
        return this;
    }

    public IRPCCallBack getCallBack() {
        return callBack;
    }

    public RPCParameter setCallBack(IRPCCallBack callBack) {
        this.callBack = callBack;
        return this;
    }

    public int getOpcode() {
        return opcode;
    }

    public RPCParameter setOpcode(int opcode) {
        this.opcode = opcode;
        return this;
    }

    public byte[] getData() {
        return data;
    }

    public RPCParameter setData(byte[] data) {
        this.data = data;
        return this;
    }

    public int getRouterType() {
        return routerType;
    }

    public void setRouterType(int routerType) {
        this.routerType = routerType;
    }

    public long getRouterId() {
        return routerId;
    }

    public void setRouterId(long routerId) {
        this.routerId = routerId;
    }

    public int getEncodedsourceRouter() {
        return encodedsourceRouter;
    }

    public void setEncodedsourceRouter(int encodedsourceRouter) {
        this.encodedsourceRouter = encodedsourceRouter;
    }
}
