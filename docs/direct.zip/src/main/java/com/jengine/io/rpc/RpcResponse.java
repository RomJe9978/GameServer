package com.jengine.io.rpc;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpPacket;

/**
 * RpcResponse：单次Rpc请求回包
 */
public class RpcResponse {
    /**
     * 本次RPC通信请求的唯一“id”
     */
    private long requestId;
    /**
     * 本次RPC通信的session信息
     */
    private ClientSession session;
    /**
     * 本次RPC通信的回复包
     */
    private TcpPacket response;

    public RpcResponse(long requestId, ClientSession session, TcpPacket response) {
        this.requestId = requestId;
        this.session = session;
        this.response = response;
    }

    public long getRequestId() {
        return requestId;
    }

    public ClientSession getSession() {
        return session;
    }

    public TcpPacket getResponse() {
        return response;
    }
}
