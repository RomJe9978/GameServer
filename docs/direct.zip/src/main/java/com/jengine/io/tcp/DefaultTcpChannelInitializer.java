package com.jengine.io.tcp;

import com.jengine.Jengine;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.timeout.IdleStateHandler;

/**
 * The default implementation of channel initializer.
 *
 * @author mengyan
 */
public class DefaultTcpChannelInitializer extends ChannelInitializer<NioSocketChannel> {
    @Override
    protected void initChannel(NioSocketChannel ch) throws Exception {
        ChannelPipeline channelPipLine = ch.pipeline();
        channelPipLine.addLast("frame", new LengthFieldBasedFrameDecoder(Integer.MAX_VALUE, 4, 4, 0, 0));
        channelPipLine.addLast("encoder", new TcpProtobufEncoder());
        channelPipLine.addLast("decoder", new TcpProtobufDecoder());

        // Heartbeat timeout checker
        int readerIdleTimeSeconds = Jengine.getConfiguration().getInt("network.idle.readerIdleTimeSeconds");
        int writerIdleTimeSeconds = Jengine.getConfiguration().getInt("network.idle.writerIdleTimeSeconds");
        int allIdleTimeSeconds = Jengine.getConfiguration().getInt("network.idle.allIdleTimeSeconds");
        if (readerIdleTimeSeconds > 0) {
            channelPipLine.addLast("idleStateHandler", new IdleStateHandler(readerIdleTimeSeconds, writerIdleTimeSeconds, allIdleTimeSeconds));
        }

        // packet handler
        channelPipLine.addLast("handler", new DefaultTcpPacketHandler());
    }
}
