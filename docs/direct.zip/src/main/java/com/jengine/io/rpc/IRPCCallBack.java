package com.jengine.io.rpc;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpPacket;

/**
 * 一次RPC通信的回调（请求方收到回复之后）
 *
 * @author RomJe
 */
public interface IRPCCallBack {
    /**
     * 成功收到回复信息之后的处理
     *
     * @param requestId 本次回复所关联的“请求Id”
     * @param session   rpc网络连接
     * @param response  收到的具体回复包实例
     */
    void onResponse(long requestId, ClientSession session, TcpPacket response);

    /**
     * 超时之后的处理
     *
     * @param parameter 超时的RPC信息
     */
    void onTimeOut(RPCParameter parameter);

    /**
     * 收到错误回复信息之后的处理
     */
    void onError(ClientSession session, TcpPacket response);
}