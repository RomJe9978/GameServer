package com.jengine.io.tcp;

/**
 * Packet header.
 * feat: add support for object id to dispatch msg to special thread.
 * feat: add support for logic id to implement rpc.
 * feat: add support for route type and route id to implement route.
 * feat: add support for rpc source to implement rpc unvarnished transmission.
 * 4bytes    4bytes    4bytes     4bytes     8bytes       8bytes       4bytes     8bytes       4bytes    dynamic
 * +--------+--------+---------+---------+---------+----------------+------------+----------+------------+----------------+
 * | opcode | size   | version |   crc   |   oid   |   rpcLogicId   | route type | route id | rpc source | Actual Body    |
 * +--------+--------+---------+---------+---------+----------------+------------+----------+------------+----------------+
 * |0xCA0xCA|0x0C0x0C|0xFE0xFE | 0x0C0x0C| 3000001 |    0x0C0x0C    |     1      |   122    |  0x0C0x0C  | "body content" |
 * +--------+--------+---------+---------+---------+----------------+------------+----------+------------+----------------+
 *
 * @author mengyan
 */
public class TcpPacketHeaderEx extends TcpPacketHeader {
    /**
     * object id length in bytes
     */
    public static final int OID_LENGTH_IN_BYTES = 8;
    /**
     * logic id length in bytes
     */
    public static final int RID_LENGTH_IN_BYTES = 8;

    /**
     * route type length in bytes
     */
    public static final int ROUTE_TYPE_LENGTH_IN_BYTES = 4;

    /**
     * route id length in bytes
     */
    public static final int ROUTE_ID_LENGTH_IN_BYTES = 8;

    /**
     * rpc source length in bytes
     */
    public static final int RPC_SOURCE_LENGTH_IN_BYTES = 4;

    /**
     * object id
     * 用于实现消息分发到指定线程，比如玩家消息分发到玩家线程
     * 上层业务可以选择使用或者不使用
     */
    private long oid;

    /**
     * RPC进程通信机制中的“逻辑ID”
     * <p>对于任意一个服务器单体，只要使用了RPC的机制，单次通信就会有一个逻辑id，同一个消息
     * 的多次通信是多个相互独立的逻辑id
     * <p>该值唯一与RPC机制强制绑定，如果使用RPC机制，则一次通信的请求和回复会可以被该id关联
     * 起来。不使用RPC默认为{@code 0}
     * <p>构成：前三位为“标识位”，强制约定为{@see RPC_MARK}RPC标识，底层机制上排除无效值对
     * 逻辑的影响。第四位为“类型”，表明该RPC通信包是”请求包“还是”回复包“。第五位之后的数据是
     * 一个“请求ID”，关联请求和回复。例，101(3位标识) A(1位类型) xxx...xxx(60位请求ID)
     * <p>该值对业务层完全不可见，业务层不需要关心
     */
    private long rpcLogicId;

    /**
     * 路由类型: 一种是基于服务器ID的路由，一种是基于路由表的路由策略
     * routerType取值为1-100的路由类型为基于服务器ID的路由，routerType同时代表服务器类型，具体参考{@link com.clustercommon.cluster.ServerType}
     * routerType取值为大于100为位基于路由表的路由策略
     */
    private int routerType;

    /**
     * 路由参数，取值含义取决于routerType。
     * routerType取值为1-100的路由类型routerId代表服务器ID
     * routerType取值为大于100的路由类型routerId代表路由表中的路由ID
     */
    private long routerId;

    /**
     * rpc请求的源服务器类型及服务器ID
     * 用于回包路由，如果rpc请求的源服务器类型及服务器ID不为0，则回包时会根据该值进行路由
     */
    private int encodedRpcSource;

    TcpPacketHeaderEx() {
    }

    TcpPacketHeaderEx(int opcode, long oid) {
        this.opcode = opcode;
        this.oid = oid;
    }

    TcpPacketHeaderEx(int opcode, long oid, long rpcLogicId) {
        this.opcode = opcode;
        this.oid = oid;
        this.rpcLogicId = rpcLogicId;
    }

    TcpPacketHeaderEx(int opcode, long oid, long rpcLogicId, int routerType, long routerId) {
        this(opcode, oid, rpcLogicId);
        this.routerType = routerType;
        this.routerId = routerId;
    }

    TcpPacketHeaderEx(int opcode, long oid, long rpcLogicId, int routerType, long routerId, int encodedRpcSource) {
        this(opcode, oid, rpcLogicId, routerType, routerId);
        this.encodedRpcSource = encodedRpcSource;
    }

    public void clear() {
        super.clear();
        oid = 0;
        this.rpcLogicId = 0;
    }

    @Override
    public String toString() {
        return String.format(
                "TcpPacketHeader [opcode: %d, size: %d, version: %d, crc: %d, oid: %d, rid: %d], routerType: %d, routerId: %d rpcSource: %d",
                this.opcode, this.size, this.version, this.crc, this.oid, this.rpcLogicId, this.routerType, this.routerId, this.encodedRpcSource
        );
    }

    /**
     * 返回object ID
     *
     * @return the oid
     */
    public long getOid() {
        return oid;
    }

    public void setOid(long oid) {
        this.oid = oid;
    }

    /**
     * 返回request ID
     *
     * @return the rid
     */
    public long getRpcLogicId() {
        return rpcLogicId;
    }

    public void setRpcLogicId(long rpcLogicId) {
        this.rpcLogicId = rpcLogicId;
    }

    public int getRouterType() {
        return routerType;
    }

    public void setRouterType(int routerType) {
        this.routerType = routerType;
    }

    public long getRouterId() {
        return routerId;
    }

    public void setRouterId(long routerId) {
        this.routerId = routerId;
    }

    public void setEncodedRpcSource(int encodedRpcSource) {
        this.encodedRpcSource = encodedRpcSource;
    }

    public int getEncodedRpcSource() {
        return encodedRpcSource;
    }
}