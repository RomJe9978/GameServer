package com.jengine.io.rpc;

/**
 * RPC闭包常量
 *
 * @author RomJe
 */
public class RPCConst {
    /**
     * RPC逻辑ID标识(最高三位),二进制为“011”
     */
    public final static long RPC_MARK = 0x3L << 61;

    /**
     * RPC包类型所在的编码位置
     */
    public final static int TYPE_POSITION = 60;

    /**
     * RPC通信，请求标识（单bit）
     */
    public final static byte RPC_REQUEST_TYPE = 1;

    /**
     * RPC通信，回复标识（单bit）
     */
    public final static byte RPC_RESPONSE_TYPE = 0;

    /**
     * RPC源信息
     */
    public final static int RPC_SOURCE_MARK = 0x01 << 30;

    /**
     * 初始请求id
     */
    public final static long INIT_REQUEST_ID = 1;

    /**
     * RPC轮训间隔：毫秒
     */
    public final static long RPC_SELECTOR_INTERVAL_MILLIS = 200;

    /**
     * RPC默认超时时间 ：毫秒
     */
    public final static int RPC_DEFAULT_TIME_OUT_MILLIS = 1000;
}
