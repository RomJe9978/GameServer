package com.jengine.io.tcp.connector;

import com.jengine.io.tcp.TcpProtobufDecoderEx;
import com.jengine.io.tcp.TcpProtobufEncoderEx;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;

/**
 * A tcp client implementation.
 *
 * @author mengyan
 */
public class SingleConnectorEx extends SingleConnector {
    protected SingleClientPacketHandler singleClientHandler = new SingleClientPacketHandler(this);

    public SingleConnectorEx(String host, int port, boolean autoReconnect) {
        super(host, port, autoReconnect);
    }

    /**
     * This constructor support sharing event loop group.
     *
     * @param group
     * @param host
     * @param port
     * @param autoReconnect
     */
    public SingleConnectorEx(EventLoopGroup group, String host, int port, boolean autoReconnect) {
        super(group, host, port, autoReconnect);
    }

    protected void init() {
        if (this.group == null) {
            this.group = new NioEventLoopGroup();
        }

        this.bootstrap = new Bootstrap();
        this.bootstrap.group(this.group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    public void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline channelPipLine = ch.pipeline();
                        channelPipLine.addLast("frame", new LengthFieldBasedFrameDecoder(Integer.MAX_VALUE, 4, 4, 0, 0));
                        channelPipLine.addLast("encoder", new TcpProtobufEncoderEx());
                        channelPipLine.addLast("decoder", new TcpProtobufDecoderEx());
                        channelPipLine.addLast("handler", singleClientHandler);
                    }
                });
    }
}
