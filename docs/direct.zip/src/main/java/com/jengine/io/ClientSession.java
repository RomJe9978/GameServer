package com.jengine.io;

import com.jengine.object.GameObject;
import io.netty.channel.Channel;

/**
 * ClientSession represents a connection with extra player informations.
 *
 * @author mengyan
 */
public interface ClientSession extends Connector {
    /**
     * Return the unique id of session.
     *
     * @return
     */
    String getSessionId();

    void setAttribute(String key, Object value);

    Object getAttribute(String key);

    void bindGameObject(GameObject object);

    GameObject getGameObject();

    void setChannel(Channel channel);
}
