package com.jengine.io;

import io.netty.buffer.ByteBuf;

/**
 * Abstract defines of packet encoder.
 *
 * @author mengyan
 */
public interface PacketEncoder {
	ByteBuf createByteBuf(Packet netMessage) throws Exception;
}
