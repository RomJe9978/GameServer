package com.jengine.io.http;

import com.jengine.Jengine;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.cors.CorsConfig;
import io.netty.handler.codec.http.cors.CorsConfigBuilder;
import io.netty.handler.codec.http.cors.CorsHandler;
import io.netty.handler.ssl.SslContext;

/**
 * default implementation of Http server initializer.
 *
 * @author mengyan
 */
public class DefaultHttpChannelInitializer extends ChannelInitializer<SocketChannel> {
    private final SslContext sslCtx;
    private final HttpServerService httpServerService;

    public DefaultHttpChannelInitializer(HttpServerService httpServerService, SslContext sslCtx) {
        this.httpServerService = httpServerService;
        this.sslCtx = sslCtx;
    }

    @Override
    protected void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline p = ch.pipeline();
        if (sslCtx != null) {
            p.addLast(sslCtx.newHandler(ch.alloc()));
        }

        p.addLast(new HttpServerCodec());
        p.addLast(new HttpObjectAggregator(6553500));
        if (Jengine.getConfiguration().getBoolean("network.cors", false)) {
            CorsConfig corsConfig = CorsConfigBuilder.forAnyOrigin().allowNullOrigin().allowCredentials().build();
            p.addLast(new CorsHandler(corsConfig));
        }

        p.addLast(new DefaultHttpPakcetHandler(this.httpServerService));
    }
}
