package com.jengine.io.tcp;

import com.jengine.io.ClientSession;

/**
 * A TcpClient represents a tcp client.
 *
 * @author mengyan
 */
public interface TcpClient {
	/**
	 * Binds session wth client.
	 *
	 * @param session
	 */
	void setSession(ClientSession session);

	/**
	 * Return the session which binding with client.
	 *
	 * @return
	 */
	ClientSession getSession();
}
