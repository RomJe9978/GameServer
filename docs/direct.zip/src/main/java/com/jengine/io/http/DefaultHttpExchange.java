package com.jengine.io.http;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jengine.JengineException;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.DecoderResult;
import io.netty.handler.codec.http.*;
import io.netty.util.AsciiString;
import io.netty.util.CharsetUtil;

import java.util.Collections;
import java.util.Map;

/**
 * Default implementation of HttpExchange.
 *
 * @author mengyan
 */
public class DefaultHttpExchange implements HttpExchange {
    private static final AsciiString CONTENT_TYPE = new AsciiString("Content-Type");
    private static final AsciiString CONTENT_LENGTH = new AsciiString("Content-Length");
    private static final AsciiString CONNECTION = new AsciiString("Connection");
    private static final AsciiString KEEP_ALIVE = new AsciiString("keep-alive");

    private FullHttpRequest request;
    private ChannelHandlerContext ctx;
    private HttpPacket packet;
    private HttpHandler httpHandler;
    private HttpPacketParser httpPacketParser;

    public DefaultHttpExchange(ChannelHandlerContext ctx, FullHttpRequest request) {
        this.ctx = ctx;
        this.request = request;

        this.packet = new HttpPacket(this.ctx, this.request);
        this.httpPacketParser = new HttpPacketParser(request);
    }

    @Override
    public void response(JsonObject res) {
        if (res != null && this.ctx != null) {
            this.responseJsonContent(this.ctx, this.request, res.toString());
        }
    }

    @Override
    public HttpHandler getHandler() {
        return this.httpHandler;
    }

    @Override
    public void setHandler(HttpHandler handler) {
        this.httpHandler = handler;
    }

    @Override
    public HttpPacket getRequest() {
        return this.packet;
    }

    @Override
    public String getRequestContent() {
        return parseRequest(this.request);
    }

    @Override
    public Map<String, String> getParameters() {
        Map<String, String> result;
        try {
            result = this.httpPacketParser.parse();
        } catch (Exception e) {
            JengineException.catchEx(e);
            return Collections.emptyMap();
        }

        return result;
    }

    @Override
    public JsonObject getJSONRequest() {
        JsonObject jsonObject = JsonParser.parseString(this.getRequestContent()).getAsJsonObject();
        return jsonObject;
    }

    private String parseRequest(FullHttpRequest request) {
        ByteBuf jsonBuf = request.content();
        String jsonStr = jsonBuf.toString(CharsetUtil.UTF_8);
        return jsonStr;
    }

    private void responseJsonContent(ChannelHandlerContext ctx, FullHttpRequest req, String jsonStr) {
        boolean keepAlive = HttpUtil.isKeepAlive(req);
        byte[] jsonByteByte = jsonStr.getBytes();
        FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK, Unpooled.wrappedBuffer(jsonByteByte));
        response.headers().set(CONTENT_TYPE, "application/json");
        response.headers().setInt(CONTENT_LENGTH, response.content().readableBytes());
        if (!keepAlive) {
            ctx.write(response).addListener(ChannelFutureListener.CLOSE);
        } else {
            response.headers().set(CONNECTION, KEEP_ALIVE);
            ctx.write(response);
        }
    }

    @Override
    public HttpMethod getMethod() {
        return this.request.getMethod();
    }

    @Override
    public HttpMethod method() {
        return this.request.method();
    }

    @Override
    public HttpRequest setMethod(HttpMethod method) {
        return this.request.setMethod(method);
    }

    @Override
    public String getUri() {
        return this.request.getUri();
    }

    @Override
    public String uri() {
        return this.request.uri();
    }

    @Override
    public HttpRequest setUri(String uri) {
        return this.request.setUri(uri);
    }

    @Override
    public HttpVersion getProtocolVersion() {
        return this.request.getProtocolVersion();
    }

    @Override
    public HttpVersion protocolVersion() {
        return this.request.protocolVersion();
    }

    @Override
    public HttpRequest setProtocolVersion(HttpVersion version) {
        return this.request.setProtocolVersion(version);
    }

    @Override
    public HttpHeaders headers() {
        return this.request.headers();
    }

    @Override
    public DecoderResult getDecoderResult() {
        return this.request.getDecoderResult();
    }

    @Override
    public void setDecoderResult(DecoderResult result) {
        this.request.setDecoderResult(result);
    }

    @Override
    public DecoderResult decoderResult() {
        return this.request.decoderResult();
    }
}
