package com.jengine.io.tcp;

import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.util.JsonFormat;
import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.Packet;
import com.jengine.logger.Log;
import com.jengine.object.ObjectId;
import com.jengine.util.HashUtil;
import org.slf4j.Logger;

public class TcpPacket extends Packet {
    private static final Logger log = Log.getNetworkLogger();

    private TcpPacketHeader header;
    private byte[] data;
    private ClientSession session;
    // To avoid repeated parsing.
    private Object parsedPacket = null;

    public static TcpPacket valueOf(int opcode) {
        TcpPacket packet = new TcpPacket();
        packet.setHeader(new TcpPacketHeader(opcode));
        return packet;
    }

    public static TcpPacket valueOf(int opcode, long oid) {
        TcpPacket packet = new TcpPacket();
        packet.setHeader(new TcpPacketHeaderEx(opcode, oid));
        return packet;
    }

    public static TcpPacket valueOf(int opcode, byte[] bytes) {
        TcpPacket packet = valueOf(opcode);
        try {
            packet.setData(bytes);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }
        return packet;
    }

    public static TcpPacket valueOf(int opcode, GeneratedMessageV3.Builder<?> builder) {
        TcpPacket packet = valueOf(opcode);
        try {
            byte[] data = builder.build().toByteArray();
            packet.setData(data);

        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }

        printProtocolInfo(opcode, 0, 0, builder);

        return packet;
    }

    public static TcpPacket valueOf(int opcode, long oid, GeneratedMessageV3.Builder<?> builder) {
        TcpPacket packet = valueOf(opcode, oid);
        try {
            byte[] data = builder.build().toByteArray();
            packet.setData(data);

        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }

        printProtocolInfo(opcode, oid, 0, builder);

        return packet;
    }

    public static TcpPacket valueOf(long rpcLogicId, long oid, int opcode, byte[] data) {
        TcpPacket packet = new TcpPacket();
        packet.setHeader(new TcpPacketHeaderEx(opcode, oid, rpcLogicId));
        try {
            packet.setData(data);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }
        return packet;
    }

    public static TcpPacket valueOf(long rpcLogicId, long oid, int opcode, byte[] data, int routerType, long routerId) {
        TcpPacket packet = new TcpPacket();
        packet.setHeader(new TcpPacketHeaderEx(opcode, oid, rpcLogicId, routerType, routerId));
        try {
            packet.setData(data);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }
        return packet;
    }

    public static TcpPacket valueOf(long rpcLogicId, long oid, int opcode, byte[] data, int routerType, long routerId, int encodedRpcSource) {
        TcpPacket packet = new TcpPacket();
        packet.setHeader(new TcpPacketHeaderEx(opcode, oid, rpcLogicId, routerType, routerId, encodedRpcSource));
        try {
            packet.setData(data);
        } catch (Exception e) {
            JengineException.catchEx(e);
            return null;
        }
        return packet;
    }

    /**
     * 当前TCP网络包是否是基于RPC机制的消息包
     */
    public boolean isRpcPacket() {
        return this.getRpcLogicId() != 0;
    }

    /**
     * 当前TCP网络包是否是一个“中转包”
     * <p>当routeType和routeId同时存在的时候，认为其是“中转包”
     */
    public boolean isTransferPacket() {
        return this.getRouteType() != 0 && this.getRouteId() != 0;
    }

    public TcpPacketHeader getHeader() {
        return this.header;
    }

    public void setHeader(TcpPacketHeader header) {
        this.header = header;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] data) {
        this.data = data;
        if (this.header != null) {
            this.header.setCrc(HashUtil.elfHash(data));
            if (this.header instanceof TcpPacketHeaderEx) {
                this.header.setSize(
                        TcpPacketHeader.VERSION_LENGTH_IN_BYTES
                                + TcpPacketHeader.CRC_LENGTH_IN_BYTES
                                + TcpPacketHeaderEx.OID_LENGTH_IN_BYTES
                                + TcpPacketHeaderEx.RID_LENGTH_IN_BYTES
                                + TcpPacketHeaderEx.ROUTE_TYPE_LENGTH_IN_BYTES
                                + TcpPacketHeaderEx.ROUTE_ID_LENGTH_IN_BYTES
                                + TcpPacketHeaderEx.RPC_SOURCE_LENGTH_IN_BYTES
                                + data.length);
            } else {
                this.header.setSize(TcpPacketHeader.VERSION_LENGTH_IN_BYTES + TcpPacketHeader.CRC_LENGTH_IN_BYTES + data.length);
            }
        }
    }

    public int getSize() {
        if (this.header == null) {
            return 0;
        }

        return this.header.getSize();
    }

    public int getOpcode() {
        if (this.header == null) {
            return 0;
        }

        return this.header.getOpcode();
    }

    public int getCrc() {
        if (this.header == null) {
            return 0;
        }

        return this.header.getCrc();
    }

    public boolean isValidCRC() {
        boolean checkCRC = Jengine.getConfiguration().getBoolean("network.checkCRC");
        if (checkCRC) {
            return this.getCrc() == HashUtil.elfHash(this.data);
        } else {
            return true;
        }
    }

    @Override
    public ObjectId getObjectId() {
        if (this.header instanceof TcpPacketHeaderEx) {
            long oid = ((TcpPacketHeaderEx) this.header).getOid();
            if (oid == 0) {
                return null;
            } else {
                return ObjectId.valueOf(1, oid);
            }
        }

        return null;
    }

    public long getRpcLogicId() {
        if (this.header instanceof TcpPacketHeaderEx) {
            return ((TcpPacketHeaderEx) this.header).getRpcLogicId();
        }
        return 0;
    }

    public int getRouteType() {
        if (this.header instanceof TcpPacketHeaderEx) {
            return ((TcpPacketHeaderEx) this.header).getRouterType();
        }
        return 0;
    }

    public long getRouteId() {
        if (this.header instanceof TcpPacketHeaderEx) {
            return ((TcpPacketHeaderEx) this.header).getRouterId();
        }
        return 0;
    }

    public int getRpcSource() {
        if (this.header instanceof TcpPacketHeaderEx) {
            return ((TcpPacketHeaderEx) this.header).getEncodedRpcSource();
        }
        return 0;
    }

    public int calculateCRC() {
        return HashUtil.elfHash(this.data);
    }

    public void bindSession(ClientSession session) {
        this.session = session;
    }

    public ClientSession getSession() {
        return this.session;
    }

    public <T extends GeneratedMessageV3> T parsePacket(T template) {
        if (parsedPacket == null) {
            parsedPacket = ProtobufParser.getInstance().parsePacket(this, template);
        }
        return (T) parsedPacket;
    }

    @Override
    public String toString() {
        return String.format("[TcpPacket] opcode: %s, size: %s, crc: %s", header.getOpcode(), header.getSize(), header.getCrc());
    }

    private static void printProtocolInfo(int opcode, long objectId, long rpcId, GeneratedMessageV3.Builder<?> builder) {
        try {
            if (Jengine.getConfiguration().containsKey("network.printlog") && Jengine.getConfiguration().getBoolean("network.printlog")) {
                String pbContent = JsonFormat.printer().print(builder);
                if (builder != null) {
                    log.info("[Packet] build packet, playerId: {}, protocol: {}, rpcId:{}, protocolName: {},  protobuf: \n{}",
                            objectId, opcode, rpcId, builder.getClass().getSimpleName(), pbContent);
                }
            }

        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }
}
