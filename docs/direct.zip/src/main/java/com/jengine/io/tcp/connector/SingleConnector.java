package com.jengine.io.tcp.connector;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.Connector;
import com.jengine.io.Packet;
import com.jengine.io.tcp.TcpProtobufDecoder;
import com.jengine.io.tcp.TcpProtobufEncoder;
import com.jengine.logger.Log;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import org.slf4j.Logger;

/**
 * A tcp client implementation.
 *
 * @author mengyan
 */
public class SingleConnector implements Connector {
    private static final Logger log = Log.getNetworkLogger();

    private SingleClientPacketHandler singleClientHandler = new SingleClientPacketHandler(this);
    protected volatile boolean isConnected;
    protected volatile boolean isShutdowning;
    protected String host;
    protected int port;
    protected boolean autoReconnect;
    protected Thread autoReconnectThread;
    protected ClientSession session;
    protected Bootstrap bootstrap;
    protected EventLoopGroup group;
    protected ChannelFuture channelFuture;

    public SingleConnector(String host, int port, boolean autoReconnect) {
        this.host = host;
        this.port = port;
        this.autoReconnect = autoReconnect;
        this.isShutdowning = false;

        this.init();
    }

    /**
     * This constructor support sharing event loop group.
     *
     * @param group
     * @param host
     * @param port
     * @param autoReconnect
     */
    public SingleConnector(EventLoopGroup group, String host, int port, boolean autoReconnect) {
        this.host = host;
        this.port = port;
        this.autoReconnect = autoReconnect;
        this.isShutdowning = false;
        this.group = group;

        this.init();
    }

    protected void init() {
        if (this.group == null) {
            this.group = new NioEventLoopGroup();
        }

        this.bootstrap = new Bootstrap();
        this.bootstrap.group(this.group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    public void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline channelPipLine = ch.pipeline();
                        channelPipLine.addLast("frame", new LengthFieldBasedFrameDecoder(Integer.MAX_VALUE, 4, 4, 0, 0));
                        channelPipLine.addLast("encoder", new TcpProtobufEncoder());
                        channelPipLine.addLast("decoder", new TcpProtobufDecoder());
                        channelPipLine.addLast("handler", singleClientHandler);
                    }
                });
    }

    public boolean connect() {
        synchronized (this) {
            if (!this.isConnected) {
                try {
                    channelFuture = this.bootstrap.connect(this.host, port).sync();
                    this.startReconnect();
                    return channelFuture.isSuccess();
                } catch (Exception e) {
                    Log.getNetworkLogger().error("Could not connect remote server {}:{}, reconnecting...", this.host, this.port);
                    this.startReconnect();
                    return false;
                }
            } else {
                log.info("[SingleConnector] connected already, abort connect.");
            }
        }

        return true;
    }

    private void startReconnect() {
        // init after connect server
        if (this.autoReconnect && (this.autoReconnectThread == null)) {
            this.autoReconnectThread = new Thread(new AutoReconnect());
            this.autoReconnectThread.setName("SingleConnector-AutoReconnectThread");
            this.autoReconnectThread.start();
        }
    }

    public void disconnect() {
        this.channelFuture.channel().close();
    }

    public void reconnect() throws InterruptedException {
        while (!isConnected && !this.isShutdowning) {
            try {
                Thread.sleep(5000L);
            } catch (InterruptedException e) {

            }
            log.info("[SingleConnector] reconnecting...");
            this.connect();
        }
    }

    public void onConnected(ClientSession session) {
        this.isConnected = true;
        this.session = session;
        log.info("[SingleConnector] connected.");
    }

    public void onDisconnected() {
        this.isConnected = false;
        this.session = null;
        log.info("[SingleConnector] disconnected.");
    }

    @Override
    public boolean isActive() {
        return this.isConnected;
    }

    @Override
    public String remoteAddr() {
        return null;
    }

    @Override
    public void send(Packet packet) {
        if (this.session != null && this.isConnected) {
            this.session.send(packet);
        }
    }

    @Override
    public boolean sendSync(Packet packet) {
        if (this.session != null && this.isConnected) {
            return this.session.sendSync(packet);
        }

        return false;
    }

    @Override
    public void close(boolean immediately) {
        this.isShutdowning = true;
        this.group.shutdownGracefully();
    }

    public class AutoReconnect implements Runnable {
        @Override
        public void run() {
            while (SingleConnector.this.autoReconnect && !SingleConnector.this.isShutdowning) {
                try {
                    Thread.sleep(5000L);
                } catch (InterruptedException e) {
                    JengineException.catchEx(e);
                }

                if (SingleConnector.this.isConnected) {
                    continue;
                }

                try {
                    SingleConnector.this.reconnect();
                } catch (InterruptedException e) {
                    JengineException.catchEx(e);
                }

            }
        }
    }
}
