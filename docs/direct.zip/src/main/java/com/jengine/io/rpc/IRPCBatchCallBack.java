package com.jengine.io.rpc;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpPacket;

import java.util.Map;

/**
 * IRPCBatchCallBack：N次批量RPC调用的回调
 */
public interface IRPCBatchCallBack {

    /**
     * 成功收集到所有等待的请求之后的处理
     *
     * @param batchResponse 成功的RPC回包
     */
    void onResponse(Map<Long, RpcResponse> batchResponse);

    /**
     * 批量操作超时之后的处理
     * <p>只要批量组内有任意一个RPC超时，即会触发该方法
     *
     * @param timeoutParameter 超时的RPC列表
     * @param batchResponse    部分成功的RPC回包
     */
    void onTimeOut(Map<Long, RPCParameter> timeoutParameter, Map<Long, RpcResponse> batchResponse);

    /**
     * 收到错误回复信息之后的处理
     */
    void onError(ClientSession session, TcpPacket response);
}