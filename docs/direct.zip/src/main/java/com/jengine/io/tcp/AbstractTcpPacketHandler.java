package com.jengine.io.tcp;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.SessionManager;
import com.jengine.logger.Log;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.socket.ChannelInputShutdownEvent;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;

/**
 * Basic implementation of tcp packet handler.
 *
 * @author mengyan
 */
public abstract class AbstractTcpPacketHandler extends ChannelInboundHandlerAdapter {
    private static final Logger log = Log.getNetworkLogger();
    private static final SessionManager sessionManager = SessionManager.getInstance();

    public abstract void onSessionOpened(ClientSession clientSession);

    public abstract void onSessionClosed(ClientSession clientSession);

    @Override
    public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        ctx.fireChannelRegistered();

        ClientSession clientSession = TcpSessionBuilder.getInstance().build(sessionManager, ctx.channel());
        boolean addSuccess = sessionManager.addSession(clientSession);
        if (!addSuccess) {
            log.error("[TcpServerHandler] add new session failed: session max size limit, address:{}, current size:{}",
                    ctx.channel().remoteAddress(), sessionManager.getSize());
            clientSession.close(false);
            ctx.close();
            return;
        }

        clientSession.setChannel(ctx.channel());
        this.onSessionOpened(clientSession);
    }

    @Override
    public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
        ClientSession clientSession = ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get();

        if (clientSession == null) {
            ctx.fireChannelUnregistered();
            return;
        }

        this.onSessionClosed(clientSession);

        disconnect(ctx.channel());

        ctx.fireChannelUnregistered();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.info("channel exceptionCaught, connection closed. The reason is: ", cause);

        try {
            ClientSession clientSession = ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get();
            if (clientSession != null) {
                this.onSessionClosed(clientSession);
            }
        } catch (Exception e) {
            JengineException.catchEx(e);
        }

        this.disconnect(ctx.channel());
        ctx.close();
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        super.userEventTriggered(ctx, evt);
        if (evt instanceof IdleStateEvent || evt instanceof ChannelInputShutdownEvent) {
            TcpClientSession session = ctx.channel().attr(TcpSessionBuilder.CHANNEL_SESSION).get();
            this.onSessionClosed(session);
            disconnect(ctx.channel());
        }
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    protected void disconnect(Channel channel) {
        TcpClientSession session = channel.attr(TcpSessionBuilder.CHANNEL_SESSION).get();
        if (session == null) {
            log.error("tcp session null channelId is:" + channel.id().asLongText());
            return;
        }

        channel.attr(TcpSessionBuilder.CHANNEL_SESSION).set(null);
        session.close(false);
    }
}
