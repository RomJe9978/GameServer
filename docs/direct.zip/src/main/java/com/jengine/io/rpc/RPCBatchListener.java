package com.jengine.io.rpc;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.object.ObjectId;
import com.jengine.task.AbstractTask;
import com.jengine.task.TaskExecutor;
import com.jengine.util.EmptyUtil;
import com.jengine.util.TimeUtil;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RPC批量通信机制的监听器
 */
public class RPCBatchListener {
    // key: 单次rpc请求ID，value: 批量rpc参数
    private final Map<Long, RPCBatchParameter> rpcListenMap = new ConcurrentHashMap<>();
    // key: 批量rpc请求ID，value: 批量rpc参数
    private final Map<Long, RPCBatchParameter> batchRpcMap = new ConcurrentHashMap<>();

    /**
     * 所有监听的RPC的回包
     * key：batchId，value：<Rpc的requestId，对应回包信息>
     */
    private final Map<Long, Map<Long, RpcResponse>> batchResponseMap = new ConcurrentHashMap<>();

    /**
     * RPC批量通讯注册“请求”的监听
     *
     * @param batchParameter 批量监听参数，包含所有RPC通讯的信息
     */
    public void listen(long batchId, RPCBatchParameter batchParameter) {
        if (Objects.isNull(batchParameter)) {
            return;
        }

        List<Rpc> rpcList = batchParameter.listRpc();
        if (EmptyUtil.isEmpty(rpcList)) {
            return;
        }

        rpcList.forEach(rpc -> this.rpcListenMap.put(rpc.getRequestId(), batchParameter));
        this.batchRpcMap.put(batchId, batchParameter);
    }

    /**
     * 解除监听，返回监听的数据
     */
    public RPCBatchParameter cancelListen(long requestId) {
        return this.rpcListenMap.remove(requestId);
    }

    /**
     * 触发监听，该接口内会直接移除特定的监听
     */
    public void trigger(long requestId, ClientSession session, TcpPacket packet) {
        if (Objects.isNull(session) || Objects.isNull(packet) || !this.rpcListenMap.containsKey(requestId)) {
            return;
        }

        // 先移除单个rpc的监听
        RPCBatchParameter batchParameter = this.cancelListen(requestId);
        if (Objects.isNull(batchParameter)) {
            return;
        }

        // 添加回复包
        long batchId = batchParameter.getBatchId();
        Map<Long, RpcResponse> rpcResponseMap = this.batchResponseMap.get(batchId);
        if (Objects.isNull(rpcResponseMap)) {
            rpcResponseMap = new ConcurrentHashMap<>();
            this.batchResponseMap.put(batchId, rpcResponseMap);
        }
        rpcResponseMap.put(requestId, new RpcResponse(requestId, session, packet));

        // 批量rpc全部回复
        final Map<Long, RpcResponse> tempMap = rpcResponseMap;
        if (rpcResponseMap.size() == batchParameter.listRpc().size()) {
            // batch线程处理消息回调
            try {
                TaskExecutor.getInstance().postLogicTask(new AbstractTask(true) {
                    @Override
                    public ObjectId getDispatchId() {
                        return ObjectId.valueOfId(batchParameter.getObjectId());
                    }

                    @Override
                    public void run() {
                        IRPCBatchCallBack callBack = batchParameter.getCallBack();
                        if (Objects.nonNull(callBack)) {
                            callBack.onResponse(tempMap);
                        }
                    }

                    @Override
                    public int getType() {
                        return 0;
                    }
                });
            } catch (Exception e) {
                JengineException.catchEx(e);
            }

            // 移除相关的监听和记录
            this.batchRpcMap.remove(batchParameter.getBatchId());
            this.batchResponseMap.remove(batchParameter.getBatchId());
        }
    }

    /**
     * 批量请求超时机制
     */
    public void timeOut() {
        if (this.batchRpcMap.isEmpty()) {
            return;
        }

        // 轮训超时
        long curTime = TimeUtil.getTimeInMillis();
        List<RPCBatchParameter> outBatchList = new ArrayList<>();
        this.batchRpcMap.forEach((batchId, parameter) -> {
            if (curTime >= parameter.getOutTimestamp()) {
                outBatchList.add(parameter);
            }
        });

        // 取消监听，处理超时回调
        try {
            outBatchList.forEach(batchParameter -> {
                RPCBatchParameter rpcBatchParameter = this.batchRpcMap.remove(batchParameter.getBatchId());
                rpcBatchParameter.listRpc().forEach(rpc -> this.rpcListenMap.remove(rpc.getRequestId()));
                final Map<Long, RpcResponse> tempResponseMap = this.batchResponseMap.remove(batchParameter.getBatchId());
                final Map<Long, RPCParameter> tempTimeOutMap = new HashMap<>();
                for (Rpc rpc : rpcBatchParameter.listRpc()) {
                    if (Objects.nonNull(tempResponseMap) && !tempResponseMap.containsKey(rpc.getRequestId())) {
                        tempTimeOutMap.put(rpc.getRequestId(), rpc.getRpcParameter());
                    }
                }

                // 必须分发会batchRpc的线程，保证处理一致
                TaskExecutor.getInstance().postLogicTask(new AbstractTask(true) {
                    @Override
                    public ObjectId getDispatchId() {
                        return ObjectId.valueOfId(batchParameter.getObjectId());
                    }

                    @Override
                    public void run() {
                        IRPCBatchCallBack callBack = batchParameter.getCallBack();
                        if (Objects.nonNull(callBack)) {
                            callBack.onTimeOut(tempTimeOutMap, tempResponseMap);
                        }
                    }

                    @Override
                    public int getType() {
                        return 0;
                    }
                });
            });
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }
}
