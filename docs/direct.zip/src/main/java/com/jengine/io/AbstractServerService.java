package com.jengine.io;

import com.jengine.service.Service;

/**
 * Base server service
 *
 * @author mengyan
 */
public abstract class AbstractServerService implements Service {
	private final String serviceId;
	protected final int port;

	public AbstractServerService(String serviceId, int serverPort) {
		this.serviceId = serviceId;
		this.port = serverPort;
	}

	@Override
	public String getId() {
		return this.serviceId;
	}


	public int getPort() {
		return this.port;
	}
}
