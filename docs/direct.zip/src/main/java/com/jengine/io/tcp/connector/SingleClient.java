package com.jengine.io.tcp.connector;

import com.jengine.io.ClientSession;
import com.jengine.io.tcp.TcpClient;
import com.jengine.io.tcp.TcpPacket;

/**
 * The default implementation of TcpClient.
 *
 * @author mengyan
 */
public class SingleClient implements TcpClient {
	private ClientSession session;

	@Override
	public void setSession(ClientSession session) {
		this.session = session;
	}

	@Override
	public ClientSession getSession() {
		return this.session;
	}

	public void send(TcpPacket packet) {
		this.session.send(packet);
	}
}
