package com.jengine.io.tcp;

import com.jengine.Jengine;
import com.jengine.io.AbstractServerService;
import com.jengine.service.Service;

/**
 * Tcp server wrapper.
 *
 * @author mengyan
 */
public class TcpServerService extends AbstractServerService {
    private static final int DEFAULT_BOSS_GROUP_THREADS = 1;
    private static final int DEFAULT_WORKER_GROUP_THREADS = 0;

    private Service beforeCloseTcpService;
    private TcpServer tcpServer;
    private boolean useExPacket;

    public TcpServerService() {
        super(Jengine.getConfiguration().getString("server.name"),
                Jengine.getConfiguration().getInt("server.port"));

        this.tcpServer = new TcpServer(this.getPort());
        this.useExPacket = Jengine.getConfiguration().getBoolean("server.useExPacket", false);
    }

    public TcpServerService(String serverId, int port) {
        super(serverId, port);
    }

    public TcpServerService(String serverId, int port, boolean useExPacket) {
        super(serverId, port);
        this.useExPacket = useExPacket;
    }

    @Override
    public boolean init() {
        if (this.useExPacket) {
            this.tcpServer.setChannelInitializer(new DefaultTcpChannelInitializerEx());
        } else {
            this.tcpServer.setChannelInitializer(new DefaultTcpChannelInitializer());
        }
        this.tcpServer.setBossGroupThreads(DEFAULT_BOSS_GROUP_THREADS);
        this.tcpServer.setWorkerGroupThreads(DEFAULT_WORKER_GROUP_THREADS);

        return true;
    }

    @Override
    public boolean startup() {
        return this.tcpServer.start();
    }

    @Override
    public boolean shutdown() {
        if (this.beforeCloseTcpService != null) {
            try {
                this.beforeCloseTcpService.shutdown();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return this.tcpServer.stop();
    }

    public void setBeforeCloseTcpService(Service service) {
        this.beforeCloseTcpService = service;
    }
}
