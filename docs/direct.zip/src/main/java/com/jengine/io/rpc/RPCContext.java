package com.jengine.io.rpc;

import com.jengine.io.ClientSession;
import com.jengine.io.Packet;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.logger.Log;
import com.jengine.util.BitUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * RPC上下文实例(单例)
 * <p>内部所有的组件和逻辑，保证线程安全
 * <p>业务层使用“RPC机制”的桥梁
 *
 * @author RomJe
 */
public class RPCContext {
    private final static RPCContext INSTANCE = new RPCContext();

    /**
     * RPC通信ID生成器
     */
    private final AtomicLong idGenerator = new AtomicLong(RPCConst.INIT_REQUEST_ID);

    /**
     * RPC的通信监听器
     */
    private final RPCListener rpcListener = new RPCListener();

    /**
     * RPC批量通信监听器
     */
    private final RPCBatchListener rpcBatchListener = new RPCBatchListener();

    private RPCContext() {
    }

    public static RPCContext getInstance() {
        return INSTANCE;
    }

    /**
     * 最底层的一次RPC通信中的请求接口
     *
     * @param parameter 业务层填充的本次RPC请求信息
     * @return 返回本次RPC请求唯一“请求id”
     */
    public long request(RPCParameter parameter) {
        if (!isValidParameter(parameter)) {
            return 0;
        }

        // 无论参数是否设置，此处都会设置本次请求的逻辑id
        long requestId = generateId();
        long rpcLogicId = RPCContext.encodeLogicId(RPCConst.RPC_REQUEST_TYPE, requestId);
        parameter.setRequestId(requestId);

        Packet tcpPacket = TcpPacket.valueOf(
                rpcLogicId,
                parameter.getObjectId(),
                parameter.getOpcode(),
                parameter.getData(),
                parameter.getRouterType(),
                parameter.getRouterId(),
                parameter.getEncodedsourceRouter()
        );
        parameter.getConnector().send(tcpPacket);

        // 注册监听
        // 如果回调为空，则忽略监听，仅作为消息发送应用
        if (parameter.getCallBack() != null) {
            parameter.setRequestId(requestId);
            RPCContext.getInstance().getRpcListener().listen(requestId, parameter);
        }

        return requestId;
    }

    public List<Long> batchRequest(RPCBatchParameter batchParameter) {
        List<Long> result = new ArrayList<>();

        long batchId = generateId();
        for (Rpc rpc : batchParameter.listRpc()) {
            RPCParameter parameter = rpc.getRpcParameter();
            if (!isValidParameter(rpc.getRpcParameter())) {
                result.add(0L);
                continue;
            }

            // 无论参数是否设置，此处都会设置本次请求的逻辑id
            long rpcLogicId = RPCContext.encodeLogicId(RPCConst.RPC_REQUEST_TYPE, parameter.getRequestId());
            Packet tcpPacket = TcpPacket.valueOf(
                    rpcLogicId,
                    parameter.getObjectId(),
                    parameter.getOpcode(),
                    parameter.getData(),
                    parameter.getRouterType(),
                    parameter.getRouterId(),
                    parameter.getEncodedsourceRouter()
            );
            parameter.getConnector().send(tcpPacket);
            result.add(parameter.getRequestId());
        }

        // 注册监听
        // 如果回调为空，则忽略监听，仅作为消息发送应用
        if (batchParameter.getCallBack() != null) {
            batchParameter.setBatchId(batchId);
            RPCContext.getInstance().getRpcBatchListener().listen(batchId, batchParameter);
        }
        return result;
    }

    /**
     * 最底层的一次RPC通信中的回复接口
     *
     * @param requestPacket 关联的RPC请求包
     * @param parameter     业务层填充的本次RPC回复信息
     */
    public void response(TcpPacket requestPacket, RPCParameter parameter) {
        if (Objects.isNull(requestPacket) || Objects.isNull(parameter)) {
            return;
        }

        if (!requestPacket.isRpcPacket()) {
            return;
        }

        // 直接回复即可
        long requestId = requestPacket.getRpcLogicId();
        long originRequestId = RPCContext.decodeRequestId(requestId);
        long rpcLogicId = RPCContext.encodeLogicId(RPCConst.RPC_RESPONSE_TYPE, originRequestId);

        Packet tcpPacket = null;
        int encodedRpcSource = requestPacket.getRpcSource();
        if (encodedRpcSource != 0) {
            tcpPacket = TcpPacket.valueOf(
                    rpcLogicId,
                    parameter.getObjectId(),
                    parameter.getOpcode(),
                    parameter.getData(),
                    decodeRpcSourceType(encodedRpcSource),
                    decodeRpcSourceId(encodedRpcSource),
                    encodedRpcSource
            );
        } else {
            tcpPacket = TcpPacket.valueOf(
                    rpcLogicId,
                    parameter.getObjectId(),
                    parameter.getOpcode(),
                    parameter.getData(),
                    parameter.getRouterType(),
                    parameter.getRouterId(),
                    encodedRpcSource
            );
        }
        parameter.getConnector().send(tcpPacket);
    }

    /**
     * 生成新的自增id
     */
    public long generateId() {
        return idGenerator.getAndIncrement();
    }

    /**
     * 是否是RPC的回复包
     */
    public static boolean isRpcResponse(TcpPacket packet) {
        if (Objects.isNull(packet)) {
            return false;
        }
        return packet.isRpcPacket() && isResponseType(packet.getRpcLogicId());
    }

    public RPCListener getRpcListener() {
        return this.rpcListener;
    }

    public RPCBatchListener getRpcBatchListener() {
        return this.rpcBatchListener;
    }

    /**
     * 收到了RPC的回复包，交由底层“监听机制”去处理
     */
    public void onRpcResponse(ClientSession session, TcpPacket packet) {
        if (Objects.isNull(session) || Objects.isNull(packet)) {
            return;
        }
        long decodeRequestId = decodeRequestId(packet.getRpcLogicId());
        this.rpcListener.trigger(decodeRequestId, session, packet);
        this.rpcBatchListener.trigger(decodeRequestId, session, packet);
    }

    /**
     * 编码逻辑id，根据类型和业务层“请求id”
     */
    public static long encodeLogicId(long type, long requestId) {
        return RPCConst.RPC_MARK | (type << RPCConst.TYPE_POSITION) | requestId;
    }

    /**
     * 根据逻辑ID解码出“请求id”
     * <p>不关心类型，因为请求和回复的逻辑id中的请求id是一样的
     */
    public static long decodeRequestId(long rpcLogicId) {
        return (rpcLogicId << 4) >>> 4;
    }

    /**
     * 指定rpc逻辑id，是否是“回复”类型
     */
    public static boolean isResponseType(long logicId) {
        return BitUtil.bitAtLong(logicId, RPCConst.TYPE_POSITION) == RPCConst.RPC_RESPONSE_TYPE;
    }

    /**
     * 编码rpc源信息
     */
    public static int encodeRpcSource(int sourceType, int sourceId) {
        return RPCConst.RPC_SOURCE_MARK | ((sourceType << 26) >>> 2) | sourceId;
    }

    /**
     * 解码rpc源服务器类型
     */
    public static int decodeRpcSourceType(int encodedRpcSource) {
        return (encodedRpcSource << 2) >>> 26;
    }

    /**
     * 解码rpc源服务器Id
     */
    public static int decodeRpcSourceId(int encodedRpcSource) {
        return (encodedRpcSource << 8) >>> 8;
    }

    public boolean isValidParameter(RPCParameter parameter) {
        if (Objects.isNull(parameter)) {
            Log.getNetworkLogger().error("RPCContext request RPCParameter is null");
            return false;
        }

        if (parameter.getConnector() == null) {
            Log.getNetworkLogger().error("RPCContext request Connector is null");
            return false;
        }

        if (parameter.getOpcode() == 0) {
            Log.getNetworkLogger().error("RPCContext request opcode is 0");
            return false;
        }

        if (Objects.isNull(parameter.getData())) {
            Log.getNetworkLogger().error("RPCContext request data is empty");
            return false;
        }

        return true;
    }
}
