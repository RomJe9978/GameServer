package com.jengine.io.tcp;

import com.jengine.io.Packet;
import com.jengine.io.PacketEncoder;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;
import io.netty.util.CharsetUtil;

import java.nio.charset.Charset;
import java.util.List;

/**
 * Encodes from one message to a protobuf message
 *
 * @author mengyan
 */
public class TcpProtobufEncoder extends MessageToMessageEncoder<TcpPacket> implements PacketEncoder {
    protected static final int INITIAL_CAPACITY = 256;
    private final Charset charset;

    public TcpProtobufEncoder() {
        this(CharsetUtil.UTF_8);
    }

    public TcpProtobufEncoder(Charset charset) {
        if (charset == null) {
            throw new NullPointerException("charset");
        } else {
            this.charset = charset;
        }
    }

    @Override
    protected void encode(ChannelHandlerContext ctx, TcpPacket msg, List<Object> out) throws Exception {
        ByteBuf netMessageBuf = this.createByteBuf(msg);
        out.add(netMessageBuf);
    }

    @Override
    public ByteBuf createByteBuf(Packet packet) throws Exception {
        TcpPacket tcpPacket = (TcpPacket) packet;
        ByteBuf byteBuf = Unpooled.buffer(INITIAL_CAPACITY);

        // encode header
        TcpPacketHeader packetHeader = tcpPacket.getHeader();
        byteBuf.writeInt(packetHeader.getOpcode());
        byteBuf.writeInt(packetHeader.getSize());
        byteBuf.writeInt(packetHeader.getVersion());
        byteBuf.writeInt(packetHeader.getCrc());

        byte[] data = tcpPacket.getData();
        byteBuf.writeBytes(data);
        byteBuf.slice();

        return byteBuf;
    }
}
