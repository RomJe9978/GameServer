package com.jengine.io.http;

import com.jengine.JengineException;
import com.jengine.logger.Log;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.SelfSignedCertificate;

/**
 * Http server implementation.
 *
 * @author mengyan
 */
public class HttpServerService implements Runnable {
    private final String host;
    private final int port;

    private boolean userSSL = false;

    private SslContext sslCtx;
    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;
    private ServerBootstrap serverBootstrap;

    private HttpHandlerDispatcher dispatcher;

    public HttpServerService(String host, int port) {
        this.host = host;
        this.port = port;
        this.dispatcher = new HttpHandlerDispatcher();
    }

    public void createContext(String uri, HttpHandler handler) {
        this.dispatcher.registerHandler(uri, handler);
    }

    public void registerBeforeCallHandler(HttpHandler handler) {
        this.dispatcher.registerBeforeCallHandler(handler);
    }

    public void registerErrorHandler(HttpHandler handler) {
        this.dispatcher.registerErrorHandler(handler);
    }

    public void registerNotFoundHandler(HttpHandler handler) {
        this.dispatcher.registerNotFoundHandler(handler);
    }

    public void clearContext() {
        this.dispatcher.clear();
    }

    public void handle(HttpExchange httpExchange) {
        if (!this.dispatcher.handle(httpExchange)) {
            this.dispatcher.handleError(httpExchange);
        }
    }

    public boolean start() {
        if (this.init()) {
            Thread thread = new Thread(this);
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            thread.start();
            return true;
        }

        return false;
    }

    public boolean shutdown() {
        if (bossGroup != null) {
            bossGroup.shutdownGracefully();
        }

        if (workerGroup != null) {
            workerGroup.shutdownGracefully();
        }

        return true;
    }

    private boolean init() {
        try {
            if (userSSL) {
                SelfSignedCertificate ssc = new SelfSignedCertificate();
                sslCtx = SslContextBuilder.forServer(ssc.certificate(), ssc.privateKey()).build();
            } else {
                sslCtx = null;
            }

            bossGroup = new NioEventLoopGroup(1);
            workerGroup = new NioEventLoopGroup(1);
            serverBootstrap = new ServerBootstrap();
            serverBootstrap.option(ChannelOption.SO_BACKLOG, 1024);
            serverBootstrap.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(new DefaultHttpChannelInitializer(this, sslCtx));

        } catch (Exception e) {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();

            JengineException.catchEx(e);
            return false;
        }

        return true;
    }

    private void startServer() throws InterruptedException {
        Channel ch = serverBootstrap.bind(this.host, this.port).sync().channel();
        Log.getNetworkLogger().info("Server listening " + (userSSL ? "https" : "http") + "://{}:{}", this.host, this.port);

        ch.closeFuture().sync();
    }

    @Override
    public void run() {
        try {
            this.startServer();
        } catch (Exception e) {
            JengineException.catchEx(e);

            this.shutdown();
        }
    }
}
