package com.jengine.io.http;

import com.google.gson.JsonObject;
import io.netty.handler.codec.http.HttpRequest;

import java.util.Map;

/**
 * The bridge of a http request and a http response.
 *
 * @author mengyan
 */
public interface HttpExchange extends HttpRequest {

    HttpPacket getRequest();

    String getRequestContent();

    Map<String, String> getParameters();

    JsonObject getJSONRequest();

    void response(JsonObject res);

    void setHandler(HttpHandler handler);

    HttpHandler getHandler();
}
