package com.jengine.io.http;

/**
 * Http handler interface.
 *
 * @author mengyan
 */
public interface HttpHandler {
	void handle(HttpExchange httpExchange) throws Exception;
}
