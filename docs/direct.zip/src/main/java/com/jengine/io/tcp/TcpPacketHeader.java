package com.jengine.io.tcp;

/**
 * Packet header.
 * +--------+--------+---------+---------+----------------+
 * | opcode | size   | version |   crc   | Actual Body    |
 * |0xCA0xCA|0x0C0x0C|0xFE0xFE |         | "body content" |
 * +--------+--------+---------+---------+----------------+
 *
 * @author mengyan
 */
public class TcpPacketHeader {
    public static final int OPCODE_LENGTH_IN_BYTES = 4;
    public static final int SIZE_LENGTH_IN_BYTES = 4;
    public static final int VERSION_LENGTH_IN_BYTES = 4;
    public static final int CRC_LENGTH_IN_BYTES = 4;

    protected int opcode;
    protected int size;
    protected int version;
    protected int crc;

    TcpPacketHeader() {
    }

    TcpPacketHeader(int opcode) {
        this.opcode = opcode;
    }

    public void clear() {
        this.opcode = 0;
        this.size = 0;
        this.version = 0;
        this.crc = 0;
    }

    @Override
    public String toString() {
        return String.format("TcpPacketHeader [opcode: %d, size: %d, version: %d, crc: %d]", this.opcode, this.size, this.version, this.crc);
    }

    public int getOpcode() {
        return opcode;
    }

    public void setOpcode(int opcode) {
        this.opcode = opcode;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getCrc() {
        return crc;
    }

    public void setCrc(int crc) {
        this.crc = crc;
    }
}