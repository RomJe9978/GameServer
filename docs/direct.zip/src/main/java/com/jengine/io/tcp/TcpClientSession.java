package com.jengine.io.tcp;

import com.jengine.JengineException;
import com.jengine.io.ClientSession;
import com.jengine.io.ClientSessionUtil;
import com.jengine.io.Packet;
import com.jengine.io.SessionManager;
import com.jengine.logger.Log;
import com.jengine.object.GameObject;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.util.AttributeKey;
import org.slf4j.Logger;

import java.net.InetSocketAddress;

/**
 * A tcp connection orresponds to a TcpClientSession.
 *
 * @author mengyan
 */
public class TcpClientSession implements ClientSession {
    private static final Logger log = Log.getNetworkLogger();

    private String id;
    private SessionManager sessionManager;
    private volatile Channel channel;
    private GameObject gameObject;

    public TcpClientSession(SessionManager sessionManager, Channel channel) {
        this.id = ClientSessionUtil.getSessionId(channel);
        this.sessionManager = sessionManager;
        this.channel = channel;
    }

    @Override
    public String getSessionId() {
        return this.id;
    }

    @Override
    public boolean isActive() {
        return this.channel.isActive();
    }

    @Override
    public String remoteAddr() {
        return this.channel.remoteAddress().toString().split(":")[0].substring(1);
    }

    @Override
    public void send(Packet packet) {
        if (this.channel == null || packet == null || !this.channel.isActive()) {
            return;
        }

        log.info("\r\n<------------|send packet|------------>\n {}\r\n---------------------------------------", packet);
        channel.writeAndFlush(packet);
    }

    @Override
    public boolean sendSync(Packet packet) {
        if (this.channel == null || packet == null || !this.channel.isActive()) {
            return false;
        }

        log.info("\r\n<------------|send packet|------------>\n {}\r\n---------------------------------------", packet);
        try {
            ChannelFuture future = channel.writeAndFlush(packet).sync();
            if (future.isSuccess()) {
                return true;
            } else {
                return false;
            }
        } catch (InterruptedException e) {
            JengineException.catchEx(e);
            return false;
        }
    }

    @Override
    public void close(boolean immediately) {
        if (this.sessionManager != null) {
            this.sessionManager.removeSession(this);
        }

        if (this.channel != null) {
            log.info("TcpClientSession close session: {}", this.getSessionId());
            this.channel.attr(TcpSessionBuilder.CHANNEL_SESSION).set(null);
            this.channel.close();
        }
    }

    @Override
    public void setAttribute(String key, Object value) {
        if (this.channel != null) {
            this.channel.attr(AttributeKey.valueOf(key)).set(value);
        }
    }

    @Override
    public Object getAttribute(String key) {
        return this.channel.attr(AttributeKey.valueOf(key));
    }

    @Override
    public void bindGameObject(GameObject object) {
        this.gameObject = object;
    }

    @Override
    public GameObject getGameObject() {
        return this.gameObject;
    }

    public Channel getChannel() {
        return channel;
    }

    @Override
    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public String getRemoteAddress() {
        InetSocketAddress insocket = (InetSocketAddress) (this.getChannel().remoteAddress());
        String clientIP = insocket.getAddress().getHostAddress();
        return clientIP;
    }
}
