package com.jengine.io;

public interface Connector {
    /**
     * Whether the session is active.
     *
     * @return
     */
    boolean isActive();

    String remoteAddr();

    void send(Packet packet);

    boolean sendSync(Packet packet);

    void close(boolean immediately);
}
