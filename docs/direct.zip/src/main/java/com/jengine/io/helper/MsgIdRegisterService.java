package com.jengine.io.helper;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.protobuf.GeneratedMessageV3;
import com.jengine.Jengine;
import com.jengine.logger.Log;
import com.jengine.service.Service;
import com.jengine.util.JSONUtil;
import com.jengine.util.StringUtil;
import org.slf4j.Logger;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A register for msg name and msg id.
 *
 * @author mengyan
 */
public class MsgIdRegisterService implements Service {
    private static final Logger log = Log.getNetworkLogger();

    private static final String MSG_ID_FILE_SEPARATOR = ",";
    private Map<String, Integer> msgName2MsgId = new ConcurrentHashMap<>();
    private Map< Integer, String> msgId2Name = new ConcurrentHashMap<>();

    private Map<String,String> msgName2Module = new ConcurrentHashMap<>();

    public int getMsgIdForMsg(GeneratedMessageV3.Builder<?> builder) {
        String msgName = builder.getDefaultInstanceForType().getClass().getSimpleName();

        if (!this.msgName2MsgId.containsKey(msgName)) {
            log.error("msg name: {} not registered!", msgName);
            return 0;
        }

        return this.msgName2MsgId.get(msgName);
    }

    public String getMsgNameForMsgId(int msgId) {
        if (!this.msgId2Name.containsKey(msgId)) {
            log.error("msg id: {} not registered!", msgId);
            return null;
        }

        return this.msgId2Name.get(msgId);
    }

    @Override
    public String getId() {
        return "MsgIdRegister";
    }

    @Override
    public boolean init() {
        return true;
    }

    @Override
    public boolean startup() throws Exception {
        String msgIdFiles = Jengine.getConfiguration().getString("network.msgIdMapperFile");
        String msgModuleMapFile = Jengine.getConfiguration().getString("network.msgModuleMapperFile");

        if(StringUtil.isNotEmpty(msgModuleMapFile)){
            String file = msgModuleMapFile;
            JsonObject jsonObject = JSONUtil.loadObjectFromFile(file);
            Set<Map.Entry<String, JsonElement>> entrySet = jsonObject.entrySet();
            for (Map.Entry<String, JsonElement> entry : entrySet) {
                String msgName = entry.getKey();
                String moduleName = jsonObject.get(msgName).getAsString();
                this.msgName2Module.put(msgName, moduleName);
                log.info("register msg name: {} with module name: {}", msgName, moduleName);
            }
        }

        if (StringUtil.isNotEmpty(msgIdFiles)) {
            String[] files = msgIdFiles.split(MSG_ID_FILE_SEPARATOR);
            for (String file : files) {
                JsonObject jsonObject = JSONUtil.loadObjectFromFile(file);

                Set<Map.Entry<String, JsonElement>> entrySet = jsonObject.entrySet();
                for (Map.Entry<String, JsonElement> entry : entrySet) {
                    String msgName = entry.getKey();
                    Integer msgId = jsonObject.get(msgName).getAsInt();
                    this.msgName2MsgId.put(msgName, msgId);
                    this.msgId2Name.put(msgId,"com.golden.protocol." + this.msgName2Module.get(msgName) + "$" +msgName);
                    log.info("register msg name: {} with msg id: {}", msgName, msgId);
                }
            }
        }

        return true;
    }

    @Override
    public boolean shutdown() throws Exception {
        return true;
    }
}
