package com.jengine.io.rpc;

import com.google.protobuf.GeneratedMessageV3;
import com.jengine.Jengine;
import com.jengine.io.Connector;
import com.jengine.io.helper.MsgIdRegisterService;
import com.jengine.io.tcp.TcpPacket;
import com.jengine.util.TimeUtil;

import java.util.Objects;

/**
 * Rpc包装类
 * RPC底层机制的参数封装以及请求，回包接口等的处理
 * <p>具体参数与方法解耦，增强底层方法的可维护性，可扩展性
 * <p>采用“链式设值”方式，增强用户使用的灵活性
 * <p>外部调用request方法发起请求，调用response方法回包
 */
public class Rpc {
    /**
     * RPC底层机制的参数封装
     */
    private final RPCParameter rpcParameter = new RPCParameter();

    /**
     * 为了保证必要的参数被正确传递，隐藏构造方法
     */
    private Rpc() {
        this.initDefaultRpcSource();
    }

    public static Rpc newRequestInstance(Connector connector, long objectId, GeneratedMessageV3.Builder<?> builder) {
        Rpc rpc = new Rpc();
        rpc.rpcParameter.setConnector(connector);
        rpc.rpcParameter.setObjectId(objectId);

        if (Objects.nonNull(builder)) {
            rpc.rpcParameter.setOpcode(Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder));
            rpc.rpcParameter.setData(builder.build().toByteArray());
        }
        return rpc;
    }

    /**
     * 创建Rpc实例
     *
     * @param connector 要通信的网络连接
     */
    public static Rpc newInstance(Connector connector) {
        Rpc rpc = new Rpc();
        rpc.rpcParameter.setConnector(connector);

        return rpc;
    }

    public long request() {
        return RPCContext.getInstance().request(this.rpcParameter);
    }

    /**
     * 发起RPC请求
     */
    public long request(GeneratedMessageV3.Builder<?> builder) {
        this.rpcParameter.setOpcode(Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder));
        this.rpcParameter.setData(builder.build().toByteArray());
        return RPCContext.getInstance().request(this.rpcParameter);
    }

    /**
     * 发送RPC回包
     *
     * @param requestPacket
     */
    public void response(TcpPacket requestPacket, GeneratedMessageV3.Builder<?> builder) {
        // 对于rpc回包，由于不需要根据opcode进行消息派发，强制设置opcode为0，防止业务层误设置
        this.rpcParameter.setOpcode(0);
        this.rpcParameter.setData(builder.build().toByteArray());
        // 设置objectID为原参数用于消息路由
        this.rpcParameter.setObjectId(requestPacket.getObjectId() == null ? 0 : requestPacket.getObjectId().getId());
        RPCContext.getInstance().response(requestPacket, this.rpcParameter);
    }

    public long getRequestId() {
        return this.rpcParameter.getRequestId();
    }

    /**
     * 设置objectID用于消息路由，可选参数
     */
    public Rpc setObjectId(long objectId) {
        this.rpcParameter.setObjectId(objectId);
        return this;
    }

    /**
     * 设置回调，可选参数
     *
     * @param callBack
     * @return
     */
    public Rpc setCallBack(IRPCCallBack callBack) {
        this.rpcParameter.setCallBack(callBack);
        return this;
    }

    /**
     * 设置超时时长，可选参数
     *
     * @param timeOutMillis
     * @return
     */
    public Rpc setTimeOutMillis(int timeOutMillis) {
        this.rpcParameter.setTimeOutMillis(TimeUtil.getTimeInMillis() + timeOutMillis);
        return this;
    }

    /**
     * 设置请求协议体
     *
     * @param builder
     * @return
     */
    public Rpc setMessage(GeneratedMessageV3.Builder<?> builder) {
        this.rpcParameter.setOpcode(Jengine.getAppContext().get(MsgIdRegisterService.class).getMsgIdForMsg(builder));
        this.rpcParameter.setData(builder.build().toByteArray());

        return this;
    }

    /**
     * 设置业务路由的类型
     * 路由类型: 一种是基于服务器ID的路由，一种是基于路由表的路由策略
     * routerType取值为1-100的路由类型为基于服务器ID的路由
     * routerType取值为大于100为位基于路由表的路由策略
     *
     * @param routerType
     * @return
     */
    public Rpc setRouterType(int routerType) {
        this.rpcParameter.setRouterType(routerType);
        return this;
    }

    /**
     * 设置业务路由的ID
     *
     * @param routerId
     * @return
     */
    public Rpc setRouterId(long routerId) {
        this.rpcParameter.setRouterId(routerId);
        return this;
    }

    /**
     * 设置编码后的RPC源服务器信息
     *
     * @param encodedRpcSource
     * @return
     */
    public Rpc setEncodedRpcSource(int encodedRpcSource) {
        this.rpcParameter.setEncodedsourceRouter(encodedRpcSource);
        return this;
    }

    /**
     * 根据服务器配置，获取RPC源服务器默认的信息
     *
     * @return
     */
    public Rpc initDefaultRpcSource() {
//        int rpcSourceType = Integer.parseInt(Jengine.getConfiguration().getString("server.type"));
//        int rpcSourceId = Integer.parseInt(Jengine.getConfiguration().getString("server.id"));
//        this.rpcParameter.setEncodedsourceRouter(RPCContext.encodeRpcSource(rpcSourceType, rpcSourceId));
        return this;
    }

    public RPCParameter getRpcParameter() {
        return this.rpcParameter;
    }

}
