package com.jengine.io;

import com.jengine.Jengine;
import com.jengine.logger.Log;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages key material for {@link ClientSession}s and so set the right session ids and
 * {@link ClientSession}s.
 *
 * @author mengyan
 */
public class SessionManager {
    private static final Logger log = Log.getNetworkLogger();

    private static SessionManager instance = new SessionManager();

    public static SessionManager getInstance() {
        return instance;
    }

    private SessionManager() {
    }

    /**
     * Cache all active sessions.
     */
    private Map<String, ClientSession> sessions = new ConcurrentHashMap<>();

    /**
     * Add a new session to cache.
     *
     * @param session
     */
    public synchronized boolean addSession(ClientSession session) {
        // max connections number check.
        if (this.sessions.size() >= Jengine.getConfiguration().getInt("network.connection.maxSize")) {
            return false;
        }
        this.sessions.put(session.getSessionId(), session);

        log.info("new session created: {}, current sessions size: {}", session.getSessionId(), this.sessions.size());
        return true;
    }


    /**
     * Remove a session from cache.
     *
     * @param sessionId
     */
    public void removeSession(String sessionId) {
        this.sessions.remove(sessionId);
        log.info("close session, current sessions size: {}", this.sessions.size());

    }

    /**
     * Remove a session from cache.
     *
     * @param session
     */
    public void removeSession(ClientSession session) {
        if (session != null) {
            this.removeSession(session.getSessionId());
        }
    }

    /**
     * Return a view of sessions in cache.
     *
     * @return
     */
    public Collection<ClientSession> getSessions() {
        return this.sessions.values();
    }

    /**
     * Return sessions number.
     *
     * @return
     */
    public int getSize() {
        return this.sessions.size();
    }
}
