package com.jengine.io.rpc;

import com.jengine.util.EmptyUtil;
import com.jengine.util.TimeUtil;

import java.util.List;
import java.util.Objects;

/**
 * RpcBatch 批零RPC调用包装
 * 底层基于RPC的调用封装，支持批量调用
 */
public class RpcBatch {
    /**
     * 批量RPC底层机制的参数封装
     */
    private final RPCBatchParameter batchParameter = new RPCBatchParameter();

    private RpcBatch() {
        this.setTimeOutMillis(RPCConst.RPC_DEFAULT_TIME_OUT_MILLIS);
    }

    /**
     * 创建批量Rpc实例
     */
    public static RpcBatch newInstance(long objectId) {
        RpcBatch rpcBatch = new RpcBatch();
        rpcBatch.setObjectId(objectId);
        return rpcBatch;
    }

    /**
     * 添加一组rpc
     */
    public RpcBatch addRpcList(List<Rpc> rpcList) {
        if (EmptyUtil.nonEmpty(rpcList)) {
            rpcList.forEach(this::addRpc);
        }
        return this;
    }

    /**
     * 添加一个Rpc
     * 在这个过程中会生成rpc请求的唯一ID，并且填充到原始的rpc参数中
     */
    public RpcBatch addRpc(Rpc rpc) {
        if (Objects.isNull(rpc)) {
            return this;
        }

        RPCParameter rpcParameter = rpc.getRpcParameter();
        if (RPCContext.getInstance().isValidParameter(rpcParameter)) {
            // 生成唯一的requestId
            long requestId = RPCContext.getInstance().generateId();
            rpcParameter.setRequestId(requestId);
            // 批量模式下，每个rpc请求不需要单独的回调
            rpcParameter.setCallBack(null);
        }

        this.batchParameter.addRpc(rpc);
        return this;
    }

    /**
     * 发起RPC请求
     *
     * @return
     */
    public List<Long> request() {
        return RPCContext.getInstance().batchRequest(this.batchParameter);
    }

    /**
     * 设置objectID用于消息路由，可选参数
     */
    public RpcBatch setObjectId(long objectId) {
        this.batchParameter.setObjectId(objectId);
        return this;
    }

    /**
     * 设置批量回调，可选参数
     */
    public RpcBatch setCallBack(IRPCBatchCallBack callBack) {
        this.batchParameter.setCallBack(callBack);
        return this;
    }

    /**
     * @param timeOutMillis 多长时间算作超时：ms
     */
    public RpcBatch setTimeOutMillis(int timeOutMillis) {
        this.batchParameter.setOutTimestamp(TimeUtil.getTimeInMillis() + timeOutMillis);
        return this;
    }
}
