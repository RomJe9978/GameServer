package com.jengine.io;

import com.jengine.object.ObjectId;

public class Packet {
    protected ObjectId objectId;

    public ObjectId getObjectId() {
        return objectId;
    }
}
