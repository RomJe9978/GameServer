package com.jengine.io.http;

import com.jengine.JengineException;
import com.jengine.logger.Log;
import io.netty.handler.codec.http.QueryStringDecoder;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Http message's handler register and dispatcher.
 *
 * @author mengyan
 */
public class HttpHandlerDispatcher {
    private static final Logger log = Log.getNetworkLogger();
    private static final String URI_STARTER = "/";

    private Map<String, HttpHandler> handlers;
    private List<HttpHandler> beforeCallHandlers;
    private List<HttpHandler> errorHandlers;
    private HttpHandler notFoundHandler;

    public HttpHandlerDispatcher() {
        this.handlers = new ConcurrentHashMap<>();
        this.errorHandlers = new ArrayList<>();
        this.beforeCallHandlers = new ArrayList<>();
    }

    public void registerHandler(String uri, HttpHandler handler) {
        if (!uri.startsWith(URI_STARTER)) {
            uri = URI_STARTER + uri;
        }
        log.info("[HttpHandlerDispatcher] registerHandler(uri: {}, handler:{})", uri, handler.getClass().getSimpleName());

        if (this.handlers.containsKey(uri)) {
            log.warn("[HttpHandlerDispatcher] registerHandler failed for duplicated handler(uri: {}, handler:{})", uri, handler.getClass().getSimpleName());
            return;
        }

        this.handlers.put(uri, handler);
    }

    public void registerErrorHandler(HttpHandler handler) {
        this.errorHandlers.add(handler);
    }

    public void registerBeforeCallHandler(HttpHandler handler) {
        this.beforeCallHandlers.add(handler);
    }

    public void registerNotFoundHandler(HttpHandler handler) {
        this.notFoundHandler = handler;
    }

    public void clear() {
        this.handlers.clear();
    }

    public boolean handle(HttpExchange httpExchange) {
        try {
            for (HttpHandler handler : this.beforeCallHandlers) {
                handler.handle(httpExchange);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String uri = httpExchange.uri();
        QueryStringDecoder decoder = new QueryStringDecoder(uri);

        HttpHandler handler = this.handlers.get(decoder.path());
        if (handler != null) {
            httpExchange.setHandler(handler);
            try {
                handler.handle(httpExchange);
            } catch (Exception e) {
                JengineException.catchEx(e);
                return false;
            }
            return true;
        } else {
            log.error("[HttpHandlerDispatcher] uri: {} not registered.", uri);
            if (this.notFoundHandler != null) {
                try {
                    this.notFoundHandler.handle(httpExchange);
                    return true;
                } catch (Exception e) {
                    JengineException.catchEx(e);
                }
            }
            return false;
        }
    }

    public void handleError(HttpExchange httpExchange) {
        for (HttpHandler handler : this.errorHandlers) {
            try {
                handler.handle(httpExchange);
            } catch (Exception e) {
                JengineException.catchEx(e);
            }
        }
    }
}
