package com.jengine.io.tcp;

import com.jengine.io.ClientSession;
import com.jengine.io.SessionBuilder;
import com.jengine.io.SessionManager;
import io.netty.channel.Channel;
import io.netty.util.AttributeKey;

/**
 * Builder of session.
 *
 * @author mengyan
 */
public class TcpSessionBuilder implements SessionBuilder {
    private static TcpSessionBuilder instance = new TcpSessionBuilder();

    public static TcpSessionBuilder getInstance() {
        return instance;
    }

    private static final String SESSION = "SESSION";
    public static final AttributeKey<TcpClientSession> CHANNEL_SESSION = AttributeKey
            .valueOf(SESSION);

    @Override
    public ClientSession build(SessionManager sessionManager, Channel channel) {
        TcpClientSession session = new TcpClientSession(sessionManager, channel);

        // bind session with channel.
        channel.attr(CHANNEL_SESSION).set(session);

        return session;
    }
}
