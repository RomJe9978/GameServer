package com.jengine.io.rpc;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author RomJe
 */
public class RPCBatchParameter {
    /**
     * 本次批量通信的唯一“id”
     */
    private long batchId;

    /**
     * 本次通信设置的超时时间戳：毫秒
     * <p>到该绝对时间戳之后算作”超时“
     * <p>不指定的时候会强制设置默认超时时间
     */
    private long outTimestamp;

    /**
     * 最终消息配发的object id
     */
    private long objectId;

    /**
     * 本次RPC通信的回调
     */
    private IRPCBatchCallBack callBack;

    /**
     * 本次批量请求的所有RPC列表
     * <p>强制保证添加的每一个RPC都是非空的，很有必要
     */
    private final List<Rpc> rpcList = new ArrayList<>();

    public List<Rpc> listRpc() {
        return this.rpcList;
    }

    public RPCBatchParameter addRpc(Rpc rpc) {
        if (Objects.nonNull(rpc)) {
            this.rpcList.add(rpc);
        }
        return this;
    }

    public long getBatchId() {
        return batchId;
    }

    public RPCBatchParameter setBatchId(long batchId) {
        this.batchId = batchId;
        return this;
    }

    public long getOutTimestamp() {
        return outTimestamp;
    }

    public RPCBatchParameter setOutTimestamp(long outTimestamp) {
        this.outTimestamp = outTimestamp;
        return this;
    }

    public long getObjectId() {
        return objectId;
    }

    public RPCBatchParameter setObjectId(long objectId) {
        this.objectId = objectId;
        return this;
    }

    public IRPCBatchCallBack getCallBack() {
        return callBack;
    }

    public RPCBatchParameter setCallBack(IRPCBatchCallBack callBack) {
        this.callBack = callBack;
        return this;
    }
}
