package com.jengine.io.http;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.http.FullHttpRequest;

/**
 * The default implementation of http handler.
 *
 * @author mengyan
 */
public class DefaultHttpPakcetHandler extends ChannelInboundHandlerAdapter {
	private final HttpServerService httpServerService;

	public DefaultHttpPakcetHandler(HttpServerService httpServerService) {
		this.httpServerService = httpServerService;
	}

	@Override
	public void channelReadComplete(ChannelHandlerContext ctx) {
		ctx.flush();
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) {
		if (msg instanceof FullHttpRequest) {
			FullHttpRequest req = (FullHttpRequest) msg;
			HttpExchange httpExchange = new DefaultHttpExchange(ctx, req);
			this.httpServerService.handle(httpExchange);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
		cause.printStackTrace();
		ctx.close();
	}

}
