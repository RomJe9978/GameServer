package com.jengine.io.http;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jengine.JengineException;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.QueryStringDecoder;
import io.netty.handler.codec.http.multipart.Attribute;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
import io.netty.handler.codec.http.multipart.InterfaceHttpData;
import io.netty.util.CharsetUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A simply implementation of Http request parser.
 *
 * @author mengyan
 */
public class HttpPacketParser {
    private FullHttpRequest fullReq;
    private static final String CONTENT_TYPE_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
    private static final String CONTENT_TYPE_JSON = "application/json";

    public HttpPacketParser(FullHttpRequest req) {
        this.fullReq = req;
    }

    public Map<String, String> parse() throws IOException, JengineException {
        HttpMethod method = fullReq.method();
        Map<String, String> parameters = new HashMap<>();

        if (HttpMethod.GET == method) {
            QueryStringDecoder decoder = new QueryStringDecoder(fullReq.uri());
            decoder.parameters().entrySet().forEach(entry -> {
                parameters.put(entry.getKey(), entry.getValue().get(0));
            });

        } else if (HttpMethod.POST == method) {
            if (fullReq.headers().get(HttpHeaderNames.CONTENT_TYPE).contains(CONTENT_TYPE_X_WWW_FORM_URLENCODED)) {
                HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(fullReq);
                decoder.offer(fullReq);

                List<InterfaceHttpData> parmeterList = decoder.getBodyHttpDatas();
                for (InterfaceHttpData parameter : parmeterList) {
                    Attribute data = (Attribute) parameter;
                    parameters.put(data.getName(), data.getValue());
                }
                decoder.destroy();

            } else if (fullReq.headers().get(HttpHeaderNames.CONTENT_TYPE).contains(CONTENT_TYPE_JSON)) {
                ByteBuf jsonBuf = fullReq.content();
                String jsonStr = jsonBuf.toString(CharsetUtil.UTF_8);
                JsonObject jsonObject = JsonParser.parseString(jsonStr).getAsJsonObject();

                Set<Map.Entry<String, JsonElement>> entrySet = jsonObject.entrySet();
                for (Map.Entry<String, JsonElement> entry : entrySet) {
                    String key = entry.getKey();
                    String value = jsonObject.get(key).getAsString();
                    parameters.put(key, value);
                }
            }
        } else {
            throw new JengineException("unsupported HTTP method");
        }

        return parameters;
    }
}