package com.jengine.io.tcp;

import com.jengine.io.ClientSession;
import com.jengine.logger.Log;
import org.slf4j.Logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Dispatches a tcp packet.
 *
 * @author mengyan
 */
public class TcpPacketDispatcher {
    private static final Logger log = Log.getNetworkLogger();

    private static final TcpPacketDispatcher instance = new TcpPacketDispatcher();

    public static TcpPacketDispatcher getInstance() {
        return instance;
    }

    private Map<Integer, Method> handlers;
    private Map<Integer, Object> handlerClassInstances;

    private Map<Integer, SimpleHandler> simpleHandlerMap;

    private TcpPacketDispatcher() {
        this.handlers = new HashMap<>();
        this.handlerClassInstances = new HashMap<>();
        this.simpleHandlerMap = new HashMap<>();
    }

    public void registerHandler(int code, Method handler, Object object) {
        log.info("[TcpPacketDispatcher] registerHandler(code: {}, listener:{})", code, object.getClass().getSimpleName());

        if (this.handlers.containsKey(code)) {
            log.error("[TcpPacketDispatcher] registerHandler failed for duplicated event(code: {}, listener:{})", code, object.getClass().getSimpleName());
            return;
        }

        this.handlers.put(code, handler);
        this.handlerClassInstances.put(code, object);
    }

    public void registerSimpleHandler(int code, SimpleHandler handler) {
        this.simpleHandlerMap.put(code, handler);
    }

    public boolean handle(ClientSession session, TcpPacket packet) throws InvocationTargetException, IllegalAccessException {
        int opcode = packet.getOpcode();
        Method handler = this.handlers.get(opcode);
        if (handler != null) {
            handler.invoke(handlerClassInstances.get(opcode), session, packet);
            return true;
        } else if (simpleHandlerMap.get(opcode) != null) {
            simpleHandlerMap.get(opcode).onPacket(session, packet);
            return true;
        } else if (opcode == 0) {
            // ignore it to avoid log spam. support rpc mode.

            return true;
        } else {
            log.error("[TcpPacketDispatcher] opcode: {} not registered.", opcode);
            return false;
        }
    }
}
