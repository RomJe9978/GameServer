package com.jengine.io.rpc;

import com.jengine.updater.Updatable;
import com.jengine.util.TimeUtil;

/**
 * RPC机制的全局时间轮训器
 *
 * @author RomJe
 */
public class RPCTimeSelector implements Updatable {
    private long lastUpdateTime;

    @Override
    public long getUpdateInterval() {
        return RPCConst.RPC_SELECTOR_INTERVAL_MILLIS;
    }

    @Override
    public long getLastUpdateAt() {
        return this.lastUpdateTime;
    }

    @Override
    public boolean update() {
        this.lastUpdateTime = TimeUtil.getTimeInMillis();
        RPCContext.getInstance().getRpcListener().timeOut();
        RPCContext.getInstance().getRpcBatchListener().timeOut();
        return true;
    }
}
