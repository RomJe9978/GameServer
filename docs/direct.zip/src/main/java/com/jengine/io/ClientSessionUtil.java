package com.jengine.io;

import io.netty.channel.Channel;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Session utility wrapper.
 *
 * @author mengyan
 */
public class ClientSessionUtil {
    private static final AtomicLong idGenerator = new AtomicLong(0);

    /**
     * Generates a new session ID.
     *
     * @return
     */
    public static String getSessionId(Channel channel) {
//        return String.valueOf(idGenerator.incrementAndGet());
        // use netty channel id as session unique id.
        return channel.id().asLongText();
    }
}
