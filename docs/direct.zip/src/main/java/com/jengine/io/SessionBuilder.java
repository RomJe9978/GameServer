package com.jengine.io;

import io.netty.channel.Channel;

/**
 * Creates a client session.
 *
 * @author mengyan
 */
public interface SessionBuilder {
    /**
     * Build a new ClientSession by netty channel.
     *
     * @param channel
     * @return
     */
    ClientSession build(SessionManager sessionManager, Channel channel);
}
