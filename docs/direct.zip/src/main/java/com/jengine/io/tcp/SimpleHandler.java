package com.jengine.io.tcp;

import com.jengine.io.ClientSession;

/**
 * A simple tcp packet handler.
 *
 * @author mengyan
 */
public interface SimpleHandler {
	void onPacket(ClientSession session, TcpPacket packet);
}
