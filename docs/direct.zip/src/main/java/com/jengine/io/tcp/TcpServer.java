package com.jengine.io.tcp;

import com.jengine.Jengine;
import com.jengine.JengineException;
import com.jengine.logger.Log;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import org.slf4j.Logger;

/**
 * A generic tcp server implementation.
 *
 * @author mengyan
 */
public class TcpServer {
    private static final Logger log = Log.getNetworkLogger();
    private int port;
    private int bossGroupThreads;
    private int workerGroupThreads;

    /**
     * Netty components.
     */
    private ChannelInitializer channelInitializer;
    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;
    private ChannelFuture serverChannelFuture;

    public TcpServer(int port) {
        this.port = port;
    }

    public TcpServer(int port, ChannelInitializer channelInitializer) {
        this(port);
        this.channelInitializer = channelInitializer;
    }

    public boolean start() {
        if (this.channelInitializer == null) {
            this.channelInitializer = new DefaultTcpChannelInitializer();
        }

        this.bossGroup = new NioEventLoopGroup(this.bossGroupThreads);
        this.workerGroup = new NioEventLoopGroup(this.workerGroupThreads);

        ServerBootstrap serverBootstrap = new ServerBootstrap();
        serverBootstrap = serverBootstrap.group(bossGroup, workerGroup);
        serverBootstrap.channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, Jengine.getConfiguration().getInt("network.sockopt.SO_BACKLOG"))
                .childOption(ChannelOption.SO_REUSEADDR, Jengine.getConfiguration().getBoolean("network.sockopt.SO_REUSEADDR"))
                .childOption(ChannelOption.SO_RCVBUF, Jengine.getConfiguration().getInt("network.sockopt.SO_RCVBUF"))
                .childOption(ChannelOption.SO_SNDBUF, Jengine.getConfiguration().getInt("network.sockopt.SO_SNDBUF"))
                .childOption(ChannelOption.TCP_NODELAY, Jengine.getConfiguration().getBoolean("network.sockopt.TCP_NODELAY"))
                .childOption(ChannelOption.SO_KEEPALIVE, Jengine.getConfiguration().getBoolean("network.sockopt.SO_KEEPALIVE"))
                .childOption(ChannelOption.ALLOCATOR, new PooledByteBufAllocator(false))
                .handler(new LoggingHandler(LogLevel.INFO))
                .childHandler(channelInitializer);

        try {
            this.serverChannelFuture = serverBootstrap.bind(this.port).sync();
        } catch (InterruptedException e) {
            JengineException.catchEx(e);
            return false;
        }
        this.serverChannelFuture.channel().closeFuture().addListener(ChannelFutureListener.CLOSE);
        log.info("server start at port: {}", this.port);
        return true;
    }

    public boolean stop() {
        if (this.serverChannelFuture != null) {
            this.serverChannelFuture.channel().close().syncUninterruptibly();
        }

        if (this.bossGroup != null) {
            this.bossGroup.shutdownGracefully();
        }
        if (this.workerGroup != null) {
            this.workerGroup.shutdownGracefully();
        }

        log.info("server at port: {} stoped", this.port);
        return true;
    }

    public int getBossGroupThreads() {
        return bossGroupThreads;
    }

    public void setBossGroupThreads(int bossGroupThreads) {
        this.bossGroupThreads = bossGroupThreads;
    }

    public int getWorkerGroupThreads() {
        return workerGroupThreads;
    }

    public void setWorkerGroupThreads(int workerGroupThreads) {
        this.workerGroupThreads = workerGroupThreads;
    }

    public ChannelInitializer getChannelInitializer() {
        return channelInitializer;
    }

    public void setChannelInitializer(ChannelInitializer channelInitializer) {
        this.channelInitializer = channelInitializer;
    }
}
