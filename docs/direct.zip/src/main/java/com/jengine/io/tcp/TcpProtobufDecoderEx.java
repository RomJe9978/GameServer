package com.jengine.io.tcp;

import com.jengine.io.Packet;
import com.jengine.logger.Log;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.CodecException;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;

import java.nio.charset.Charset;

/**
 * Implementation of TCP protobuf decoder.
 *
 * @author mengyan
 */
public class TcpProtobufDecoderEx extends TcpProtobufDecoder {
    private static final Logger log = Log.getNetworkLogger();

    public TcpProtobufDecoderEx() {
        this(CharsetUtil.UTF_8);
    }

    public TcpProtobufDecoderEx(Charset charset) {
        super(charset);
    }

    @Override
    public Packet praseMessage(ByteBuf byteBuf) throws CodecException {
        TcpPacket packet = new TcpPacket();

        // read header
        TcpPacketHeaderEx packetHeader = new TcpPacketHeaderEx();
        packetHeader.setOpcode(byteBuf.readInt());
        packetHeader.setSize(byteBuf.readInt());
        packetHeader.setVersion(byteBuf.readInt());
        packetHeader.setCrc(byteBuf.readInt());
        packetHeader.setOid(byteBuf.readLong());
        packetHeader.setRpcLogicId(byteBuf.readLong());
        packetHeader.setRouterType(byteBuf.readInt());
        packetHeader.setRouterId(byteBuf.readLong());
        packetHeader.setEncodedRpcSource(byteBuf.readInt());
        packet.setHeader(packetHeader);

        // read body
        int byteLength = byteBuf.readableBytes();
        byte[] bytes = new byte[byteLength];
        byteBuf.getBytes(byteBuf.readerIndex(), bytes);
        packet.setData(bytes);

        log.info("\r\n>============|receive packet|=============<\n {}\r\n=======================================", packet.toString());
        return packet;
    }
}
