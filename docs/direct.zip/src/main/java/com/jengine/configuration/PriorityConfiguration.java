package com.jengine.configuration;

import org.apache.commons.configuration2.ConfigurationDecoder;
import org.apache.commons.configuration2.ImmutableConfiguration;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A configuration wrapper for supporting leveled configuration.
 *
 * @author mengyan
 */
public class PriorityConfiguration implements ImmutableConfiguration {
    private ImmutableConfiguration priorProxy;
    private ImmutableConfiguration proxy;

    // temporary value for test env
    private Map<String, Object> tempValues;

    public PriorityConfiguration(ImmutableConfiguration priorProxy, ImmutableConfiguration proxy) {
        this.priorProxy = priorProxy;
        this.proxy = proxy;

        this.tempValues = new ConcurrentHashMap<>();
    }

    @Override
    public boolean isEmpty() {
        return priorProxy.isEmpty();
    }

    @Override
    public int size() {
        return priorProxy.size();
    }

    @Override
    public boolean containsKey(String key) {
        return this.priorProxy.containsKey(key) || this.proxy.containsKey(key);
    }

    @Override
    public Object getProperty(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getProperty(key);
        }

        return this.proxy.getProperty(key);
    }

    @Override
    public Iterator<String> getKeys(String prefix) {
        Iterator<String> result = this.priorProxy.getKeys(prefix);

        if (result == null) {
            return this.proxy.getKeys(prefix);
        } else {
            return result;
        }
    }

    @Override
    public Iterator<String> getKeys() {
        Iterator<String> result = this.priorProxy.getKeys();

        if (result == null) {
            return this.proxy.getKeys();
        } else {
            return result;
        }
    }

    @Override
    public Properties getProperties(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getProperties(key);
        }

        return this.proxy.getProperties(key);
    }

    @Override
    public boolean getBoolean(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBoolean(key);
        }

        return this.proxy.getBoolean(key);
    }

    @Override
    public boolean getBoolean(String key, boolean defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBoolean(key, defaultValue);
        }

        return this.proxy.getBoolean(key, defaultValue);
    }

    @Override
    public Boolean getBoolean(String key, Boolean defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBoolean(key, defaultValue);
        }

        return this.proxy.getBoolean(key, defaultValue);
    }

    @Override
    public byte getByte(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getByte(key);
        }

        return this.proxy.getByte(key);
    }

    @Override
    public byte getByte(String key, byte defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getByte(key, defaultValue);
        }

        return this.proxy.getByte(key, defaultValue);
    }

    @Override
    public Byte getByte(String key, Byte defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getByte(key, defaultValue);
        }

        return this.proxy.getByte(key, defaultValue);
    }

    @Override
    public double getDouble(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getDouble(key);
        }

        return this.proxy.getDouble(key);
    }

    @Override
    public double getDouble(String key, double defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getDouble(key, defaultValue);
        }

        return this.proxy.getDouble(key, defaultValue);
    }

    @Override
    public Double getDouble(String key, Double defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getDouble(key, defaultValue);
        }

        return this.proxy.getDouble(key, defaultValue);
    }

    @Override
    public float getFloat(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getFloat(key);
        }

        return this.proxy.getFloat(key);
    }

    @Override
    public float getFloat(String key, float defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getFloat(key, defaultValue);
        }

        return this.proxy.getFloat(key, defaultValue);
    }

    @Override
    public Float getFloat(String key, Float defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getFloat(key, defaultValue);
        }

        return this.proxy.getFloat(key, defaultValue);
    }

    @Override
    public int getInt(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getInt(key);
        }

        return this.proxy.getInt(key);
    }

    @Override
    public int getInt(String key, int defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getInt(key, defaultValue);
        }

        return this.proxy.getInt(key, defaultValue);
    }

    @Override
    public Integer getInteger(String key, Integer defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getInt(key, defaultValue);
        }

        return this.proxy.getInt(key, defaultValue);
    }

    @Override
    public long getLong(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getLong(key);
        }

        return this.proxy.getLong(key);
    }

    @Override
    public long getLong(String key, long defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getLong(key, defaultValue);
        }

        return this.proxy.getLong(key, defaultValue);
    }

    @Override
    public Long getLong(String key, Long defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getLong(key, defaultValue);
        }

        return this.proxy.getLong(key, defaultValue);
    }

    @Override
    public short getShort(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getShort(key);
        }

        return this.proxy.getShort(key);
    }

    @Override
    public short getShort(String key, short defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getShort(key, defaultValue);
        }

        return this.proxy.getShort(key, defaultValue);
    }

    @Override
    public Short getShort(String key, Short defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getShort(key, defaultValue);
        }

        return this.proxy.getShort(key, defaultValue);
    }

    @Override
    public BigDecimal getBigDecimal(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBigDecimal(key);
        }

        return this.proxy.getBigDecimal(key);
    }

    @Override
    public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBigDecimal(key, defaultValue);
        }

        return this.proxy.getBigDecimal(key, defaultValue);
    }

    @Override
    public BigInteger getBigInteger(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBigInteger(key);
        }

        return this.proxy.getBigInteger(key);
    }

    @Override
    public BigInteger getBigInteger(String key, BigInteger defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getBigInteger(key, defaultValue);
        }

        return this.proxy.getBigInteger(key, defaultValue);
    }

    @Override
    public String getString(String key) {
        if (this.tempValues != null && this.tempValues.containsKey(key)) {
            return String.valueOf(this.tempValues.get(key));
        }

        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getString(key);
        }

        return this.proxy.getString(key);
    }

    public void setString(String key, String value) {
        this.tempValues.put(key, value);
    }

    @Override
    public String getString(String key, String defaultValue) {
        if (this.tempValues != null && this.tempValues.containsKey(key)) {
            return String.valueOf(this.tempValues.get(key));
        }

        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getString(key, defaultValue);
        }

        return this.proxy.getString(key, defaultValue);
    }

    public void setDynamicValue(String key, Object value) {
        this.tempValues.put(key, value);
    }

    public String getDynamicStringValue(String key) {
        Object value = this.tempValues.get(key);
        return String.valueOf(value);
    }

    public Integer getDynamicIntValue(String key) {
        return Integer.parseInt(getDynamicStringValue(key));
    }

    public Long getDynamicLongValue(String key) {
        return Long.parseLong(getDynamicStringValue(key));
    }

    public List getDynamicListValue(String key) {
        Object value = this.tempValues.get(key);
        if (value instanceof List) {
            return (List) value;
        }

        return null;
    }

    @Override
    public String getEncodedString(String key, ConfigurationDecoder decoder) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getEncodedString(key, decoder);
        }

        return this.proxy.getEncodedString(key, decoder);
    }

    @Override
    public String getEncodedString(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getEncodedString(key);
        }

        return this.proxy.getEncodedString(key);
    }

    @Override
    public String[] getStringArray(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getStringArray(key);
        }

        return this.proxy.getStringArray(key);
    }

    @Override
    public List<Object> getList(String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getList(key);
        }

        return this.proxy.getList(key);
    }

    @Override
    public List<Object> getList(String key, List<?> defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getList(key, defaultValue);
        }

        return this.proxy.getList(key, defaultValue);
    }

    @Override
    public <T> T get(Class<T> cls, String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.get(cls, key);
        }

        return this.proxy.get(cls, key);
    }

    @Override
    public <T> T get(Class<T> cls, String key, T defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.get(cls, key, defaultValue);
        }

        return this.proxy.get(cls, key, defaultValue);
    }

    @Override
    public Object getArray(Class<?> cls, String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getArray(cls, key);
        }

        return this.proxy.getArray(cls, key);
    }

    @Override
    public Object getArray(Class<?> cls, String key, Object defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getArray(cls, key, defaultValue);
        }

        return this.proxy.getArray(cls, key, defaultValue);
    }

    @Override
    public <T> List<T> getList(Class<T> cls, String key) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getList(cls, key);
        }

        return this.proxy.getList(cls, key);
    }

    @Override
    public <T> List<T> getList(Class<T> cls, String key, List<T> defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getList(cls, key, defaultValue);
        }

        return this.proxy.getList(cls, key, defaultValue);
    }

    @Override
    public <T> Collection<T> getCollection(Class<T> cls, String key, Collection<T> target) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getCollection(cls, key, target);
        }

        return this.proxy.getCollection(cls, key, target);
    }

    @Override
    public <T> Collection<T> getCollection(Class<T> cls, String key, Collection<T> target, Collection<T> defaultValue) {
        if (this.priorProxy.containsKey(key)) {
            return this.priorProxy.getCollection(cls, key, target, defaultValue);
        }

        return this.proxy.getCollection(cls, key, target, defaultValue);
    }

    @Override
    public ImmutableConfiguration immutableSubset(String prefix) {
        ImmutableConfiguration result = this.priorProxy.immutableSubset(prefix);

        if (result == null) {
            return this.proxy.immutableSubset(prefix);
        } else {
            return result;
        }
    }
}
