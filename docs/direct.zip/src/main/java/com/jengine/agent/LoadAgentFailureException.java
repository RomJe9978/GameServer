package com.jengine.agent;

/**
 * When load class agent failure, will throw this exception.
 *
 * @author mengyan
 */
public class LoadAgentFailureException extends Exception {
	public LoadAgentFailureException() {
		super();
	}

	public LoadAgentFailureException(String message) {
		super(message);
	}

	public LoadAgentFailureException(String message, Throwable cause) {
		super(message, cause);
	}

	public LoadAgentFailureException(Throwable cause) {
		super(cause);
	}

	public LoadAgentFailureException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
