package com.jengine.agent;

import com.jengine.logger.Log;
import com.jengine.util.FileUtil;
import com.jengine.util.ProcessUtil;
import com.sun.tools.attach.VirtualMachine;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import org.slf4j.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.net.URL;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

/**
 * Class agent.
 *
 * @author mengyan
 */
public class ClassAgent {
	private static final Logger log = Log.getJengineLogger();
	private static final String JAR_FILE_NAME = "classagent";
	private static final String JAR_FILE_SUFFIX = ".jar";
	private static final int LOAD_AGENT_WAIT_TIME_IN_SEC = 5;
	private static final String FILE_PROTOCOL = "file:";
	private static final String MANIFEST_ATTRIBUTE_AGENT_CLASS = "Agent-Class";
	private static final String MANIFEST_ATTRIBUTE_CAN_RETRANSFORM_CLASS = "Can-Retransform-Classes";
	private static final String MANIFEST_ATTRIBUTE_CAN_REDEFINE_CLASS = "Can-Redefine-Classes";
	private static volatile Instrumentation instrumentation = null;

	public static void agentmain(String agentArgs, Instrumentation inst) {
		if (!inst.isRedefineClassesSupported()) {
			log.error("Current JVM configuration supports redefinition of classes, abort");
			return;
		}

		instrumentation = inst;
	}

	public static void redefineClasses(String filePath, String className)
			throws UnmodifiableClassException, ClassNotFoundException, LoadAgentFailureException, IOException {
		Class clazz = Class.forName(className);

		if (!filePath.endsWith("/")) {
			filePath += "/";
		}

		URL url = new URL(new URL(FILE_PROTOCOL + filePath), clazz.getSimpleName() + ".class");
		InputStream classStream = url.openStream();
		byte[] bytecode = FileUtil.toByteArray(classStream);
		ClassDefinition definition = new ClassDefinition(clazz, bytecode);

		redefineClasses(definition);
	}

	public static boolean redefineClassesOrInterior(String filePath, String className){
		try{
			Class clazz = Class.forName(className);

			if (!filePath.endsWith("/")) {
				filePath += "/";
			}

			String clzName = null;
			if(className.indexOf("$")!=-1){
				clzName = className.substring(className.lastIndexOf(".")+1);
			}else{
				clzName = clazz.getSimpleName();
			}

			URL url = new URL(new URL(FILE_PROTOCOL + filePath), clzName + ".class");
			InputStream classStream = url.openStream();
			byte[] bytecode = FileUtil.toByteArray(classStream);
			ClassDefinition definition = new ClassDefinition(clazz, bytecode);

			redefineClasses(definition);
		}catch (Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static void redefineClasses(ClassDefinition... definitions)
			throws UnmodifiableClassException, ClassNotFoundException, LoadAgentFailureException {
		ensureAgentLoaded();
		instrumentation.redefineClasses(definitions);
	}

	private static void ensureAgentLoaded() throws LoadAgentFailureException {
		if (instrumentation != null) {
			// already loaded
			return;
		}

		// load the agent
		try {
			File agentJar = createAgentJarFile();

			String pid = ProcessUtil.getProcessPID();

			// load the agent
			VirtualMachine vm = VirtualMachine.attach(pid);
			vm.loadAgent(agentJar.getAbsolutePath(), "");
			vm.detach();
		} catch (Exception e) {
			throw new LoadAgentFailureException(e);
		}

		while (waitingLoad()) {
			return;
		}
	}

	private static boolean waitingLoad() throws LoadAgentFailureException {
		for (int sec = 0; sec < LOAD_AGENT_WAIT_TIME_IN_SEC; sec++) {
			if (instrumentation != null) {
				return true;
			}

			try {
				log.info("Sleeping for 1 second while waiting for agent to load.");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new LoadAgentFailureException();
			}
		}

		throw new LoadAgentFailureException();
	}

	private static File createAgentJarFile() throws IOException {
		File jarFile = File.createTempFile(JAR_FILE_NAME, JAR_FILE_SUFFIX);
		jarFile.deleteOnExit();

		try (JarOutputStream jarOutputStream = new JarOutputStream(new FileOutputStream(jarFile), createManifestFile())) {

			JarEntry agent = new JarEntry(ClassAgent.class.getName().replace('.', '/') + ".class");
			jarOutputStream.putNextEntry(agent);

			ClassPool pool = ClassPool.getDefault();
			CtClass ctClass = pool.get(ClassAgent.class.getName());
			jarOutputStream.write(ctClass.toBytecode());
			jarOutputStream.closeEntry();

		} catch (CannotCompileException | NotFoundException e) {
			throw new IOException(e);
		}

		return jarFile;
	}


	/**
	 * each agent must contain a manifest file to descripbe some properties.
	 */
	private static Manifest createManifestFile() {
		Manifest manifest = new Manifest();
		Attributes mainAttributes = manifest.getMainAttributes();
		mainAttributes.put(Attributes.Name.MANIFEST_VERSION, "1.0");
		mainAttributes.put(new Attributes.Name(MANIFEST_ATTRIBUTE_AGENT_CLASS), ClassAgent.class.getName());
		mainAttributes.put(new Attributes.Name(MANIFEST_ATTRIBUTE_CAN_RETRANSFORM_CLASS), "true");
		mainAttributes.put(new Attributes.Name(MANIFEST_ATTRIBUTE_CAN_REDEFINE_CLASS), "true");

		return manifest;
	}
}
