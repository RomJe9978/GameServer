package com.jengine.logger;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import com.jengine.JengineException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.InputStream;

public class Log {
    private static final String LOGFILE_PATH = "logback.xml";

    /**
     * Exception-related logs
     */
    private static final Logger exception = LoggerFactory.getLogger("Exception");

    /**
     * Network-related logs
     */
    private static final Logger network = LoggerFactory.getLogger("Network");

    /**
     * Database-related logs
     */
    private static final Logger database = LoggerFactory.getLogger("Database");

    /**
     * Jengine-related logs
     */
    private static final Logger jengine = LoggerFactory.getLogger("Jengine");

    /**
     * GM-related logs
     */
    private static final Logger gm = LoggerFactory.getLogger("GM");

    /**
     * Logic-related logs
     */
    private static final Logger logic = LoggerFactory.getLogger("Logic");


    public static Logger getExceptionLogger() {
        return exception;
    }

    public static Logger getNetworkLogger() {
        return network;
    }

    public static Logger getDatabaseLogger() {
        return database;
    }

    public static Logger getJengineLogger() {
        return jengine;
    }

    public static Logger getGMLogger() {
        return gm;
    }

    public static Logger getLogic() {
        return logic;
    }

    public static void initLogPath() {
        setLogPath(LOGFILE_PATH);
    }

    public static void setLogPath(String userFilePath) {
        try {
            LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
            loggerContext.reset();
            JoranConfigurator configurator = new JoranConfigurator();
            InputStream configStream = new FileInputStream(userFilePath);
            configurator.setContext(loggerContext);
            configurator.doConfigure(configStream);
            configStream.close();
        } catch (Exception e) {
            JengineException.catchEx(e);
        }
    }
}
