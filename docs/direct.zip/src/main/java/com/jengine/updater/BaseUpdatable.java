package com.jengine.updater;

import com.jengine.util.TimeUtil;

public class BaseUpdatable implements Updatable {
    protected long interval;
    protected long lastUpdateAt;

    public BaseUpdatable() {
    }

    public BaseUpdatable(long intervalInMillis) {
        this.interval = intervalInMillis;
        this.lastUpdateAt = TimeUtil.getTimeInMillis();
    }

    @Override
    public long getUpdateInterval() {
        return this.interval;
    }

    @Override
    public long getLastUpdateAt() {
        return this.lastUpdateAt;
    }

    @Override
    public boolean update() {
        this.lastUpdateAt = TimeUtil.getTimeInMillis();
        return true;
    }
}
