package com.jengine.updater;

/**
 * @author mengyan
 */
public interface Updater {
	void addSyncUpdatable(Updatable updatable);

	void addAsyncUpdatable(Updatable updatable);

	void update();
}
