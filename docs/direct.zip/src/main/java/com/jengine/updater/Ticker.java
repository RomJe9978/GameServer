package com.jengine.updater;

import com.jengine.object.GameObject;

/**
 * A {@Ticker} represents a Periodic event which apply on a game object.
 *
 * @author mengyan
 */
public interface Ticker {
	void onTick(GameObject gameObject);
}
