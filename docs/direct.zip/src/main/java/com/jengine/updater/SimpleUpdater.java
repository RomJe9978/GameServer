package com.jengine.updater;

import com.jengine.JengineException;
import com.jengine.logger.Log;
import com.jengine.object.UpdatableGameObject;
import com.jengine.task.TaskExecutor;
import com.jengine.task.UpdateTask;
import com.jengine.util.TimeUtil;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of {@Updater}.
 *
 * @author mengyan
 */
public class SimpleUpdater implements Updater {
	private static final Logger log = Log.getJengineLogger();

	private List<Updatable> syncUpdatableList;
	private List<Updatable> asyncUpdatableList;

	public SimpleUpdater() {
		this.syncUpdatableList = new ArrayList<>();
		this.asyncUpdatableList = new ArrayList<>();
	}

	@Override
	public void addSyncUpdatable(Updatable updatable) {
		this.syncUpdatableList.add(updatable);
	}

	@Override
	public void addAsyncUpdatable(Updatable updatable) {
		AsyncRunner au = new AsyncRunner(updatable);

		Thread t = new Thread(au, "Updater-Async-" + this.asyncUpdatableList.size());
		t.setPriority(8);
		t.start();

		this.asyncUpdatableList.add(au);
	}

	@Override
	public void update() {
		for (Updatable updatable : this.asyncUpdatableList) {
			try {
				if (TimeUtil.getTimeInMillis() - updatable.getLastUpdateAt() > updatable.getUpdateInterval()) {
					if (updatable instanceof UpdatableGameObject) {
						UpdatableGameObject updatableGameObject = (UpdatableGameObject) updatable;
						TaskExecutor.getInstance().postUpdateTask(UpdateTask.valueOf(updatableGameObject, true));
					} else {
						updatable.update();
					}
				}
			} catch (Exception e) {
				JengineException.catchEx(e);
			}
		}

		for (Updatable updatable : this.syncUpdatableList) {
			try {
				if (TimeUtil.getTimeInMillis() - updatable.getLastUpdateAt() > updatable.getUpdateInterval()) {
					updatable.update();
				}
			} catch (Exception e) {
				JengineException.catchEx(e);
			}
		}
	}

	class AsyncRunner extends BaseUpdatable implements Runnable {
		private Updatable updatable;

		public AsyncRunner(Updatable updatable) {
			this.updatable = updatable;
		}

		@Override
		public boolean update() {
			synchronized (this) {
				super.update();
				notify();
				return true;
			}
		}

		@Override
		public void run() {
			while (true) {
				synchronized (this) {
					try {
						wait();
					} catch (InterruptedException e) {
						JengineException.catchEx(e);
					}
				}

				try {
					this.updatable.update();
				} catch (Exception e) {
					JengineException.catchEx(e);
				}

			}
		}
	}
}
