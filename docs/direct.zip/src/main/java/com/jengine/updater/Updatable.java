package com.jengine.updater;

/**
 * @author mengyan
 */
public interface Updatable {
	/**
	 * return the update interval of this updater.
	 *
	 * @return
	 */
	default long getUpdateInterval() {
		return 0;
	}

	/**
	 * Returns the timestamp last update in milliseconds.
	 * if not set the update time each time, will use the default update frequency to update.
	 *
	 * @return
	 */
	default long getLastUpdateAt() {
		return 0;
	}

	/**
	 * Update logic.
	 *
	 * @return
	 */
	boolean update();
}
