package com.jengine;

/**
 * Object container
 * <p>
 * Each object instance created through AppContext will automatically obtain
 * service initialization, start-up, protocol processing,
 * event monitoring, tick based redirect management and
 * other functions as long as it meets the corresponding specifications.
 *
 * @author mengyan
 */
public interface AppContext {
	<T> T get(Class<T> superClass);

	<X, Y extends X> void create(Class<Y> extendClass, Class<X> superClass) throws Exception;

}
