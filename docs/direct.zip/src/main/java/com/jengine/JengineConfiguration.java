package com.jengine;

public class JengineConfiguration {
    /**
     * The interval in milliseconds of thread monitor log.
     */
    private static long threadMonitorLogIntervalInMs = 10000L;

    /**
     * The interval in milliseconds of thread monitor check.
     */
    private static long threadMonitorCheckIntervalInMs = 1000L;

    /**
     * The max number of thread blocking.
     */
    private static int threadMonitorMaxBlockingSize = 1000;

    /**
     * The default number of map in object accessor
     */
    private static int defaultSizeOfObjectAccessor = 16;

    public static long getThreadMonitorLogIntervalInMs() {
        return threadMonitorLogIntervalInMs;
    }

    public static void setThreadMonitorLogIntervalInMs(long threadMonitorLogIntervalInMs) {
        JengineConfiguration.threadMonitorLogIntervalInMs = threadMonitorLogIntervalInMs;
    }

    public static int getDefaultSizeOfObjectAccessor() {
        return defaultSizeOfObjectAccessor;
    }

    public static void setDefaultSizeOfObjectAccessor(int defaultSizeOfObjectAccessor) {
        JengineConfiguration.defaultSizeOfObjectAccessor = defaultSizeOfObjectAccessor;
    }

    public static long getThreadMonitorCheckIntervalInMs() {
        return threadMonitorCheckIntervalInMs;
    }

    public static void setThreadMonitorCheckIntervalInMs(long threadMonitorCheckIntervalInMs) {
        JengineConfiguration.threadMonitorCheckIntervalInMs = threadMonitorCheckIntervalInMs;
    }

    public static int getThreadMonitorMaxBlockingSize() {
        return threadMonitorMaxBlockingSize;
    }

    public static void setThreadMonitorMaxBlockingSize(int threadMonitorMaxBlockingSize) {
        JengineConfiguration.threadMonitorMaxBlockingSize = threadMonitorMaxBlockingSize;
    }
}
