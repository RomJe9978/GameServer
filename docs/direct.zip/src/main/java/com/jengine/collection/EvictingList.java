package com.jengine.collection;

import java.util.Collection;
import java.util.LinkedList;

/**
 * A non-blocking list which automatically evicts elements from the head of the list when
 * attempting to add new elements onto the list and it is full. This queue orders elements FIFO
 * (first-in-first-out). This data structure is logically equivalent to a circular buffer (i.e.,
 * cyclic buffer or ring buffer).
 *
 * <p>An evicting list must be configured with a maximum size. Each time an element is added to a
 * full queue, the list automatically removes its head element.
 *
 * <p>This class is thread-safe, and does not accept null elements.
 *
 * @author mengyan
 */
public class EvictingList<T> extends LinkedList<T> {
    private static final long serialVersionUID = 1592612616231532364L;
    private int maxSize;

    public EvictingList(int maxSize) {
        super();
        this.maxSize = maxSize;
    }

    @Override
    public synchronized boolean add(T e) {
        if (size() + 1 > maxSize) {
            super.removeFirst();
        }

        return super.add(e);
    }

    @Override
    public synchronized boolean addAll(Collection<? extends T> c) {
        int toRemove = size() + c.size() - maxSize;
        if (toRemove > 0) {
            super.removeRange(0, toRemove);
        }

        return super.addAll(c);
    }
}
