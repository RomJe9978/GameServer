package com.jengine.tracker;

import com.jengine.logger.Log;
import com.jengine.util.StringUtil;
import io.sentry.Sentry;
import io.sentry.SentryClient;
import org.slf4j.Logger;

import java.util.Map;

/**
 * The default {@link ExceptionTracker} implementation.
 *
 * @author mengyan
 */
public class SentryTracker implements ExceptionTracker {
    private static final Logger log = Log.getJengineLogger();
    private volatile boolean initialized = false;

    /**
     * @param dsn  Data Source Name of the Sentry server.
     * @param tags tags to be added to the current context.
     */
    public SentryTracker(String dsn, Map<String, String> tags) {
        if (StringUtil.isEmpty(dsn) || tags == null) {
            log.error("[SentryTracker] init sentry failed for invalid config, dsn:{}, tags:{}", dsn, tags);
            return;
        }

        SentryClient client = Sentry.init(dsn);
        client.setTags(tags);

        initialized = true;
    }

    /**
     * Sends exception information to sentry system.
     * Will ignore the track operation if `Sentry` not initialized.
     *
     * @param e a Exception
     */
    @Override
    public void track(Exception e) {
        if (initialized) {
            Sentry.capture(e);
        }
    }
}
