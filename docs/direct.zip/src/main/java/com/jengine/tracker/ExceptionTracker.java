package com.jengine.tracker;

/**
 * A {@ExceptionTracker} tracks the exception information.
 */
public interface ExceptionTracker {
	/**
	 * Tracks a exception and send exception details to special receiver.
	 *
	 * @param e a Exception
	 */
	void track(Exception e);
}
