package com.jengine.lang;

/**
 * Prioritized can be implemented by objects that should be sorted.
 *
 * @author mengyan
 */
public interface Prioritized extends Comparable<Prioritized> {
    /**
     * The maximum priority
     */
    int MAX_PRIORITY = Integer.MAX_VALUE;

    /**
     * The minimum priority
     */
    int MIN_PRIORITY = Integer.MIN_VALUE;

    /**
     * The default priority
     */
    int DEFAULT_PRIORITY = 0;


    default int getPriority() {
        return DEFAULT_PRIORITY;
    }

    @Override
    default int compareTo(Prioritized o) {
        return Integer.compare(this.getPriority(), o.getPriority());
    }
}
