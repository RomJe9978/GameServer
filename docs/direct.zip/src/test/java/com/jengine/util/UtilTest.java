package com.jengine.util;

import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import static org.junit.Assert.assertEquals;

public class UtilTest {
    @Test
    public void timeUtil() throws UnsupportedEncodingException {
        assertEquals(TimeUtil.daysBetween(new Date(1590983987000L), new Date(1591243187000L)), -3);
        //        assertEquals("20200601", TimeUtil.getMonthFirstDayFormat(TimeUtil.YYYYMMDD2));
        //        assertEquals("2020-06-01", TimeUtil.getMonthFirstDayFormat(TimeUtil.YYYYMMDD));
        //        assertEquals(20200601, TimeUtil.getMonthFirstDayInt());
        System.out.println("中国人44".length());
        System.out.println("にほんご".getBytes().length);
    }

    @Test
    public void numUtil() {
        assertEquals(2, NumberUtil.ceil(1.2));
        assertEquals(2, NumberUtil.ceil(1.5));
        assertEquals(2, NumberUtil.ceil(2.0));
        assertEquals(1, NumberUtil.floor(1.2));
        assertEquals(1, NumberUtil.floor(1.9));
        assertEquals(2, NumberUtil.floor(2.0));
    }

    @Test
    public void randUtil() {
        Integer[] array = {1, 2, 3};
        for (int i = 0; i < 10; i++) {
            System.out.println(RandUtil.choice(array));
        }
    }
}
