package com.jengine.configuration;

import org.apache.commons.configuration2.YAMLConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;

public class ConfigurationTest {
	@Test
	public void configuration() throws ConfigurationException, FileNotFoundException {
		YAMLConfiguration config = new YAMLConfiguration();
		config.read(new FileInputStream("src/test/resources/demo.yaml"));

		System.out.println(config.getInt("network.idle.readerIdleTimeSeconds"));
		Iterator<String> keys = config.getKeys();
		while (keys.hasNext()) {
			String key = keys.next();
			String value = config.getString(key);
			System.out.println(key + " = " + value);
		}
	}
}
