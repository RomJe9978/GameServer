# Jengine
A simple and easy to use game server framework in Java.

Prerequisites
-------------

This sugguest Java 8 or later and Maven is required.

Features
--------

- Threading model
- Event-driven model
- Periodic logic processing model (Updater & Ticker)
- Netty-based network communication
- Annotation-based protocol, event handling mechanism
- Logical modularity
- Game object management
- Data entity persistence
- Exception capture and tracking
- Utility package
- System log predefined
- RPC (to do)
- The cache module
- Hot update
- Script mechanism

Structure
-------------------------

Changes
-------------------------

#### 2021.11
- migrate to submodule